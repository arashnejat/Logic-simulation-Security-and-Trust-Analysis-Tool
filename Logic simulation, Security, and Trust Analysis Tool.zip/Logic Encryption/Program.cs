﻿using System;
using System.Windows.Forms;

namespace LogicEncryption
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //ProbPropTest.Test();
            //return;Application.Run(new FormMain());
            //    try
            //    {
            //            Console.Beep(1000, 2000);
            Application.Run(new FormMain());
            //    }
            //    catch (Exception exception)
            //    {
            //        MessageBox.Show("Error message:\r\n" + exception.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    }
        }
    }
}
