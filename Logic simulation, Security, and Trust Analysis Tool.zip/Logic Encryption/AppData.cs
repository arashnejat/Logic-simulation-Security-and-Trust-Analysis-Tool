﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

//For XMLAppData
using System.Xml.Serialization;

//For BinaryAppData: (And Use [Serializable] before each class declaration
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

// For JsonNetAppData
//using Newtonsoft.Json;

// For JavaScriptJSonAppData
//using System.Web.Script.Serialization;

//public class MemoryAppData
//{
//    public static string GetLocalPath()
//    {
//        var path = Application.StartupPath;
//        if (!path.EndsWith("\\"))
//            path += "\\";
//        return path;
//    }

//    public static bool SaveData<T>(string filePath, T objectToSerialize)
//    {


//        var memStream2 = new MemoryStream();

//        var sw2 = new StreamReader(memStream2);

//        try
//        {
//            var memStream = new MemoryStream();
//            var sw = new StreamWriter(memStream);

//            sw.Write(objectToSerialize);
//            File.WriteAllBytes(filePath,memStream.GetBuffer());

//            //using (var stream = File.Open(filePath, FileMode.Create))
//            //{
//            //    //var bFormatter = new BinaryFormatter();
//            //    //bFormatter.Serialize(stream, objectToSerialize);

//            //}

//            return true;
//        }
//        catch (Exception e)
//        {
//            MessageBox.Show("Error in saving JSon data\n" + e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
//            return false;
//        }
//    }

//    public static bool LoadData<T>(string filePath, out T intendedObject)
//    {
//        try
//        {
//            var memStream = new MemoryStream();

//            var memstream = new MemoryStream(File.ReadAllBytes(filePath));
//            var sR = new StreamReader(memStream);
            
//            //using (var stream = File.Open(filePath, FileMode.Open))
//            //{
//            //    var bFormatter = new BinaryFormatter();
//            //    intendedObject = (T)bFormatter.Deserialize(stream);
//            //}

//            return true;
//        }
//        catch (Exception e)
//        {
//            intendedObject = default(T);
//            return false;
//        }
//    }
//}

//=========================================================================================

//public class BinaryAppData
//{
//    public static string GetLocalPath()
//    {
//        var path = Application.StartupPath;
//        if (!path.EndsWith("\\"))
//            path += "\\";
//        return path;
//    }

//    public static bool SaveData<T>(string filePath, T objectToSerialize)
//    {
//        try
//        {
//            using (var stream = File.Open(filePath, FileMode.Create))
//            {
//                var bFormatter = new BinaryFormatter();
//                bFormatter.Serialize(stream, objectToSerialize);
//            }

//            return true;
//        }
//        catch (Exception e)
//        {
//            MessageBox.Show("Error in saving JSon data\n" + e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
//            return false;
//        }
//    }

//    public static bool LoadData<T>(string filePath, out T intendedObject)
//    {
//        try
//        {
//            using (var stream = File.Open(filePath, FileMode.Open))
//            {
//                var bFormatter = new BinaryFormatter();
//                intendedObject = (T)bFormatter.Deserialize(stream);
//            }

//            return true;
//        }
//        catch (Exception e)
//        {
//            intendedObject = default(T);
//            return false;
//        }
//    }
//}

//=========================================================================================

//Till 8.32GB Tested Succesfully tested (5000000 Records)
//public class JsonNetAppData
//{
//    public static string GetLocalPath()
//    {
//        var path = Application.StartupPath;
//        if (!path.EndsWith("\\"))
//            path += "\\";
//        return path;
//    }

//    public static bool SaveData(string filePath, object intendedObject)
//    {
//        try
//        {
//            try { File.Delete(filePath); } catch (Exception) { }

//            using (var fs = File.Open(filePath, FileMode.CreateNew))
//            using (var sw = new StreamWriter(fs))
//            using (var jw = new JsonTextWriter(sw))
//            {
//                jw.Formatting = Formatting.Indented;
//                var serializer = new JsonSerializer();
//                serializer.Serialize(jw, intendedObject);
//            }
//            return true;
//        }
//        catch (Exception e)
//        {
//            MessageBox.Show("Error in saving JSon data\n" + e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
//            return false;
//        }
//    }

//    public static bool LoadData<T>(string filePath, out T intendedObject)
//    {
//        try
//        {
//            using (var fs = File.Open(filePath, FileMode.Open))
//            using (var sw = new StreamReader(fs))
//            using (var jw = new JsonTextReader(sw))
//            {
//                var serializer = new JsonSerializer();
//                intendedObject = (T)serializer.Deserialize(jw, typeof(T));
//            }

//            if (intendedObject == null)
//                throw new Exception();

//            return intendedObject != null;
//        }
//        catch (Exception e2)
//        {
//            intendedObject = default(T);
//            return false;
//        }
//    }
//}

//=========================================================================================

public class XMLAppData
{
    public static string GetLocalPath()
    {
        var path = Application.StartupPath;
        if (!path.EndsWith("\\"))
            path += "\\";
        return path;
    }

    public static bool SaveData<T>(string filePath, T intendedObject)
    {
        try
        {
            try { File.Delete(filePath); } catch (Exception) { }

            using (var stream = File.Create(filePath))
            {
                var ser = new XmlSerializer(typeof(T));
                ser.Serialize(stream, intendedObject); // your instance
            }
            return true;
        }
        catch (Exception e)
        {
            MessageBox.Show("Error in saving XML data.\n" + e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            return false;
        }
    }

    public static bool LoadData<T>(string filePath, out T intendedObject)
    {
        try
        {
            using (var stream = File.OpenRead(filePath))
            {
                var ser = new XmlSerializer(typeof(T));
                intendedObject = (T)ser.Deserialize(stream);
            }

            if (intendedObject == null)
                throw new Exception();

            return intendedObject != null;
        }
        catch (Exception exception)
        {
            intendedObject = default(T);
            return false;
        }
    }
}

//=========================================================================================
//public class JavaScriptJSonAppData
//{
//    public static string GetLocalPath()
//    {
//        var path = Application.StartupPath;
//        if (!path.EndsWith("\\"))
//            path += "\\";
//        return path;
//    }

//    public static bool SaveData(string filePath, object intendedObject)
//    {
//        try
//        {
//            try { File.Delete(filePath); }
//            catch (Exception) { }


//            using (TextWriter writer = File.CreateText(filePath))
//            {
//                var ser = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
//                writer.Write(ser.Serialize(intendedObject));
//            }
//            return true;
//        }
//        catch (Exception e)
//        {
//            MessageBox.Show("Error in saving JavaScriptJSon data.\n" + e.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
//            return false;
//        }
//    }
//    public static bool LoadData<T>(string filePath, out T intendedObject)
//    {
//        try
//        {
//            var ser = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
//            var readString = SamimiIO.ReadAllText(filePath);
//            intendedObject = ser.Deserialize<T>(readString);

//            if (intendedObject == null)
//                throw new Exception();

//            return intendedObject != null;
//        }
//        catch (Exception e2)
//        {
//            intendedObject = default(T);
//            return false;
//        }
//    }
//}