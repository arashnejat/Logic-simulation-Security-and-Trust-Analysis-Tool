﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace LogicEncryption
{
    public partial class FormMain : Form
    {
        private string _inputFileName;
        private string _netlistName;
        private string _outputFileName;
        private bool _needToSaveInput;
        private bool _needToSaveOutput;
        private string _title;
        private TextBox _lastFocusedTextBox = null;
        private List<Net> _nets; //متغیر عمومی برنامه که به لیست نت های مدار اشاره می کند

        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            Icon = Properties.Resources.Icon;
            Text = FormAboutBox.AssemblyTitle;
            _title = FormAboutBox.AssemblyTitle;

            textBoxClockName.Text = Parser.GeneratedClockName;

            //ورودی سید رندم باید یه عدد تصادفی باشه (دیگه تغییرش نده وگرنه کش هات کار نمی کنن!)، وگرنه امکان داره مثلا هیچوقت گیت اینورتر در  مدار اضافه نشه
            textBoxMainInputKey.Text = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(new Random(136602), 1024);
            tabControlCommands.SelectTab(tabPageLogicEncryptions);
            
            //tabControlAlgorithms.SelectTab(tabPageFARajendran);

            textBoxResultsDirectory.Text = ResultsDirectory;
            textBoxCacheDirectory.Text = CacheManager.CacheDirectory;
        }

        /// <summary>
        /// با استفاده از متن نت لیست موجود در تکست باکس اینپوت، اقدام به پارس متن آن کرده
        /// و لیستی از نت ها که تشکیل دهنده مدار هستند را در متغیر
        /// _nets
        ///  قرار می دهد  
        /// </summary>
        private void ParseInputAgain()
        {
            List<Net> outputNets;
            _nets = Parser.CreateNets(input: textBoxInput.Text, generateFanouts: checkBoxGenerateFanouts.Checked, outputNets: out outputNets);
        }

        //===========================================================================
        //===========================================================================
        //===========================================================================
        //===========================================================================
        //===========================================================================
        //===========================================================================

        #region User Interface Evets & Functions
        private void testSCOAPIntegrityWithInternalSamplesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TestSCOAPProgram();
        }

        private void checkBoxRandomSeed_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDownFaultImpactsRandomSeed.Enabled = !checkBoxFaultImpactsRandomSeed.Checked;
        }

        private void helpToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ShowHelpForm();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowAboutForm();
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            FormClosingMethod(e);
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            New();
        }

        private void toolStripButtonParseInputAndCalculateSCOAPParameters_Click(object sender, EventArgs e)
        {
            ParseInputAndCalculateSCOAPParameters();
        }

        private void toolStripButtonNew_Click(object sender, EventArgs e)
        {
            New();
        }

        private void toolStripButtonExit_Click(object sender, EventArgs e)
        {
            Exit();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exit();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        private void saveOutputToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveOutput();
        }

        private void toolStripButtonOpen_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        private void toolStripButtonSaveOutput_Click(object sender, EventArgs e)
        {
            SaveOutput();
        }

        private void toolStripButtonSaveInputAs_Click(object sender, EventArgs e)
        {
            if(SaveInputAs())
                OpenFile(saveFileDialog1.FileName);
        }

        private void parseInputAndCalculateSCOAPParametersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ParseInputAndCalculateSCOAPParameters();
        }

        private void FormMain_Resize(object sender, EventArgs e)
        {
            FormResized();
        }

        private void saveInputAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (SaveInputAs())
                OpenFile(saveFileDialog1.FileName);
        }

        private void textBoxInput_TextChanged(object sender, EventArgs e)
        {
            InputChanged();
        }

        private void buttonLogicSimulation_Click(object sender, EventArgs e)
        {
            LogicSimulate();
        }

        private void checkBoxLogicSimulationRandomSeed_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDownLogicSimulationRandomSeed.Enabled = !checkBoxLogicSimulationRandomSeed.Checked;
        }

        private void buttonAbortLogicSimulation_Click(object sender, EventArgs e)
        {
            LogicSimulation.Abort = true;
        }

        private void buttonFARajendranOriginalEncrypt_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(button: buttonFARajendranOriginalEncrypt, function: Alg01FARajendranEncryptOriginal);
        }

        private void buttonFARajendranAsIPresumeItIsEncrypt_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonFARajendranAsIPresumeItIsEncrypt, Alg02FARajendranEnrcyptAsIPresumeItIs);
        }

        private void buttonAlg04AntiHardwareTrojanEnhancedEncryption_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg04AntiHardwareTrojanEnhancedEncryption, Alg04AntiHardwareTrojanEnhancedEncryption);
        }

        private void buttonAlg13AntiHTOriginal_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg13AntiHTOriginal, Alg13AntiHardwareTrojanOriginalEncryption);
        }

        private void buttonRandomXORXNOREncryption_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonRandomXORXNOREncryption, RandomXORXNOREncrypt);
        }

        private void buttonCalculateHammingDistance_Click(object sender, EventArgs e)
        {
            CalculateHammingDistanceBetweenOriginalCircuitAndEncryptedCircuit();
        }

        private void buttonCheckIntegrity_Click(object sender, EventArgs e)
        {
            CheckIntegrityOfEncryptedCircuit();
        }

        private string _oldCheckingsKey = "0";
        private void textBoxCheckingsKey_TextChanged(object sender, EventArgs e)
        {
            var newKey = textBoxCheckingsKey.Text;
            foreach (var ch in newKey)
            {
                if (ch != '0' && ch != '1')
                {
                    textBoxCheckingsKey.Text = _oldCheckingsKey;
                    return;
                }
            }

            _oldCheckingsKey = textBoxCheckingsKey.Text;
            labelCheckingsKeyLength.Text = "Key Length: " + newKey.Length;

            textBoxFaultImpacts2Key.Text = textBoxCheckingsKey.Text;
        }

        private void textBoxHTGeneratedKey_TextChanged(object sender, EventArgs e)
        {
            labelHTGeneratedKeyLength.Text = "Key Length: " + textBoxHTGeneratedKey.Text.Length;
        }

        private void textBoxResultsDirectory_TextChanged(object sender, EventArgs e)
        {
            ResultsDirectory = textBoxResultsDirectory.Text;
        }

        private void checkBoxHTMeetThreshold_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDownHTThreshold.Enabled = checkBoxHTMeetThreshold.Checked;
        }

        private string _oldMainImpactsKey = "0";
        private void textBoxMainInputKey_TextChanged(object sender, EventArgs e)
        {
            var newKey = textBoxMainInputKey.Text;
            foreach (var ch in newKey)
            {
                if (ch != '0' && ch != '1')
                {
                    textBoxMainInputKey.Text = _oldMainImpactsKey;
                    return;
                }
            }

            _oldMainImpactsKey = textBoxMainInputKey.Text;
            labelMainKeyInputLength.Text = "Key Length: " + newKey.Length;
        }

        private void textBoxFARajendranGeneratedKey_TextChanged(object sender, EventArgs e)
        {
            labelFARajendranGeneratedKeyLength.Text = "Key Length: " + textBoxFARajendranGeneratedKey.Text.Length;
        }


        private void checkBoxOpenResultsDirectory_CheckedChanged(object sender, EventArgs e)
        {
            SimulationReporter.OpenDirectory = checkBoxOpenResultsDirectory.Checked;
        }


        private void buttonFARajendranAlg10_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonFARajendranAlg10, Alg10FARajendranEnrcypt);
        }

        private void buttonAlg11_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg11, Alg11FARajendranEnrcypt);
        }

        private void textBoxCacheDirectory_TextChanged(object sender, EventArgs e)
        {
            CacheManager.CacheDirectory = textBoxCacheDirectory.Text;
        }

        private void buttonOpenCacheFolder_Click(object sender, EventArgs e)
        {
            Process.Start(CacheManager.CacheDirectory);
        }

        private void buttonOpenResultsFolder_Click(object sender, EventArgs e)
        {
            Process.Start(ResultsDirectory);
        }

        private void timerEncryptor_Tick(object sender, EventArgs e)
        {
            TimerEncryptorTick();
        }

        private void buttonAlg14GreedyXKeys_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg14GreedyXKeys, Alg14GreedyXKeys);
        }

        private void buttonAlg17AntiHardwareTrojanEnhancedEncryption2_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg17AntiHardwareTrojanEnhancedEncryption2, Alg17AntiHardwareTrojanEnhancedEncryption);
        }

        private void tabPageAntiHardwareTrojanEncryption_Click(object sender, EventArgs e)
        {

        }

        private void buttonAlg18AntiHTOriginalNoSlackTIme_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg18AntiHTOriginalNoSlackTIme, Alg18AntiHardwareTrojanOriginalEncryptionNoSlackTime);
        }

        private void buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime, Alg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime);
        }

        private void buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime, Alg20AntiHardwareTrojanEnhancedEncryptionNoSlackTime);
        }

        private void buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync, Alg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync);
        }

        private void buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime, Alg22AntiHardwareTrojanEnhancedEncryptionXORXNORNoSlackTimeSync);
        }

        private void buttonSamimi02Encrypt_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime, Samimi02Encryption);
        }

        private void buttonAlg23_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg23, Alg23);

        }

        private void buttonAlg24_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg24, Alg24);
        }

        private void buttonCalculatePowerUser_Click(object sender, EventArgs e)
        {
            var nets = PowerAreaDelay.LoadNetsFromNetlistString(textBoxInput.Text);
            var input = textBoxInput.Text;
            var keyTitle = "#Key:\t";
            var endLineIndex = input.IndexOf("\r\n");
            var key = textBoxInput.Text.Substring(keyTitle.Length, endLineIndex - keyTitle.Length);

            textBoxOutput.Text = PowerAreaDelay.CalculateOrLoadProbabilities(nets, _netlistName, allowSaveResults: true, key: key) + "\r\n";
            textBoxOutput.Text += PowerAreaDelay.CalculatePowerOfNetlist(nets).ToString();
        }

        private void checkBoxReportProbabilitiesAfterEncryption_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxReportProbabilitiesAfterEncryption.Checked == false)
                checkBoxReportPowerAfterEncryption.Checked = false;
        }

        private void signalPropagationSimulationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControlCommands.SelectTab(tabPageTools);
            tabControlTools.SelectTab(tabPageSignalPropagationSimulation);
        }

        #endregion

        //===========================================================================
        //===========================================================================
        //===========================================================================
        //===========================================================================
        //===========================================================================
        //===========================================================================

        #region FaultImpacts + Partial Class!

        private void buttonCalculateFaultImpactsMultiThread_Click(object sender, EventArgs e)
        {
            CalculateFaultImpacts();
        }

        private void buttonCalculateFaultImpacts2MultiThread_Click(object sender, EventArgs e)
        {
            CalculateFaultImpacts2();
        }

        #endregion

        #region Signal Propagation Simulation + Partial Class!
        private void listBoxSignalPropagationInputNets_KeyUp(object sender, KeyEventArgs e)
        {
            SetValue(e: e, listBox: listBoxSignalPropagationInputNets);
        }

        private void listBoxSignalPropagationOutputNets_KeyUp(object sender, KeyEventArgs e)
        {
            SetValue(e: e, listBox: listBoxSignalPropagationOutputNets);
        }

        private void listBoxSignalPropagationNets_KeyUp(object sender, KeyEventArgs e)
        {
            SetValue(e: e, listBox: listBoxSignalPropagationMiddleNets);
        }

        private void buttonSignalPropagationParseInput_Click(object sender, EventArgs e)
        {
            checkBoxAutoClock.Checked = false;

            ParseInputAgain();
            if (_nets == null || _nets.Count == 0)
                return;

            OutputSignalValues(true);
        }

        private void listBoxSignalPropagationNets_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxSignalPropagationMiddleNets.SelectedIndex < 0)
                return;
            SetValues(listBoxSignalPropagationMiddleNets);
        }

        private void listBoxSignalPropagationInputNets_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxSignalPropagationInputNets.SelectedIndex < 0)
                return;
            SetValues(listBoxSignalPropagationInputNets);
        }

        private void listBoxSignalPropagationOutputNets_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxSignalPropagationOutputNets.SelectedIndex < 0)
                return;
            SetValues(listBoxSignalPropagationOutputNets);
        }

        private void buttonSignalPropagationFillListOfNets_Click(object sender, EventArgs e)
        {
            OutputSignalValues(true);
        }

        private void OutputSignalValues(bool? reset = false)
        {
            checkBoxAvoidLoop.Checked = Net.SValueMethods.AvoidLoop;
            Net.ToStringMode = Net.NetToStringMode.SValueFull;
            if (checkBoxOutputToTextbox.Checked)
            {
                string output = "";
                var selStart = textBoxOutput.SelectionStart;
                foreach (var net in _nets)
                    output += net.Name + " : " + Net.SignalToString(net.SValue) + "\r\n";
                textBoxOutput.Text = output;

                textBoxOutput.SelectionStart = selStart;
                textBoxOutput.ScrollToCaret();
            }

            if (_nets == null || _nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------

            if (reset.HasValue && reset.Value)
            {
                listBoxSignalPropagationMiddleNets.Items.Clear();
                listBoxSignalPropagationInputNets.Items.Clear();
                listBoxSignalPropagationOutputNets.Items.Clear();

                List<Net> inputNets;
                List<Net> middleNets;
                List<Net> outputNets;

                Parser.ClassifyInputMiddleOutputNets(nets: _nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets);
                //var clockNet = CommonMethods.GetMainClockNet(_nets);

                foreach (var net in middleNets)
                    listBoxSignalPropagationMiddleNets.Items.Add(net);

                foreach (var inputNet in inputNets)
                    listBoxSignalPropagationInputNets.Items.Add(inputNet);

                foreach (var outputNet in outputNets)
                    listBoxSignalPropagationOutputNets.Items.Add(outputNet);
            }
            else
            {
                for (var i = 0; i < listBoxSignalPropagationMiddleNets.Items.Count; i++)
                    listBoxSignalPropagationMiddleNets.Items[i] = listBoxSignalPropagationMiddleNets.Items[i];


                for (var i = 0; i < listBoxSignalPropagationInputNets.Items.Count; i++)
                    listBoxSignalPropagationInputNets.Items[i] = listBoxSignalPropagationInputNets.Items[i];


                for (var i = 0; i < listBoxSignalPropagationOutputNets.Items.Count; i++)
                    listBoxSignalPropagationOutputNets.Items[i] = listBoxSignalPropagationOutputNets.Items[i];
            }
        }

        private void checkBoxAvoidLoop_CheckedChanged(object sender, EventArgs e)
        {
            Net.SValueMethods.AvoidLoop = checkBoxAvoidLoop.Checked;
        }

        private void timerClock_Tick(object sender, EventArgs e)
        {
            if (_nets == null || _nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------

            foreach (var net in _nets)
            {
                if (net.Name == textBoxClockName.Text)
                {
                    if (net.SValue == Net.Signal.X)
                        net.SValue = Net.Signal.V1;

                    Net.SValueMethods.Imply(net, GateNot.Function(net.SValue));

                    if (checkBoxAutoOutput.Checked)
                        OutputSignalValues();
                }
            }
        }

        private void checkBoxAutoPropagateForward_CheckedChanged(object sender, EventArgs e)
        {
            Net.SValueMethods.AutoPropagateForward = checkBoxAutoPropagateForward.Checked;
        }

        private void showHideToolboxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowHideToolbox();
        }

        private void checkBoxAutoClock_CheckedChanged(object sender, EventArgs e)
        {
            timerClock.Enabled = checkBoxAutoClock.Checked;
        }

        private void numericUpDownPeriod_ValueChanged(object sender, EventArgs e)
        {
            SetClockPeriod();
        }

        private void numericUpDownPeriod_Click(object sender, EventArgs e)
        {
            SetClockPeriod();
        }

        private void SetClockPeriod()
        {
            int period;
            if (int.TryParse(numericUpDownPeriod.Text, out period))
                timerClock.Interval = period;
            else
                timerClock.Interval = (int)numericUpDownPeriod.Value;
        }

        private void numericUpDownPeriod_KeyDown(object sender, KeyEventArgs e)
        {
            SetClockPeriod();
        }

        private void numericUpDownPeriod_KeyUp(object sender, KeyEventArgs e)
        {
            SetClockPeriod();
        }

        private void toolStripButtonToolbox_Click(object sender, EventArgs e)
        {
            ShowHideToolbox();
        }

        private void SetValue(bool sta0 = false, bool sta1 = false, bool staNormal = false, bool v0 = false, bool v1 = false, bool vx = false, bool vd = false, bool vd_ = false, KeyEventArgs e = null, ListBox listBox = null)
        {
            if (listBox == null)
            {
                if (listBoxSignalPropagationInputNets.ForeColor == Color.Purple)
                    listBox = listBoxSignalPropagationInputNets;

                else if (listBoxSignalPropagationOutputNets.ForeColor == Color.Purple)
                    listBox = listBoxSignalPropagationOutputNets;

                else if (listBoxSignalPropagationMiddleNets.ForeColor == Color.Purple)
                    listBox = listBoxSignalPropagationMiddleNets;
            }

            if (listBox == null || listBox.Items.Count == 0)
                return;

            if (e == null)
            {
                e = new KeyEventArgs(Keys.Z);
            }

            if (staNormal || (e.Alt && (e.KeyCode == Keys.NumPad2 || e.KeyCode == Keys.D2 || e.KeyCode == Keys.NumPad5 || e.KeyCode == Keys.NumPad9 || e.KeyCode == Keys.N)))
            {
                foreach (var selectedItem in listBox.SelectedItems)
                {
                    ((Net)selectedItem).Sta1 = false;
                    ((Net)selectedItem).Sta0 = false;
                    Net.SValueMethods.Imply((Net)selectedItem, ((Net)selectedItem).SValue);
                }
                OutputSignalValues();
            }
            if (sta0 || (e.Alt && (e.KeyCode == Keys.NumPad0 || e.KeyCode == Keys.D0)))
            {
                foreach (var selectedItem in listBox.SelectedItems)
                {
                    ((Net)selectedItem).Sta1 = false;
                    ((Net)selectedItem).Sta0 = true;
                    Net.SValueMethods.Imply((Net)selectedItem, ((Net)selectedItem).SValue);
                }
                OutputSignalValues();
            }
            else if (sta1 || (e.Alt && (e.KeyCode == Keys.NumPad1 || e.KeyCode == Keys.D1)))
            {
                foreach (var selectedItem in listBox.SelectedItems)
                {
                    ((Net)selectedItem).Sta1 = true;
                    ((Net)selectedItem).Sta0 = false;
                    Net.SValueMethods.Imply((Net)selectedItem, ((Net)selectedItem).SValue);
                }
                OutputSignalValues();
            }
            else if (v0 || (e.Control && (e.KeyCode == Keys.NumPad0 || e.KeyCode == Keys.NumPad0 || e.KeyCode == Keys.D0)))
            {
                foreach (var selectedItem in listBox.SelectedItems)
                    Net.SValueMethods.Imply((Net)selectedItem, Net.Signal.V0);
                OutputSignalValues();
            }
            else if (v1 || (e.Control && (e.KeyCode == Keys.NumPad1 || e.KeyCode == Keys.NumPad1 || e.KeyCode == Keys.D1)))
            {
                foreach (var selectedItem in listBox.SelectedItems)
                    Net.SValueMethods.Imply((Net)selectedItem, Net.Signal.V1);
                OutputSignalValues();
            }
            else if (vx || (e.Control && (e.KeyCode == Keys.X)))
            {
                foreach (var selectedItem in listBox.SelectedItems)
                    Net.SValueMethods.Imply((Net)selectedItem, Net.Signal.X);
                OutputSignalValues();
            }
            else if (vd || (e.Control && (e.KeyCode == Keys.D)))
            {
                foreach (var selectedItem in listBox.SelectedItems)
                    Net.SValueMethods.Imply((Net)selectedItem, Net.Signal.D);
                OutputSignalValues();
            }
            else if (vd_ || (e.Control && (e.KeyCode == Keys.E || e.KeyCode == Keys.F)))
            {
                foreach (var selectedItem in listBox.SelectedItems)
                    Net.SValueMethods.Imply((Net)selectedItem, Net.Signal.D_);
                OutputSignalValues();
            }
        }

        private bool _avoidSetValuesLoop;
        private void SetValues(ListBox listBox = null)
        {
            if (_avoidSetValuesLoop)
                return;

            _avoidSetValuesLoop = true;
            if (listBox == null)
            {
                if (listBoxSignalPropagationInputNets.ForeColor == Color.Purple)
                    listBox = listBoxSignalPropagationInputNets;

                else if (listBoxSignalPropagationOutputNets.ForeColor == Color.Purple)
                    listBox = listBoxSignalPropagationOutputNets;

                else if (listBoxSignalPropagationMiddleNets.ForeColor == Color.Purple)
                    listBox = listBoxSignalPropagationMiddleNets;
            }
            if (listBox == null || listBox.Items.Count == 0)
                return;

            var net = ((Net)listBox.SelectedItem);
            if (net.Sta0)
            {
                radioButtonSTA0.Checked = true;
                //radioButtonSTA1.Checked = false;
                //radioButtonNonStuck.Checked = false;
            }
            else if (net.Sta1)
            {
                radioButtonSTA1.Checked = true;
                //radioButtonSTA0.Checked = false;
                //radioButtonNonStuck.Checked = false;
            }
            else
            {
                radioButtonNonStuck.Checked = true;
                //radioButtonSTA0.Checked = false;
                //radioButtonSTA1.Checked = false;
            }
            switch (net.SValue)
            {
                case Net.Signal.D:
                    radioButtonVD.Checked = true;
                    break;
                case Net.Signal.D_:
                    radioButtonVD_.Checked = true;
                    break;
                case Net.Signal.V0:
                    radioButtonV0.Checked = true;
                    break;
                case Net.Signal.V1:
                    radioButtonV1.Checked = true;
                    break;
                case Net.Signal.X:
                    radioButtonVX.Checked = true;
                    break;
            }
            radioButtonSTA0.Checked = ((Net)listBox.SelectedItem).Sta0;
            radioButtonSTA1.Checked = ((Net)listBox.SelectedItem).Sta1;
            radioButtonNonStuck.Checked = !((Net)listBox.SelectedItem).Sta0 && !((Net)listBox.SelectedItem).Sta1;

            _avoidSetValuesLoop = false;
        }

        private void radioButton5SignalValuesMode_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5SignalValuesMode.Checked)
            {
                Net.SValueMethods.SignalMode = Net.SignalValueMode.FiveValues01XDD_;
            }
            else
            {
                Net.SValueMethods.SignalMode = Net.SignalValueMode.ThreeValues01X;
            }
        }

        private void checkBoxAutoGenerateStuckAtValues_CheckedChanged(object sender, EventArgs e)
        {
            Net.SValueMethods.AutoGenerateStuckAtValues = checkBoxAutoGenerateStuckAtValues.Checked;
        }

        private void listBoxSignalPropagationInputNets_Enter(object sender, EventArgs e)
        {
            listBoxSignalPropagationInputNets.ForeColor = Color.Purple;
            listBoxSignalPropagationOutputNets.ForeColor = Color.Black;
            listBoxSignalPropagationMiddleNets.ForeColor = Color.Black;
        }

        private void listBoxSignalPropagationOutputNets_Enter(object sender, EventArgs e)
        {
            listBoxSignalPropagationInputNets.ForeColor = Color.Black;
            listBoxSignalPropagationOutputNets.ForeColor = Color.Purple;
            listBoxSignalPropagationMiddleNets.ForeColor = Color.Black;
        }

        private void listBoxSignalPropagationMiddleNets_Enter(object sender, EventArgs e)
        {
            listBoxSignalPropagationInputNets.ForeColor = Color.Black;
            listBoxSignalPropagationOutputNets.ForeColor = Color.Black;
            listBoxSignalPropagationMiddleNets.ForeColor = Color.Purple;
        }

        private void buttonSignalPropagationSetNormal_Click(object sender, EventArgs e)
        {
            SetValue(staNormal: true);
            SetValues();
        }

        private void buttonSignalPropagationSetSA0_Click(object sender, EventArgs e)
        {
            SetValue(sta0: true);
            SetValues();
        }

        private void buttonSignalPropagationSetSA1_Click(object sender, EventArgs e)
        {
            SetValue(sta1: true);
            SetValues();
        }

        private void buttonSignalPropagationSet0_Click(object sender, EventArgs e)
        {
            SetValue(v0: true);
            SetValues();
        }

        private void buttonSignalPropagationSet1_Click(object sender, EventArgs e)
        {
            SetValue(v1: true);
            SetValues();
        }

        private void buttonSignalPropagationSetD_Click(object sender, EventArgs e)
        {
            SetValue(vd: true);
            SetValues();
        }

        private void buttonSignalPropagationSetD__Click(object sender, EventArgs e)
        {
            SetValue(vd_: true);
            SetValues();
        }

        private void buttonSignalPropagationSetX_Click(object sender, EventArgs e)
        {
            SetValue(vx: true);
            SetValues();
        }

        #endregion 

        #region Levelization & SlackTime + Partial Class!

        private void buttonLevelizeNets_Click(object sender, EventArgs e)
        {
            LevelizeNetsForSimulationAndSlackTime();
        }

        private void buttonSlackTimes_Click(object sender, EventArgs e)
        {
            CalculateSlackTimes();
        }
        #endregion

        #region Find And  F3 In Inputs And Results

        private void textBoxInput_DoubleClick(object sender, EventArgs e)
        {
            FindInTextBox(textBoxInput.SelectedText, textBoxOutput, autoParse: true, forceReset: true);
        }

        private void textBoxOutput_DoubleClick(object sender, EventArgs e)
        {
            FindInTextBox(textBoxOutput.SelectedText, textBoxInput, autoParse: true, forceReset: true);
        }

        private void textBoxInput_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.A)
            {
                textBoxInput.SelectionStart = 0;
                textBoxInput.SelectionLength = textBoxInput.Text.Length;
            }

            else if (e.KeyCode == Keys.F3 || e.KeyCode == Keys.F && e.Control)
            {
                FindInTextBox(textBoxFindInOutput.Text, textBoxOutput);
            }
        }

        private void textBoxOutput_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.A)
            {
                textBoxOutput.SelectionStart = 0;
                textBoxOutput.SelectionLength = textBoxOutput.Text.Length;
            }

            else if (e.KeyCode == Keys.F3 || e.KeyCode == Keys.F && e.Control)
            {
                FindInTextBox(textBoxFindInInput.Text, textBoxInput);
            }
        }

        private void textBoxGeneratedNetlist_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.A)
            {
                textBoxGeneratedNetlist.SelectionStart = 0;
                textBoxGeneratedNetlist.SelectionLength = textBoxGeneratedNetlist.Text.Length;
            }
        }

        private void findTextInOtherBoxToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (_lastFocusedTextBox == textBoxInput)
            {
                FindInTextBox(textBoxFindInOutput.Text, textBoxOutput);
            }
            else if (_lastFocusedTextBox == textBoxOutput)
            {
                FindInTextBox(textBoxFindInInput.Text, textBoxInput);
            }
        }

        private void textBoxOutput_Enter(object sender, EventArgs e)
        {
            _lastFocusedTextBox = textBoxOutput;
        }

        private void textBoxInput_Enter(object sender, EventArgs e)
        {
            _lastFocusedTextBox = textBoxInput;
        }

        private void buttonFindInOutput_Click(object sender, EventArgs e)
        {
            FindInTextBox(textBoxFindInOutput.Text, textBoxOutput);
        }

        private void buttonFindInInput_Click(object sender, EventArgs e)
        {
            FindInTextBox(textBoxFindInInput.Text, textBoxInput);
        }

        private void textBoxFindInOutput_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.F3 || (e.Control && e.KeyCode == Keys.F))
                FindInTextBox(textBoxFindInOutput.Text, textBoxOutput);
        }

        private void textBoxFindInInput_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.F3 || (e.Control && e.KeyCode == Keys.F))
                FindInTextBox(textBoxFindInInput.Text, textBoxInput);
        }

        #endregion

        #region PowerAreaDelay

        private void buttonCalculatePower_Click(object sender, EventArgs e)
        {
            var nets = PowerAreaDelay.LoadNetsFromNetlistString(textBoxInput.Text);
            textBoxOutput.Text = PowerAreaDelay.CalculateOrLoadProbabilities(nets, _netlistName, allowSaveResults: true) + "\r\n";
            textBoxOutput.Text += PowerAreaDelay.CalculatePowerOfNetlist(nets).ToString();
        }

        private void buttonCalculateArea_Click(object sender, EventArgs e)
        {
            var nets = PowerAreaDelay.LoadNetsFromNetlistString(textBoxInput.Text);
            textBoxOutput.Text = PowerAreaDelay.CalculateAreaOfNetlist(nets: nets, ignoreKeyInverters: checkBoxIgnoreKeyInverters.Checked).ToString();
        }

        private void buttonCalculateDelay_Click(object sender, EventArgs e)
        {
            var nets = PowerAreaDelay.LoadNetsFromNetlistString(textBoxInput.Text);
            textBoxOutput.Text = PowerAreaDelay.CalculateDelayOfNetlist(nets).ToString();
        }

        #endregion

        private void buttonAlg25_Click(object sender, EventArgs e)
        {
            EnqueueEncryptionAlgorithm(buttonAlg25, Alg25SmartGreedyXKeys);
        }

        private void numericUpDownRareThreshold_ValueChanged(object sender, EventArgs e)
        {
            var value = numericUpDownRareThreshold.Value;
            labelRareThreshold.Text = "Rare Threshold: (< "+value.ToString()+" && "+(1-value).ToString()+">)";
        }

        private void buttonTemporary_Click(object sender, EventArgs e)
        {
            textBoxOutput.Text = "";
            foreach (var net in _nets)
            {
                textBoxOutput.Text += net.Name + " " + net.LevelNumberInSCOAP + "\r\n";
            }
        }

        public string uniqueOutputs_DirectoryPathMain;
        public string uniqueOutputs_MainReport;

        private void buttonUniqueOutputs_Click(object sender, EventArgs e)
        {
            string SessionName;
            SessionName = textBoxSessoinName.Text ;
            
            uniqueOutputs_DirectoryPathMain = ResultsDirectory.EndsWith("\\") ? ResultsDirectory : ResultsDirectory + "\\" +
                                    SessionName + " " +
                                    DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss") +
                                     "\\";
            SamimiIO.CreateDirectory(uniqueOutputs_DirectoryPathMain);

            uniqueOutputs_MainReport = "";
            var csvRowHeader = "sep=,\n";
            SimulationReporter.AddToCSVRow(ref csvRowHeader, "Name");
            SimulationReporter.AddToCSVRow(ref csvRowHeader, "Inputs");
            SimulationReporter.AddToCSVRow(ref csvRowHeader, "Unique Outputs");
            uniqueOutputs_MainReport += csvRowHeader + "\n";

            EnqueueEncryptionAlgorithm(buttonUniqueOutputs, GetCountOfUniqueOutputs);
        }

        /// <summary>
        /// تعداد خروجیهای یونیک را بر میگرداند
        /// </summary>
        private void GetCountOfUniqueOutputs()
        {
            if (checkBoxCheckingsRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownCheckingsRandomSeed.Value = random.Next(minValue: 1, maxValue: (int)numericUpDownCheckingsRandomSeed.Maximum);
            }

            var oldText = textBoxOutput.Text;
            if (!string.IsNullOrEmpty(oldText))
                oldText += "\r\n";

            List<Net> outputNetsNormal;
            var normalNets = Parser.CreateNets(input: textBoxInput.Text, generateFanouts: checkBoxGenerateFanouts.Checked, outputNets: out outputNetsNormal);
            if (normalNets.Count == 0)
            {
                return;// "Error - No nets in normal netlist";
            }

            bool detailedReport = checkBoxDetailedInputsOutputReport.Checked;
            int randomPatternsCount = (int)numericUpDownCheckingsRandomPatterns.Value;
            var uniqueRandomPatterns = checkBoxCheckingsUniqueRandomPatterns.Checked;
            var randomSeed = (int)numericUpDownCheckingsRandomSeed.Value;
            List<EncryptionChecker.InputsOutputsVO> inputsOutputs;
            var uniqueOutputsCount = EncryptionChecker.GetUniqueOutputsCount(
                normalNets: normalNets,
                uniqueRandomPatterns: uniqueRandomPatterns,
                randomPatterns: randomPatternsCount,
                randomSeed: randomSeed,
                clockTimes: (int)numericUpDownCheckingsClockTimes.Value,
                inputsOutputs: out inputsOutputs,
                textBox: textBoxOutput,
                detailedReport: detailedReport,
                netlistName: _netlistName);

            if (detailedReport)
            {
                var report = "";
                var csvRowHeader = "sep=,\n";
                csvRowHeader += "\"" + "Input" + "\"" + ',' + "\"" + "Output" + "\"" + ',' + "\"" + "Clock" + "\"" ;
                report += csvRowHeader + "\n";

                //var csvRowData = "";
                long index = 0;
                var currentOutput = textBoxOutput.Text;
                foreach (var item in inputsOutputs)
                {
                    index++;
                    if (index % 10 == 0)
                    {
                        textBoxOutput.Text = currentOutput + "\r\n" + "Generating Detailed Report:\r\n" + index + "/" + inputsOutputs.Count;
                        Application.DoEvents();
                    }
                    report += "\"" + item.Input + "\"" + ',' + "\"" + item.Output + "\"" + ',' + "\"" + item.Clock + "\"" + "\n";
                    //csvRowData += item.Input + ',';
                    //csvRowData += item.Output + ',';
                    //csvRowData += item.Clock + ',';
                    //SimulationReporter.AddToCSVRow(ref csvRowData, item.Input);
                    //SimulationReporter.AddToCSVRow(ref csvRowData, item.Output);
                    //SimulationReporter.AddToCSVRow(ref csvRowData, item.Clock);
                    //report += csvRowData + "\n";
                }

                SamimiIO.WriteAllText(uniqueOutputs_DirectoryPathMain + _netlistName + ".csv", report);
            }

            var csvRow = "";
            SimulationReporter.AddToCSVRow(ref csvRow, _netlistName);
            SimulationReporter.AddToCSVRow(ref csvRow, randomPatternsCount.ToString());
            SimulationReporter.AddToCSVRow(ref csvRow, uniqueOutputsCount);
            uniqueOutputs_MainReport += csvRow + "\n";

            SamimiIO.WriteAllText(uniqueOutputs_DirectoryPathMain + "00 Report-" + textBoxSessoinName.Text  + ".csv", uniqueOutputs_MainReport);
                        
            Output(oldText + _netlistName + ": " + uniqueOutputsCount, true);
            Application.DoEvents();
            if(fileIndex == FileNamesList.Count)
                Process.Start(uniqueOutputs_DirectoryPathMain);
        }
    }
}
