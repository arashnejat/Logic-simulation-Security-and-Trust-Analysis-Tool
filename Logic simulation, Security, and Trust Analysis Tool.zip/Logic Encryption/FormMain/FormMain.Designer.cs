﻿namespace LogicEncryption
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.textBoxInput = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.saveInputAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveOutputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ParseInputAndCalculateSCOAPParametersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testSCOAPIntegrityWithInternalSamplesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showHideToolboxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.signalPropagationSimulationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.encryptionAlgorithmsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.encryptionSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.findToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.findTextInOtherBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.labelInput = new System.Windows.Forms.Label();
            this.labelOutput = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonNew = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonOpen = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonSaveInputAs = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonSaveOutput = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonCalculateSCOAPParameters = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonExit = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonToolbox = new System.Windows.Forms.ToolStripButton();
            this.progressBarMain = new System.Windows.Forms.ProgressBar();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelTestabilityIndex = new System.Windows.Forms.ToolStripStatusLabel();
            this.checkBoxOutputTestabilityIndexDetails = new System.Windows.Forms.CheckBox();
            this.checkBoxOutputTestabilityIndex = new System.Windows.Forms.CheckBox();
            this.textBoxFindInInput = new System.Windows.Forms.TextBox();
            this.textBoxFindInOutput = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.buttonFindInOutput = new System.Windows.Forms.Button();
            this.buttonFindInInput = new System.Windows.Forms.Button();
            this.numericUpDownFaultImpactsRandomPatterns = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownFaultImpactsClockTimes = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownFaultImpactsNumberOfThreads = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownFaultImpactsRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownLogicSimulationRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownLogicSimulationRandomPatterns = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownLogicSimulationThreshold = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownLogicSimulationClockTicks = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownCheckingsRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownCheckingsRandomPatterns = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownCheckingsClockTimes = new System.Windows.Forms.NumericUpDown();
            this.listBoxSignalPropagationMiddleNets = new System.Windows.Forms.ListBox();
            this.listBoxSignalPropagationInputNets = new System.Windows.Forms.ListBox();
            this.listBoxSignalPropagationOutputNets = new System.Windows.Forms.ListBox();
            this.radioButtonSTA0 = new System.Windows.Forms.RadioButton();
            this.radioButtonNonStuck = new System.Windows.Forms.RadioButton();
            this.radioButtonSTA1 = new System.Windows.Forms.RadioButton();
            this.buttonSignalPropagationSetSA0 = new System.Windows.Forms.Button();
            this.buttonSignalPropagationSetNormal = new System.Windows.Forms.Button();
            this.buttonSignalPropagationSetSA1 = new System.Windows.Forms.Button();
            this.radioButtonVD = new System.Windows.Forms.RadioButton();
            this.radioButtonVD_ = new System.Windows.Forms.RadioButton();
            this.radioButtonV1 = new System.Windows.Forms.RadioButton();
            this.radioButtonVX = new System.Windows.Forms.RadioButton();
            this.radioButtonV0 = new System.Windows.Forms.RadioButton();
            this.buttonSignalPropagationSet0 = new System.Windows.Forms.Button();
            this.buttonSignalPropagationSet1 = new System.Windows.Forms.Button();
            this.buttonSignalPropagationSetD = new System.Windows.Forms.Button();
            this.buttonSignalPropagationSetD_ = new System.Windows.Forms.Button();
            this.buttonSignalPropagationSetX = new System.Windows.Forms.Button();
            this.numericUpDownPeriod = new System.Windows.Forms.NumericUpDown();
            this.textBoxClockName = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tabControlOutput = new System.Windows.Forms.TabControl();
            this.tabPageOutputLog = new System.Windows.Forms.TabPage();
            this.textBoxOutput = new System.Windows.Forms.TextBox();
            this.tabPageLargeOutput = new System.Windows.Forms.TabPage();
            this.richTextBoxOutput = new System.Windows.Forms.RichTextBox();
            this.tabPageGeneratedNetlist = new System.Windows.Forms.TabPage();
            this.textBoxGeneratedNetlist = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxGenerateFanouts = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.panelToolBox = new System.Windows.Forms.Panel();
            this.tabControlCommands = new System.Windows.Forms.TabControl();
            this.tabPageLogicEncryptions = new System.Windows.Forms.TabPage();
            this.tabControlEncryptions = new System.Windows.Forms.TabControl();
            this.tabPageEncryptionAlgorithms = new System.Windows.Forms.TabPage();
            this.tabControlAlgorithms = new System.Windows.Forms.TabControl();
            this.tabPageRandomXORXNOR = new System.Windows.Forms.TabPage();
            this.label13 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.numericUpDownRandomXORXNORRRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption = new System.Windows.Forms.CheckBox();
            this.label58 = new System.Windows.Forms.Label();
            this.textBoxRandomXORXNORDirectoryComment = new System.Windows.Forms.TextBox();
            this.checkBoxRandomXORXNORDontUseCache = new System.Windows.Forms.CheckBox();
            this.label59 = new System.Windows.Forms.Label();
            this.textBoxRandomXORXNORInlineComment = new System.Windows.Forms.TextBox();
            this.labelRandomXORXNORGeneratedKeyLength = new System.Windows.Forms.Label();
            this.textBoxRandomXORXNORGeneratedKey = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.numericUpDownRandomXORXNORKeyLength = new System.Windows.Forms.NumericUpDown();
            this.checkBoxRandomXORXNORRandomSeed = new System.Windows.Forms.CheckBox();
            this.numericUpDownRandomXORXNORRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.buttonRandomXORXNOREncryption = new System.Windows.Forms.Button();
            this.tabPageAntiHardwareTrojanEncryption = new System.Windows.Forms.TabPage();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime = new System.Windows.Forms.Button();
            this.buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync = new System.Windows.Forms.Button();
            this.label127 = new System.Windows.Forms.Label();
            this.numericUpDownHTRRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.label126 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime = new System.Windows.Forms.Button();
            this.buttonAlg18AntiHTOriginalNoSlackTIme = new System.Windows.Forms.Button();
            this.buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime = new System.Windows.Forms.Button();
            this.buttonAlg17AntiHardwareTrojanEnhancedEncryption2 = new System.Windows.Forms.Button();
            this.buttonAlg13AntiHTOriginal = new System.Windows.Forms.Button();
            this.checkBoxHTReportSlackTimesBeforeEncryption = new System.Windows.Forms.CheckBox();
            this.checkBoxHTReportProbabilitiesBeforeEncryption = new System.Windows.Forms.CheckBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBoxHTDirectoryComment = new System.Windows.Forms.TextBox();
            this.checkBoxHTDontUseCache = new System.Windows.Forms.CheckBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBoxHTInlineComment = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.labelHTGeneratedKeyLength = new System.Windows.Forms.Label();
            this.textBoxHTGeneratedKey = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.numericUpDownHTKeyLength = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.numericUpDownHTProbMin = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.numericUpDownHTSlackMin = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.numericUpDownHTClockTicks = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownHTThreshold = new System.Windows.Forms.NumericUpDown();
            this.checkBoxHTMeetThreshold = new System.Windows.Forms.CheckBox();
            this.checkBoxHTRandomSeed = new System.Windows.Forms.CheckBox();
            this.numericUpDownHTRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.numericUpDownHTRandomPatterns = new System.Windows.Forms.NumericUpDown();
            this.buttonAlg04AntiHardwareTrojanEnhancedEncryption = new System.Windows.Forms.Button();
            this.tabPageFARajendran = new System.Windows.Forms.TabPage();
            this.checkBoxFARajendranUseFaultImpacts2 = new System.Windows.Forms.CheckBox();
            this.label102 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.buttonAlg11 = new System.Windows.Forms.Button();
            this.buttonFARajendranAlg10 = new System.Windows.Forms.Button();
            this.label57 = new System.Windows.Forms.Label();
            this.numericUpDownFARajendranRRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.checkBoxFARajendranReportProbabilitiesBeforeEncryption = new System.Windows.Forms.CheckBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.buttonFARajendranAsIPresumeItIsEncrypt = new System.Windows.Forms.Button();
            this.buttonFARajendranOriginalEncrypt = new System.Windows.Forms.Button();
            this.labelFARajendranGeneratedKeyLength = new System.Windows.Forms.Label();
            this.textBoxFARajendranGeneratedKey = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.numericUpDownFARajendranKeyLength = new System.Windows.Forms.NumericUpDown();
            this.label44 = new System.Windows.Forms.Label();
            this.textBoxFARajendranDirectoryComment = new System.Windows.Forms.TextBox();
            this.checkBoxFARajendranDontUseCache = new System.Windows.Forms.CheckBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBoxFARajendranInlineComment = new System.Windows.Forms.TextBox();
            this.checkBoxFARajendranRandomSeed = new System.Windows.Forms.CheckBox();
            this.checkBoxFARajendranUniqueRandomPatterns = new System.Windows.Forms.CheckBox();
            this.numericUpDownFARajendranRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownFARajendranNumberOfThreads = new System.Windows.Forms.NumericUpDown();
            this.label46 = new System.Windows.Forms.Label();
            this.numericUpDownFARajendranClockTimes = new System.Windows.Forms.NumericUpDown();
            this.label47 = new System.Windows.Forms.Label();
            this.numericUpDownFARajendranRandomPatterns = new System.Windows.Forms.NumericUpDown();
            this.label48 = new System.Windows.Forms.Label();
            this.tabPageGreedyXAlgorithm = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonHDLRSmartGreedy = new System.Windows.Forms.RadioButton();
            this.radioButtonSmartGreedy = new System.Windows.Forms.RadioButton();
            this.radioButtonHDPower2SmartGreedy = new System.Windows.Forms.RadioButton();
            this.labelRareThreshold = new System.Windows.Forms.Label();
            this.numericUpDownRareThreshold = new System.Windows.Forms.NumericUpDown();
            this.checkBoxGreedyInverterMode = new System.Windows.Forms.CheckBox();
            this.buttonAlg25 = new System.Windows.Forms.Button();
            this.label103 = new System.Windows.Forms.Label();
            this.numericUpDownAlg14GreedyNumberOfThreads = new System.Windows.Forms.NumericUpDown();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.numericUpDownAlg14GreedyRRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption = new System.Windows.Forms.CheckBox();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.labelAlg14GreedyGeneratedKeyLength = new System.Windows.Forms.Label();
            this.textBoxAlg14GreedyGeneratedKey = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.numericUpDownAlg14GreedyKeyLength = new System.Windows.Forms.NumericUpDown();
            this.label79 = new System.Windows.Forms.Label();
            this.textBoxAlg14GreedyDirectoryComment = new System.Windows.Forms.TextBox();
            this.checkBoxAlg14GreedyDontUseCache = new System.Windows.Forms.CheckBox();
            this.label80 = new System.Windows.Forms.Label();
            this.textBoxAlg14GreedyInlineComment = new System.Windows.Forms.TextBox();
            this.buttonAlg14GreedyXKeys = new System.Windows.Forms.Button();
            this.checkBoxAlg14GreedyHammingDistanceForceWrongInputs = new System.Windows.Forms.CheckBox();
            this.numericUpDownAlg14GreedyClockTimes = new System.Windows.Forms.NumericUpDown();
            this.label73 = new System.Windows.Forms.Label();
            this.checkBoxAlg14GreedyRandomSeed = new System.Windows.Forms.CheckBox();
            this.checkBoxAlg14GreedyUniqueRandomPatterns = new System.Windows.Forms.CheckBox();
            this.numericUpDownAlg14GreedyRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.label74 = new System.Windows.Forms.Label();
            this.numericUpDownAlg14GreedyRandomPatterns = new System.Windows.Forms.NumericUpDown();
            this.tabPageSamimi02Combined = new System.Windows.Forms.TabPage();
            this.label130 = new System.Windows.Forms.Label();
            this.checkBoxAlg24Key = new System.Windows.Forms.CheckBox();
            this.buttonAlg24 = new System.Windows.Forms.Button();
            this.checkBoxAlg23Key = new System.Windows.Forms.CheckBox();
            this.buttonAlg23 = new System.Windows.Forms.Button();
            this.checkBoxCombined2PHTDontUseCache = new System.Windows.Forms.CheckBox();
            this.buttonSamimi02Encrypt = new System.Windows.Forms.Button();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.labelCombined2GeneratedKeyLength = new System.Windows.Forms.Label();
            this.textBoxCombined2GeneratedKey = new System.Windows.Forms.TextBox();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.textBoxCombined2DirectoryComment = new System.Windows.Forms.TextBox();
            this.label111 = new System.Windows.Forms.Label();
            this.textBoxCombined2InlineComment = new System.Windows.Forms.TextBox();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.numericUpDownCombined2KeyLength = new System.Windows.Forms.NumericUpDown();
            this.label115 = new System.Windows.Forms.Label();
            this.numericUpDownCombined2PHTClockTicksHT = new System.Windows.Forms.NumericUpDown();
            this.label116 = new System.Windows.Forms.Label();
            this.numericUpDownCombined2PHTRandomPatternsHT = new System.Windows.Forms.NumericUpDown();
            this.label117 = new System.Windows.Forms.Label();
            this.numericUpDownCombined2PHTRandomSeedHT = new System.Windows.Forms.NumericUpDown();
            this.label118 = new System.Windows.Forms.Label();
            this.checkBoxCombined2PHTReportSlackTimesBeforeEncryption = new System.Windows.Forms.CheckBox();
            this.checkBoxCombined2PHTReportProbabilitiesBeforeEncryption = new System.Windows.Forms.CheckBox();
            this.label119 = new System.Windows.Forms.Label();
            this.numericUpDownCombined2PHTMaxHTKeyLength = new System.Windows.Forms.NumericUpDown();
            this.label120 = new System.Windows.Forms.Label();
            this.numericUpDownCombined2PHTProbMin = new System.Windows.Forms.NumericUpDown();
            this.label121 = new System.Windows.Forms.Label();
            this.numericUpDownCombined2PHTSlackMin = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownCombined2PHTThresholdHT = new System.Windows.Forms.NumericUpDown();
            this.checkBoxCombined2PHTMeetThresholdHT = new System.Windows.Forms.CheckBox();
            this.checkBoxCombined2PHTConsiderSlackTime = new System.Windows.Forms.CheckBox();
            this.numericUpDownCombined2PGNumberOfThreads = new System.Windows.Forms.NumericUpDown();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.numericUpDownCombined2PGKeyRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.checkBoxCombined2PGReportProbabilitiesBeforeEncryption = new System.Windows.Forms.CheckBox();
            this.checkBoxCombined2PGDontUseCache = new System.Windows.Forms.CheckBox();
            this.checkBoxCombined2PGHammingDistanceForceWrongInputs = new System.Windows.Forms.CheckBox();
            this.numericUpDownCombined2PGClockTimes = new System.Windows.Forms.NumericUpDown();
            this.label124 = new System.Windows.Forms.Label();
            this.checkBoxCombined2PGUniqueRandomPatterns = new System.Windows.Forms.CheckBox();
            this.numericUpDownCombined2PGRandomSeed = new System.Windows.Forms.NumericUpDown();
            this.label125 = new System.Windows.Forms.Label();
            this.numericUpDownCombined2PGRandomPatterns = new System.Windows.Forms.NumericUpDown();
            this.tabPageCheckings = new System.Windows.Forms.TabPage();
            this.label36 = new System.Windows.Forms.Label();
            this.textBoxSessoinName = new System.Windows.Forms.TextBox();
            this.buttonUniqueOutputs = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.checkBoxChickingsHammingDistanceForceWrongInputs = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.checkBoxCheckingsUniqueRandomPatterns = new System.Windows.Forms.CheckBox();
            this.checkBoxCheckingsRandomSeed = new System.Windows.Forms.CheckBox();
            this.label56 = new System.Windows.Forms.Label();
            this.buttonCalculateHammingDistance = new System.Windows.Forms.Button();
            this.labelCheckingsKeyLength = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxCheckingsKey = new System.Windows.Forms.TextBox();
            this.buttonCheckIntegrity = new System.Windows.Forms.Button();
            this.tabPageEncryptionSettings = new System.Windows.Forms.TabPage();
            this.checkBoxReportUserPowerAfterEncryption = new System.Windows.Forms.CheckBox();
            this.checkboxGenerateVerilogAfterEncryption = new System.Windows.Forms.CheckBox();
            this.checkBoxReportDelayAfterEncryption = new System.Windows.Forms.CheckBox();
            this.checkBoxReportPowerAfterEncryption = new System.Windows.Forms.CheckBox();
            this.checkBoxReportAreaAfterEncryption = new System.Windows.Forms.CheckBox();
            this.buttonOpenResultsFolder = new System.Windows.Forms.Button();
            this.buttonOpenCacheFolder = new System.Windows.Forms.Button();
            this.textBoxResultsDirectory = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.textBoxCacheDirectory = new System.Windows.Forms.TextBox();
            this.checkBoxOpenResultsDirectory = new System.Windows.Forms.CheckBox();
            this.checkBoxReportSlackTimesAfterEncryption = new System.Windows.Forms.CheckBox();
            this.checkBoxReportIntegrityAfterEncryption = new System.Windows.Forms.CheckBox();
            this.checkBoxReportProbabilitiesAfterEncryption = new System.Windows.Forms.CheckBox();
            this.label28 = new System.Windows.Forms.Label();
            this.checkBoxReportHammingDistanceAfterEncryption = new System.Windows.Forms.CheckBox();
            this.labelMainKeyInputLength = new System.Windows.Forms.Label();
            this.textBoxMainInputKey = new System.Windows.Forms.TextBox();
            this.tabPageTools = new System.Windows.Forms.TabPage();
            this.tabControlTools = new System.Windows.Forms.TabControl();
            this.tabPageSignalPropagationSimulation = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.panelSAs = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.tableLayoutPanelToolboxOptions = new System.Windows.Forms.TableLayoutPanel();
            this.checkBoxOutputToTextbox = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.radioButton3SignalValuesMode = new System.Windows.Forms.RadioButton();
            this.radioButton5SignalValuesMode = new System.Windows.Forms.RadioButton();
            this.checkBoxAutoGenerateStuckAtValues = new System.Windows.Forms.CheckBox();
            this.checkBoxAutoPropagateForward = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.checkBoxAutoClock = new System.Windows.Forms.CheckBox();
            this.checkBoxAvoidLoop = new System.Windows.Forms.CheckBox();
            this.checkBoxAutoOutput = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanelToolboxLoadButtons = new System.Windows.Forms.TableLayoutPanel();
            this.buttonSignalPropagationFillListOfNets = new System.Windows.Forms.Button();
            this.buttonSignalPropagationParseInput = new System.Windows.Forms.Button();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.panelSignals = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.tabPageFaultImpacts = new System.Windows.Forms.TabPage();
            this.buttonCalculateFaultImpacts2MultiThread = new System.Windows.Forms.Button();
            this.label134 = new System.Windows.Forms.Label();
            this.textBoxFaultImpacts2Key = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonCalculateFaultImpactsMultiThread = new System.Windows.Forms.Button();
            this.checkBoxFaultImpactsDontUseCache = new System.Windows.Forms.CheckBox();
            this.checkBoxFaultImpactsRandomSeed = new System.Windows.Forms.CheckBox();
            this.checkBoxFaultImpactsUniqueRandomPatterns = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPageProbabilityComputation = new System.Windows.Forms.TabPage();
            this.buttonTemporary = new System.Windows.Forms.Button();
            this.checkBoxLogicSimulationSortResultsDescending = new System.Windows.Forms.CheckBox();
            this.checkBoxLogicSimulationDontUseCache = new System.Windows.Forms.CheckBox();
            this.buttonAbortLogicSimulation = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.checkBoxLogicSimulationMeetThreshold = new System.Windows.Forms.CheckBox();
            this.checkBoxLogicSimulationRandomSeed = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonLogicSimulation = new System.Windows.Forms.Button();
            this.tabPageLevelizationsAndSlackTimes = new System.Windows.Forms.TabPage();
            this.buttonLevelizeNets = new System.Windows.Forms.Button();
            this.buttonSlackTimes = new System.Windows.Forms.Button();
            this.tabPagePowerAreaDelay = new System.Windows.Forms.TabPage();
            this.checkBoxIgnoreKeyInverters = new System.Windows.Forms.CheckBox();
            this.buttonCalculatePowerUser = new System.Windows.Forms.Button();
            this.buttonCalculateDelay = new System.Windows.Forms.Button();
            this.buttonCalculateArea = new System.Windows.Forms.Button();
            this.buttonCalculatePower = new System.Windows.Forms.Button();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.timerClock = new System.Windows.Forms.Timer(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.timerEncryptor = new System.Windows.Forms.Timer(this.components);
            this.checkBoxDetailedInputsOutputReport = new System.Windows.Forms.CheckBox();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFaultImpactsRandomPatterns)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFaultImpactsClockTimes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFaultImpactsNumberOfThreads)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFaultImpactsRandomSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLogicSimulationRandomSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLogicSimulationRandomPatterns)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLogicSimulationThreshold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLogicSimulationClockTicks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCheckingsRandomSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCheckingsRandomPatterns)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCheckingsClockTimes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPeriod)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabControlOutput.SuspendLayout();
            this.tabPageOutputLog.SuspendLayout();
            this.tabPageLargeOutput.SuspendLayout();
            this.tabPageGeneratedNetlist.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panelToolBox.SuspendLayout();
            this.tabControlCommands.SuspendLayout();
            this.tabPageLogicEncryptions.SuspendLayout();
            this.tabControlEncryptions.SuspendLayout();
            this.tabPageEncryptionAlgorithms.SuspendLayout();
            this.tabControlAlgorithms.SuspendLayout();
            this.tabPageRandomXORXNOR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRandomXORXNORRRandomSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRandomXORXNORKeyLength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRandomXORXNORRandomSeed)).BeginInit();
            this.tabPageAntiHardwareTrojanEncryption.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTRRandomSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTKeyLength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTProbMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTSlackMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTClockTicks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTThreshold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTRandomSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTRandomPatterns)).BeginInit();
            this.tabPageFARajendran.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFARajendranRRandomSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFARajendranKeyLength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFARajendranRandomSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFARajendranNumberOfThreads)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFARajendranClockTimes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFARajendranRandomPatterns)).BeginInit();
            this.tabPageGreedyXAlgorithm.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRareThreshold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlg14GreedyNumberOfThreads)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlg14GreedyRRandomSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlg14GreedyKeyLength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlg14GreedyClockTimes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlg14GreedyRandomSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlg14GreedyRandomPatterns)).BeginInit();
            this.tabPageSamimi02Combined.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2KeyLength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTClockTicksHT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTRandomPatternsHT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTRandomSeedHT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTMaxHTKeyLength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTProbMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTSlackMin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTThresholdHT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PGNumberOfThreads)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PGKeyRandomSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PGClockTimes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PGRandomSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PGRandomPatterns)).BeginInit();
            this.tabPageCheckings.SuspendLayout();
            this.tabPageEncryptionSettings.SuspendLayout();
            this.tabPageTools.SuspendLayout();
            this.tabControlTools.SuspendLayout();
            this.tabPageSignalPropagationSimulation.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panelSAs.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tableLayoutPanelToolboxOptions.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanelToolboxLoadButtons.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.panelSignals.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tabPageFaultImpacts.SuspendLayout();
            this.tabPageProbabilityComputation.SuspendLayout();
            this.tabPageLevelizationsAndSlackTimes.SuspendLayout();
            this.tabPagePowerAreaDelay.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxInput
            // 
            this.textBoxInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxInput.Font = new System.Drawing.Font("Lucida Console", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxInput.HideSelection = false;
            this.textBoxInput.Location = new System.Drawing.Point(3, 17);
            this.textBoxInput.Margin = new System.Windows.Forms.Padding(3, 0, 4, 0);
            this.textBoxInput.MaxLength = 2147483646;
            this.textBoxInput.Multiline = true;
            this.textBoxInput.Name = "textBoxInput";
            this.textBoxInput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxInput.Size = new System.Drawing.Size(200, 520);
            this.textBoxInput.TabIndex = 1;
            this.textBoxInput.TextChanged += new System.EventHandler(this.textBoxInput_TextChanged);
            this.textBoxInput.DoubleClick += new System.EventHandler(this.textBoxInput_DoubleClick);
            this.textBoxInput.Enter += new System.EventHandler(this.textBoxInput_Enter);
            this.textBoxInput.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBoxInput_KeyUp);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.operationToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.findToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1065, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.toolStripMenuItem3,
            this.openToolStripMenuItem,
            this.toolStripMenuItem1,
            this.saveInputAsToolStripMenuItem,
            this.saveOutputToolStripMenuItem,
            this.toolStripMenuItem2,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripMenuItem.Image")));
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.N)));
            this.newToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.newToolStripMenuItem.Text = "&New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(208, 6);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("openToolStripMenuItem.Image")));
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.openToolStripMenuItem.Text = "&Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(208, 6);
            // 
            // saveInputAsToolStripMenuItem
            // 
            this.saveInputAsToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("saveInputAsToolStripMenuItem.Image")));
            this.saveInputAsToolStripMenuItem.Name = "saveInputAsToolStripMenuItem";
            this.saveInputAsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveInputAsToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.saveInputAsToolStripMenuItem.Text = "Save Input As";
            this.saveInputAsToolStripMenuItem.Click += new System.EventHandler(this.saveInputAsToolStripMenuItem_Click);
            // 
            // saveOutputToolStripMenuItem
            // 
            this.saveOutputToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("saveOutputToolStripMenuItem.Image")));
            this.saveOutputToolStripMenuItem.Name = "saveOutputToolStripMenuItem";
            this.saveOutputToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.S)));
            this.saveOutputToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.saveOutputToolStripMenuItem.Text = "&Save Output";
            this.saveOutputToolStripMenuItem.Click += new System.EventHandler(this.saveOutputToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(208, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("exitToolStripMenuItem.Image")));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // operationToolStripMenuItem
            // 
            this.operationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ParseInputAndCalculateSCOAPParametersToolStripMenuItem,
            this.testSCOAPIntegrityWithInternalSamplesToolStripMenuItem});
            this.operationToolStripMenuItem.Name = "operationToolStripMenuItem";
            this.operationToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.operationToolStripMenuItem.Text = "&SCOAP";
            // 
            // ParseInputAndCalculateSCOAPParametersToolStripMenuItem
            // 
            this.ParseInputAndCalculateSCOAPParametersToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ParseInputAndCalculateSCOAPParametersToolStripMenuItem.Image")));
            this.ParseInputAndCalculateSCOAPParametersToolStripMenuItem.Name = "ParseInputAndCalculateSCOAPParametersToolStripMenuItem";
            this.ParseInputAndCalculateSCOAPParametersToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5;
            this.ParseInputAndCalculateSCOAPParametersToolStripMenuItem.Size = new System.Drawing.Size(320, 22);
            this.ParseInputAndCalculateSCOAPParametersToolStripMenuItem.Text = "Parse Input && &Calculate SCOAP Parameters";
            this.ParseInputAndCalculateSCOAPParametersToolStripMenuItem.Click += new System.EventHandler(this.parseInputAndCalculateSCOAPParametersToolStripMenuItem_Click);
            // 
            // testSCOAPIntegrityWithInternalSamplesToolStripMenuItem
            // 
            this.testSCOAPIntegrityWithInternalSamplesToolStripMenuItem.Name = "testSCOAPIntegrityWithInternalSamplesToolStripMenuItem";
            this.testSCOAPIntegrityWithInternalSamplesToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
            this.testSCOAPIntegrityWithInternalSamplesToolStripMenuItem.Size = new System.Drawing.Size(320, 22);
            this.testSCOAPIntegrityWithInternalSamplesToolStripMenuItem.Text = "&Test Internal Samples";
            this.testSCOAPIntegrityWithInternalSamplesToolStripMenuItem.Visible = false;
            this.testSCOAPIntegrityWithInternalSamplesToolStripMenuItem.Click += new System.EventHandler(this.testSCOAPIntegrityWithInternalSamplesToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showHideToolboxToolStripMenuItem,
            this.signalPropagationSimulationToolStripMenuItem,
            this.encryptionAlgorithmsToolStripMenuItem,
            this.encryptionSettingsToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.toolsToolStripMenuItem.Text = "&Tools";
            // 
            // showHideToolboxToolStripMenuItem
            // 
            this.showHideToolboxToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("showHideToolboxToolStripMenuItem.Image")));
            this.showHideToolboxToolStripMenuItem.Name = "showHideToolboxToolStripMenuItem";
            this.showHideToolboxToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F8;
            this.showHideToolboxToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.showHideToolboxToolStripMenuItem.Text = "&Show/Hide Toolbox";
            this.showHideToolboxToolStripMenuItem.Click += new System.EventHandler(this.showHideToolboxToolStripMenuItem_Click);
            // 
            // signalPropagationSimulationToolStripMenuItem
            // 
            this.signalPropagationSimulationToolStripMenuItem.Name = "signalPropagationSimulationToolStripMenuItem";
            this.signalPropagationSimulationToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F6;
            this.signalPropagationSimulationToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.signalPropagationSimulationToolStripMenuItem.Text = "Signal Propagation Simulation";
            this.signalPropagationSimulationToolStripMenuItem.Click += new System.EventHandler(this.signalPropagationSimulationToolStripMenuItem_Click);
            // 
            // encryptionAlgorithmsToolStripMenuItem
            // 
            this.encryptionAlgorithmsToolStripMenuItem.Name = "encryptionAlgorithmsToolStripMenuItem";
            this.encryptionAlgorithmsToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.encryptionAlgorithmsToolStripMenuItem.Text = "Encryption Algorithms";
            // 
            // encryptionSettingsToolStripMenuItem
            // 
            this.encryptionSettingsToolStripMenuItem.Name = "encryptionSettingsToolStripMenuItem";
            this.encryptionSettingsToolStripMenuItem.Size = new System.Drawing.Size(253, 22);
            this.encryptionSettingsToolStripMenuItem.Text = "Encryption Settings";
            // 
            // findToolStripMenuItem
            // 
            this.findToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.findTextInOtherBoxToolStripMenuItem});
            this.findToolStripMenuItem.Name = "findToolStripMenuItem";
            this.findToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.findToolStripMenuItem.Text = "F&ind";
            // 
            // findTextInOtherBoxToolStripMenuItem
            // 
            this.findTextInOtherBoxToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("findTextInOtherBoxToolStripMenuItem.Image")));
            this.findTextInOtherBoxToolStripMenuItem.Name = "findTextInOtherBoxToolStripMenuItem";
            this.findTextInOtherBoxToolStripMenuItem.Size = new System.Drawing.Size(446, 22);
            this.findTextInOtherBoxToolStripMenuItem.Text = "&Find Text In Other Box               Double Click On Word   or  Ctrl+F  or  F3";
            this.findTextInOtherBoxToolStripMenuItem.Click += new System.EventHandler(this.findTextInOtherBoxToolStripMenuItem_Click_1);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem1,
            this.toolStripMenuItem4,
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // helpToolStripMenuItem1
            // 
            this.helpToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("helpToolStripMenuItem1.Image")));
            this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            this.helpToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.helpToolStripMenuItem1.Size = new System.Drawing.Size(223, 22);
            this.helpToolStripMenuItem1.Text = "&Help (Syntax && Example)";
            this.helpToolStripMenuItem1.Click += new System.EventHandler(this.helpToolStripMenuItem1_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(220, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("aboutToolStripMenuItem.Image")));
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.aboutToolStripMenuItem.Text = "&About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Supported files|*.txt;*.bench;*.isc|Text files|*.txt|Benchmark files|*.bench|Isca" +
    "s files|*.isc";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "Supported files|*.txt;*.bench;*.isc|Text files|*.txt|Benchmark files|*.bench|Isca" +
    "s files|*.isc";
            // 
            // labelInput
            // 
            this.labelInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelInput.Location = new System.Drawing.Point(3, 0);
            this.labelInput.Name = "labelInput";
            this.labelInput.Size = new System.Drawing.Size(201, 17);
            this.labelInput.TabIndex = 4;
            this.labelInput.Text = "Input:";
            // 
            // labelOutput
            // 
            this.labelOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelOutput.Location = new System.Drawing.Point(210, 0);
            this.labelOutput.Name = "labelOutput";
            this.labelOutput.Size = new System.Drawing.Size(346, 17);
            this.labelOutput.TabIndex = 5;
            this.labelOutput.Text = "Output:";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonNew,
            this.toolStripSeparator4,
            this.toolStripButtonOpen,
            this.toolStripSeparator2,
            this.toolStripButtonSaveInputAs,
            this.toolStripSeparator3,
            this.toolStripButtonSaveOutput,
            this.toolStripSeparator1,
            this.toolStripButtonCalculateSCOAPParameters,
            this.toolStripButtonExit,
            this.toolStripSeparator6,
            this.toolStripButtonToolbox});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1065, 37);
            this.toolStrip1.TabIndex = 6;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonNew
            // 
            this.toolStripButtonNew.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonNew.Image")));
            this.toolStripButtonNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonNew.Name = "toolStripButtonNew";
            this.toolStripButtonNew.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripButtonNew.Size = new System.Drawing.Size(65, 34);
            this.toolStripButtonNew.Text = "New";
            this.toolStripButtonNew.ToolTipText = "New (Ctrl + N)";
            this.toolStripButtonNew.Click += new System.EventHandler(this.toolStripButtonNew_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 37);
            // 
            // toolStripButtonOpen
            // 
            this.toolStripButtonOpen.Image = global::LogicEncryption.Properties.Resources.OpenFolder;
            this.toolStripButtonOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonOpen.Name = "toolStripButtonOpen";
            this.toolStripButtonOpen.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripButtonOpen.Size = new System.Drawing.Size(70, 34);
            this.toolStripButtonOpen.Text = "Open";
            this.toolStripButtonOpen.ToolTipText = "Open (Ctrl + O)";
            this.toolStripButtonOpen.Click += new System.EventHandler(this.toolStripButtonOpen_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 37);
            // 
            // toolStripButtonSaveInputAs
            // 
            this.toolStripButtonSaveInputAs.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSaveInputAs.Image")));
            this.toolStripButtonSaveInputAs.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSaveInputAs.Name = "toolStripButtonSaveInputAs";
            this.toolStripButtonSaveInputAs.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripButtonSaveInputAs.Size = new System.Drawing.Size(96, 34);
            this.toolStripButtonSaveInputAs.Text = "Save Input";
            this.toolStripButtonSaveInputAs.ToolTipText = "Save Input As (Ctrl + S)";
            this.toolStripButtonSaveInputAs.Click += new System.EventHandler(this.toolStripButtonSaveInputAs_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 37);
            // 
            // toolStripButtonSaveOutput
            // 
            this.toolStripButtonSaveOutput.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSaveOutput.Image")));
            this.toolStripButtonSaveOutput.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSaveOutput.Name = "toolStripButtonSaveOutput";
            this.toolStripButtonSaveOutput.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripButtonSaveOutput.Size = new System.Drawing.Size(106, 34);
            this.toolStripButtonSaveOutput.Text = "Save Output";
            this.toolStripButtonSaveOutput.ToolTipText = "Save Output (Ctrl + Shift + S)";
            this.toolStripButtonSaveOutput.Click += new System.EventHandler(this.toolStripButtonSaveOutput_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
            // 
            // toolStripButtonCalculateSCOAPParameters
            // 
            this.toolStripButtonCalculateSCOAPParameters.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonCalculateSCOAPParameters.Image")));
            this.toolStripButtonCalculateSCOAPParameters.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonCalculateSCOAPParameters.Name = "toolStripButtonCalculateSCOAPParameters";
            this.toolStripButtonCalculateSCOAPParameters.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripButtonCalculateSCOAPParameters.Size = new System.Drawing.Size(79, 34);
            this.toolStripButtonCalculateSCOAPParameters.Text = "SCOAP";
            this.toolStripButtonCalculateSCOAPParameters.ToolTipText = "Calculate SCOAP Parameters (F5)";
            this.toolStripButtonCalculateSCOAPParameters.Visible = false;
            this.toolStripButtonCalculateSCOAPParameters.Click += new System.EventHandler(this.toolStripButtonParseInputAndCalculateSCOAPParameters_Click);
            // 
            // toolStripButtonExit
            // 
            this.toolStripButtonExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButtonExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonExit.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonExit.Image")));
            this.toolStripButtonExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonExit.Name = "toolStripButtonExit";
            this.toolStripButtonExit.Size = new System.Drawing.Size(34, 34);
            this.toolStripButtonExit.Text = "Exit (Ctrl + Q)";
            this.toolStripButtonExit.Click += new System.EventHandler(this.toolStripButtonExit_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 37);
            this.toolStripSeparator6.Visible = false;
            // 
            // toolStripButtonToolbox
            // 
            this.toolStripButtonToolbox.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonToolbox.Image")));
            this.toolStripButtonToolbox.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonToolbox.Name = "toolStripButtonToolbox";
            this.toolStripButtonToolbox.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.toolStripButtonToolbox.Size = new System.Drawing.Size(83, 34);
            this.toolStripButtonToolbox.Text = "Toolbox";
            this.toolStripButtonToolbox.ToolTipText = "Show/Hide Toolbox (F8)";
            this.toolStripButtonToolbox.Click += new System.EventHandler(this.toolStripButtonToolbox_Click);
            // 
            // progressBarMain
            // 
            this.progressBarMain.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBarMain.Location = new System.Drawing.Point(0, 647);
            this.progressBarMain.Name = "progressBarMain";
            this.progressBarMain.Size = new System.Drawing.Size(1065, 23);
            this.progressBarMain.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBarMain.TabIndex = 7;
            this.progressBarMain.Visible = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelTestabilityIndex});
            this.statusStrip1.Location = new System.Drawing.Point(0, 648);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1065, 22);
            this.statusStrip1.TabIndex = 8;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabelTestabilityIndex
            // 
            this.toolStripStatusLabelTestabilityIndex.Name = "toolStripStatusLabelTestabilityIndex";
            this.toolStripStatusLabelTestabilityIndex.Size = new System.Drawing.Size(0, 17);
            // 
            // checkBoxOutputTestabilityIndexDetails
            // 
            this.checkBoxOutputTestabilityIndexDetails.AutoSize = true;
            this.checkBoxOutputTestabilityIndexDetails.Location = new System.Drawing.Point(176, 0);
            this.checkBoxOutputTestabilityIndexDetails.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.checkBoxOutputTestabilityIndexDetails.Name = "checkBoxOutputTestabilityIndexDetails";
            this.checkBoxOutputTestabilityIndexDetails.Size = new System.Drawing.Size(167, 17);
            this.checkBoxOutputTestabilityIndexDetails.TabIndex = 9;
            this.checkBoxOutputTestabilityIndexDetails.Text = "Show Testability Index Details In Output";
            this.checkBoxOutputTestabilityIndexDetails.UseVisualStyleBackColor = true;
            this.checkBoxOutputTestabilityIndexDetails.Visible = false;
            // 
            // checkBoxOutputTestabilityIndex
            // 
            this.checkBoxOutputTestabilityIndex.AutoSize = true;
            this.checkBoxOutputTestabilityIndex.Checked = true;
            this.checkBoxOutputTestabilityIndex.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxOutputTestabilityIndex.Location = new System.Drawing.Point(0, 0);
            this.checkBoxOutputTestabilityIndex.Margin = new System.Windows.Forms.Padding(0, 0, 3, 3);
            this.checkBoxOutputTestabilityIndex.Name = "checkBoxOutputTestabilityIndex";
            this.checkBoxOutputTestabilityIndex.Size = new System.Drawing.Size(170, 17);
            this.checkBoxOutputTestabilityIndex.TabIndex = 8;
            this.checkBoxOutputTestabilityIndex.Text = "Show Testability Index In Output";
            this.checkBoxOutputTestabilityIndex.UseVisualStyleBackColor = true;
            this.checkBoxOutputTestabilityIndex.Visible = false;
            // 
            // textBoxFindInInput
            // 
            this.textBoxFindInInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxFindInInput.Location = new System.Drawing.Point(3, 4);
            this.textBoxFindInInput.Margin = new System.Windows.Forms.Padding(3, 4, 0, 3);
            this.textBoxFindInInput.Name = "textBoxFindInInput";
            this.textBoxFindInInput.Size = new System.Drawing.Size(176, 20);
            this.textBoxFindInInput.TabIndex = 3;
            this.toolTip1.SetToolTip(this.textBoxFindInInput, "Find in input");
            this.textBoxFindInInput.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBoxFindInInput_KeyUp);
            // 
            // textBoxFindInOutput
            // 
            this.textBoxFindInOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxFindInOutput.Location = new System.Drawing.Point(3, 4);
            this.textBoxFindInOutput.Margin = new System.Windows.Forms.Padding(3, 4, 0, 3);
            this.textBoxFindInOutput.Name = "textBoxFindInOutput";
            this.textBoxFindInOutput.Size = new System.Drawing.Size(321, 20);
            this.textBoxFindInOutput.TabIndex = 5;
            this.toolTip1.SetToolTip(this.textBoxFindInOutput, "Find in output");
            this.textBoxFindInOutput.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBoxFindInOutput_KeyUp);
            // 
            // buttonFindInOutput
            // 
            this.buttonFindInOutput.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonFindInOutput.BackgroundImage")));
            this.buttonFindInOutput.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonFindInOutput.Location = new System.Drawing.Point(327, 3);
            this.buttonFindInOutput.Name = "buttonFindInOutput";
            this.buttonFindInOutput.Size = new System.Drawing.Size(22, 21);
            this.buttonFindInOutput.TabIndex = 6;
            this.toolTip1.SetToolTip(this.buttonFindInOutput, "Find in output");
            this.buttonFindInOutput.UseVisualStyleBackColor = true;
            this.buttonFindInOutput.Click += new System.EventHandler(this.buttonFindInOutput_Click);
            // 
            // buttonFindInInput
            // 
            this.buttonFindInInput.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonFindInInput.BackgroundImage")));
            this.buttonFindInInput.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonFindInInput.Location = new System.Drawing.Point(182, 3);
            this.buttonFindInInput.Name = "buttonFindInInput";
            this.buttonFindInInput.Size = new System.Drawing.Size(22, 21);
            this.buttonFindInInput.TabIndex = 4;
            this.toolTip1.SetToolTip(this.buttonFindInInput, "Find in input");
            this.buttonFindInInput.UseVisualStyleBackColor = true;
            this.buttonFindInInput.Click += new System.EventHandler(this.buttonFindInInput_Click);
            // 
            // numericUpDownFaultImpactsRandomPatterns
            // 
            this.numericUpDownFaultImpactsRandomPatterns.Location = new System.Drawing.Point(240, 18);
            this.numericUpDownFaultImpactsRandomPatterns.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownFaultImpactsRandomPatterns.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownFaultImpactsRandomPatterns.Name = "numericUpDownFaultImpactsRandomPatterns";
            this.numericUpDownFaultImpactsRandomPatterns.Size = new System.Drawing.Size(62, 20);
            this.numericUpDownFaultImpactsRandomPatterns.TabIndex = 13;
            this.toolTip1.SetToolTip(this.numericUpDownFaultImpactsRandomPatterns, "Clock Period");
            this.numericUpDownFaultImpactsRandomPatterns.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // numericUpDownFaultImpactsClockTimes
            // 
            this.numericUpDownFaultImpactsClockTimes.Location = new System.Drawing.Point(240, 66);
            this.numericUpDownFaultImpactsClockTimes.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownFaultImpactsClockTimes.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownFaultImpactsClockTimes.Name = "numericUpDownFaultImpactsClockTimes";
            this.numericUpDownFaultImpactsClockTimes.Size = new System.Drawing.Size(62, 20);
            this.numericUpDownFaultImpactsClockTimes.TabIndex = 15;
            this.toolTip1.SetToolTip(this.numericUpDownFaultImpactsClockTimes, "Clock Period");
            this.numericUpDownFaultImpactsClockTimes.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // numericUpDownFaultImpactsNumberOfThreads
            // 
            this.numericUpDownFaultImpactsNumberOfThreads.Location = new System.Drawing.Point(240, 92);
            this.numericUpDownFaultImpactsNumberOfThreads.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownFaultImpactsNumberOfThreads.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownFaultImpactsNumberOfThreads.Name = "numericUpDownFaultImpactsNumberOfThreads";
            this.numericUpDownFaultImpactsNumberOfThreads.Size = new System.Drawing.Size(62, 20);
            this.numericUpDownFaultImpactsNumberOfThreads.TabIndex = 20;
            this.toolTip1.SetToolTip(this.numericUpDownFaultImpactsNumberOfThreads, "Clock Period");
            this.numericUpDownFaultImpactsNumberOfThreads.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // numericUpDownFaultImpactsRandomSeed
            // 
            this.numericUpDownFaultImpactsRandomSeed.Location = new System.Drawing.Point(240, 118);
            this.numericUpDownFaultImpactsRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownFaultImpactsRandomSeed.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownFaultImpactsRandomSeed.Name = "numericUpDownFaultImpactsRandomSeed";
            this.numericUpDownFaultImpactsRandomSeed.Size = new System.Drawing.Size(62, 20);
            this.numericUpDownFaultImpactsRandomSeed.TabIndex = 27;
            this.toolTip1.SetToolTip(this.numericUpDownFaultImpactsRandomSeed, "Clock Period");
            this.numericUpDownFaultImpactsRandomSeed.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDownLogicSimulationRandomSeed
            // 
            this.numericUpDownLogicSimulationRandomSeed.Location = new System.Drawing.Point(279, 39);
            this.numericUpDownLogicSimulationRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownLogicSimulationRandomSeed.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownLogicSimulationRandomSeed.Name = "numericUpDownLogicSimulationRandomSeed";
            this.numericUpDownLogicSimulationRandomSeed.Size = new System.Drawing.Size(74, 20);
            this.numericUpDownLogicSimulationRandomSeed.TabIndex = 45;
            this.toolTip1.SetToolTip(this.numericUpDownLogicSimulationRandomSeed, "Clock Period");
            this.numericUpDownLogicSimulationRandomSeed.Value = new decimal(new int[] {
            309302,
            0,
            0,
            0});
            // 
            // numericUpDownLogicSimulationRandomPatterns
            // 
            this.numericUpDownLogicSimulationRandomPatterns.Location = new System.Drawing.Point(279, 13);
            this.numericUpDownLogicSimulationRandomPatterns.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDownLogicSimulationRandomPatterns.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownLogicSimulationRandomPatterns.Name = "numericUpDownLogicSimulationRandomPatterns";
            this.numericUpDownLogicSimulationRandomPatterns.Size = new System.Drawing.Size(74, 20);
            this.numericUpDownLogicSimulationRandomPatterns.TabIndex = 43;
            this.toolTip1.SetToolTip(this.numericUpDownLogicSimulationRandomPatterns, "Clock Period");
            this.numericUpDownLogicSimulationRandomPatterns.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // numericUpDownLogicSimulationThreshold
            // 
            this.numericUpDownLogicSimulationThreshold.DecimalPlaces = 8;
            this.numericUpDownLogicSimulationThreshold.Increment = new decimal(new int[] {
            1,
            0,
            0,
            393216});
            this.numericUpDownLogicSimulationThreshold.Location = new System.Drawing.Point(279, 65);
            this.numericUpDownLogicSimulationThreshold.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownLogicSimulationThreshold.Name = "numericUpDownLogicSimulationThreshold";
            this.numericUpDownLogicSimulationThreshold.Size = new System.Drawing.Size(74, 20);
            this.numericUpDownLogicSimulationThreshold.TabIndex = 48;
            this.toolTip1.SetToolTip(this.numericUpDownLogicSimulationThreshold, "Clock Period");
            this.numericUpDownLogicSimulationThreshold.Value = new decimal(new int[] {
            2,
            0,
            0,
            327680});
            // 
            // numericUpDownLogicSimulationClockTicks
            // 
            this.numericUpDownLogicSimulationClockTicks.Location = new System.Drawing.Point(279, 91);
            this.numericUpDownLogicSimulationClockTicks.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownLogicSimulationClockTicks.Name = "numericUpDownLogicSimulationClockTicks";
            this.numericUpDownLogicSimulationClockTicks.Size = new System.Drawing.Size(74, 20);
            this.numericUpDownLogicSimulationClockTicks.TabIndex = 49;
            this.toolTip1.SetToolTip(this.numericUpDownLogicSimulationClockTicks, "Clock Period");
            this.numericUpDownLogicSimulationClockTicks.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // numericUpDownCheckingsRandomSeed
            // 
            this.numericUpDownCheckingsRandomSeed.Location = new System.Drawing.Point(221, 68);
            this.numericUpDownCheckingsRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownCheckingsRandomSeed.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCheckingsRandomSeed.Name = "numericUpDownCheckingsRandomSeed";
            this.numericUpDownCheckingsRandomSeed.Size = new System.Drawing.Size(74, 20);
            this.numericUpDownCheckingsRandomSeed.TabIndex = 36;
            this.toolTip1.SetToolTip(this.numericUpDownCheckingsRandomSeed, "Clock Period");
            this.numericUpDownCheckingsRandomSeed.Value = new decimal(new int[] {
            2015,
            0,
            0,
            0});
            // 
            // numericUpDownCheckingsRandomPatterns
            // 
            this.numericUpDownCheckingsRandomPatterns.Location = new System.Drawing.Point(221, 23);
            this.numericUpDownCheckingsRandomPatterns.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.numericUpDownCheckingsRandomPatterns.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCheckingsRandomPatterns.Name = "numericUpDownCheckingsRandomPatterns";
            this.numericUpDownCheckingsRandomPatterns.Size = new System.Drawing.Size(74, 20);
            this.numericUpDownCheckingsRandomPatterns.TabIndex = 32;
            this.toolTip1.SetToolTip(this.numericUpDownCheckingsRandomPatterns, "Clock Period");
            this.numericUpDownCheckingsRandomPatterns.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // numericUpDownCheckingsClockTimes
            // 
            this.numericUpDownCheckingsClockTimes.Location = new System.Drawing.Point(233, 138);
            this.numericUpDownCheckingsClockTimes.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownCheckingsClockTimes.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCheckingsClockTimes.Name = "numericUpDownCheckingsClockTimes";
            this.numericUpDownCheckingsClockTimes.Size = new System.Drawing.Size(62, 20);
            this.numericUpDownCheckingsClockTimes.TabIndex = 42;
            this.toolTip1.SetToolTip(this.numericUpDownCheckingsClockTimes, "Clock Period");
            this.numericUpDownCheckingsClockTimes.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // listBoxSignalPropagationMiddleNets
            // 
            this.listBoxSignalPropagationMiddleNets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxSignalPropagationMiddleNets.FormattingEnabled = true;
            this.listBoxSignalPropagationMiddleNets.Location = new System.Drawing.Point(0, 144);
            this.listBoxSignalPropagationMiddleNets.Margin = new System.Windows.Forms.Padding(0);
            this.listBoxSignalPropagationMiddleNets.Name = "listBoxSignalPropagationMiddleNets";
            this.listBoxSignalPropagationMiddleNets.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBoxSignalPropagationMiddleNets.Size = new System.Drawing.Size(458, 99);
            this.listBoxSignalPropagationMiddleNets.TabIndex = 11;
            this.toolTip1.SetToolTip(this.listBoxSignalPropagationMiddleNets, "Middle Nets");
            this.listBoxSignalPropagationMiddleNets.SelectedIndexChanged += new System.EventHandler(this.listBoxSignalPropagationNets_SelectedIndexChanged);
            this.listBoxSignalPropagationMiddleNets.Enter += new System.EventHandler(this.listBoxSignalPropagationMiddleNets_Enter);
            this.listBoxSignalPropagationMiddleNets.KeyUp += new System.Windows.Forms.KeyEventHandler(this.listBoxSignalPropagationNets_KeyUp);
            // 
            // listBoxSignalPropagationInputNets
            // 
            this.listBoxSignalPropagationInputNets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxSignalPropagationInputNets.FormattingEnabled = true;
            this.listBoxSignalPropagationInputNets.Location = new System.Drawing.Point(0, 0);
            this.listBoxSignalPropagationInputNets.Margin = new System.Windows.Forms.Padding(0);
            this.listBoxSignalPropagationInputNets.Name = "listBoxSignalPropagationInputNets";
            this.listBoxSignalPropagationInputNets.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBoxSignalPropagationInputNets.Size = new System.Drawing.Size(458, 72);
            this.listBoxSignalPropagationInputNets.TabIndex = 13;
            this.toolTip1.SetToolTip(this.listBoxSignalPropagationInputNets, "Primary Inputs");
            this.listBoxSignalPropagationInputNets.SelectedIndexChanged += new System.EventHandler(this.listBoxSignalPropagationInputNets_SelectedIndexChanged);
            this.listBoxSignalPropagationInputNets.Enter += new System.EventHandler(this.listBoxSignalPropagationInputNets_Enter);
            this.listBoxSignalPropagationInputNets.KeyUp += new System.Windows.Forms.KeyEventHandler(this.listBoxSignalPropagationInputNets_KeyUp);
            // 
            // listBoxSignalPropagationOutputNets
            // 
            this.listBoxSignalPropagationOutputNets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxSignalPropagationOutputNets.FormattingEnabled = true;
            this.listBoxSignalPropagationOutputNets.Location = new System.Drawing.Point(0, 72);
            this.listBoxSignalPropagationOutputNets.Margin = new System.Windows.Forms.Padding(0);
            this.listBoxSignalPropagationOutputNets.Name = "listBoxSignalPropagationOutputNets";
            this.listBoxSignalPropagationOutputNets.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBoxSignalPropagationOutputNets.Size = new System.Drawing.Size(458, 72);
            this.listBoxSignalPropagationOutputNets.TabIndex = 14;
            this.toolTip1.SetToolTip(this.listBoxSignalPropagationOutputNets, "Primary Outputs");
            this.listBoxSignalPropagationOutputNets.SelectedIndexChanged += new System.EventHandler(this.listBoxSignalPropagationOutputNets_SelectedIndexChanged);
            this.listBoxSignalPropagationOutputNets.Enter += new System.EventHandler(this.listBoxSignalPropagationOutputNets_Enter);
            this.listBoxSignalPropagationOutputNets.KeyUp += new System.Windows.Forms.KeyEventHandler(this.listBoxSignalPropagationOutputNets_KeyUp);
            // 
            // radioButtonSTA0
            // 
            this.radioButtonSTA0.AutoSize = true;
            this.radioButtonSTA0.Location = new System.Drawing.Point(69, 3);
            this.radioButtonSTA0.Margin = new System.Windows.Forms.Padding(0);
            this.radioButtonSTA0.Name = "radioButtonSTA0";
            this.radioButtonSTA0.Size = new System.Drawing.Size(48, 17);
            this.radioButtonSTA0.TabIndex = 18;
            this.radioButtonSTA0.Text = "SA-0";
            this.toolTip1.SetToolTip(this.radioButtonSTA0, "Ctrl + 0");
            this.radioButtonSTA0.UseVisualStyleBackColor = true;
            // 
            // radioButtonNonStuck
            // 
            this.radioButtonNonStuck.AutoSize = true;
            this.radioButtonNonStuck.Location = new System.Drawing.Point(3, 3);
            this.radioButtonNonStuck.Margin = new System.Windows.Forms.Padding(0);
            this.radioButtonNonStuck.Name = "radioButtonNonStuck";
            this.radioButtonNonStuck.Size = new System.Drawing.Size(58, 17);
            this.radioButtonNonStuck.TabIndex = 17;
            this.radioButtonNonStuck.Text = "Normal";
            this.toolTip1.SetToolTip(this.radioButtonNonStuck, "Ctrl + N");
            this.radioButtonNonStuck.UseVisualStyleBackColor = true;
            // 
            // radioButtonSTA1
            // 
            this.radioButtonSTA1.AutoSize = true;
            this.radioButtonSTA1.Location = new System.Drawing.Point(125, 3);
            this.radioButtonSTA1.Margin = new System.Windows.Forms.Padding(0);
            this.radioButtonSTA1.Name = "radioButtonSTA1";
            this.radioButtonSTA1.Size = new System.Drawing.Size(48, 17);
            this.radioButtonSTA1.TabIndex = 19;
            this.radioButtonSTA1.Text = "SA-1";
            this.toolTip1.SetToolTip(this.radioButtonSTA1, "Ctrl + 0");
            this.radioButtonSTA1.UseVisualStyleBackColor = true;
            // 
            // buttonSignalPropagationSetSA0
            // 
            this.buttonSignalPropagationSetSA0.Location = new System.Drawing.Point(239, 0);
            this.buttonSignalPropagationSetSA0.Name = "buttonSignalPropagationSetSA0";
            this.buttonSignalPropagationSetSA0.Size = new System.Drawing.Size(46, 20);
            this.buttonSignalPropagationSetSA0.TabIndex = 22;
            this.buttonSignalPropagationSetSA0.Text = "SA-0";
            this.toolTip1.SetToolTip(this.buttonSignalPropagationSetSA0, "( Alt + 0 )");
            this.buttonSignalPropagationSetSA0.UseVisualStyleBackColor = true;
            this.buttonSignalPropagationSetSA0.Click += new System.EventHandler(this.buttonSignalPropagationSetSA0_Click);
            // 
            // buttonSignalPropagationSetNormal
            // 
            this.buttonSignalPropagationSetNormal.Location = new System.Drawing.Point(186, 0);
            this.buttonSignalPropagationSetNormal.Name = "buttonSignalPropagationSetNormal";
            this.buttonSignalPropagationSetNormal.Size = new System.Drawing.Size(54, 20);
            this.buttonSignalPropagationSetNormal.TabIndex = 20;
            this.buttonSignalPropagationSetNormal.Text = "Normal";
            this.toolTip1.SetToolTip(this.buttonSignalPropagationSetNormal, "( Alt + 2 ) or ( Alt + 9 ) or ( Alt + 5 ) or ( Alt + N )");
            this.buttonSignalPropagationSetNormal.UseVisualStyleBackColor = true;
            this.buttonSignalPropagationSetNormal.Click += new System.EventHandler(this.buttonSignalPropagationSetNormal_Click);
            // 
            // buttonSignalPropagationSetSA1
            // 
            this.buttonSignalPropagationSetSA1.Location = new System.Drawing.Point(284, 0);
            this.buttonSignalPropagationSetSA1.Name = "buttonSignalPropagationSetSA1";
            this.buttonSignalPropagationSetSA1.Size = new System.Drawing.Size(46, 20);
            this.buttonSignalPropagationSetSA1.TabIndex = 23;
            this.buttonSignalPropagationSetSA1.Text = "SA-1";
            this.toolTip1.SetToolTip(this.buttonSignalPropagationSetSA1, "( Alt + 1 )");
            this.buttonSignalPropagationSetSA1.UseVisualStyleBackColor = true;
            this.buttonSignalPropagationSetSA1.Click += new System.EventHandler(this.buttonSignalPropagationSetSA1_Click);
            // 
            // radioButtonVD
            // 
            this.radioButtonVD.AutoSize = true;
            this.radioButtonVD.Location = new System.Drawing.Point(69, 3);
            this.radioButtonVD.Margin = new System.Windows.Forms.Padding(0);
            this.radioButtonVD.Name = "radioButtonVD";
            this.radioButtonVD.Size = new System.Drawing.Size(33, 17);
            this.radioButtonVD.TabIndex = 14;
            this.radioButtonVD.Text = "D";
            this.toolTip1.SetToolTip(this.radioButtonVD, "Shift + D");
            this.radioButtonVD.UseVisualStyleBackColor = true;
            // 
            // radioButtonVD_
            // 
            this.radioButtonVD_.AutoSize = true;
            this.radioButtonVD_.Location = new System.Drawing.Point(104, 3);
            this.radioButtonVD_.Margin = new System.Windows.Forms.Padding(0);
            this.radioButtonVD_.Name = "radioButtonVD_";
            this.radioButtonVD_.Size = new System.Drawing.Size(35, 17);
            this.radioButtonVD_.TabIndex = 15;
            this.radioButtonVD_.Text = "D\'";
            this.toolTip1.SetToolTip(this.radioButtonVD_, "Shift + F ");
            this.radioButtonVD_.UseVisualStyleBackColor = true;
            // 
            // radioButtonV1
            // 
            this.radioButtonV1.AutoSize = true;
            this.radioButtonV1.Location = new System.Drawing.Point(36, 3);
            this.radioButtonV1.Margin = new System.Windows.Forms.Padding(0);
            this.radioButtonV1.Name = "radioButtonV1";
            this.radioButtonV1.Size = new System.Drawing.Size(31, 17);
            this.radioButtonV1.TabIndex = 13;
            this.radioButtonV1.Text = "1";
            this.toolTip1.SetToolTip(this.radioButtonV1, "Shift + 1");
            this.radioButtonV1.UseVisualStyleBackColor = true;
            // 
            // radioButtonVX
            // 
            this.radioButtonVX.AutoSize = true;
            this.radioButtonVX.Location = new System.Drawing.Point(141, 3);
            this.radioButtonVX.Margin = new System.Windows.Forms.Padding(0);
            this.radioButtonVX.Name = "radioButtonVX";
            this.radioButtonVX.Size = new System.Drawing.Size(32, 17);
            this.radioButtonVX.TabIndex = 16;
            this.radioButtonVX.Text = "X";
            this.toolTip1.SetToolTip(this.radioButtonVX, "Shift + X");
            this.radioButtonVX.UseVisualStyleBackColor = true;
            // 
            // radioButtonV0
            // 
            this.radioButtonV0.AutoSize = true;
            this.radioButtonV0.Location = new System.Drawing.Point(3, 3);
            this.radioButtonV0.Margin = new System.Windows.Forms.Padding(0);
            this.radioButtonV0.Name = "radioButtonV0";
            this.radioButtonV0.Size = new System.Drawing.Size(31, 17);
            this.radioButtonV0.TabIndex = 12;
            this.radioButtonV0.Text = "0";
            this.toolTip1.SetToolTip(this.radioButtonV0, "Shift + 0");
            this.radioButtonV0.UseVisualStyleBackColor = true;
            // 
            // buttonSignalPropagationSet0
            // 
            this.buttonSignalPropagationSet0.Location = new System.Drawing.Point(186, 1);
            this.buttonSignalPropagationSet0.Name = "buttonSignalPropagationSet0";
            this.buttonSignalPropagationSet0.Size = new System.Drawing.Size(36, 20);
            this.buttonSignalPropagationSet0.TabIndex = 17;
            this.buttonSignalPropagationSet0.Text = "0";
            this.toolTip1.SetToolTip(this.buttonSignalPropagationSet0, "( Ctrl + 0 )");
            this.buttonSignalPropagationSet0.UseVisualStyleBackColor = true;
            this.buttonSignalPropagationSet0.Click += new System.EventHandler(this.buttonSignalPropagationSet0_Click);
            // 
            // buttonSignalPropagationSet1
            // 
            this.buttonSignalPropagationSet1.Location = new System.Drawing.Point(221, 1);
            this.buttonSignalPropagationSet1.Name = "buttonSignalPropagationSet1";
            this.buttonSignalPropagationSet1.Size = new System.Drawing.Size(36, 20);
            this.buttonSignalPropagationSet1.TabIndex = 18;
            this.buttonSignalPropagationSet1.Text = "1";
            this.toolTip1.SetToolTip(this.buttonSignalPropagationSet1, "( Ctrl + 1 )");
            this.buttonSignalPropagationSet1.UseVisualStyleBackColor = true;
            this.buttonSignalPropagationSet1.Click += new System.EventHandler(this.buttonSignalPropagationSet1_Click);
            // 
            // buttonSignalPropagationSetD
            // 
            this.buttonSignalPropagationSetD.Location = new System.Drawing.Point(256, 1);
            this.buttonSignalPropagationSetD.Name = "buttonSignalPropagationSetD";
            this.buttonSignalPropagationSetD.Size = new System.Drawing.Size(36, 20);
            this.buttonSignalPropagationSetD.TabIndex = 19;
            this.buttonSignalPropagationSetD.Text = "D";
            this.toolTip1.SetToolTip(this.buttonSignalPropagationSetD, "( Ctrl + D )");
            this.buttonSignalPropagationSetD.UseVisualStyleBackColor = true;
            this.buttonSignalPropagationSetD.Click += new System.EventHandler(this.buttonSignalPropagationSetD_Click);
            // 
            // buttonSignalPropagationSetD_
            // 
            this.buttonSignalPropagationSetD_.Location = new System.Drawing.Point(291, 1);
            this.buttonSignalPropagationSetD_.Name = "buttonSignalPropagationSetD_";
            this.buttonSignalPropagationSetD_.Size = new System.Drawing.Size(36, 20);
            this.buttonSignalPropagationSetD_.TabIndex = 20;
            this.buttonSignalPropagationSetD_.Text = "D\'";
            this.toolTip1.SetToolTip(this.buttonSignalPropagationSetD_, "( Ctrl + E ) or ( Ctrl + F )");
            this.buttonSignalPropagationSetD_.UseVisualStyleBackColor = true;
            this.buttonSignalPropagationSetD_.Click += new System.EventHandler(this.buttonSignalPropagationSetD__Click);
            // 
            // buttonSignalPropagationSetX
            // 
            this.buttonSignalPropagationSetX.Location = new System.Drawing.Point(326, 1);
            this.buttonSignalPropagationSetX.Name = "buttonSignalPropagationSetX";
            this.buttonSignalPropagationSetX.Size = new System.Drawing.Size(36, 20);
            this.buttonSignalPropagationSetX.TabIndex = 21;
            this.buttonSignalPropagationSetX.Text = "X";
            this.toolTip1.SetToolTip(this.buttonSignalPropagationSetX, "( Ctrl + X )");
            this.buttonSignalPropagationSetX.UseVisualStyleBackColor = true;
            this.buttonSignalPropagationSetX.Click += new System.EventHandler(this.buttonSignalPropagationSetX_Click);
            // 
            // numericUpDownPeriod
            // 
            this.numericUpDownPeriod.Location = new System.Drawing.Point(99, 2);
            this.numericUpDownPeriod.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownPeriod.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownPeriod.Name = "numericUpDownPeriod";
            this.numericUpDownPeriod.Size = new System.Drawing.Size(48, 20);
            this.numericUpDownPeriod.TabIndex = 9;
            this.toolTip1.SetToolTip(this.numericUpDownPeriod, "Clock Period");
            this.numericUpDownPeriod.Value = new decimal(new int[] {
            250,
            0,
            0,
            0});
            this.numericUpDownPeriod.ValueChanged += new System.EventHandler(this.numericUpDownPeriod_ValueChanged);
            this.numericUpDownPeriod.Click += new System.EventHandler(this.numericUpDownPeriod_Click);
            this.numericUpDownPeriod.KeyDown += new System.Windows.Forms.KeyEventHandler(this.numericUpDownPeriod_KeyDown);
            this.numericUpDownPeriod.KeyUp += new System.Windows.Forms.KeyEventHandler(this.numericUpDownPeriod_KeyUp);
            // 
            // textBoxClockName
            // 
            this.textBoxClockName.Location = new System.Drawing.Point(37, 1);
            this.textBoxClockName.Name = "textBoxClockName";
            this.textBoxClockName.Size = new System.Drawing.Size(86, 20);
            this.textBoxClockName.TabIndex = 10;
            this.textBoxClockName.Text = "GClk";
            this.toolTip1.SetToolTip(this.textBoxClockName, "Name of Clock Net");
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.12686F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 62.87314F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 498F));
            this.tableLayoutPanel1.Controls.Add(this.tabControlOutput, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelInput, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.labelOutput, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxInput, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.checkBoxGenerateFanouts, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel4, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.panelToolBox, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel10, 2, 3);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(4, 66);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 17F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1058, 584);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tabControlOutput
            // 
            this.tabControlOutput.Controls.Add(this.tabPageOutputLog);
            this.tabControlOutput.Controls.Add(this.tabPageLargeOutput);
            this.tabControlOutput.Controls.Add(this.tabPageGeneratedNetlist);
            this.tabControlOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlOutput.Location = new System.Drawing.Point(210, 20);
            this.tabControlOutput.Name = "tabControlOutput";
            this.tabControlOutput.SelectedIndex = 0;
            this.tabControlOutput.Size = new System.Drawing.Size(346, 514);
            this.tabControlOutput.TabIndex = 10;
            // 
            // tabPageOutputLog
            // 
            this.tabPageOutputLog.Controls.Add(this.textBoxOutput);
            this.tabPageOutputLog.Location = new System.Drawing.Point(4, 22);
            this.tabPageOutputLog.Name = "tabPageOutputLog";
            this.tabPageOutputLog.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageOutputLog.Size = new System.Drawing.Size(338, 488);
            this.tabPageOutputLog.TabIndex = 0;
            this.tabPageOutputLog.Text = "Output";
            this.tabPageOutputLog.UseVisualStyleBackColor = true;
            // 
            // textBoxOutput
            // 
            this.textBoxOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxOutput.Font = new System.Drawing.Font("Lucida Console", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxOutput.HideSelection = false;
            this.textBoxOutput.Location = new System.Drawing.Point(3, 3);
            this.textBoxOutput.Margin = new System.Windows.Forms.Padding(3, 0, 4, 0);
            this.textBoxOutput.MaxLength = 2147483646;
            this.textBoxOutput.Multiline = true;
            this.textBoxOutput.Name = "textBoxOutput";
            this.textBoxOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxOutput.Size = new System.Drawing.Size(332, 482);
            this.textBoxOutput.TabIndex = 3;
            this.textBoxOutput.DoubleClick += new System.EventHandler(this.textBoxOutput_DoubleClick);
            this.textBoxOutput.Enter += new System.EventHandler(this.textBoxOutput_Enter);
            this.textBoxOutput.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBoxOutput_KeyUp);
            // 
            // tabPageLargeOutput
            // 
            this.tabPageLargeOutput.Controls.Add(this.richTextBoxOutput);
            this.tabPageLargeOutput.Location = new System.Drawing.Point(4, 22);
            this.tabPageLargeOutput.Name = "tabPageLargeOutput";
            this.tabPageLargeOutput.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLargeOutput.Size = new System.Drawing.Size(338, 488);
            this.tabPageLargeOutput.TabIndex = 2;
            this.tabPageLargeOutput.Text = "Large Output";
            this.tabPageLargeOutput.UseVisualStyleBackColor = true;
            // 
            // richTextBoxOutput
            // 
            this.richTextBoxOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBoxOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBoxOutput.Font = new System.Drawing.Font("Lucida Console", 9.5F);
            this.richTextBoxOutput.Location = new System.Drawing.Point(3, 3);
            this.richTextBoxOutput.Name = "richTextBoxOutput";
            this.richTextBoxOutput.Size = new System.Drawing.Size(332, 482);
            this.richTextBoxOutput.TabIndex = 0;
            this.richTextBoxOutput.Text = "";
            // 
            // tabPageGeneratedNetlist
            // 
            this.tabPageGeneratedNetlist.Controls.Add(this.textBoxGeneratedNetlist);
            this.tabPageGeneratedNetlist.Location = new System.Drawing.Point(4, 22);
            this.tabPageGeneratedNetlist.Name = "tabPageGeneratedNetlist";
            this.tabPageGeneratedNetlist.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageGeneratedNetlist.Size = new System.Drawing.Size(338, 488);
            this.tabPageGeneratedNetlist.TabIndex = 1;
            this.tabPageGeneratedNetlist.Text = "Generated Netlist";
            this.tabPageGeneratedNetlist.UseVisualStyleBackColor = true;
            // 
            // textBoxGeneratedNetlist
            // 
            this.textBoxGeneratedNetlist.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxGeneratedNetlist.Font = new System.Drawing.Font("Lucida Console", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxGeneratedNetlist.HideSelection = false;
            this.textBoxGeneratedNetlist.Location = new System.Drawing.Point(3, 3);
            this.textBoxGeneratedNetlist.Margin = new System.Windows.Forms.Padding(3, 0, 4, 0);
            this.textBoxGeneratedNetlist.MaxLength = 2147483646;
            this.textBoxGeneratedNetlist.Multiline = true;
            this.textBoxGeneratedNetlist.Name = "textBoxGeneratedNetlist";
            this.textBoxGeneratedNetlist.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxGeneratedNetlist.Size = new System.Drawing.Size(332, 482);
            this.textBoxGeneratedNetlist.TabIndex = 4;
            this.textBoxGeneratedNetlist.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textBoxGeneratedNetlist_KeyUp);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel3.Controls.Add(this.buttonFindInOutput, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.textBoxFindInOutput, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(207, 537);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(352, 27);
            this.tableLayoutPanel3.TabIndex = 7;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel2.Controls.Add(this.buttonFindInInput, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.textBoxFindInInput, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 537);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(207, 27);
            this.tableLayoutPanel2.TabIndex = 6;
            // 
            // checkBoxGenerateFanouts
            // 
            this.checkBoxGenerateFanouts.AutoSize = true;
            this.checkBoxGenerateFanouts.Location = new System.Drawing.Point(3, 564);
            this.checkBoxGenerateFanouts.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.checkBoxGenerateFanouts.Name = "checkBoxGenerateFanouts";
            this.checkBoxGenerateFanouts.Size = new System.Drawing.Size(201, 17);
            this.checkBoxGenerateFanouts.TabIndex = 7;
            this.checkBoxGenerateFanouts.Text = "Generate Fan-Out Nets (Accurate Testability Index Of Whole Circuit) (Longer Calcu" +
    "lations)";
            this.checkBoxGenerateFanouts.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.checkBoxOutputTestabilityIndexDetails, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.checkBoxOutputTestabilityIndex, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(210, 564);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(346, 17);
            this.tableLayoutPanel4.TabIndex = 8;
            // 
            // panelToolBox
            // 
            this.panelToolBox.Controls.Add(this.tabControlCommands);
            this.panelToolBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelToolBox.Location = new System.Drawing.Point(562, 20);
            this.panelToolBox.Name = "panelToolBox";
            this.tableLayoutPanel1.SetRowSpan(this.panelToolBox, 2);
            this.panelToolBox.Size = new System.Drawing.Size(493, 541);
            this.panelToolBox.TabIndex = 9;
            // 
            // tabControlCommands
            // 
            this.tabControlCommands.Controls.Add(this.tabPageLogicEncryptions);
            this.tabControlCommands.Controls.Add(this.tabPageTools);
            this.tabControlCommands.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlCommands.Location = new System.Drawing.Point(0, 0);
            this.tabControlCommands.Margin = new System.Windows.Forms.Padding(0);
            this.tabControlCommands.Multiline = true;
            this.tabControlCommands.Name = "tabControlCommands";
            this.tabControlCommands.SelectedIndex = 0;
            this.tabControlCommands.Size = new System.Drawing.Size(493, 541);
            this.tabControlCommands.TabIndex = 100;
            // 
            // tabPageLogicEncryptions
            // 
            this.tabPageLogicEncryptions.Controls.Add(this.tabControlEncryptions);
            this.tabPageLogicEncryptions.Location = new System.Drawing.Point(4, 22);
            this.tabPageLogicEncryptions.Name = "tabPageLogicEncryptions";
            this.tabPageLogicEncryptions.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLogicEncryptions.Size = new System.Drawing.Size(485, 515);
            this.tabPageLogicEncryptions.TabIndex = 8;
            this.tabPageLogicEncryptions.Text = "Logic Encryptions";
            this.tabPageLogicEncryptions.UseVisualStyleBackColor = true;
            // 
            // tabControlEncryptions
            // 
            this.tabControlEncryptions.Controls.Add(this.tabPageEncryptionAlgorithms);
            this.tabControlEncryptions.Controls.Add(this.tabPageCheckings);
            this.tabControlEncryptions.Controls.Add(this.tabPageEncryptionSettings);
            this.tabControlEncryptions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlEncryptions.Location = new System.Drawing.Point(3, 3);
            this.tabControlEncryptions.Margin = new System.Windows.Forms.Padding(0);
            this.tabControlEncryptions.Name = "tabControlEncryptions";
            this.tabControlEncryptions.SelectedIndex = 0;
            this.tabControlEncryptions.Size = new System.Drawing.Size(479, 509);
            this.tabControlEncryptions.TabIndex = 9;
            // 
            // tabPageEncryptionAlgorithms
            // 
            this.tabPageEncryptionAlgorithms.Controls.Add(this.tabControlAlgorithms);
            this.tabPageEncryptionAlgorithms.Location = new System.Drawing.Point(4, 22);
            this.tabPageEncryptionAlgorithms.Name = "tabPageEncryptionAlgorithms";
            this.tabPageEncryptionAlgorithms.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEncryptionAlgorithms.Size = new System.Drawing.Size(471, 483);
            this.tabPageEncryptionAlgorithms.TabIndex = 0;
            this.tabPageEncryptionAlgorithms.Text = "Algorithms";
            this.tabPageEncryptionAlgorithms.UseVisualStyleBackColor = true;
            // 
            // tabControlAlgorithms
            // 
            this.tabControlAlgorithms.Controls.Add(this.tabPageRandomXORXNOR);
            this.tabControlAlgorithms.Controls.Add(this.tabPageAntiHardwareTrojanEncryption);
            this.tabControlAlgorithms.Controls.Add(this.tabPageFARajendran);
            this.tabControlAlgorithms.Controls.Add(this.tabPageGreedyXAlgorithm);
            this.tabControlAlgorithms.Controls.Add(this.tabPageSamimi02Combined);
            this.tabControlAlgorithms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlAlgorithms.Location = new System.Drawing.Point(3, 3);
            this.tabControlAlgorithms.Margin = new System.Windows.Forms.Padding(0);
            this.tabControlAlgorithms.Name = "tabControlAlgorithms";
            this.tabControlAlgorithms.SelectedIndex = 0;
            this.tabControlAlgorithms.Size = new System.Drawing.Size(465, 477);
            this.tabControlAlgorithms.TabIndex = 4;
            // 
            // tabPageRandomXORXNOR
            // 
            this.tabPageRandomXORXNOR.Controls.Add(this.label13);
            this.tabPageRandomXORXNOR.Controls.Add(this.label20);
            this.tabPageRandomXORXNOR.Controls.Add(this.label5);
            this.tabPageRandomXORXNOR.Controls.Add(this.label6);
            this.tabPageRandomXORXNOR.Controls.Add(this.label12);
            this.tabPageRandomXORXNOR.Controls.Add(this.label133);
            this.tabPageRandomXORXNOR.Controls.Add(this.numericUpDownRandomXORXNORRRandomSeed);
            this.tabPageRandomXORXNOR.Controls.Add(this.checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption);
            this.tabPageRandomXORXNOR.Controls.Add(this.label58);
            this.tabPageRandomXORXNOR.Controls.Add(this.textBoxRandomXORXNORDirectoryComment);
            this.tabPageRandomXORXNOR.Controls.Add(this.checkBoxRandomXORXNORDontUseCache);
            this.tabPageRandomXORXNOR.Controls.Add(this.label59);
            this.tabPageRandomXORXNOR.Controls.Add(this.textBoxRandomXORXNORInlineComment);
            this.tabPageRandomXORXNOR.Controls.Add(this.labelRandomXORXNORGeneratedKeyLength);
            this.tabPageRandomXORXNOR.Controls.Add(this.textBoxRandomXORXNORGeneratedKey);
            this.tabPageRandomXORXNOR.Controls.Add(this.label60);
            this.tabPageRandomXORXNOR.Controls.Add(this.label61);
            this.tabPageRandomXORXNOR.Controls.Add(this.numericUpDownRandomXORXNORKeyLength);
            this.tabPageRandomXORXNOR.Controls.Add(this.checkBoxRandomXORXNORRandomSeed);
            this.tabPageRandomXORXNOR.Controls.Add(this.numericUpDownRandomXORXNORRandomSeed);
            this.tabPageRandomXORXNOR.Controls.Add(this.buttonRandomXORXNOREncryption);
            this.tabPageRandomXORXNOR.Location = new System.Drawing.Point(4, 22);
            this.tabPageRandomXORXNOR.Name = "tabPageRandomXORXNOR";
            this.tabPageRandomXORXNOR.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageRandomXORXNOR.Size = new System.Drawing.Size(457, 451);
            this.tabPageRandomXORXNOR.TabIndex = 7;
            this.tabPageRandomXORXNOR.Text = "Random";
            this.tabPageRandomXORXNOR.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(106, 243);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 13);
            this.label13.TabIndex = 168;
            this.label13.Text = "Directory Comment:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(106, 217);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(82, 13);
            this.label20.TabIndex = 167;
            this.label20.Text = "Inline Comment:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(104, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 166;
            this.label5.Text = "R Random Seed:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(106, 142);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 13);
            this.label6.TabIndex = 165;
            this.label6.Text = "Generated Key:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(104, 89);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 13);
            this.label12.TabIndex = 164;
            this.label12.Text = "Key Length:";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(103, 110);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(0, 13);
            this.label133.TabIndex = 163;
            // 
            // numericUpDownRandomXORXNORRRandomSeed
            // 
            this.numericUpDownRandomXORXNORRRandomSeed.Location = new System.Drawing.Point(213, 113);
            this.numericUpDownRandomXORXNORRRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownRandomXORXNORRRandomSeed.Name = "numericUpDownRandomXORXNORRRandomSeed";
            this.numericUpDownRandomXORXNORRRandomSeed.Size = new System.Drawing.Size(92, 20);
            this.numericUpDownRandomXORXNORRRandomSeed.TabIndex = 162;
            this.numericUpDownRandomXORXNORRRandomSeed.Value = new decimal(new int[] {
            198705,
            0,
            0,
            0});
            // 
            // checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption
            // 
            this.checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption.AutoSize = true;
            this.checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption.Checked = true;
            this.checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption.Location = new System.Drawing.Point(106, 64);
            this.checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption.Name = "checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption";
            this.checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption.Size = new System.Drawing.Size(204, 17);
            this.checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption.TabIndex = 147;
            this.checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption.Text = "Report Probabilities Before Encryption";
            this.checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption.UseVisualStyleBackColor = true;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(105, 243);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(0, 13);
            this.label58.TabIndex = 146;
            // 
            // textBoxRandomXORXNORDirectoryComment
            // 
            this.textBoxRandomXORXNORDirectoryComment.Location = new System.Drawing.Point(210, 240);
            this.textBoxRandomXORXNORDirectoryComment.Name = "textBoxRandomXORXNORDirectoryComment";
            this.textBoxRandomXORXNORDirectoryComment.Size = new System.Drawing.Size(94, 20);
            this.textBoxRandomXORXNORDirectoryComment.TabIndex = 145;
            // 
            // checkBoxRandomXORXNORDontUseCache
            // 
            this.checkBoxRandomXORXNORDontUseCache.AutoSize = true;
            this.checkBoxRandomXORXNORDontUseCache.Location = new System.Drawing.Point(107, 176);
            this.checkBoxRandomXORXNORDontUseCache.Name = "checkBoxRandomXORXNORDontUseCache";
            this.checkBoxRandomXORXNORDontUseCache.Size = new System.Drawing.Size(107, 17);
            this.checkBoxRandomXORXNORDontUseCache.TabIndex = 144;
            this.checkBoxRandomXORXNORDontUseCache.Text = "Don\'t Use Cache";
            this.checkBoxRandomXORXNORDontUseCache.UseVisualStyleBackColor = true;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(105, 217);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(0, 13);
            this.label59.TabIndex = 143;
            // 
            // textBoxRandomXORXNORInlineComment
            // 
            this.textBoxRandomXORXNORInlineComment.Location = new System.Drawing.Point(210, 214);
            this.textBoxRandomXORXNORInlineComment.Name = "textBoxRandomXORXNORInlineComment";
            this.textBoxRandomXORXNORInlineComment.Size = new System.Drawing.Size(94, 20);
            this.textBoxRandomXORXNORInlineComment.TabIndex = 142;
            // 
            // labelRandomXORXNORGeneratedKeyLength
            // 
            this.labelRandomXORXNORGeneratedKeyLength.AutoSize = true;
            this.labelRandomXORXNORGeneratedKeyLength.Location = new System.Drawing.Point(210, 160);
            this.labelRandomXORXNORGeneratedKeyLength.Name = "labelRandomXORXNORGeneratedKeyLength";
            this.labelRandomXORXNORGeneratedKeyLength.Size = new System.Drawing.Size(0, 13);
            this.labelRandomXORXNORGeneratedKeyLength.TabIndex = 141;
            // 
            // textBoxRandomXORXNORGeneratedKey
            // 
            this.textBoxRandomXORXNORGeneratedKey.Location = new System.Drawing.Point(213, 137);
            this.textBoxRandomXORXNORGeneratedKey.Name = "textBoxRandomXORXNORGeneratedKey";
            this.textBoxRandomXORXNORGeneratedKey.ReadOnly = true;
            this.textBoxRandomXORXNORGeneratedKey.Size = new System.Drawing.Size(92, 20);
            this.textBoxRandomXORXNORGeneratedKey.TabIndex = 140;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(105, 135);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(0, 13);
            this.label60.TabIndex = 139;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(104, 87);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(0, 13);
            this.label61.TabIndex = 138;
            // 
            // numericUpDownRandomXORXNORKeyLength
            // 
            this.numericUpDownRandomXORXNORKeyLength.Location = new System.Drawing.Point(213, 87);
            this.numericUpDownRandomXORXNORKeyLength.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownRandomXORXNORKeyLength.Name = "numericUpDownRandomXORXNORKeyLength";
            this.numericUpDownRandomXORXNORKeyLength.Size = new System.Drawing.Size(92, 20);
            this.numericUpDownRandomXORXNORKeyLength.TabIndex = 137;
            this.numericUpDownRandomXORXNORKeyLength.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // checkBoxRandomXORXNORRandomSeed
            // 
            this.checkBoxRandomXORXNORRandomSeed.AutoSize = true;
            this.checkBoxRandomXORXNORRandomSeed.Location = new System.Drawing.Point(106, 28);
            this.checkBoxRandomXORXNORRandomSeed.Name = "checkBoxRandomXORXNORRandomSeed";
            this.checkBoxRandomXORXNORRandomSeed.Size = new System.Drawing.Size(97, 17);
            this.checkBoxRandomXORXNORRandomSeed.TabIndex = 136;
            this.checkBoxRandomXORXNORRandomSeed.Text = "Random Seed:";
            this.checkBoxRandomXORXNORRandomSeed.UseVisualStyleBackColor = true;
            // 
            // numericUpDownRandomXORXNORRandomSeed
            // 
            this.numericUpDownRandomXORXNORRandomSeed.Location = new System.Drawing.Point(212, 26);
            this.numericUpDownRandomXORXNORRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownRandomXORXNORRandomSeed.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownRandomXORXNORRandomSeed.Name = "numericUpDownRandomXORXNORRandomSeed";
            this.numericUpDownRandomXORXNORRandomSeed.Size = new System.Drawing.Size(92, 20);
            this.numericUpDownRandomXORXNORRandomSeed.TabIndex = 135;
            this.numericUpDownRandomXORXNORRandomSeed.Value = new decimal(new int[] {
            309302,
            0,
            0,
            0});
            // 
            // buttonRandomXORXNOREncryption
            // 
            this.buttonRandomXORXNOREncryption.Location = new System.Drawing.Point(104, 266);
            this.buttonRandomXORXNOREncryption.Name = "buttonRandomXORXNOREncryption";
            this.buttonRandomXORXNOREncryption.Size = new System.Drawing.Size(200, 41);
            this.buttonRandomXORXNOREncryption.TabIndex = 134;
            this.buttonRandomXORXNOREncryption.Text = "Encrypt";
            this.buttonRandomXORXNOREncryption.UseVisualStyleBackColor = true;
            this.buttonRandomXORXNOREncryption.Click += new System.EventHandler(this.buttonRandomXORXNOREncryption_Click);
            // 
            // tabPageAntiHardwareTrojanEncryption
            // 
            this.tabPageAntiHardwareTrojanEncryption.AutoScroll = true;
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label32);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label33);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label29);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label30);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label31);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label25);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label26);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label27);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label23);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label129);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label128);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label127);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.numericUpDownHTRRandomSeed);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label126);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label105);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.buttonAlg18AntiHTOriginalNoSlackTIme);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.buttonAlg17AntiHardwareTrojanEnhancedEncryption2);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.buttonAlg13AntiHTOriginal);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.checkBoxHTReportSlackTimesBeforeEncryption);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.checkBoxHTReportProbabilitiesBeforeEncryption);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label37);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.textBoxHTDirectoryComment);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.checkBoxHTDontUseCache);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label24);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.textBoxHTInlineComment);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label21);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.labelHTGeneratedKeyLength);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.textBoxHTGeneratedKey);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label19);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label18);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.numericUpDownHTKeyLength);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label17);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.numericUpDownHTProbMin);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label16);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.numericUpDownHTSlackMin);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label14);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.numericUpDownHTClockTicks);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.numericUpDownHTThreshold);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.checkBoxHTMeetThreshold);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.checkBoxHTRandomSeed);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.numericUpDownHTRandomSeed);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.label15);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.numericUpDownHTRandomPatterns);
            this.tabPageAntiHardwareTrojanEncryption.Controls.Add(this.buttonAlg04AntiHardwareTrojanEnhancedEncryption);
            this.tabPageAntiHardwareTrojanEncryption.Location = new System.Drawing.Point(4, 22);
            this.tabPageAntiHardwareTrojanEncryption.Name = "tabPageAntiHardwareTrojanEncryption";
            this.tabPageAntiHardwareTrojanEncryption.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageAntiHardwareTrojanEncryption.Size = new System.Drawing.Size(456, 451);
            this.tabPageAntiHardwareTrojanEncryption.TabIndex = 3;
            this.tabPageAntiHardwareTrojanEncryption.Text = "Anti HT";
            this.tabPageAntiHardwareTrojanEncryption.UseVisualStyleBackColor = true;
            this.tabPageAntiHardwareTrojanEncryption.Click += new System.EventHandler(this.tabPageAntiHardwareTrojanEncryption_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(102, 372);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(99, 13);
            this.label32.TabIndex = 176;
            this.label32.Text = "Directory Comment:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(102, 346);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(82, 13);
            this.label33.TabIndex = 175;
            this.label33.Text = "Inline Comment:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(100, 215);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(89, 13);
            this.label29.TabIndex = 174;
            this.label29.Text = "R Random Seed:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(102, 269);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(81, 13);
            this.label30.TabIndex = 173;
            this.label30.Text = "Generated Key:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(100, 240);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(64, 13);
            this.label31.TabIndex = 172;
            this.label31.Text = "Key Length:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(100, 143);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(78, 13);
            this.label25.TabIndex = 171;
            this.label25.Text = "Min Probability:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(100, 117);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(76, 13);
            this.label26.TabIndex = 170;
            this.label26.Text = "Min Slacktime:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(100, 91);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(66, 13);
            this.label27.TabIndex = 169;
            this.label27.Text = "Clock Ticks:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(101, 13);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(92, 13);
            this.label23.TabIndex = 168;
            this.label23.Text = "Random Patterns:";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.ForeColor = System.Drawing.Color.Red;
            this.label129.Location = new System.Drawing.Point(13, 816);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(0, 13);
            this.label129.TabIndex = 167;
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.ForeColor = System.Drawing.Color.Red;
            this.label128.Location = new System.Drawing.Point(13, 760);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(0, 13);
            this.label128.TabIndex = 166;
            // 
            // buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime
            // 
            this.buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime.Location = new System.Drawing.Point(105, 798);
            this.buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime.Name = "buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime";
            this.buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime.Size = new System.Drawing.Size(200, 49);
            this.buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime.TabIndex = 165;
            this.buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime.Text = "Alg22 = Anti HT Enhanced Encrypt 1 XOR/XNOR (No Slacktime) ProposedAlg1";
            this.buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime.UseVisualStyleBackColor = true;
            this.buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime.Click += new System.EventHandler(this.buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime_Click);
            // 
            // buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync
            // 
            this.buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync.Location = new System.Drawing.Point(105, 742);
            this.buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync.Name = "buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync";
            this.buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync.Size = new System.Drawing.Size(200, 49);
            this.buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync.TabIndex = 164;
            this.buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync.Text = "Alg21 = Anti HT Enhanced Encrypt 1 XOR/XNOR";
            this.buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync.UseVisualStyleBackColor = true;
            this.buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync.Click += new System.EventHandler(this.buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync_Click);
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(100, 215);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(0, 13);
            this.label127.TabIndex = 163;
            // 
            // numericUpDownHTRRandomSeed
            // 
            this.numericUpDownHTRRandomSeed.Location = new System.Drawing.Point(209, 213);
            this.numericUpDownHTRRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownHTRRandomSeed.Name = "numericUpDownHTRRandomSeed";
            this.numericUpDownHTRRandomSeed.Size = new System.Drawing.Size(92, 20);
            this.numericUpDownHTRRandomSeed.TabIndex = 162;
            this.numericUpDownHTRRandomSeed.Value = new decimal(new int[] {
            198705,
            0,
            0,
            0});
            // 
            // label126
            // 
            this.label126.BackColor = System.Drawing.Color.Black;
            this.label126.Location = new System.Drawing.Point(-13, 733);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(400, 2);
            this.label126.TabIndex = 127;
            // 
            // label105
            // 
            this.label105.BackColor = System.Drawing.Color.Black;
            this.label105.Location = new System.Drawing.Point(-15, 560);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(400, 2);
            this.label105.TabIndex = 126;
            // 
            // buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime
            // 
            this.buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime.Location = new System.Drawing.Point(105, 677);
            this.buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime.Name = "buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime";
            this.buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime.Size = new System.Drawing.Size(200, 49);
            this.buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime.TabIndex = 125;
            this.buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime.Text = "Alg20 = Alg17 Anti HT Enhanced Encrypt 2 (No Slacktime)";
            this.buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime.UseVisualStyleBackColor = true;
            this.buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime.Click += new System.EventHandler(this.buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime_Click);
            // 
            // buttonAlg18AntiHTOriginalNoSlackTIme
            // 
            this.buttonAlg18AntiHTOriginalNoSlackTIme.Location = new System.Drawing.Point(105, 568);
            this.buttonAlg18AntiHTOriginalNoSlackTIme.Name = "buttonAlg18AntiHTOriginalNoSlackTIme";
            this.buttonAlg18AntiHTOriginalNoSlackTIme.Size = new System.Drawing.Size(200, 49);
            this.buttonAlg18AntiHTOriginalNoSlackTIme.TabIndex = 124;
            this.buttonAlg18AntiHTOriginalNoSlackTIme.Text = "Alg18 = Alg13 Anti HT Original Encrypt   (Original Paper) (No Slacktime)";
            this.buttonAlg18AntiHTOriginalNoSlackTIme.UseVisualStyleBackColor = true;
            this.buttonAlg18AntiHTOriginalNoSlackTIme.Click += new System.EventHandler(this.buttonAlg18AntiHTOriginalNoSlackTIme_Click);
            // 
            // buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime
            // 
            this.buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime.Location = new System.Drawing.Point(105, 622);
            this.buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime.Name = "buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime";
            this.buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime.Size = new System.Drawing.Size(200, 49);
            this.buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime.TabIndex = 123;
            this.buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime.Text = "Alg19 = Alg04 Anti HT Enhanced Encrypt 1 (No Slacktime)";
            this.buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime.UseVisualStyleBackColor = true;
            this.buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime.Click += new System.EventHandler(this.buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime_Click);
            // 
            // buttonAlg17AntiHardwareTrojanEnhancedEncryption2
            // 
            this.buttonAlg17AntiHardwareTrojanEnhancedEncryption2.Location = new System.Drawing.Point(105, 504);
            this.buttonAlg17AntiHardwareTrojanEnhancedEncryption2.Name = "buttonAlg17AntiHardwareTrojanEnhancedEncryption2";
            this.buttonAlg17AntiHardwareTrojanEnhancedEncryption2.Size = new System.Drawing.Size(200, 49);
            this.buttonAlg17AntiHardwareTrojanEnhancedEncryption2.TabIndex = 122;
            this.buttonAlg17AntiHardwareTrojanEnhancedEncryption2.Text = "Alg17 Anti HT Enhanced Encrypt 2";
            this.buttonAlg17AntiHardwareTrojanEnhancedEncryption2.UseVisualStyleBackColor = true;
            this.buttonAlg17AntiHardwareTrojanEnhancedEncryption2.Click += new System.EventHandler(this.buttonAlg17AntiHardwareTrojanEnhancedEncryption2_Click);
            // 
            // buttonAlg13AntiHTOriginal
            // 
            this.buttonAlg13AntiHTOriginal.Location = new System.Drawing.Point(104, 395);
            this.buttonAlg13AntiHTOriginal.Name = "buttonAlg13AntiHTOriginal";
            this.buttonAlg13AntiHTOriginal.Size = new System.Drawing.Size(200, 49);
            this.buttonAlg13AntiHTOriginal.TabIndex = 121;
            this.buttonAlg13AntiHTOriginal.Text = "Alg13 Anti HT Original Encrypt   (Original Paper)";
            this.buttonAlg13AntiHTOriginal.UseVisualStyleBackColor = true;
            this.buttonAlg13AntiHTOriginal.Click += new System.EventHandler(this.buttonAlg13AntiHTOriginal_Click);
            // 
            // checkBoxHTReportSlackTimesBeforeEncryption
            // 
            this.checkBoxHTReportSlackTimesBeforeEncryption.AutoSize = true;
            this.checkBoxHTReportSlackTimesBeforeEncryption.Checked = true;
            this.checkBoxHTReportSlackTimesBeforeEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxHTReportSlackTimesBeforeEncryption.Enabled = false;
            this.checkBoxHTReportSlackTimesBeforeEncryption.Location = new System.Drawing.Point(102, 190);
            this.checkBoxHTReportSlackTimesBeforeEncryption.Name = "checkBoxHTReportSlackTimesBeforeEncryption";
            this.checkBoxHTReportSlackTimesBeforeEncryption.Size = new System.Drawing.Size(203, 17);
            this.checkBoxHTReportSlackTimesBeforeEncryption.TabIndex = 120;
            this.checkBoxHTReportSlackTimesBeforeEncryption.Text = "Report SlackTimes Before Encryption";
            this.checkBoxHTReportSlackTimesBeforeEncryption.UseVisualStyleBackColor = true;
            // 
            // checkBoxHTReportProbabilitiesBeforeEncryption
            // 
            this.checkBoxHTReportProbabilitiesBeforeEncryption.AutoSize = true;
            this.checkBoxHTReportProbabilitiesBeforeEncryption.Checked = true;
            this.checkBoxHTReportProbabilitiesBeforeEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxHTReportProbabilitiesBeforeEncryption.Enabled = false;
            this.checkBoxHTReportProbabilitiesBeforeEncryption.Location = new System.Drawing.Point(102, 167);
            this.checkBoxHTReportProbabilitiesBeforeEncryption.Name = "checkBoxHTReportProbabilitiesBeforeEncryption";
            this.checkBoxHTReportProbabilitiesBeforeEncryption.Size = new System.Drawing.Size(204, 17);
            this.checkBoxHTReportProbabilitiesBeforeEncryption.TabIndex = 119;
            this.checkBoxHTReportProbabilitiesBeforeEncryption.Text = "Report Probabilities Before Encryption";
            this.checkBoxHTReportProbabilitiesBeforeEncryption.UseVisualStyleBackColor = true;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(105, 372);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(0, 13);
            this.label37.TabIndex = 86;
            // 
            // textBoxHTDirectoryComment
            // 
            this.textBoxHTDirectoryComment.Location = new System.Drawing.Point(210, 369);
            this.textBoxHTDirectoryComment.Name = "textBoxHTDirectoryComment";
            this.textBoxHTDirectoryComment.Size = new System.Drawing.Size(94, 20);
            this.textBoxHTDirectoryComment.TabIndex = 85;
            // 
            // checkBoxHTDontUseCache
            // 
            this.checkBoxHTDontUseCache.AutoSize = true;
            this.checkBoxHTDontUseCache.Location = new System.Drawing.Point(103, 305);
            this.checkBoxHTDontUseCache.Name = "checkBoxHTDontUseCache";
            this.checkBoxHTDontUseCache.Size = new System.Drawing.Size(107, 17);
            this.checkBoxHTDontUseCache.TabIndex = 84;
            this.checkBoxHTDontUseCache.Text = "Don\'t Use Cache";
            this.checkBoxHTDontUseCache.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(105, 346);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 13);
            this.label24.TabIndex = 83;
            // 
            // textBoxHTInlineComment
            // 
            this.textBoxHTInlineComment.Location = new System.Drawing.Point(210, 343);
            this.textBoxHTInlineComment.Name = "textBoxHTInlineComment";
            this.textBoxHTInlineComment.Size = new System.Drawing.Size(94, 20);
            this.textBoxHTInlineComment.TabIndex = 82;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(1, 328);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(400, 2);
            this.label21.TabIndex = 76;
            // 
            // labelHTGeneratedKeyLength
            // 
            this.labelHTGeneratedKeyLength.AutoSize = true;
            this.labelHTGeneratedKeyLength.Location = new System.Drawing.Point(206, 289);
            this.labelHTGeneratedKeyLength.Name = "labelHTGeneratedKeyLength";
            this.labelHTGeneratedKeyLength.Size = new System.Drawing.Size(0, 13);
            this.labelHTGeneratedKeyLength.TabIndex = 75;
            // 
            // textBoxHTGeneratedKey
            // 
            this.textBoxHTGeneratedKey.Location = new System.Drawing.Point(209, 266);
            this.textBoxHTGeneratedKey.Name = "textBoxHTGeneratedKey";
            this.textBoxHTGeneratedKey.ReadOnly = true;
            this.textBoxHTGeneratedKey.Size = new System.Drawing.Size(92, 20);
            this.textBoxHTGeneratedKey.TabIndex = 74;
            this.textBoxHTGeneratedKey.TextChanged += new System.EventHandler(this.textBoxHTGeneratedKey_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(102, 269);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(0, 13);
            this.label19.TabIndex = 73;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(100, 240);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 13);
            this.label18.TabIndex = 72;
            // 
            // numericUpDownHTKeyLength
            // 
            this.numericUpDownHTKeyLength.Location = new System.Drawing.Point(209, 240);
            this.numericUpDownHTKeyLength.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownHTKeyLength.Name = "numericUpDownHTKeyLength";
            this.numericUpDownHTKeyLength.Size = new System.Drawing.Size(92, 20);
            this.numericUpDownHTKeyLength.TabIndex = 71;
            this.numericUpDownHTKeyLength.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(100, 141);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 13);
            this.label17.TabIndex = 70;
            // 
            // numericUpDownHTProbMin
            // 
            this.numericUpDownHTProbMin.DecimalPlaces = 2;
            this.numericUpDownHTProbMin.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDownHTProbMin.Location = new System.Drawing.Point(209, 141);
            this.numericUpDownHTProbMin.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownHTProbMin.Name = "numericUpDownHTProbMin";
            this.numericUpDownHTProbMin.Size = new System.Drawing.Size(92, 20);
            this.numericUpDownHTProbMin.TabIndex = 69;
            this.numericUpDownHTProbMin.Value = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(100, 115);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(0, 13);
            this.label16.TabIndex = 68;
            // 
            // numericUpDownHTSlackMin
            // 
            this.numericUpDownHTSlackMin.Location = new System.Drawing.Point(209, 115);
            this.numericUpDownHTSlackMin.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownHTSlackMin.Name = "numericUpDownHTSlackMin";
            this.numericUpDownHTSlackMin.Size = new System.Drawing.Size(92, 20);
            this.numericUpDownHTSlackMin.TabIndex = 67;
            this.numericUpDownHTSlackMin.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(100, 89);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 13);
            this.label14.TabIndex = 66;
            // 
            // numericUpDownHTClockTicks
            // 
            this.numericUpDownHTClockTicks.Location = new System.Drawing.Point(209, 89);
            this.numericUpDownHTClockTicks.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownHTClockTicks.Name = "numericUpDownHTClockTicks";
            this.numericUpDownHTClockTicks.Size = new System.Drawing.Size(92, 20);
            this.numericUpDownHTClockTicks.TabIndex = 65;
            this.numericUpDownHTClockTicks.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // numericUpDownHTThreshold
            // 
            this.numericUpDownHTThreshold.DecimalPlaces = 8;
            this.numericUpDownHTThreshold.Increment = new decimal(new int[] {
            1,
            0,
            0,
            393216});
            this.numericUpDownHTThreshold.Location = new System.Drawing.Point(209, 63);
            this.numericUpDownHTThreshold.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownHTThreshold.Name = "numericUpDownHTThreshold";
            this.numericUpDownHTThreshold.Size = new System.Drawing.Size(92, 20);
            this.numericUpDownHTThreshold.TabIndex = 64;
            this.numericUpDownHTThreshold.Value = new decimal(new int[] {
            2,
            0,
            0,
            327680});
            // 
            // checkBoxHTMeetThreshold
            // 
            this.checkBoxHTMeetThreshold.AutoSize = true;
            this.checkBoxHTMeetThreshold.Checked = true;
            this.checkBoxHTMeetThreshold.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxHTMeetThreshold.Location = new System.Drawing.Point(103, 62);
            this.checkBoxHTMeetThreshold.Name = "checkBoxHTMeetThreshold";
            this.checkBoxHTMeetThreshold.Size = new System.Drawing.Size(103, 17);
            this.checkBoxHTMeetThreshold.TabIndex = 63;
            this.checkBoxHTMeetThreshold.Text = "Meet Threshold:";
            this.checkBoxHTMeetThreshold.UseVisualStyleBackColor = true;
            this.checkBoxHTMeetThreshold.CheckedChanged += new System.EventHandler(this.checkBoxHTMeetThreshold_CheckedChanged);
            // 
            // checkBoxHTRandomSeed
            // 
            this.checkBoxHTRandomSeed.AutoSize = true;
            this.checkBoxHTRandomSeed.Location = new System.Drawing.Point(103, 39);
            this.checkBoxHTRandomSeed.Name = "checkBoxHTRandomSeed";
            this.checkBoxHTRandomSeed.Size = new System.Drawing.Size(97, 17);
            this.checkBoxHTRandomSeed.TabIndex = 62;
            this.checkBoxHTRandomSeed.Text = "Random Seed:";
            this.checkBoxHTRandomSeed.UseVisualStyleBackColor = true;
            // 
            // numericUpDownHTRandomSeed
            // 
            this.numericUpDownHTRandomSeed.Location = new System.Drawing.Point(209, 37);
            this.numericUpDownHTRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownHTRandomSeed.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownHTRandomSeed.Name = "numericUpDownHTRandomSeed";
            this.numericUpDownHTRandomSeed.Size = new System.Drawing.Size(92, 20);
            this.numericUpDownHTRandomSeed.TabIndex = 61;
            this.numericUpDownHTRandomSeed.Value = new decimal(new int[] {
            309302,
            0,
            0,
            0});
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(100, 13);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 13);
            this.label15.TabIndex = 60;
            // 
            // numericUpDownHTRandomPatterns
            // 
            this.numericUpDownHTRandomPatterns.Location = new System.Drawing.Point(209, 11);
            this.numericUpDownHTRandomPatterns.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDownHTRandomPatterns.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownHTRandomPatterns.Name = "numericUpDownHTRandomPatterns";
            this.numericUpDownHTRandomPatterns.Size = new System.Drawing.Size(92, 20);
            this.numericUpDownHTRandomPatterns.TabIndex = 59;
            this.numericUpDownHTRandomPatterns.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // buttonAlg04AntiHardwareTrojanEnhancedEncryption
            // 
            this.buttonAlg04AntiHardwareTrojanEnhancedEncryption.Location = new System.Drawing.Point(105, 449);
            this.buttonAlg04AntiHardwareTrojanEnhancedEncryption.Name = "buttonAlg04AntiHardwareTrojanEnhancedEncryption";
            this.buttonAlg04AntiHardwareTrojanEnhancedEncryption.Size = new System.Drawing.Size(200, 49);
            this.buttonAlg04AntiHardwareTrojanEnhancedEncryption.TabIndex = 41;
            this.buttonAlg04AntiHardwareTrojanEnhancedEncryption.Text = "Alg04 Anti HT Enhanced Encrypt 1";
            this.buttonAlg04AntiHardwareTrojanEnhancedEncryption.UseVisualStyleBackColor = true;
            this.buttonAlg04AntiHardwareTrojanEnhancedEncryption.Click += new System.EventHandler(this.buttonAlg04AntiHardwareTrojanEnhancedEncryption_Click);
            // 
            // tabPageFARajendran
            // 
            this.tabPageFARajendran.AutoScroll = true;
            this.tabPageFARajendran.Controls.Add(this.checkBoxFARajendranUseFaultImpacts2);
            this.tabPageFARajendran.Controls.Add(this.label102);
            this.tabPageFARajendran.Controls.Add(this.label101);
            this.tabPageFARajendran.Controls.Add(this.label100);
            this.tabPageFARajendran.Controls.Add(this.label99);
            this.tabPageFARajendran.Controls.Add(this.buttonAlg11);
            this.tabPageFARajendran.Controls.Add(this.buttonFARajendranAlg10);
            this.tabPageFARajendran.Controls.Add(this.label57);
            this.tabPageFARajendran.Controls.Add(this.numericUpDownFARajendranRRandomSeed);
            this.tabPageFARajendran.Controls.Add(this.checkBoxFARajendranReportProbabilitiesBeforeEncryption);
            this.tabPageFARajendran.Controls.Add(this.label55);
            this.tabPageFARajendran.Controls.Add(this.label54);
            this.tabPageFARajendran.Controls.Add(this.buttonFARajendranAsIPresumeItIsEncrypt);
            this.tabPageFARajendran.Controls.Add(this.buttonFARajendranOriginalEncrypt);
            this.tabPageFARajendran.Controls.Add(this.labelFARajendranGeneratedKeyLength);
            this.tabPageFARajendran.Controls.Add(this.textBoxFARajendranGeneratedKey);
            this.tabPageFARajendran.Controls.Add(this.label42);
            this.tabPageFARajendran.Controls.Add(this.label43);
            this.tabPageFARajendran.Controls.Add(this.numericUpDownFARajendranKeyLength);
            this.tabPageFARajendran.Controls.Add(this.label44);
            this.tabPageFARajendran.Controls.Add(this.textBoxFARajendranDirectoryComment);
            this.tabPageFARajendran.Controls.Add(this.checkBoxFARajendranDontUseCache);
            this.tabPageFARajendran.Controls.Add(this.label45);
            this.tabPageFARajendran.Controls.Add(this.textBoxFARajendranInlineComment);
            this.tabPageFARajendran.Controls.Add(this.checkBoxFARajendranRandomSeed);
            this.tabPageFARajendran.Controls.Add(this.checkBoxFARajendranUniqueRandomPatterns);
            this.tabPageFARajendran.Controls.Add(this.numericUpDownFARajendranRandomSeed);
            this.tabPageFARajendran.Controls.Add(this.numericUpDownFARajendranNumberOfThreads);
            this.tabPageFARajendran.Controls.Add(this.label46);
            this.tabPageFARajendran.Controls.Add(this.numericUpDownFARajendranClockTimes);
            this.tabPageFARajendran.Controls.Add(this.label47);
            this.tabPageFARajendran.Controls.Add(this.numericUpDownFARajendranRandomPatterns);
            this.tabPageFARajendran.Controls.Add(this.label48);
            this.tabPageFARajendran.Location = new System.Drawing.Point(4, 22);
            this.tabPageFARajendran.Name = "tabPageFARajendran";
            this.tabPageFARajendran.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFARajendran.Size = new System.Drawing.Size(456, 451);
            this.tabPageFARajendran.TabIndex = 6;
            this.tabPageFARajendran.Text = "FA Rajendran";
            this.tabPageFARajendran.UseVisualStyleBackColor = true;
            // 
            // checkBoxFARajendranUseFaultImpacts2
            // 
            this.checkBoxFARajendranUseFaultImpacts2.AutoSize = true;
            this.checkBoxFARajendranUseFaultImpacts2.Location = new System.Drawing.Point(289, 382);
            this.checkBoxFARajendranUseFaultImpacts2.Name = "checkBoxFARajendranUseFaultImpacts2";
            this.checkBoxFARajendranUseFaultImpacts2.Size = new System.Drawing.Size(98, 17);
            this.checkBoxFARajendranUseFaultImpacts2.TabIndex = 142;
            this.checkBoxFARajendranUseFaultImpacts2.Text = "Fault Impacts 2";
            this.checkBoxFARajendranUseFaultImpacts2.UseVisualStyleBackColor = true;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.ForeColor = System.Drawing.Color.Red;
            this.label102.Location = new System.Drawing.Point(16, 586);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(43, 13);
            this.label102.TabIndex = 141;
            this.label102.Text = "Synced";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.ForeColor = System.Drawing.Color.Red;
            this.label101.Location = new System.Drawing.Point(16, 508);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(43, 13);
            this.label101.TabIndex = 140;
            this.label101.Text = "Synced";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.ForeColor = System.Drawing.Color.Red;
            this.label100.Location = new System.Drawing.Point(16, 447);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(43, 13);
            this.label100.TabIndex = 139;
            this.label100.Text = "Synced";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.ForeColor = System.Drawing.Color.Red;
            this.label99.Location = new System.Drawing.Point(16, 386);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(43, 13);
            this.label99.TabIndex = 138;
            this.label99.Text = "Synced";
            // 
            // buttonAlg11
            // 
            this.buttonAlg11.Location = new System.Drawing.Point(96, 487);
            this.buttonAlg11.Name = "buttonAlg11";
            this.buttonAlg11.Size = new System.Drawing.Size(187, 55);
            this.buttonAlg11.TabIndex = 137;
            this.buttonAlg11.Text = "Alg11 FA Rajendran Enhanced\r\n(No Duplicate FI Net, XOR && XNOR KeyGate, KeyInput," +
    " KeyInverter)";
            this.buttonAlg11.UseVisualStyleBackColor = true;
            this.buttonAlg11.Click += new System.EventHandler(this.buttonAlg11_Click);
            // 
            // buttonFARajendranAlg10
            // 
            this.buttonFARajendranAlg10.Location = new System.Drawing.Point(96, 426);
            this.buttonFARajendranAlg10.Name = "buttonFARajendranAlg10";
            this.buttonFARajendranAlg10.Size = new System.Drawing.Size(187, 55);
            this.buttonFARajendranAlg10.TabIndex = 136;
            this.buttonFARajendranAlg10.Text = "Alg10 FA Rajendran \r\n(No Duplicate FI Net)";
            this.buttonFARajendranAlg10.UseVisualStyleBackColor = true;
            this.buttonFARajendranAlg10.Click += new System.EventHandler(this.buttonFARajendranAlg10_Click);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(93, 192);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(89, 13);
            this.label57.TabIndex = 135;
            this.label57.Text = "R Random Seed:";
            // 
            // numericUpDownFARajendranRRandomSeed
            // 
            this.numericUpDownFARajendranRRandomSeed.Location = new System.Drawing.Point(202, 190);
            this.numericUpDownFARajendranRRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownFARajendranRRandomSeed.Name = "numericUpDownFARajendranRRandomSeed";
            this.numericUpDownFARajendranRRandomSeed.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownFARajendranRRandomSeed.TabIndex = 134;
            this.numericUpDownFARajendranRRandomSeed.Value = new decimal(new int[] {
            198705,
            0,
            0,
            0});
            // 
            // checkBoxFARajendranReportProbabilitiesBeforeEncryption
            // 
            this.checkBoxFARajendranReportProbabilitiesBeforeEncryption.AutoSize = true;
            this.checkBoxFARajendranReportProbabilitiesBeforeEncryption.Checked = true;
            this.checkBoxFARajendranReportProbabilitiesBeforeEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxFARajendranReportProbabilitiesBeforeEncryption.Location = new System.Drawing.Point(96, 141);
            this.checkBoxFARajendranReportProbabilitiesBeforeEncryption.Name = "checkBoxFARajendranReportProbabilitiesBeforeEncryption";
            this.checkBoxFARajendranReportProbabilitiesBeforeEncryption.Size = new System.Drawing.Size(204, 17);
            this.checkBoxFARajendranReportProbabilitiesBeforeEncryption.TabIndex = 133;
            this.checkBoxFARajendranReportProbabilitiesBeforeEncryption.Text = "Report Probabilities Before Encryption";
            this.checkBoxFARajendranReportProbabilitiesBeforeEncryption.UseVisualStyleBackColor = true;
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.Color.Black;
            this.label55.Location = new System.Drawing.Point(-3, 360);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(400, 2);
            this.label55.TabIndex = 132;
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.Color.Black;
            this.label54.Location = new System.Drawing.Point(-3, 251);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(400, 2);
            this.label54.TabIndex = 131;
            // 
            // buttonFARajendranAsIPresumeItIsEncrypt
            // 
            this.buttonFARajendranAsIPresumeItIsEncrypt.Enabled = false;
            this.buttonFARajendranAsIPresumeItIsEncrypt.Location = new System.Drawing.Point(96, 548);
            this.buttonFARajendranAsIPresumeItIsEncrypt.Name = "buttonFARajendranAsIPresumeItIsEncrypt";
            this.buttonFARajendranAsIPresumeItIsEncrypt.Size = new System.Drawing.Size(187, 88);
            this.buttonFARajendranAsIPresumeItIsEncrypt.TabIndex = 130;
            this.buttonFARajendranAsIPresumeItIsEncrypt.Text = "Alg02 FA Rajendran \r\nCorrupted\r\n(No Duplicate FI Net, XOR KeyGate, KeyInput)";
            this.buttonFARajendranAsIPresumeItIsEncrypt.UseVisualStyleBackColor = true;
            this.buttonFARajendranAsIPresumeItIsEncrypt.Click += new System.EventHandler(this.buttonFARajendranAsIPresumeItIsEncrypt_Click);
            // 
            // buttonFARajendranOriginalEncrypt
            // 
            this.buttonFARajendranOriginalEncrypt.Location = new System.Drawing.Point(96, 365);
            this.buttonFARajendranOriginalEncrypt.Name = "buttonFARajendranOriginalEncrypt";
            this.buttonFARajendranOriginalEncrypt.Size = new System.Drawing.Size(187, 55);
            this.buttonFARajendranOriginalEncrypt.TabIndex = 23;
            this.buttonFARajendranOriginalEncrypt.Text = "Alg01 FA Rajendran\r\n(Original Paper)";
            this.buttonFARajendranOriginalEncrypt.UseVisualStyleBackColor = true;
            this.buttonFARajendranOriginalEncrypt.Click += new System.EventHandler(this.buttonFARajendranOriginalEncrypt_Click);
            // 
            // labelFARajendranGeneratedKeyLength
            // 
            this.labelFARajendranGeneratedKeyLength.AutoSize = true;
            this.labelFARajendranGeneratedKeyLength.Location = new System.Drawing.Point(199, 344);
            this.labelFARajendranGeneratedKeyLength.Name = "labelFARajendranGeneratedKeyLength";
            this.labelFARajendranGeneratedKeyLength.Size = new System.Drawing.Size(73, 13);
            this.labelFARajendranGeneratedKeyLength.TabIndex = 129;
            this.labelFARajendranGeneratedKeyLength.Text = "Key Length: 0";
            // 
            // textBoxFARajendranGeneratedKey
            // 
            this.textBoxFARajendranGeneratedKey.Location = new System.Drawing.Point(202, 321);
            this.textBoxFARajendranGeneratedKey.Name = "textBoxFARajendranGeneratedKey";
            this.textBoxFARajendranGeneratedKey.ReadOnly = true;
            this.textBoxFARajendranGeneratedKey.Size = new System.Drawing.Size(112, 20);
            this.textBoxFARajendranGeneratedKey.TabIndex = 128;
            this.textBoxFARajendranGeneratedKey.TextChanged += new System.EventHandler(this.textBoxFARajendranGeneratedKey_TextChanged);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(95, 322);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(81, 13);
            this.label42.TabIndex = 127;
            this.label42.Text = "Generated Key:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(93, 166);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(64, 13);
            this.label43.TabIndex = 126;
            this.label43.Text = "Key Length:";
            // 
            // numericUpDownFARajendranKeyLength
            // 
            this.numericUpDownFARajendranKeyLength.Location = new System.Drawing.Point(202, 164);
            this.numericUpDownFARajendranKeyLength.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownFARajendranKeyLength.Name = "numericUpDownFARajendranKeyLength";
            this.numericUpDownFARajendranKeyLength.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownFARajendranKeyLength.TabIndex = 125;
            this.numericUpDownFARajendranKeyLength.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(93, 297);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(99, 13);
            this.label44.TabIndex = 124;
            this.label44.Text = "Directory Comment:";
            // 
            // textBoxFARajendranDirectoryComment
            // 
            this.textBoxFARajendranDirectoryComment.Location = new System.Drawing.Point(202, 294);
            this.textBoxFARajendranDirectoryComment.Name = "textBoxFARajendranDirectoryComment";
            this.textBoxFARajendranDirectoryComment.Size = new System.Drawing.Size(112, 20);
            this.textBoxFARajendranDirectoryComment.TabIndex = 123;
            // 
            // checkBoxFARajendranDontUseCache
            // 
            this.checkBoxFARajendranDontUseCache.AutoSize = true;
            this.checkBoxFARajendranDontUseCache.Location = new System.Drawing.Point(96, 220);
            this.checkBoxFARajendranDontUseCache.Name = "checkBoxFARajendranDontUseCache";
            this.checkBoxFARajendranDontUseCache.Size = new System.Drawing.Size(107, 17);
            this.checkBoxFARajendranDontUseCache.TabIndex = 122;
            this.checkBoxFARajendranDontUseCache.Text = "Don\'t Use Cache";
            this.checkBoxFARajendranDontUseCache.UseVisualStyleBackColor = true;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(93, 271);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(82, 13);
            this.label45.TabIndex = 121;
            this.label45.Text = "Inline Comment:";
            // 
            // textBoxFARajendranInlineComment
            // 
            this.textBoxFARajendranInlineComment.Location = new System.Drawing.Point(202, 268);
            this.textBoxFARajendranInlineComment.Name = "textBoxFARajendranInlineComment";
            this.textBoxFARajendranInlineComment.Size = new System.Drawing.Size(112, 20);
            this.textBoxFARajendranInlineComment.TabIndex = 120;
            // 
            // checkBoxFARajendranRandomSeed
            // 
            this.checkBoxFARajendranRandomSeed.AutoSize = true;
            this.checkBoxFARajendranRandomSeed.Location = new System.Drawing.Point(96, 113);
            this.checkBoxFARajendranRandomSeed.Name = "checkBoxFARajendranRandomSeed";
            this.checkBoxFARajendranRandomSeed.Size = new System.Drawing.Size(97, 17);
            this.checkBoxFARajendranRandomSeed.TabIndex = 119;
            this.checkBoxFARajendranRandomSeed.Text = "Random Seed:";
            this.checkBoxFARajendranRandomSeed.UseVisualStyleBackColor = true;
            // 
            // checkBoxFARajendranUniqueRandomPatterns
            // 
            this.checkBoxFARajendranUniqueRandomPatterns.AutoSize = true;
            this.checkBoxFARajendranUniqueRandomPatterns.Checked = true;
            this.checkBoxFARajendranUniqueRandomPatterns.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxFARajendranUniqueRandomPatterns.Location = new System.Drawing.Point(96, 35);
            this.checkBoxFARajendranUniqueRandomPatterns.Name = "checkBoxFARajendranUniqueRandomPatterns";
            this.checkBoxFARajendranUniqueRandomPatterns.Size = new System.Drawing.Size(145, 17);
            this.checkBoxFARajendranUniqueRandomPatterns.TabIndex = 118;
            this.checkBoxFARajendranUniqueRandomPatterns.Text = "Unique Random Patterns";
            this.checkBoxFARajendranUniqueRandomPatterns.UseVisualStyleBackColor = true;
            // 
            // numericUpDownFARajendranRandomSeed
            // 
            this.numericUpDownFARajendranRandomSeed.Location = new System.Drawing.Point(202, 111);
            this.numericUpDownFARajendranRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownFARajendranRandomSeed.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownFARajendranRandomSeed.Name = "numericUpDownFARajendranRandomSeed";
            this.numericUpDownFARajendranRandomSeed.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownFARajendranRandomSeed.TabIndex = 117;
            this.numericUpDownFARajendranRandomSeed.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDownFARajendranNumberOfThreads
            // 
            this.numericUpDownFARajendranNumberOfThreads.Location = new System.Drawing.Point(202, 85);
            this.numericUpDownFARajendranNumberOfThreads.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownFARajendranNumberOfThreads.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownFARajendranNumberOfThreads.Name = "numericUpDownFARajendranNumberOfThreads";
            this.numericUpDownFARajendranNumberOfThreads.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownFARajendranNumberOfThreads.TabIndex = 115;
            this.numericUpDownFARajendranNumberOfThreads.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(93, 59);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(66, 13);
            this.label46.TabIndex = 114;
            this.label46.Text = "Clock Ticks:";
            // 
            // numericUpDownFARajendranClockTimes
            // 
            this.numericUpDownFARajendranClockTimes.Location = new System.Drawing.Point(202, 59);
            this.numericUpDownFARajendranClockTimes.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownFARajendranClockTimes.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownFARajendranClockTimes.Name = "numericUpDownFARajendranClockTimes";
            this.numericUpDownFARajendranClockTimes.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownFARajendranClockTimes.TabIndex = 113;
            this.numericUpDownFARajendranClockTimes.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(93, 13);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(92, 13);
            this.label47.TabIndex = 112;
            this.label47.Text = "Random Patterns:";
            // 
            // numericUpDownFARajendranRandomPatterns
            // 
            this.numericUpDownFARajendranRandomPatterns.Location = new System.Drawing.Point(202, 11);
            this.numericUpDownFARajendranRandomPatterns.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownFARajendranRandomPatterns.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownFARajendranRandomPatterns.Name = "numericUpDownFARajendranRandomPatterns";
            this.numericUpDownFARajendranRandomPatterns.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownFARajendranRandomPatterns.TabIndex = 111;
            this.numericUpDownFARajendranRandomPatterns.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(93, 87);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(103, 13);
            this.label48.TabIndex = 116;
            this.label48.Text = "Number Of Threads:";
            // 
            // tabPageGreedyXAlgorithm
            // 
            this.tabPageGreedyXAlgorithm.AutoScroll = true;
            this.tabPageGreedyXAlgorithm.Controls.Add(this.groupBox1);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.checkBoxGreedyInverterMode);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.buttonAlg25);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.label103);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.numericUpDownAlg14GreedyNumberOfThreads);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.label82);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.label81);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.numericUpDownAlg14GreedyRRandomSeed);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.label75);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.label76);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.labelAlg14GreedyGeneratedKeyLength);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.textBoxAlg14GreedyGeneratedKey);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.label77);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.label78);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.numericUpDownAlg14GreedyKeyLength);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.label79);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.textBoxAlg14GreedyDirectoryComment);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.checkBoxAlg14GreedyDontUseCache);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.label80);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.textBoxAlg14GreedyInlineComment);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.buttonAlg14GreedyXKeys);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.checkBoxAlg14GreedyHammingDistanceForceWrongInputs);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.numericUpDownAlg14GreedyClockTimes);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.label73);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.checkBoxAlg14GreedyRandomSeed);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.checkBoxAlg14GreedyUniqueRandomPatterns);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.numericUpDownAlg14GreedyRandomSeed);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.label74);
            this.tabPageGreedyXAlgorithm.Controls.Add(this.numericUpDownAlg14GreedyRandomPatterns);
            this.tabPageGreedyXAlgorithm.Location = new System.Drawing.Point(4, 22);
            this.tabPageGreedyXAlgorithm.Name = "tabPageGreedyXAlgorithm";
            this.tabPageGreedyXAlgorithm.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageGreedyXAlgorithm.Size = new System.Drawing.Size(456, 451);
            this.tabPageGreedyXAlgorithm.TabIndex = 8;
            this.tabPageGreedyXAlgorithm.Text = "Greedy";
            this.tabPageGreedyXAlgorithm.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonHDLRSmartGreedy);
            this.groupBox1.Controls.Add(this.radioButtonSmartGreedy);
            this.groupBox1.Controls.Add(this.radioButtonHDPower2SmartGreedy);
            this.groupBox1.Controls.Add(this.labelRareThreshold);
            this.groupBox1.Controls.Add(this.numericUpDownRareThreshold);
            this.groupBox1.Location = new System.Drawing.Point(225, 449);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(187, 133);
            this.groupBox1.TabIndex = 270;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Algorithm";
            // 
            // radioButtonHDLRSmartGreedy
            // 
            this.radioButtonHDLRSmartGreedy.AutoSize = true;
            this.radioButtonHDLRSmartGreedy.Location = new System.Drawing.Point(9, 96);
            this.radioButtonHDLRSmartGreedy.Name = "radioButtonHDLRSmartGreedy";
            this.radioButtonHDLRSmartGreedy.Size = new System.Drawing.Size(173, 17);
            this.radioButtonHDLRSmartGreedy.TabIndex = 272;
            this.radioButtonHDLRSmartGreedy.Text = "(HD) / (1+ Log(1 + rareSignals))";
            this.radioButtonHDLRSmartGreedy.UseVisualStyleBackColor = true;
            // 
            // radioButtonSmartGreedy
            // 
            this.radioButtonSmartGreedy.AutoSize = true;
            this.radioButtonSmartGreedy.Checked = true;
            this.radioButtonSmartGreedy.Location = new System.Drawing.Point(9, 50);
            this.radioButtonSmartGreedy.Name = "radioButtonSmartGreedy";
            this.radioButtonSmartGreedy.Size = new System.Drawing.Size(110, 17);
            this.radioButtonSmartGreedy.TabIndex = 271;
            this.radioButtonSmartGreedy.TabStop = true;
            this.radioButtonSmartGreedy.Text = "(HD) / rareSignals";
            this.radioButtonSmartGreedy.UseVisualStyleBackColor = true;
            // 
            // radioButtonHDPower2SmartGreedy
            // 
            this.radioButtonHDPower2SmartGreedy.AutoSize = true;
            this.radioButtonHDPower2SmartGreedy.Location = new System.Drawing.Point(9, 73);
            this.radioButtonHDPower2SmartGreedy.Name = "radioButtonHDPower2SmartGreedy";
            this.radioButtonHDPower2SmartGreedy.Size = new System.Drawing.Size(128, 17);
            this.radioButtonHDPower2SmartGreedy.TabIndex = 270;
            this.radioButtonHDPower2SmartGreedy.Text = "(HD ^ 2) / rareSignals";
            this.radioButtonHDPower2SmartGreedy.UseVisualStyleBackColor = true;
            // 
            // labelRareThreshold
            // 
            this.labelRareThreshold.AutoSize = true;
            this.labelRareThreshold.Location = new System.Drawing.Point(6, 13);
            this.labelRareThreshold.Name = "labelRareThreshold";
            this.labelRareThreshold.Size = new System.Drawing.Size(161, 13);
            this.labelRareThreshold.TabIndex = 268;
            this.labelRareThreshold.Text = "Rare Threshold: (< 0.01 && 0.99>)";
            // 
            // numericUpDownRareThreshold
            // 
            this.numericUpDownRareThreshold.DecimalPlaces = 4;
            this.numericUpDownRareThreshold.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numericUpDownRareThreshold.Location = new System.Drawing.Point(99, 29);
            this.numericUpDownRareThreshold.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.numericUpDownRareThreshold.Name = "numericUpDownRareThreshold";
            this.numericUpDownRareThreshold.Size = new System.Drawing.Size(68, 20);
            this.numericUpDownRareThreshold.TabIndex = 267;
            this.numericUpDownRareThreshold.Value = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDownRareThreshold.ValueChanged += new System.EventHandler(this.numericUpDownRareThreshold_ValueChanged);
            // 
            // checkBoxGreedyInverterMode
            // 
            this.checkBoxGreedyInverterMode.AutoSize = true;
            this.checkBoxGreedyInverterMode.Location = new System.Drawing.Point(99, 103);
            this.checkBoxGreedyInverterMode.Name = "checkBoxGreedyInverterMode";
            this.checkBoxGreedyInverterMode.Size = new System.Drawing.Size(92, 17);
            this.checkBoxGreedyInverterMode.TabIndex = 165;
            this.checkBoxGreedyInverterMode.Text = "Inverter Mode";
            this.checkBoxGreedyInverterMode.UseVisualStyleBackColor = true;
            // 
            // buttonAlg25
            // 
            this.buttonAlg25.Location = new System.Drawing.Point(85, 455);
            this.buttonAlg25.Name = "buttonAlg25";
            this.buttonAlg25.Size = new System.Drawing.Size(134, 114);
            this.buttonAlg25.TabIndex = 266;
            this.buttonAlg25.Text = "Alg25 Smart Greedy";
            this.buttonAlg25.UseVisualStyleBackColor = true;
            this.buttonAlg25.Click += new System.EventHandler(this.buttonAlg25_Click);
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.ForeColor = System.Drawing.Color.Red;
            this.label103.Location = new System.Drawing.Point(36, 411);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(43, 13);
            this.label103.TabIndex = 164;
            this.label103.Text = "Synced";
            // 
            // numericUpDownAlg14GreedyNumberOfThreads
            // 
            this.numericUpDownAlg14GreedyNumberOfThreads.Location = new System.Drawing.Point(204, 149);
            this.numericUpDownAlg14GreedyNumberOfThreads.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownAlg14GreedyNumberOfThreads.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownAlg14GreedyNumberOfThreads.Name = "numericUpDownAlg14GreedyNumberOfThreads";
            this.numericUpDownAlg14GreedyNumberOfThreads.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownAlg14GreedyNumberOfThreads.TabIndex = 162;
            this.numericUpDownAlg14GreedyNumberOfThreads.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(95, 151);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(103, 13);
            this.label82.TabIndex = 163;
            this.label82.Text = "Number Of Threads:";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(96, 253);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(89, 13);
            this.label81.TabIndex = 161;
            this.label81.Text = "R Random Seed:";
            // 
            // numericUpDownAlg14GreedyRRandomSeed
            // 
            this.numericUpDownAlg14GreedyRRandomSeed.Location = new System.Drawing.Point(205, 251);
            this.numericUpDownAlg14GreedyRRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownAlg14GreedyRRandomSeed.Name = "numericUpDownAlg14GreedyRRandomSeed";
            this.numericUpDownAlg14GreedyRRandomSeed.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownAlg14GreedyRRandomSeed.TabIndex = 160;
            this.numericUpDownAlg14GreedyRRandomSeed.Value = new decimal(new int[] {
            198705,
            0,
            0,
            0});
            // 
            // checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption
            // 
            this.checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption.AutoSize = true;
            this.checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption.Checked = true;
            this.checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption.Location = new System.Drawing.Point(99, 173);
            this.checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption.Name = "checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption";
            this.checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption.Size = new System.Drawing.Size(204, 17);
            this.checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption.TabIndex = 159;
            this.checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption.Text = "Report Probabilities Before Encryption";
            this.checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption.UseVisualStyleBackColor = true;
            // 
            // label75
            // 
            this.label75.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label75.BackColor = System.Drawing.Color.Black;
            this.label75.Location = new System.Drawing.Point(0, 381);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(439, 2);
            this.label75.TabIndex = 158;
            // 
            // label76
            // 
            this.label76.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label76.BackColor = System.Drawing.Color.Black;
            this.label76.Location = new System.Drawing.Point(0, 275);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(439, 2);
            this.label76.TabIndex = 157;
            // 
            // labelAlg14GreedyGeneratedKeyLength
            // 
            this.labelAlg14GreedyGeneratedKeyLength.AutoSize = true;
            this.labelAlg14GreedyGeneratedKeyLength.Location = new System.Drawing.Point(202, 362);
            this.labelAlg14GreedyGeneratedKeyLength.Name = "labelAlg14GreedyGeneratedKeyLength";
            this.labelAlg14GreedyGeneratedKeyLength.Size = new System.Drawing.Size(73, 13);
            this.labelAlg14GreedyGeneratedKeyLength.TabIndex = 156;
            this.labelAlg14GreedyGeneratedKeyLength.Text = "Key Length: 0";
            // 
            // textBoxAlg14GreedyGeneratedKey
            // 
            this.textBoxAlg14GreedyGeneratedKey.Location = new System.Drawing.Point(205, 339);
            this.textBoxAlg14GreedyGeneratedKey.Name = "textBoxAlg14GreedyGeneratedKey";
            this.textBoxAlg14GreedyGeneratedKey.ReadOnly = true;
            this.textBoxAlg14GreedyGeneratedKey.Size = new System.Drawing.Size(112, 20);
            this.textBoxAlg14GreedyGeneratedKey.TabIndex = 155;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(98, 340);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(81, 13);
            this.label77.TabIndex = 154;
            this.label77.Text = "Generated Key:";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(96, 228);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(64, 13);
            this.label78.TabIndex = 153;
            this.label78.Text = "Key Length:";
            // 
            // numericUpDownAlg14GreedyKeyLength
            // 
            this.numericUpDownAlg14GreedyKeyLength.Location = new System.Drawing.Point(205, 226);
            this.numericUpDownAlg14GreedyKeyLength.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownAlg14GreedyKeyLength.Name = "numericUpDownAlg14GreedyKeyLength";
            this.numericUpDownAlg14GreedyKeyLength.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownAlg14GreedyKeyLength.TabIndex = 152;
            this.numericUpDownAlg14GreedyKeyLength.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(96, 315);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(99, 13);
            this.label79.TabIndex = 151;
            this.label79.Text = "Directory Comment:";
            // 
            // textBoxAlg14GreedyDirectoryComment
            // 
            this.textBoxAlg14GreedyDirectoryComment.Location = new System.Drawing.Point(205, 312);
            this.textBoxAlg14GreedyDirectoryComment.Name = "textBoxAlg14GreedyDirectoryComment";
            this.textBoxAlg14GreedyDirectoryComment.Size = new System.Drawing.Size(112, 20);
            this.textBoxAlg14GreedyDirectoryComment.TabIndex = 150;
            // 
            // checkBoxAlg14GreedyDontUseCache
            // 
            this.checkBoxAlg14GreedyDontUseCache.AutoSize = true;
            this.checkBoxAlg14GreedyDontUseCache.Location = new System.Drawing.Point(99, 203);
            this.checkBoxAlg14GreedyDontUseCache.Name = "checkBoxAlg14GreedyDontUseCache";
            this.checkBoxAlg14GreedyDontUseCache.Size = new System.Drawing.Size(107, 17);
            this.checkBoxAlg14GreedyDontUseCache.TabIndex = 149;
            this.checkBoxAlg14GreedyDontUseCache.Text = "Don\'t Use Cache";
            this.checkBoxAlg14GreedyDontUseCache.UseVisualStyleBackColor = true;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(96, 289);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(82, 13);
            this.label80.TabIndex = 148;
            this.label80.Text = "Inline Comment:";
            // 
            // textBoxAlg14GreedyInlineComment
            // 
            this.textBoxAlg14GreedyInlineComment.Location = new System.Drawing.Point(205, 286);
            this.textBoxAlg14GreedyInlineComment.Name = "textBoxAlg14GreedyInlineComment";
            this.textBoxAlg14GreedyInlineComment.Size = new System.Drawing.Size(112, 20);
            this.textBoxAlg14GreedyInlineComment.TabIndex = 147;
            // 
            // buttonAlg14GreedyXKeys
            // 
            this.buttonAlg14GreedyXKeys.Location = new System.Drawing.Point(85, 390);
            this.buttonAlg14GreedyXKeys.Name = "buttonAlg14GreedyXKeys";
            this.buttonAlg14GreedyXKeys.Size = new System.Drawing.Size(327, 55);
            this.buttonAlg14GreedyXKeys.TabIndex = 138;
            this.buttonAlg14GreedyXKeys.Text = "Alg 14 Greedy XKeys\r\nProposedAlg2";
            this.buttonAlg14GreedyXKeys.UseVisualStyleBackColor = true;
            this.buttonAlg14GreedyXKeys.Click += new System.EventHandler(this.buttonAlg14GreedyXKeys_Click);
            // 
            // checkBoxAlg14GreedyHammingDistanceForceWrongInputs
            // 
            this.checkBoxAlg14GreedyHammingDistanceForceWrongInputs.AutoSize = true;
            this.checkBoxAlg14GreedyHammingDistanceForceWrongInputs.Location = new System.Drawing.Point(99, 127);
            this.checkBoxAlg14GreedyHammingDistanceForceWrongInputs.Name = "checkBoxAlg14GreedyHammingDistanceForceWrongInputs";
            this.checkBoxAlg14GreedyHammingDistanceForceWrongInputs.Size = new System.Drawing.Size(120, 17);
            this.checkBoxAlg14GreedyHammingDistanceForceWrongInputs.TabIndex = 63;
            this.checkBoxAlg14GreedyHammingDistanceForceWrongInputs.Text = "Force Wrong Inputs";
            this.checkBoxAlg14GreedyHammingDistanceForceWrongInputs.UseVisualStyleBackColor = true;
            // 
            // numericUpDownAlg14GreedyClockTimes
            // 
            this.numericUpDownAlg14GreedyClockTimes.Location = new System.Drawing.Point(205, 79);
            this.numericUpDownAlg14GreedyClockTimes.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownAlg14GreedyClockTimes.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownAlg14GreedyClockTimes.Name = "numericUpDownAlg14GreedyClockTimes";
            this.numericUpDownAlg14GreedyClockTimes.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownAlg14GreedyClockTimes.TabIndex = 61;
            this.numericUpDownAlg14GreedyClockTimes.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(96, 81);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(66, 13);
            this.label73.TabIndex = 62;
            this.label73.Text = "Clock Ticks:";
            // 
            // checkBoxAlg14GreedyRandomSeed
            // 
            this.checkBoxAlg14GreedyRandomSeed.AutoSize = true;
            this.checkBoxAlg14GreedyRandomSeed.Enabled = false;
            this.checkBoxAlg14GreedyRandomSeed.Location = new System.Drawing.Point(99, 52);
            this.checkBoxAlg14GreedyRandomSeed.Name = "checkBoxAlg14GreedyRandomSeed";
            this.checkBoxAlg14GreedyRandomSeed.Size = new System.Drawing.Size(97, 17);
            this.checkBoxAlg14GreedyRandomSeed.TabIndex = 60;
            this.checkBoxAlg14GreedyRandomSeed.Text = "Random Seed:";
            this.checkBoxAlg14GreedyRandomSeed.UseVisualStyleBackColor = true;
            // 
            // checkBoxAlg14GreedyUniqueRandomPatterns
            // 
            this.checkBoxAlg14GreedyUniqueRandomPatterns.AutoSize = true;
            this.checkBoxAlg14GreedyUniqueRandomPatterns.Checked = true;
            this.checkBoxAlg14GreedyUniqueRandomPatterns.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAlg14GreedyUniqueRandomPatterns.Location = new System.Drawing.Point(99, 29);
            this.checkBoxAlg14GreedyUniqueRandomPatterns.Name = "checkBoxAlg14GreedyUniqueRandomPatterns";
            this.checkBoxAlg14GreedyUniqueRandomPatterns.Size = new System.Drawing.Size(145, 17);
            this.checkBoxAlg14GreedyUniqueRandomPatterns.TabIndex = 59;
            this.checkBoxAlg14GreedyUniqueRandomPatterns.Text = "Unique Random Patterns";
            this.checkBoxAlg14GreedyUniqueRandomPatterns.UseVisualStyleBackColor = true;
            // 
            // numericUpDownAlg14GreedyRandomSeed
            // 
            this.numericUpDownAlg14GreedyRandomSeed.Location = new System.Drawing.Point(205, 50);
            this.numericUpDownAlg14GreedyRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownAlg14GreedyRandomSeed.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownAlg14GreedyRandomSeed.Name = "numericUpDownAlg14GreedyRandomSeed";
            this.numericUpDownAlg14GreedyRandomSeed.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownAlg14GreedyRandomSeed.TabIndex = 58;
            this.numericUpDownAlg14GreedyRandomSeed.Value = new decimal(new int[] {
            2015,
            0,
            0,
            0});
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(96, 7);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(92, 13);
            this.label74.TabIndex = 57;
            this.label74.Text = "Random Patterns:";
            // 
            // numericUpDownAlg14GreedyRandomPatterns
            // 
            this.numericUpDownAlg14GreedyRandomPatterns.Location = new System.Drawing.Point(205, 5);
            this.numericUpDownAlg14GreedyRandomPatterns.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownAlg14GreedyRandomPatterns.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownAlg14GreedyRandomPatterns.Name = "numericUpDownAlg14GreedyRandomPatterns";
            this.numericUpDownAlg14GreedyRandomPatterns.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownAlg14GreedyRandomPatterns.TabIndex = 56;
            this.numericUpDownAlg14GreedyRandomPatterns.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // tabPageSamimi02Combined
            // 
            this.tabPageSamimi02Combined.AutoScroll = true;
            this.tabPageSamimi02Combined.Controls.Add(this.label130);
            this.tabPageSamimi02Combined.Controls.Add(this.checkBoxAlg24Key);
            this.tabPageSamimi02Combined.Controls.Add(this.buttonAlg24);
            this.tabPageSamimi02Combined.Controls.Add(this.checkBoxAlg23Key);
            this.tabPageSamimi02Combined.Controls.Add(this.buttonAlg23);
            this.tabPageSamimi02Combined.Controls.Add(this.checkBoxCombined2PHTDontUseCache);
            this.tabPageSamimi02Combined.Controls.Add(this.buttonSamimi02Encrypt);
            this.tabPageSamimi02Combined.Controls.Add(this.label106);
            this.tabPageSamimi02Combined.Controls.Add(this.label107);
            this.tabPageSamimi02Combined.Controls.Add(this.label108);
            this.tabPageSamimi02Combined.Controls.Add(this.labelCombined2GeneratedKeyLength);
            this.tabPageSamimi02Combined.Controls.Add(this.textBoxCombined2GeneratedKey);
            this.tabPageSamimi02Combined.Controls.Add(this.label109);
            this.tabPageSamimi02Combined.Controls.Add(this.label110);
            this.tabPageSamimi02Combined.Controls.Add(this.textBoxCombined2DirectoryComment);
            this.tabPageSamimi02Combined.Controls.Add(this.label111);
            this.tabPageSamimi02Combined.Controls.Add(this.textBoxCombined2InlineComment);
            this.tabPageSamimi02Combined.Controls.Add(this.label112);
            this.tabPageSamimi02Combined.Controls.Add(this.label113);
            this.tabPageSamimi02Combined.Controls.Add(this.label114);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2KeyLength);
            this.tabPageSamimi02Combined.Controls.Add(this.label115);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2PHTClockTicksHT);
            this.tabPageSamimi02Combined.Controls.Add(this.label116);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2PHTRandomPatternsHT);
            this.tabPageSamimi02Combined.Controls.Add(this.label117);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2PHTRandomSeedHT);
            this.tabPageSamimi02Combined.Controls.Add(this.label118);
            this.tabPageSamimi02Combined.Controls.Add(this.checkBoxCombined2PHTReportSlackTimesBeforeEncryption);
            this.tabPageSamimi02Combined.Controls.Add(this.checkBoxCombined2PHTReportProbabilitiesBeforeEncryption);
            this.tabPageSamimi02Combined.Controls.Add(this.label119);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2PHTMaxHTKeyLength);
            this.tabPageSamimi02Combined.Controls.Add(this.label120);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2PHTProbMin);
            this.tabPageSamimi02Combined.Controls.Add(this.label121);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2PHTSlackMin);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2PHTThresholdHT);
            this.tabPageSamimi02Combined.Controls.Add(this.checkBoxCombined2PHTMeetThresholdHT);
            this.tabPageSamimi02Combined.Controls.Add(this.checkBoxCombined2PHTConsiderSlackTime);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2PGNumberOfThreads);
            this.tabPageSamimi02Combined.Controls.Add(this.label122);
            this.tabPageSamimi02Combined.Controls.Add(this.label123);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2PGKeyRandomSeed);
            this.tabPageSamimi02Combined.Controls.Add(this.checkBoxCombined2PGReportProbabilitiesBeforeEncryption);
            this.tabPageSamimi02Combined.Controls.Add(this.checkBoxCombined2PGDontUseCache);
            this.tabPageSamimi02Combined.Controls.Add(this.checkBoxCombined2PGHammingDistanceForceWrongInputs);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2PGClockTimes);
            this.tabPageSamimi02Combined.Controls.Add(this.label124);
            this.tabPageSamimi02Combined.Controls.Add(this.checkBoxCombined2PGUniqueRandomPatterns);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2PGRandomSeed);
            this.tabPageSamimi02Combined.Controls.Add(this.label125);
            this.tabPageSamimi02Combined.Controls.Add(this.numericUpDownCombined2PGRandomPatterns);
            this.tabPageSamimi02Combined.Location = new System.Drawing.Point(4, 22);
            this.tabPageSamimi02Combined.Name = "tabPageSamimi02Combined";
            this.tabPageSamimi02Combined.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSamimi02Combined.Size = new System.Drawing.Size(456, 451);
            this.tabPageSamimi02Combined.TabIndex = 10;
            this.tabPageSamimi02Combined.Text = "Combined AntiHT & Greedy";
            this.tabPageSamimi02Combined.UseVisualStyleBackColor = true;
            // 
            // label130
            // 
            this.label130.BackColor = System.Drawing.Color.Black;
            this.label130.Location = new System.Drawing.Point(-8, 736);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(400, 2);
            this.label130.TabIndex = 265;
            // 
            // checkBoxAlg24Key
            // 
            this.checkBoxAlg24Key.AutoSize = true;
            this.checkBoxAlg24Key.Checked = true;
            this.checkBoxAlg24Key.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAlg24Key.Location = new System.Drawing.Point(218, 815);
            this.checkBoxAlg24Key.Name = "checkBoxAlg24Key";
            this.checkBoxAlg24Key.Size = new System.Drawing.Size(132, 17);
            this.checkBoxAlg24Key.TabIndex = 264;
            this.checkBoxAlg24Key.Text = "Fill 128bit Key Lengths";
            this.checkBoxAlg24Key.UseVisualStyleBackColor = true;
            // 
            // buttonAlg24
            // 
            this.buttonAlg24.Location = new System.Drawing.Point(54, 797);
            this.buttonAlg24.Name = "buttonAlg24";
            this.buttonAlg24.Size = new System.Drawing.Size(158, 50);
            this.buttonAlg24.TabIndex = 263;
            this.buttonAlg24.Text = "Alg24 = Alg23 (No Slacktime)\r\nProposedAlg3";
            this.buttonAlg24.UseVisualStyleBackColor = true;
            this.buttonAlg24.Click += new System.EventHandler(this.buttonAlg24_Click);
            // 
            // checkBoxAlg23Key
            // 
            this.checkBoxAlg23Key.AutoSize = true;
            this.checkBoxAlg23Key.Checked = true;
            this.checkBoxAlg23Key.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAlg23Key.Location = new System.Drawing.Point(218, 759);
            this.checkBoxAlg23Key.Name = "checkBoxAlg23Key";
            this.checkBoxAlg23Key.Size = new System.Drawing.Size(132, 17);
            this.checkBoxAlg23Key.TabIndex = 262;
            this.checkBoxAlg23Key.Text = "Fill 128bit Key Lengths";
            this.checkBoxAlg23Key.UseVisualStyleBackColor = true;
            // 
            // buttonAlg23
            // 
            this.buttonAlg23.Location = new System.Drawing.Point(54, 741);
            this.buttonAlg23.Name = "buttonAlg23";
            this.buttonAlg23.Size = new System.Drawing.Size(158, 50);
            this.buttonAlg23.TabIndex = 261;
            this.buttonAlg23.Text = "Alg23";
            this.buttonAlg23.UseVisualStyleBackColor = true;
            this.buttonAlg23.Click += new System.EventHandler(this.buttonAlg23_Click);
            // 
            // checkBoxCombined2PHTDontUseCache
            // 
            this.checkBoxCombined2PHTDontUseCache.AutoSize = true;
            this.checkBoxCombined2PHTDontUseCache.Location = new System.Drawing.Point(94, 224);
            this.checkBoxCombined2PHTDontUseCache.Name = "checkBoxCombined2PHTDontUseCache";
            this.checkBoxCombined2PHTDontUseCache.Size = new System.Drawing.Size(107, 17);
            this.checkBoxCombined2PHTDontUseCache.TabIndex = 260;
            this.checkBoxCombined2PHTDontUseCache.Text = "Don\'t Use Cache";
            this.checkBoxCombined2PHTDontUseCache.UseVisualStyleBackColor = true;
            // 
            // buttonSamimi02Encrypt
            // 
            this.buttonSamimi02Encrypt.Location = new System.Drawing.Point(54, 683);
            this.buttonSamimi02Encrypt.Name = "buttonSamimi02Encrypt";
            this.buttonSamimi02Encrypt.Size = new System.Drawing.Size(296, 50);
            this.buttonSamimi02Encrypt.TabIndex = 259;
            this.buttonSamimi02Encrypt.Text = "Combined 2 Encrypt";
            this.buttonSamimi02Encrypt.UseVisualStyleBackColor = true;
            this.buttonSamimi02Encrypt.Click += new System.EventHandler(this.buttonSamimi02Encrypt_Click);
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(6, 292);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(107, 13);
            this.label106.TabIndex = 258;
            this.label106.Text = "Section Greedy HDs:";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(93, 361);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(78, 13);
            this.label107.TabIndex = 257;
            this.label107.Text = "Random Seed:";
            // 
            // label108
            // 
            this.label108.BackColor = System.Drawing.Color.Black;
            this.label108.Location = new System.Drawing.Point(-8, 672);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(400, 2);
            this.label108.TabIndex = 256;
            // 
            // labelCombined2GeneratedKeyLength
            // 
            this.labelCombined2GeneratedKeyLength.AutoSize = true;
            this.labelCombined2GeneratedKeyLength.Location = new System.Drawing.Point(198, 649);
            this.labelCombined2GeneratedKeyLength.Name = "labelCombined2GeneratedKeyLength";
            this.labelCombined2GeneratedKeyLength.Size = new System.Drawing.Size(73, 13);
            this.labelCombined2GeneratedKeyLength.TabIndex = 255;
            this.labelCombined2GeneratedKeyLength.Text = "Key Length: 0";
            // 
            // textBoxCombined2GeneratedKey
            // 
            this.textBoxCombined2GeneratedKey.Location = new System.Drawing.Point(201, 626);
            this.textBoxCombined2GeneratedKey.Name = "textBoxCombined2GeneratedKey";
            this.textBoxCombined2GeneratedKey.ReadOnly = true;
            this.textBoxCombined2GeneratedKey.Size = new System.Drawing.Size(112, 20);
            this.textBoxCombined2GeneratedKey.TabIndex = 254;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(94, 627);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(81, 13);
            this.label109.TabIndex = 253;
            this.label109.Text = "Generated Key:";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(92, 602);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(99, 13);
            this.label110.TabIndex = 252;
            this.label110.Text = "Directory Comment:";
            // 
            // textBoxCombined2DirectoryComment
            // 
            this.textBoxCombined2DirectoryComment.Location = new System.Drawing.Point(201, 599);
            this.textBoxCombined2DirectoryComment.Name = "textBoxCombined2DirectoryComment";
            this.textBoxCombined2DirectoryComment.Size = new System.Drawing.Size(112, 20);
            this.textBoxCombined2DirectoryComment.TabIndex = 251;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(92, 576);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(82, 13);
            this.label111.TabIndex = 250;
            this.label111.Text = "Inline Comment:";
            // 
            // textBoxCombined2InlineComment
            // 
            this.textBoxCombined2InlineComment.Location = new System.Drawing.Point(201, 573);
            this.textBoxCombined2InlineComment.Name = "textBoxCombined2InlineComment";
            this.textBoxCombined2InlineComment.Size = new System.Drawing.Size(112, 20);
            this.textBoxCombined2InlineComment.TabIndex = 249;
            // 
            // label112
            // 
            this.label112.BackColor = System.Drawing.Color.Black;
            this.label112.Location = new System.Drawing.Point(-8, 561);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(400, 2);
            this.label112.TabIndex = 248;
            // 
            // label113
            // 
            this.label113.BackColor = System.Drawing.Color.Black;
            this.label113.Location = new System.Drawing.Point(-7, 287);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(400, 2);
            this.label113.TabIndex = 234;
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(93, 531);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(64, 13);
            this.label114.TabIndex = 233;
            this.label114.Text = "Key Length:";
            // 
            // numericUpDownCombined2KeyLength
            // 
            this.numericUpDownCombined2KeyLength.Location = new System.Drawing.Point(200, 529);
            this.numericUpDownCombined2KeyLength.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownCombined2KeyLength.Name = "numericUpDownCombined2KeyLength";
            this.numericUpDownCombined2KeyLength.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownCombined2KeyLength.TabIndex = 232;
            this.numericUpDownCombined2KeyLength.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(92, 103);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(66, 13);
            this.label115.TabIndex = 231;
            this.label115.Text = "Clock Ticks:";
            // 
            // numericUpDownCombined2PHTClockTicksHT
            // 
            this.numericUpDownCombined2PHTClockTicksHT.Location = new System.Drawing.Point(201, 103);
            this.numericUpDownCombined2PHTClockTicksHT.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownCombined2PHTClockTicksHT.Name = "numericUpDownCombined2PHTClockTicksHT";
            this.numericUpDownCombined2PHTClockTicksHT.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownCombined2PHTClockTicksHT.TabIndex = 230;
            this.numericUpDownCombined2PHTClockTicksHT.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(96, 26);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(92, 13);
            this.label116.TabIndex = 229;
            this.label116.Text = "Random Patterns:";
            // 
            // numericUpDownCombined2PHTRandomPatternsHT
            // 
            this.numericUpDownCombined2PHTRandomPatternsHT.Location = new System.Drawing.Point(202, 24);
            this.numericUpDownCombined2PHTRandomPatternsHT.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDownCombined2PHTRandomPatternsHT.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCombined2PHTRandomPatternsHT.Name = "numericUpDownCombined2PHTRandomPatternsHT";
            this.numericUpDownCombined2PHTRandomPatternsHT.Size = new System.Drawing.Size(111, 20);
            this.numericUpDownCombined2PHTRandomPatternsHT.TabIndex = 228;
            this.numericUpDownCombined2PHTRandomPatternsHT.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(6, 3);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(123, 13);
            this.label117.TabIndex = 227;
            this.label117.Text = "Section Probabilities HT:";
            // 
            // numericUpDownCombined2PHTRandomSeedHT
            // 
            this.numericUpDownCombined2PHTRandomSeedHT.Location = new System.Drawing.Point(201, 51);
            this.numericUpDownCombined2PHTRandomSeedHT.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownCombined2PHTRandomSeedHT.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCombined2PHTRandomSeedHT.Name = "numericUpDownCombined2PHTRandomSeedHT";
            this.numericUpDownCombined2PHTRandomSeedHT.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownCombined2PHTRandomSeedHT.TabIndex = 226;
            this.numericUpDownCombined2PHTRandomSeedHT.Value = new decimal(new int[] {
            309302,
            0,
            0,
            0});
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(96, 54);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(78, 13);
            this.label118.TabIndex = 225;
            this.label118.Text = "Random Seed:";
            // 
            // checkBoxCombined2PHTReportSlackTimesBeforeEncryption
            // 
            this.checkBoxCombined2PHTReportSlackTimesBeforeEncryption.AutoSize = true;
            this.checkBoxCombined2PHTReportSlackTimesBeforeEncryption.Location = new System.Drawing.Point(95, 269);
            this.checkBoxCombined2PHTReportSlackTimesBeforeEncryption.Name = "checkBoxCombined2PHTReportSlackTimesBeforeEncryption";
            this.checkBoxCombined2PHTReportSlackTimesBeforeEncryption.Size = new System.Drawing.Size(203, 17);
            this.checkBoxCombined2PHTReportSlackTimesBeforeEncryption.TabIndex = 224;
            this.checkBoxCombined2PHTReportSlackTimesBeforeEncryption.Text = "Report SlackTimes Before Encryption";
            this.checkBoxCombined2PHTReportSlackTimesBeforeEncryption.UseVisualStyleBackColor = true;
            // 
            // checkBoxCombined2PHTReportProbabilitiesBeforeEncryption
            // 
            this.checkBoxCombined2PHTReportProbabilitiesBeforeEncryption.AutoSize = true;
            this.checkBoxCombined2PHTReportProbabilitiesBeforeEncryption.Checked = true;
            this.checkBoxCombined2PHTReportProbabilitiesBeforeEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCombined2PHTReportProbabilitiesBeforeEncryption.Location = new System.Drawing.Point(95, 247);
            this.checkBoxCombined2PHTReportProbabilitiesBeforeEncryption.Name = "checkBoxCombined2PHTReportProbabilitiesBeforeEncryption";
            this.checkBoxCombined2PHTReportProbabilitiesBeforeEncryption.Size = new System.Drawing.Size(204, 17);
            this.checkBoxCombined2PHTReportProbabilitiesBeforeEncryption.TabIndex = 223;
            this.checkBoxCombined2PHTReportProbabilitiesBeforeEncryption.Text = "Report Probabilities Before Encryption";
            this.checkBoxCombined2PHTReportProbabilitiesBeforeEncryption.UseVisualStyleBackColor = true;
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(93, 204);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(105, 13);
            this.label119.TabIndex = 221;
            this.label119.Text = "Max HT Key Length:";
            // 
            // numericUpDownCombined2PHTMaxHTKeyLength
            // 
            this.numericUpDownCombined2PHTMaxHTKeyLength.Location = new System.Drawing.Point(201, 201);
            this.numericUpDownCombined2PHTMaxHTKeyLength.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownCombined2PHTMaxHTKeyLength.Name = "numericUpDownCombined2PHTMaxHTKeyLength";
            this.numericUpDownCombined2PHTMaxHTKeyLength.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownCombined2PHTMaxHTKeyLength.TabIndex = 220;
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(93, 177);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(78, 13);
            this.label120.TabIndex = 219;
            this.label120.Text = "Min Probability:";
            // 
            // numericUpDownCombined2PHTProbMin
            // 
            this.numericUpDownCombined2PHTProbMin.DecimalPlaces = 2;
            this.numericUpDownCombined2PHTProbMin.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.numericUpDownCombined2PHTProbMin.Location = new System.Drawing.Point(201, 175);
            this.numericUpDownCombined2PHTProbMin.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCombined2PHTProbMin.Name = "numericUpDownCombined2PHTProbMin";
            this.numericUpDownCombined2PHTProbMin.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownCombined2PHTProbMin.TabIndex = 218;
            this.numericUpDownCombined2PHTProbMin.Value = new decimal(new int[] {
            2,
            0,
            0,
            65536});
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(93, 151);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(76, 13);
            this.label121.TabIndex = 217;
            this.label121.Text = "Min Slacktime:";
            // 
            // numericUpDownCombined2PHTSlackMin
            // 
            this.numericUpDownCombined2PHTSlackMin.Location = new System.Drawing.Point(201, 149);
            this.numericUpDownCombined2PHTSlackMin.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownCombined2PHTSlackMin.Name = "numericUpDownCombined2PHTSlackMin";
            this.numericUpDownCombined2PHTSlackMin.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownCombined2PHTSlackMin.TabIndex = 216;
            this.numericUpDownCombined2PHTSlackMin.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // numericUpDownCombined2PHTThresholdHT
            // 
            this.numericUpDownCombined2PHTThresholdHT.DecimalPlaces = 10;
            this.numericUpDownCombined2PHTThresholdHT.Increment = new decimal(new int[] {
            1,
            0,
            0,
            393216});
            this.numericUpDownCombined2PHTThresholdHT.Location = new System.Drawing.Point(201, 77);
            this.numericUpDownCombined2PHTThresholdHT.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCombined2PHTThresholdHT.Name = "numericUpDownCombined2PHTThresholdHT";
            this.numericUpDownCombined2PHTThresholdHT.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownCombined2PHTThresholdHT.TabIndex = 215;
            this.numericUpDownCombined2PHTThresholdHT.Value = new decimal(new int[] {
            2,
            0,
            0,
            327680});
            // 
            // checkBoxCombined2PHTMeetThresholdHT
            // 
            this.checkBoxCombined2PHTMeetThresholdHT.AutoSize = true;
            this.checkBoxCombined2PHTMeetThresholdHT.Checked = true;
            this.checkBoxCombined2PHTMeetThresholdHT.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCombined2PHTMeetThresholdHT.Location = new System.Drawing.Point(96, 77);
            this.checkBoxCombined2PHTMeetThresholdHT.Name = "checkBoxCombined2PHTMeetThresholdHT";
            this.checkBoxCombined2PHTMeetThresholdHT.Size = new System.Drawing.Size(100, 17);
            this.checkBoxCombined2PHTMeetThresholdHT.TabIndex = 214;
            this.checkBoxCombined2PHTMeetThresholdHT.Text = "Meet Threshold";
            this.checkBoxCombined2PHTMeetThresholdHT.UseVisualStyleBackColor = true;
            // 
            // checkBoxCombined2PHTConsiderSlackTime
            // 
            this.checkBoxCombined2PHTConsiderSlackTime.AutoSize = true;
            this.checkBoxCombined2PHTConsiderSlackTime.Location = new System.Drawing.Point(96, 127);
            this.checkBoxCombined2PHTConsiderSlackTime.Name = "checkBoxCombined2PHTConsiderSlackTime";
            this.checkBoxCombined2PHTConsiderSlackTime.Size = new System.Drawing.Size(123, 17);
            this.checkBoxCombined2PHTConsiderSlackTime.TabIndex = 222;
            this.checkBoxCombined2PHTConsiderSlackTime.Text = "Consider Slack Time";
            this.checkBoxCombined2PHTConsiderSlackTime.UseVisualStyleBackColor = true;
            // 
            // numericUpDownCombined2PGNumberOfThreads
            // 
            this.numericUpDownCombined2PGNumberOfThreads.Location = new System.Drawing.Point(200, 433);
            this.numericUpDownCombined2PGNumberOfThreads.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownCombined2PGNumberOfThreads.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCombined2PGNumberOfThreads.Name = "numericUpDownCombined2PGNumberOfThreads";
            this.numericUpDownCombined2PGNumberOfThreads.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownCombined2PGNumberOfThreads.TabIndex = 246;
            this.numericUpDownCombined2PGNumberOfThreads.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(91, 435);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(103, 13);
            this.label122.TabIndex = 247;
            this.label122.Text = "Number Of Threads:";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(91, 505);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(89, 13);
            this.label123.TabIndex = 245;
            this.label123.Text = "R Random Seed:";
            // 
            // numericUpDownCombined2PGKeyRandomSeed
            // 
            this.numericUpDownCombined2PGKeyRandomSeed.Location = new System.Drawing.Point(200, 503);
            this.numericUpDownCombined2PGKeyRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownCombined2PGKeyRandomSeed.Name = "numericUpDownCombined2PGKeyRandomSeed";
            this.numericUpDownCombined2PGKeyRandomSeed.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownCombined2PGKeyRandomSeed.TabIndex = 244;
            this.numericUpDownCombined2PGKeyRandomSeed.Value = new decimal(new int[] {
            198705,
            0,
            0,
            0});
            // 
            // checkBoxCombined2PGReportProbabilitiesBeforeEncryption
            // 
            this.checkBoxCombined2PGReportProbabilitiesBeforeEncryption.AutoSize = true;
            this.checkBoxCombined2PGReportProbabilitiesBeforeEncryption.Checked = true;
            this.checkBoxCombined2PGReportProbabilitiesBeforeEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCombined2PGReportProbabilitiesBeforeEncryption.Location = new System.Drawing.Point(95, 457);
            this.checkBoxCombined2PGReportProbabilitiesBeforeEncryption.Name = "checkBoxCombined2PGReportProbabilitiesBeforeEncryption";
            this.checkBoxCombined2PGReportProbabilitiesBeforeEncryption.Size = new System.Drawing.Size(204, 17);
            this.checkBoxCombined2PGReportProbabilitiesBeforeEncryption.TabIndex = 243;
            this.checkBoxCombined2PGReportProbabilitiesBeforeEncryption.Text = "Report Probabilities Before Encryption";
            this.checkBoxCombined2PGReportProbabilitiesBeforeEncryption.UseVisualStyleBackColor = true;
            // 
            // checkBoxCombined2PGDontUseCache
            // 
            this.checkBoxCombined2PGDontUseCache.AutoSize = true;
            this.checkBoxCombined2PGDontUseCache.Location = new System.Drawing.Point(95, 480);
            this.checkBoxCombined2PGDontUseCache.Name = "checkBoxCombined2PGDontUseCache";
            this.checkBoxCombined2PGDontUseCache.Size = new System.Drawing.Size(107, 17);
            this.checkBoxCombined2PGDontUseCache.TabIndex = 242;
            this.checkBoxCombined2PGDontUseCache.Text = "Don\'t Use Cache";
            this.checkBoxCombined2PGDontUseCache.UseVisualStyleBackColor = true;
            // 
            // checkBoxCombined2PGHammingDistanceForceWrongInputs
            // 
            this.checkBoxCombined2PGHammingDistanceForceWrongInputs.AutoSize = true;
            this.checkBoxCombined2PGHammingDistanceForceWrongInputs.Location = new System.Drawing.Point(95, 412);
            this.checkBoxCombined2PGHammingDistanceForceWrongInputs.Name = "checkBoxCombined2PGHammingDistanceForceWrongInputs";
            this.checkBoxCombined2PGHammingDistanceForceWrongInputs.Size = new System.Drawing.Size(120, 17);
            this.checkBoxCombined2PGHammingDistanceForceWrongInputs.TabIndex = 241;
            this.checkBoxCombined2PGHammingDistanceForceWrongInputs.Text = "Force Wrong Inputs";
            this.checkBoxCombined2PGHammingDistanceForceWrongInputs.UseVisualStyleBackColor = true;
            // 
            // numericUpDownCombined2PGClockTimes
            // 
            this.numericUpDownCombined2PGClockTimes.Location = new System.Drawing.Point(201, 386);
            this.numericUpDownCombined2PGClockTimes.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownCombined2PGClockTimes.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCombined2PGClockTimes.Name = "numericUpDownCombined2PGClockTimes";
            this.numericUpDownCombined2PGClockTimes.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownCombined2PGClockTimes.TabIndex = 239;
            this.numericUpDownCombined2PGClockTimes.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(92, 388);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(66, 13);
            this.label124.TabIndex = 240;
            this.label124.Text = "Clock Ticks:";
            // 
            // checkBoxCombined2PGUniqueRandomPatterns
            // 
            this.checkBoxCombined2PGUniqueRandomPatterns.AutoSize = true;
            this.checkBoxCombined2PGUniqueRandomPatterns.Checked = true;
            this.checkBoxCombined2PGUniqueRandomPatterns.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCombined2PGUniqueRandomPatterns.Location = new System.Drawing.Point(95, 336);
            this.checkBoxCombined2PGUniqueRandomPatterns.Name = "checkBoxCombined2PGUniqueRandomPatterns";
            this.checkBoxCombined2PGUniqueRandomPatterns.Size = new System.Drawing.Size(145, 17);
            this.checkBoxCombined2PGUniqueRandomPatterns.TabIndex = 238;
            this.checkBoxCombined2PGUniqueRandomPatterns.Text = "Unique Random Patterns";
            this.checkBoxCombined2PGUniqueRandomPatterns.UseVisualStyleBackColor = true;
            // 
            // numericUpDownCombined2PGRandomSeed
            // 
            this.numericUpDownCombined2PGRandomSeed.Location = new System.Drawing.Point(201, 357);
            this.numericUpDownCombined2PGRandomSeed.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericUpDownCombined2PGRandomSeed.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCombined2PGRandomSeed.Name = "numericUpDownCombined2PGRandomSeed";
            this.numericUpDownCombined2PGRandomSeed.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownCombined2PGRandomSeed.TabIndex = 237;
            this.numericUpDownCombined2PGRandomSeed.Value = new decimal(new int[] {
            2015,
            0,
            0,
            0});
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(92, 314);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(92, 13);
            this.label125.TabIndex = 236;
            this.label125.Text = "Random Patterns:";
            // 
            // numericUpDownCombined2PGRandomPatterns
            // 
            this.numericUpDownCombined2PGRandomPatterns.Location = new System.Drawing.Point(201, 312);
            this.numericUpDownCombined2PGRandomPatterns.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownCombined2PGRandomPatterns.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownCombined2PGRandomPatterns.Name = "numericUpDownCombined2PGRandomPatterns";
            this.numericUpDownCombined2PGRandomPatterns.Size = new System.Drawing.Size(112, 20);
            this.numericUpDownCombined2PGRandomPatterns.TabIndex = 235;
            this.numericUpDownCombined2PGRandomPatterns.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // tabPageCheckings
            // 
            this.tabPageCheckings.Controls.Add(this.checkBoxDetailedInputsOutputReport);
            this.tabPageCheckings.Controls.Add(this.label36);
            this.tabPageCheckings.Controls.Add(this.textBoxSessoinName);
            this.tabPageCheckings.Controls.Add(this.buttonUniqueOutputs);
            this.tabPageCheckings.Controls.Add(this.label9);
            this.tabPageCheckings.Controls.Add(this.checkBoxChickingsHammingDistanceForceWrongInputs);
            this.tabPageCheckings.Controls.Add(this.label11);
            this.tabPageCheckings.Controls.Add(this.numericUpDownCheckingsClockTimes);
            this.tabPageCheckings.Controls.Add(this.checkBoxCheckingsUniqueRandomPatterns);
            this.tabPageCheckings.Controls.Add(this.checkBoxCheckingsRandomSeed);
            this.tabPageCheckings.Controls.Add(this.label56);
            this.tabPageCheckings.Controls.Add(this.numericUpDownCheckingsRandomSeed);
            this.tabPageCheckings.Controls.Add(this.numericUpDownCheckingsRandomPatterns);
            this.tabPageCheckings.Controls.Add(this.buttonCalculateHammingDistance);
            this.tabPageCheckings.Controls.Add(this.labelCheckingsKeyLength);
            this.tabPageCheckings.Controls.Add(this.label10);
            this.tabPageCheckings.Controls.Add(this.textBoxCheckingsKey);
            this.tabPageCheckings.Controls.Add(this.buttonCheckIntegrity);
            this.tabPageCheckings.Location = new System.Drawing.Point(4, 22);
            this.tabPageCheckings.Name = "tabPageCheckings";
            this.tabPageCheckings.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCheckings.Size = new System.Drawing.Size(471, 483);
            this.tabPageCheckings.TabIndex = 2;
            this.tabPageCheckings.Text = "Checkings Settings";
            this.tabPageCheckings.UseVisualStyleBackColor = true;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(112, 344);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(78, 13);
            this.label36.TabIndex = 135;
            this.label36.Text = "Session Name:";
            // 
            // textBoxSessoinName
            // 
            this.textBoxSessoinName.Location = new System.Drawing.Point(196, 341);
            this.textBoxSessoinName.Name = "textBoxSessoinName";
            this.textBoxSessoinName.Size = new System.Drawing.Size(99, 20);
            this.textBoxSessoinName.TabIndex = 134;
            // 
            // buttonUniqueOutputs
            // 
            this.buttonUniqueOutputs.Location = new System.Drawing.Point(115, 367);
            this.buttonUniqueOutputs.Name = "buttonUniqueOutputs";
            this.buttonUniqueOutputs.Size = new System.Drawing.Size(180, 31);
            this.buttonUniqueOutputs.TabIndex = 133;
            this.buttonUniqueOutputs.Text = "Count of Unique Outputs";
            this.buttonUniqueOutputs.UseVisualStyleBackColor = true;
            this.buttonUniqueOutputs.Click += new System.EventHandler(this.buttonUniqueOutputs_Click);
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(-1, 208);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(800, 2);
            this.label9.TabIndex = 132;
            // 
            // checkBoxChickingsHammingDistanceForceWrongInputs
            // 
            this.checkBoxChickingsHammingDistanceForceWrongInputs.AutoSize = true;
            this.checkBoxChickingsHammingDistanceForceWrongInputs.Location = new System.Drawing.Point(115, 170);
            this.checkBoxChickingsHammingDistanceForceWrongInputs.Name = "checkBoxChickingsHammingDistanceForceWrongInputs";
            this.checkBoxChickingsHammingDistanceForceWrongInputs.Size = new System.Drawing.Size(294, 17);
            this.checkBoxChickingsHammingDistanceForceWrongInputs.TabIndex = 44;
            this.checkBoxChickingsHammingDistanceForceWrongInputs.Text = "Force Wrong Key Inputs (Hamming Distance Calculation)";
            this.checkBoxChickingsHammingDistanceForceWrongInputs.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(112, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(92, 13);
            this.label11.TabIndex = 33;
            this.label11.Text = "Random Patterns:";
            // 
            // checkBoxCheckingsUniqueRandomPatterns
            // 
            this.checkBoxCheckingsUniqueRandomPatterns.AutoSize = true;
            this.checkBoxCheckingsUniqueRandomPatterns.Checked = true;
            this.checkBoxCheckingsUniqueRandomPatterns.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCheckingsUniqueRandomPatterns.Location = new System.Drawing.Point(115, 47);
            this.checkBoxCheckingsUniqueRandomPatterns.Name = "checkBoxCheckingsUniqueRandomPatterns";
            this.checkBoxCheckingsUniqueRandomPatterns.Size = new System.Drawing.Size(145, 17);
            this.checkBoxCheckingsUniqueRandomPatterns.TabIndex = 37;
            this.checkBoxCheckingsUniqueRandomPatterns.Text = "Unique Random Patterns";
            this.checkBoxCheckingsUniqueRandomPatterns.UseVisualStyleBackColor = true;
            // 
            // checkBoxCheckingsRandomSeed
            // 
            this.checkBoxCheckingsRandomSeed.AutoSize = true;
            this.checkBoxCheckingsRandomSeed.Location = new System.Drawing.Point(115, 70);
            this.checkBoxCheckingsRandomSeed.Name = "checkBoxCheckingsRandomSeed";
            this.checkBoxCheckingsRandomSeed.Size = new System.Drawing.Size(97, 17);
            this.checkBoxCheckingsRandomSeed.TabIndex = 38;
            this.checkBoxCheckingsRandomSeed.Text = "Random Seed:";
            this.checkBoxCheckingsRandomSeed.UseVisualStyleBackColor = true;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(112, 140);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(66, 13);
            this.label56.TabIndex = 43;
            this.label56.Text = "Clock Ticks:";
            // 
            // buttonCalculateHammingDistance
            // 
            this.buttonCalculateHammingDistance.Location = new System.Drawing.Point(115, 265);
            this.buttonCalculateHammingDistance.Name = "buttonCalculateHammingDistance";
            this.buttonCalculateHammingDistance.Size = new System.Drawing.Size(180, 31);
            this.buttonCalculateHammingDistance.TabIndex = 39;
            this.buttonCalculateHammingDistance.Text = "Hamming Distance";
            this.buttonCalculateHammingDistance.UseVisualStyleBackColor = true;
            this.buttonCalculateHammingDistance.Click += new System.EventHandler(this.buttonCalculateHammingDistance_Click);
            // 
            // labelCheckingsKeyLength
            // 
            this.labelCheckingsKeyLength.AutoSize = true;
            this.labelCheckingsKeyLength.Location = new System.Drawing.Point(112, 117);
            this.labelCheckingsKeyLength.Name = "labelCheckingsKeyLength";
            this.labelCheckingsKeyLength.Size = new System.Drawing.Size(73, 13);
            this.labelCheckingsKeyLength.TabIndex = 41;
            this.labelCheckingsKeyLength.Text = "Key Length: 1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(112, 97);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(28, 13);
            this.label10.TabIndex = 35;
            this.label10.Text = "Key:";
            // 
            // textBoxCheckingsKey
            // 
            this.textBoxCheckingsKey.Location = new System.Drawing.Point(146, 94);
            this.textBoxCheckingsKey.Name = "textBoxCheckingsKey";
            this.textBoxCheckingsKey.Size = new System.Drawing.Size(149, 20);
            this.textBoxCheckingsKey.TabIndex = 34;
            this.textBoxCheckingsKey.Text = "0";
            this.textBoxCheckingsKey.TextChanged += new System.EventHandler(this.textBoxCheckingsKey_TextChanged);
            // 
            // buttonCheckIntegrity
            // 
            this.buttonCheckIntegrity.Location = new System.Drawing.Point(115, 228);
            this.buttonCheckIntegrity.Name = "buttonCheckIntegrity";
            this.buttonCheckIntegrity.Size = new System.Drawing.Size(180, 31);
            this.buttonCheckIntegrity.TabIndex = 40;
            this.buttonCheckIntegrity.Text = "Check Integrity";
            this.buttonCheckIntegrity.UseVisualStyleBackColor = true;
            this.buttonCheckIntegrity.Click += new System.EventHandler(this.buttonCheckIntegrity_Click);
            // 
            // tabPageEncryptionSettings
            // 
            this.tabPageEncryptionSettings.Controls.Add(this.checkBoxReportUserPowerAfterEncryption);
            this.tabPageEncryptionSettings.Controls.Add(this.checkboxGenerateVerilogAfterEncryption);
            this.tabPageEncryptionSettings.Controls.Add(this.checkBoxReportDelayAfterEncryption);
            this.tabPageEncryptionSettings.Controls.Add(this.checkBoxReportPowerAfterEncryption);
            this.tabPageEncryptionSettings.Controls.Add(this.checkBoxReportAreaAfterEncryption);
            this.tabPageEncryptionSettings.Controls.Add(this.buttonOpenResultsFolder);
            this.tabPageEncryptionSettings.Controls.Add(this.buttonOpenCacheFolder);
            this.tabPageEncryptionSettings.Controls.Add(this.textBoxResultsDirectory);
            this.tabPageEncryptionSettings.Controls.Add(this.label22);
            this.tabPageEncryptionSettings.Controls.Add(this.label65);
            this.tabPageEncryptionSettings.Controls.Add(this.textBoxCacheDirectory);
            this.tabPageEncryptionSettings.Controls.Add(this.checkBoxOpenResultsDirectory);
            this.tabPageEncryptionSettings.Controls.Add(this.checkBoxReportSlackTimesAfterEncryption);
            this.tabPageEncryptionSettings.Controls.Add(this.checkBoxReportIntegrityAfterEncryption);
            this.tabPageEncryptionSettings.Controls.Add(this.checkBoxReportProbabilitiesAfterEncryption);
            this.tabPageEncryptionSettings.Controls.Add(this.label28);
            this.tabPageEncryptionSettings.Controls.Add(this.checkBoxReportHammingDistanceAfterEncryption);
            this.tabPageEncryptionSettings.Controls.Add(this.labelMainKeyInputLength);
            this.tabPageEncryptionSettings.Controls.Add(this.textBoxMainInputKey);
            this.tabPageEncryptionSettings.Location = new System.Drawing.Point(4, 22);
            this.tabPageEncryptionSettings.Name = "tabPageEncryptionSettings";
            this.tabPageEncryptionSettings.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEncryptionSettings.Size = new System.Drawing.Size(470, 483);
            this.tabPageEncryptionSettings.TabIndex = 1;
            this.tabPageEncryptionSettings.Text = "General Encryption Settings";
            this.tabPageEncryptionSettings.UseVisualStyleBackColor = true;
            // 
            // checkBoxReportUserPowerAfterEncryption
            // 
            this.checkBoxReportUserPowerAfterEncryption.AutoSize = true;
            this.checkBoxReportUserPowerAfterEncryption.Checked = true;
            this.checkBoxReportUserPowerAfterEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxReportUserPowerAfterEncryption.Location = new System.Drawing.Point(9, 192);
            this.checkBoxReportUserPowerAfterEncryption.Name = "checkBoxReportUserPowerAfterEncryption";
            this.checkBoxReportUserPowerAfterEncryption.Size = new System.Drawing.Size(194, 17);
            this.checkBoxReportUserPowerAfterEncryption.TabIndex = 128;
            this.checkBoxReportUserPowerAfterEncryption.Text = "Report User Power After Encryption";
            this.checkBoxReportUserPowerAfterEncryption.UseVisualStyleBackColor = true;
            // 
            // checkboxGenerateVerilogAfterEncryption
            // 
            this.checkboxGenerateVerilogAfterEncryption.AutoSize = true;
            this.checkboxGenerateVerilogAfterEncryption.Checked = true;
            this.checkboxGenerateVerilogAfterEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkboxGenerateVerilogAfterEncryption.Location = new System.Drawing.Point(9, 239);
            this.checkboxGenerateVerilogAfterEncryption.Name = "checkboxGenerateVerilogAfterEncryption";
            this.checkboxGenerateVerilogAfterEncryption.Size = new System.Drawing.Size(183, 17);
            this.checkboxGenerateVerilogAfterEncryption.TabIndex = 9;
            this.checkboxGenerateVerilogAfterEncryption.Text = "Generate Verilog After Encryption";
            this.checkboxGenerateVerilogAfterEncryption.UseVisualStyleBackColor = true;
            // 
            // checkBoxReportDelayAfterEncryption
            // 
            this.checkBoxReportDelayAfterEncryption.AutoSize = true;
            this.checkBoxReportDelayAfterEncryption.Checked = true;
            this.checkBoxReportDelayAfterEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxReportDelayAfterEncryption.Location = new System.Drawing.Point(9, 216);
            this.checkBoxReportDelayAfterEncryption.Name = "checkBoxReportDelayAfterEncryption";
            this.checkBoxReportDelayAfterEncryption.Size = new System.Drawing.Size(166, 17);
            this.checkBoxReportDelayAfterEncryption.TabIndex = 127;
            this.checkBoxReportDelayAfterEncryption.Text = "Report Delay After Encryption";
            this.checkBoxReportDelayAfterEncryption.UseVisualStyleBackColor = true;
            // 
            // checkBoxReportPowerAfterEncryption
            // 
            this.checkBoxReportPowerAfterEncryption.AutoSize = true;
            this.checkBoxReportPowerAfterEncryption.Checked = true;
            this.checkBoxReportPowerAfterEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxReportPowerAfterEncryption.Location = new System.Drawing.Point(9, 169);
            this.checkBoxReportPowerAfterEncryption.Name = "checkBoxReportPowerAfterEncryption";
            this.checkBoxReportPowerAfterEncryption.Size = new System.Drawing.Size(212, 17);
            this.checkBoxReportPowerAfterEncryption.TabIndex = 126;
            this.checkBoxReportPowerAfterEncryption.Text = "Report Attacker Power After Encryption";
            this.checkBoxReportPowerAfterEncryption.UseVisualStyleBackColor = true;
            // 
            // checkBoxReportAreaAfterEncryption
            // 
            this.checkBoxReportAreaAfterEncryption.AutoSize = true;
            this.checkBoxReportAreaAfterEncryption.Checked = true;
            this.checkBoxReportAreaAfterEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxReportAreaAfterEncryption.Location = new System.Drawing.Point(9, 146);
            this.checkBoxReportAreaAfterEncryption.Name = "checkBoxReportAreaAfterEncryption";
            this.checkBoxReportAreaAfterEncryption.Size = new System.Drawing.Size(161, 17);
            this.checkBoxReportAreaAfterEncryption.TabIndex = 125;
            this.checkBoxReportAreaAfterEncryption.Text = "Report Area After Encryption";
            this.checkBoxReportAreaAfterEncryption.UseVisualStyleBackColor = true;
            // 
            // buttonOpenResultsFolder
            // 
            this.buttonOpenResultsFolder.Location = new System.Drawing.Point(317, 313);
            this.buttonOpenResultsFolder.Name = "buttonOpenResultsFolder";
            this.buttonOpenResultsFolder.Size = new System.Drawing.Size(42, 23);
            this.buttonOpenResultsFolder.TabIndex = 124;
            this.buttonOpenResultsFolder.Text = "Open";
            this.buttonOpenResultsFolder.UseVisualStyleBackColor = true;
            this.buttonOpenResultsFolder.Click += new System.EventHandler(this.buttonOpenResultsFolder_Click);
            // 
            // buttonOpenCacheFolder
            // 
            this.buttonOpenCacheFolder.Location = new System.Drawing.Point(317, 289);
            this.buttonOpenCacheFolder.Name = "buttonOpenCacheFolder";
            this.buttonOpenCacheFolder.Size = new System.Drawing.Size(42, 23);
            this.buttonOpenCacheFolder.TabIndex = 123;
            this.buttonOpenCacheFolder.Text = "Open";
            this.buttonOpenCacheFolder.UseVisualStyleBackColor = true;
            this.buttonOpenCacheFolder.Click += new System.EventHandler(this.buttonOpenCacheFolder_Click);
            // 
            // textBoxResultsDirectory
            // 
            this.textBoxResultsDirectory.Location = new System.Drawing.Point(97, 314);
            this.textBoxResultsDirectory.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxResultsDirectory.Name = "textBoxResultsDirectory";
            this.textBoxResultsDirectory.Size = new System.Drawing.Size(215, 20);
            this.textBoxResultsDirectory.TabIndex = 41;
            this.textBoxResultsDirectory.Text = "D:\\Results (Simulation Reporter)";
            this.textBoxResultsDirectory.TextChanged += new System.EventHandler(this.textBoxResultsDirectory_TextChanged);
            // 
            // label22
            // 
            this.label22.Location = new System.Drawing.Point(6, 316);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(97, 20);
            this.label22.TabIndex = 15;
            this.label22.Text = "Results Directory:";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(6, 294);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(85, 13);
            this.label65.TabIndex = 122;
            this.label65.Text = "Cache Location:";
            // 
            // textBoxCacheDirectory
            // 
            this.textBoxCacheDirectory.Location = new System.Drawing.Point(97, 291);
            this.textBoxCacheDirectory.Name = "textBoxCacheDirectory";
            this.textBoxCacheDirectory.Size = new System.Drawing.Size(215, 20);
            this.textBoxCacheDirectory.TabIndex = 121;
            this.textBoxCacheDirectory.TextChanged += new System.EventHandler(this.textBoxCacheDirectory_TextChanged);
            // 
            // checkBoxOpenResultsDirectory
            // 
            this.checkBoxOpenResultsDirectory.AutoSize = true;
            this.checkBoxOpenResultsDirectory.Checked = true;
            this.checkBoxOpenResultsDirectory.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxOpenResultsDirectory.Location = new System.Drawing.Point(9, 262);
            this.checkBoxOpenResultsDirectory.Name = "checkBoxOpenResultsDirectory";
            this.checkBoxOpenResultsDirectory.Size = new System.Drawing.Size(235, 17);
            this.checkBoxOpenResultsDirectory.TabIndex = 120;
            this.checkBoxOpenResultsDirectory.Text = "Open Results Directory (Not in sweep mode)";
            this.checkBoxOpenResultsDirectory.UseVisualStyleBackColor = true;
            this.checkBoxOpenResultsDirectory.CheckedChanged += new System.EventHandler(this.checkBoxOpenResultsDirectory_CheckedChanged);
            // 
            // checkBoxReportSlackTimesAfterEncryption
            // 
            this.checkBoxReportSlackTimesAfterEncryption.AutoSize = true;
            this.checkBoxReportSlackTimesAfterEncryption.Location = new System.Drawing.Point(9, 123);
            this.checkBoxReportSlackTimesAfterEncryption.Name = "checkBoxReportSlackTimesAfterEncryption";
            this.checkBoxReportSlackTimesAfterEncryption.Size = new System.Drawing.Size(197, 17);
            this.checkBoxReportSlackTimesAfterEncryption.TabIndex = 119;
            this.checkBoxReportSlackTimesAfterEncryption.Text = "Report Slack Times After Encryption";
            this.checkBoxReportSlackTimesAfterEncryption.UseVisualStyleBackColor = true;
            // 
            // checkBoxReportIntegrityAfterEncryption
            // 
            this.checkBoxReportIntegrityAfterEncryption.AutoSize = true;
            this.checkBoxReportIntegrityAfterEncryption.Checked = true;
            this.checkBoxReportIntegrityAfterEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxReportIntegrityAfterEncryption.Location = new System.Drawing.Point(9, 53);
            this.checkBoxReportIntegrityAfterEncryption.Name = "checkBoxReportIntegrityAfterEncryption";
            this.checkBoxReportIntegrityAfterEncryption.Size = new System.Drawing.Size(176, 17);
            this.checkBoxReportIntegrityAfterEncryption.TabIndex = 118;
            this.checkBoxReportIntegrityAfterEncryption.Text = "Report Integrity After Encryption";
            this.checkBoxReportIntegrityAfterEncryption.UseVisualStyleBackColor = true;
            // 
            // checkBoxReportProbabilitiesAfterEncryption
            // 
            this.checkBoxReportProbabilitiesAfterEncryption.AutoSize = true;
            this.checkBoxReportProbabilitiesAfterEncryption.Checked = true;
            this.checkBoxReportProbabilitiesAfterEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxReportProbabilitiesAfterEncryption.Location = new System.Drawing.Point(9, 100);
            this.checkBoxReportProbabilitiesAfterEncryption.Name = "checkBoxReportProbabilitiesAfterEncryption";
            this.checkBoxReportProbabilitiesAfterEncryption.Size = new System.Drawing.Size(195, 17);
            this.checkBoxReportProbabilitiesAfterEncryption.TabIndex = 117;
            this.checkBoxReportProbabilitiesAfterEncryption.Text = "Report Probabilities After Encryption";
            this.checkBoxReportProbabilitiesAfterEncryption.UseVisualStyleBackColor = true;
            this.checkBoxReportProbabilitiesAfterEncryption.CheckedChanged += new System.EventHandler(this.checkBoxReportProbabilitiesAfterEncryption_CheckedChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 8);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(66, 13);
            this.label28.TabIndex = 53;
            this.label28.Text = "Largest Key:";
            // 
            // checkBoxReportHammingDistanceAfterEncryption
            // 
            this.checkBoxReportHammingDistanceAfterEncryption.AutoSize = true;
            this.checkBoxReportHammingDistanceAfterEncryption.Checked = true;
            this.checkBoxReportHammingDistanceAfterEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxReportHammingDistanceAfterEncryption.Location = new System.Drawing.Point(9, 76);
            this.checkBoxReportHammingDistanceAfterEncryption.Name = "checkBoxReportHammingDistanceAfterEncryption";
            this.checkBoxReportHammingDistanceAfterEncryption.Size = new System.Drawing.Size(228, 17);
            this.checkBoxReportHammingDistanceAfterEncryption.TabIndex = 116;
            this.checkBoxReportHammingDistanceAfterEncryption.Text = "Report Hamming Distance After Encryption";
            this.checkBoxReportHammingDistanceAfterEncryption.UseVisualStyleBackColor = true;
            // 
            // labelMainKeyInputLength
            // 
            this.labelMainKeyInputLength.AutoSize = true;
            this.labelMainKeyInputLength.Location = new System.Drawing.Point(75, 28);
            this.labelMainKeyInputLength.Name = "labelMainKeyInputLength";
            this.labelMainKeyInputLength.Size = new System.Drawing.Size(100, 13);
            this.labelMainKeyInputLength.TabIndex = 54;
            this.labelMainKeyInputLength.Text = "Input Key Length: 1";
            // 
            // textBoxMainInputKey
            // 
            this.textBoxMainInputKey.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMainInputKey.Location = new System.Drawing.Point(78, 5);
            this.textBoxMainInputKey.Name = "textBoxMainInputKey";
            this.textBoxMainInputKey.Size = new System.Drawing.Size(386, 20);
            this.textBoxMainInputKey.TabIndex = 52;
            this.textBoxMainInputKey.Text = "0";
            this.textBoxMainInputKey.TextChanged += new System.EventHandler(this.textBoxMainInputKey_TextChanged);
            // 
            // tabPageTools
            // 
            this.tabPageTools.Controls.Add(this.tabControlTools);
            this.tabPageTools.Location = new System.Drawing.Point(4, 22);
            this.tabPageTools.Name = "tabPageTools";
            this.tabPageTools.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageTools.Size = new System.Drawing.Size(484, 515);
            this.tabPageTools.TabIndex = 9;
            this.tabPageTools.Text = "Tools";
            this.tabPageTools.UseVisualStyleBackColor = true;
            // 
            // tabControlTools
            // 
            this.tabControlTools.Controls.Add(this.tabPageSignalPropagationSimulation);
            this.tabControlTools.Controls.Add(this.tabPageFaultImpacts);
            this.tabControlTools.Controls.Add(this.tabPageProbabilityComputation);
            this.tabControlTools.Controls.Add(this.tabPageLevelizationsAndSlackTimes);
            this.tabControlTools.Controls.Add(this.tabPagePowerAreaDelay);
            this.tabControlTools.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlTools.Location = new System.Drawing.Point(3, 3);
            this.tabControlTools.Multiline = true;
            this.tabControlTools.Name = "tabControlTools";
            this.tabControlTools.SelectedIndex = 0;
            this.tabControlTools.Size = new System.Drawing.Size(478, 509);
            this.tabControlTools.TabIndex = 108;
            // 
            // tabPageSignalPropagationSimulation
            // 
            this.tabPageSignalPropagationSimulation.Controls.Add(this.tableLayoutPanel5);
            this.tabPageSignalPropagationSimulation.Location = new System.Drawing.Point(4, 40);
            this.tabPageSignalPropagationSimulation.Margin = new System.Windows.Forms.Padding(0);
            this.tabPageSignalPropagationSimulation.Name = "tabPageSignalPropagationSimulation";
            this.tabPageSignalPropagationSimulation.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSignalPropagationSimulation.Size = new System.Drawing.Size(470, 465);
            this.tabPageSignalPropagationSimulation.TabIndex = 0;
            this.tabPageSignalPropagationSimulation.Text = "Signal Propagation Simulation";
            this.tabPageSignalPropagationSimulation.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.panel7, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.panelSAs, 0, 6);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanelToolboxOptions, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanelToolboxLoadButtons, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel8, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel9, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel7, 0, 2);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 7;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 92F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(464, 459);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.label35);
            this.panel7.Location = new System.Drawing.Point(3, 419);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(456, 17);
            this.panel7.TabIndex = 16;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(0, 4);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(66, 13);
            this.label35.TabIndex = 0;
            this.label35.Text = "Fault Status:\r\n";
            // 
            // panelSAs
            // 
            this.panelSAs.Controls.Add(this.buttonSignalPropagationSetSA1);
            this.panelSAs.Controls.Add(this.buttonSignalPropagationSetNormal);
            this.panelSAs.Controls.Add(this.buttonSignalPropagationSetSA0);
            this.panelSAs.Controls.Add(this.panel6);
            this.panelSAs.Location = new System.Drawing.Point(0, 439);
            this.panelSAs.Margin = new System.Windows.Forms.Padding(0);
            this.panelSAs.Name = "panelSAs";
            this.panelSAs.Size = new System.Drawing.Size(462, 20);
            this.panelSAs.TabIndex = 11;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.radioButtonSTA1);
            this.panel6.Controls.Add(this.radioButtonNonStuck);
            this.panel6.Controls.Add(this.radioButtonSTA0);
            this.panel6.Enabled = false;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(188, 20);
            this.panel6.TabIndex = 24;
            // 
            // tableLayoutPanelToolboxOptions
            // 
            this.tableLayoutPanelToolboxOptions.ColumnCount = 2;
            this.tableLayoutPanel5.SetColumnSpan(this.tableLayoutPanelToolboxOptions, 2);
            this.tableLayoutPanelToolboxOptions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanelToolboxOptions.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanelToolboxOptions.Controls.Add(this.checkBoxOutputToTextbox, 1, 1);
            this.tableLayoutPanelToolboxOptions.Controls.Add(this.panel4, 1, 0);
            this.tableLayoutPanelToolboxOptions.Controls.Add(this.checkBoxAutoGenerateStuckAtValues, 1, 2);
            this.tableLayoutPanelToolboxOptions.Controls.Add(this.checkBoxAutoPropagateForward, 0, 2);
            this.tableLayoutPanelToolboxOptions.Controls.Add(this.panel1, 1, 3);
            this.tableLayoutPanelToolboxOptions.Controls.Add(this.panel3, 0, 3);
            this.tableLayoutPanelToolboxOptions.Controls.Add(this.checkBoxAvoidLoop, 0, 0);
            this.tableLayoutPanelToolboxOptions.Controls.Add(this.checkBoxAutoOutput, 0, 1);
            this.tableLayoutPanelToolboxOptions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelToolboxOptions.Location = new System.Drawing.Point(0, 32);
            this.tableLayoutPanelToolboxOptions.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanelToolboxOptions.Name = "tableLayoutPanelToolboxOptions";
            this.tableLayoutPanelToolboxOptions.RowCount = 4;
            this.tableLayoutPanelToolboxOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelToolboxOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelToolboxOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelToolboxOptions.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanelToolboxOptions.Size = new System.Drawing.Size(464, 92);
            this.tableLayoutPanelToolboxOptions.TabIndex = 14;
            // 
            // checkBoxOutputToTextbox
            // 
            this.checkBoxOutputToTextbox.AutoSize = true;
            this.checkBoxOutputToTextbox.Location = new System.Drawing.Point(153, 26);
            this.checkBoxOutputToTextbox.Name = "checkBoxOutputToTextbox";
            this.checkBoxOutputToTextbox.Size = new System.Drawing.Size(115, 17);
            this.checkBoxOutputToTextbox.TabIndex = 5;
            this.checkBoxOutputToTextbox.Text = "Output To Textbox";
            this.checkBoxOutputToTextbox.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.radioButton3SignalValuesMode);
            this.panel4.Controls.Add(this.radioButton5SignalValuesMode);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(150, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(413, 23);
            this.panel4.TabIndex = 18;
            // 
            // radioButton3SignalValuesMode
            // 
            this.radioButton3SignalValuesMode.AutoSize = true;
            this.radioButton3SignalValuesMode.Location = new System.Drawing.Point(133, 3);
            this.radioButton3SignalValuesMode.Name = "radioButton3SignalValuesMode";
            this.radioButton3SignalValuesMode.Size = new System.Drawing.Size(100, 17);
            this.radioButton3SignalValuesMode.TabIndex = 15;
            this.radioButton3SignalValuesMode.Text = "3 Values (0,1,X)";
            this.radioButton3SignalValuesMode.UseVisualStyleBackColor = true;
            // 
            // radioButton5SignalValuesMode
            // 
            this.radioButton5SignalValuesMode.AutoSize = true;
            this.radioButton5SignalValuesMode.Checked = true;
            this.radioButton5SignalValuesMode.Location = new System.Drawing.Point(3, 3);
            this.radioButton5SignalValuesMode.Name = "radioButton5SignalValuesMode";
            this.radioButton5SignalValuesMode.Size = new System.Drawing.Size(124, 17);
            this.radioButton5SignalValuesMode.TabIndex = 16;
            this.radioButton5SignalValuesMode.TabStop = true;
            this.radioButton5SignalValuesMode.Text = "5 Values (0,1,X,D,D\')";
            this.radioButton5SignalValuesMode.UseVisualStyleBackColor = true;
            this.radioButton5SignalValuesMode.CheckedChanged += new System.EventHandler(this.radioButton5SignalValuesMode_CheckedChanged);
            // 
            // checkBoxAutoGenerateStuckAtValues
            // 
            this.checkBoxAutoGenerateStuckAtValues.AutoSize = true;
            this.checkBoxAutoGenerateStuckAtValues.Location = new System.Drawing.Point(153, 49);
            this.checkBoxAutoGenerateStuckAtValues.Name = "checkBoxAutoGenerateStuckAtValues";
            this.checkBoxAutoGenerateStuckAtValues.Size = new System.Drawing.Size(174, 17);
            this.checkBoxAutoGenerateStuckAtValues.TabIndex = 17;
            this.checkBoxAutoGenerateStuckAtValues.Text = "Auto Generate Stuck-At Values";
            this.checkBoxAutoGenerateStuckAtValues.UseVisualStyleBackColor = true;
            this.checkBoxAutoGenerateStuckAtValues.CheckedChanged += new System.EventHandler(this.checkBoxAutoGenerateStuckAtValues_CheckedChanged);
            // 
            // checkBoxAutoPropagateForward
            // 
            this.checkBoxAutoPropagateForward.AutoSize = true;
            this.checkBoxAutoPropagateForward.Checked = true;
            this.checkBoxAutoPropagateForward.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAutoPropagateForward.Location = new System.Drawing.Point(3, 49);
            this.checkBoxAutoPropagateForward.Name = "checkBoxAutoPropagateForward";
            this.checkBoxAutoPropagateForward.Size = new System.Drawing.Size(141, 17);
            this.checkBoxAutoPropagateForward.TabIndex = 6;
            this.checkBoxAutoPropagateForward.Text = "Auto Propagate Forward";
            this.checkBoxAutoPropagateForward.UseVisualStyleBackColor = true;
            this.checkBoxAutoPropagateForward.CheckedChanged += new System.EventHandler(this.checkBoxAutoPropagateForward_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBoxClockName);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(150, 69);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(413, 23);
            this.panel1.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Clock:";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.numericUpDownPeriod);
            this.panel3.Controls.Add(this.checkBoxAutoClock);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 69);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(150, 23);
            this.panel3.TabIndex = 14;
            // 
            // checkBoxAutoClock
            // 
            this.checkBoxAutoClock.AutoSize = true;
            this.checkBoxAutoClock.Location = new System.Drawing.Point(3, 2);
            this.checkBoxAutoClock.Name = "checkBoxAutoClock";
            this.checkBoxAutoClock.Size = new System.Drawing.Size(100, 17);
            this.checkBoxAutoClock.TabIndex = 8;
            this.checkBoxAutoClock.Text = "Auto Clock (ms)";
            this.checkBoxAutoClock.UseVisualStyleBackColor = true;
            this.checkBoxAutoClock.CheckedChanged += new System.EventHandler(this.checkBoxAutoClock_CheckedChanged);
            // 
            // checkBoxAvoidLoop
            // 
            this.checkBoxAvoidLoop.AutoSize = true;
            this.checkBoxAvoidLoop.Checked = true;
            this.checkBoxAvoidLoop.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAvoidLoop.Location = new System.Drawing.Point(3, 3);
            this.checkBoxAvoidLoop.Name = "checkBoxAvoidLoop";
            this.checkBoxAvoidLoop.Size = new System.Drawing.Size(80, 17);
            this.checkBoxAvoidLoop.TabIndex = 3;
            this.checkBoxAvoidLoop.Text = "Avoid Loop";
            this.checkBoxAvoidLoop.UseVisualStyleBackColor = true;
            this.checkBoxAvoidLoop.CheckedChanged += new System.EventHandler(this.checkBoxAvoidLoop_CheckedChanged);
            // 
            // checkBoxAutoOutput
            // 
            this.checkBoxAutoOutput.AutoSize = true;
            this.checkBoxAutoOutput.Checked = true;
            this.checkBoxAutoOutput.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAutoOutput.Location = new System.Drawing.Point(3, 26);
            this.checkBoxAutoOutput.Name = "checkBoxAutoOutput";
            this.checkBoxAutoOutput.Size = new System.Drawing.Size(83, 17);
            this.checkBoxAutoOutput.TabIndex = 4;
            this.checkBoxAutoOutput.Text = "Auto Output";
            this.checkBoxAutoOutput.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelToolboxLoadButtons
            // 
            this.tableLayoutPanelToolboxLoadButtons.ColumnCount = 2;
            this.tableLayoutPanelToolboxLoadButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelToolboxLoadButtons.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelToolboxLoadButtons.Controls.Add(this.buttonSignalPropagationFillListOfNets, 0, 0);
            this.tableLayoutPanelToolboxLoadButtons.Controls.Add(this.buttonSignalPropagationParseInput, 1, 0);
            this.tableLayoutPanelToolboxLoadButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelToolboxLoadButtons.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelToolboxLoadButtons.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanelToolboxLoadButtons.Name = "tableLayoutPanelToolboxLoadButtons";
            this.tableLayoutPanelToolboxLoadButtons.RowCount = 1;
            this.tableLayoutPanelToolboxLoadButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelToolboxLoadButtons.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanelToolboxLoadButtons.Size = new System.Drawing.Size(464, 32);
            this.tableLayoutPanelToolboxLoadButtons.TabIndex = 8;
            // 
            // buttonSignalPropagationFillListOfNets
            // 
            this.buttonSignalPropagationFillListOfNets.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSignalPropagationFillListOfNets.Location = new System.Drawing.Point(3, 3);
            this.buttonSignalPropagationFillListOfNets.Name = "buttonSignalPropagationFillListOfNets";
            this.buttonSignalPropagationFillListOfNets.Size = new System.Drawing.Size(226, 26);
            this.buttonSignalPropagationFillListOfNets.TabIndex = 0;
            this.buttonSignalPropagationFillListOfNets.Text = "Fill List Of Nets";
            this.buttonSignalPropagationFillListOfNets.UseVisualStyleBackColor = true;
            this.buttonSignalPropagationFillListOfNets.Click += new System.EventHandler(this.buttonSignalPropagationFillListOfNets_Click);
            // 
            // buttonSignalPropagationParseInput
            // 
            this.buttonSignalPropagationParseInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonSignalPropagationParseInput.Location = new System.Drawing.Point(235, 3);
            this.buttonSignalPropagationParseInput.Name = "buttonSignalPropagationParseInput";
            this.buttonSignalPropagationParseInput.Size = new System.Drawing.Size(226, 26);
            this.buttonSignalPropagationParseInput.TabIndex = 1;
            this.buttonSignalPropagationParseInput.Text = "Parse Input Netlist && Fill List Of Nets";
            this.buttonSignalPropagationParseInput.UseVisualStyleBackColor = true;
            this.buttonSignalPropagationParseInput.Click += new System.EventHandler(this.buttonSignalPropagationParseInput_Click);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel8.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(0, 373);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(464, 23);
            this.tableLayoutPanel8.TabIndex = 12;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label34);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(456, 17);
            this.panel2.TabIndex = 0;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(0, 4);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(69, 13);
            this.label34.TabIndex = 0;
            this.label34.Text = "Signal Value:";
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.Controls.Add(this.panelSignals, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(0, 396);
            this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(464, 20);
            this.tableLayoutPanel9.TabIndex = 13;
            // 
            // panelSignals
            // 
            this.panelSignals.Controls.Add(this.buttonSignalPropagationSetX);
            this.panelSignals.Controls.Add(this.buttonSignalPropagationSetD_);
            this.panelSignals.Controls.Add(this.buttonSignalPropagationSetD);
            this.panelSignals.Controls.Add(this.buttonSignalPropagationSet1);
            this.panelSignals.Controls.Add(this.buttonSignalPropagationSet0);
            this.panelSignals.Controls.Add(this.panel5);
            this.panelSignals.Location = new System.Drawing.Point(0, 0);
            this.panelSignals.Margin = new System.Windows.Forms.Padding(0);
            this.panelSignals.Name = "panelSignals";
            this.panelSignals.Size = new System.Drawing.Size(462, 20);
            this.panelSignals.TabIndex = 10;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.radioButtonV0);
            this.panel5.Controls.Add(this.radioButtonVX);
            this.panel5.Controls.Add(this.radioButtonV1);
            this.panel5.Controls.Add(this.radioButtonVD_);
            this.panel5.Controls.Add(this.radioButtonVD);
            this.panel5.Enabled = false;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(188, 21);
            this.panel5.TabIndex = 22;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Controls.Add(this.listBoxSignalPropagationOutputNets, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.listBoxSignalPropagationInputNets, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.listBoxSignalPropagationMiddleNets, 0, 2);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 127);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 3;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(458, 243);
            this.tableLayoutPanel7.TabIndex = 15;
            // 
            // tabPageFaultImpacts
            // 
            this.tabPageFaultImpacts.Controls.Add(this.buttonCalculateFaultImpacts2MultiThread);
            this.tabPageFaultImpacts.Controls.Add(this.label134);
            this.tabPageFaultImpacts.Controls.Add(this.textBoxFaultImpacts2Key);
            this.tabPageFaultImpacts.Controls.Add(this.label3);
            this.tabPageFaultImpacts.Controls.Add(this.label2);
            this.tabPageFaultImpacts.Controls.Add(this.buttonCalculateFaultImpactsMultiThread);
            this.tabPageFaultImpacts.Controls.Add(this.checkBoxFaultImpactsDontUseCache);
            this.tabPageFaultImpacts.Controls.Add(this.checkBoxFaultImpactsRandomSeed);
            this.tabPageFaultImpacts.Controls.Add(this.numericUpDownFaultImpactsRandomPatterns);
            this.tabPageFaultImpacts.Controls.Add(this.checkBoxFaultImpactsUniqueRandomPatterns);
            this.tabPageFaultImpacts.Controls.Add(this.numericUpDownFaultImpactsClockTimes);
            this.tabPageFaultImpacts.Controls.Add(this.numericUpDownFaultImpactsRandomSeed);
            this.tabPageFaultImpacts.Controls.Add(this.label4);
            this.tabPageFaultImpacts.Controls.Add(this.numericUpDownFaultImpactsNumberOfThreads);
            this.tabPageFaultImpacts.Location = new System.Drawing.Point(4, 40);
            this.tabPageFaultImpacts.Name = "tabPageFaultImpacts";
            this.tabPageFaultImpacts.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFaultImpacts.Size = new System.Drawing.Size(469, 465);
            this.tabPageFaultImpacts.TabIndex = 7;
            this.tabPageFaultImpacts.Text = "FaultImpacts";
            this.tabPageFaultImpacts.UseVisualStyleBackColor = true;
            // 
            // buttonCalculateFaultImpacts2MultiThread
            // 
            this.buttonCalculateFaultImpacts2MultiThread.Location = new System.Drawing.Point(134, 274);
            this.buttonCalculateFaultImpacts2MultiThread.Name = "buttonCalculateFaultImpacts2MultiThread";
            this.buttonCalculateFaultImpacts2MultiThread.Size = new System.Drawing.Size(171, 25);
            this.buttonCalculateFaultImpacts2MultiThread.TabIndex = 85;
            this.buttonCalculateFaultImpacts2MultiThread.Text = "Calculate Fault Impacts 2";
            this.buttonCalculateFaultImpacts2MultiThread.UseVisualStyleBackColor = true;
            this.buttonCalculateFaultImpacts2MultiThread.Click += new System.EventHandler(this.buttonCalculateFaultImpacts2MultiThread_Click);
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Location = new System.Drawing.Point(131, 232);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(124, 13);
            this.label134.TabIndex = 84;
            this.label134.Text = "Key (for Fault Impacts 2):";
            // 
            // textBoxFaultImpacts2Key
            // 
            this.textBoxFaultImpacts2Key.Location = new System.Drawing.Point(205, 248);
            this.textBoxFaultImpacts2Key.Name = "textBoxFaultImpacts2Key";
            this.textBoxFaultImpacts2Key.Size = new System.Drawing.Size(100, 20);
            this.textBoxFaultImpacts2Key.TabIndex = 83;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(131, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Random Patterns:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(131, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "Number Of Threads:";
            // 
            // buttonCalculateFaultImpactsMultiThread
            // 
            this.buttonCalculateFaultImpactsMultiThread.Location = new System.Drawing.Point(134, 167);
            this.buttonCalculateFaultImpactsMultiThread.Name = "buttonCalculateFaultImpactsMultiThread";
            this.buttonCalculateFaultImpactsMultiThread.Size = new System.Drawing.Size(171, 25);
            this.buttonCalculateFaultImpactsMultiThread.TabIndex = 19;
            this.buttonCalculateFaultImpactsMultiThread.Text = "Calculate Fault Impacts";
            this.buttonCalculateFaultImpactsMultiThread.UseVisualStyleBackColor = true;
            this.buttonCalculateFaultImpactsMultiThread.Click += new System.EventHandler(this.buttonCalculateFaultImpactsMultiThread_Click);
            // 
            // checkBoxFaultImpactsDontUseCache
            // 
            this.checkBoxFaultImpactsDontUseCache.AutoSize = true;
            this.checkBoxFaultImpactsDontUseCache.Checked = true;
            this.checkBoxFaultImpactsDontUseCache.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxFaultImpactsDontUseCache.Location = new System.Drawing.Point(134, 144);
            this.checkBoxFaultImpactsDontUseCache.Name = "checkBoxFaultImpactsDontUseCache";
            this.checkBoxFaultImpactsDontUseCache.Size = new System.Drawing.Size(107, 17);
            this.checkBoxFaultImpactsDontUseCache.TabIndex = 82;
            this.checkBoxFaultImpactsDontUseCache.Text = "Don\'t Use Cache";
            this.checkBoxFaultImpactsDontUseCache.UseVisualStyleBackColor = true;
            // 
            // checkBoxFaultImpactsRandomSeed
            // 
            this.checkBoxFaultImpactsRandomSeed.AutoSize = true;
            this.checkBoxFaultImpactsRandomSeed.Location = new System.Drawing.Point(134, 120);
            this.checkBoxFaultImpactsRandomSeed.Name = "checkBoxFaultImpactsRandomSeed";
            this.checkBoxFaultImpactsRandomSeed.Size = new System.Drawing.Size(97, 17);
            this.checkBoxFaultImpactsRandomSeed.TabIndex = 31;
            this.checkBoxFaultImpactsRandomSeed.Text = "Random Seed:";
            this.checkBoxFaultImpactsRandomSeed.UseVisualStyleBackColor = true;
            this.checkBoxFaultImpactsRandomSeed.CheckedChanged += new System.EventHandler(this.checkBoxRandomSeed_CheckedChanged);
            // 
            // checkBoxFaultImpactsUniqueRandomPatterns
            // 
            this.checkBoxFaultImpactsUniqueRandomPatterns.AutoSize = true;
            this.checkBoxFaultImpactsUniqueRandomPatterns.Checked = true;
            this.checkBoxFaultImpactsUniqueRandomPatterns.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxFaultImpactsUniqueRandomPatterns.Location = new System.Drawing.Point(134, 42);
            this.checkBoxFaultImpactsUniqueRandomPatterns.Name = "checkBoxFaultImpactsUniqueRandomPatterns";
            this.checkBoxFaultImpactsUniqueRandomPatterns.Size = new System.Drawing.Size(145, 17);
            this.checkBoxFaultImpactsUniqueRandomPatterns.TabIndex = 29;
            this.checkBoxFaultImpactsUniqueRandomPatterns.Text = "Unique Random Patterns";
            this.checkBoxFaultImpactsUniqueRandomPatterns.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(131, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Clock Ticks:";
            // 
            // tabPageProbabilityComputation
            // 
            this.tabPageProbabilityComputation.AutoScroll = true;
            this.tabPageProbabilityComputation.Controls.Add(this.buttonTemporary);
            this.tabPageProbabilityComputation.Controls.Add(this.checkBoxLogicSimulationSortResultsDescending);
            this.tabPageProbabilityComputation.Controls.Add(this.checkBoxLogicSimulationDontUseCache);
            this.tabPageProbabilityComputation.Controls.Add(this.buttonAbortLogicSimulation);
            this.tabPageProbabilityComputation.Controls.Add(this.label8);
            this.tabPageProbabilityComputation.Controls.Add(this.numericUpDownLogicSimulationClockTicks);
            this.tabPageProbabilityComputation.Controls.Add(this.numericUpDownLogicSimulationThreshold);
            this.tabPageProbabilityComputation.Controls.Add(this.checkBoxLogicSimulationMeetThreshold);
            this.tabPageProbabilityComputation.Controls.Add(this.checkBoxLogicSimulationRandomSeed);
            this.tabPageProbabilityComputation.Controls.Add(this.numericUpDownLogicSimulationRandomSeed);
            this.tabPageProbabilityComputation.Controls.Add(this.label7);
            this.tabPageProbabilityComputation.Controls.Add(this.numericUpDownLogicSimulationRandomPatterns);
            this.tabPageProbabilityComputation.Controls.Add(this.buttonLogicSimulation);
            this.tabPageProbabilityComputation.Location = new System.Drawing.Point(4, 40);
            this.tabPageProbabilityComputation.Name = "tabPageProbabilityComputation";
            this.tabPageProbabilityComputation.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageProbabilityComputation.Size = new System.Drawing.Size(469, 465);
            this.tabPageProbabilityComputation.TabIndex = 2;
            this.tabPageProbabilityComputation.Text = "Probability Computation";
            this.tabPageProbabilityComputation.UseVisualStyleBackColor = true;
            // 
            // buttonTemporary
            // 
            this.buttonTemporary.Location = new System.Drawing.Point(35, 209);
            this.buttonTemporary.Name = "buttonTemporary";
            this.buttonTemporary.Size = new System.Drawing.Size(138, 33);
            this.buttonTemporary.TabIndex = 85;
            this.buttonTemporary.Text = "Temporary Button";
            this.buttonTemporary.UseVisualStyleBackColor = true;
            this.buttonTemporary.Click += new System.EventHandler(this.buttonTemporary_Click);
            // 
            // checkBoxLogicSimulationSortResultsDescending
            // 
            this.checkBoxLogicSimulationSortResultsDescending.AutoSize = true;
            this.checkBoxLogicSimulationSortResultsDescending.Checked = true;
            this.checkBoxLogicSimulationSortResultsDescending.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxLogicSimulationSortResultsDescending.Location = new System.Drawing.Point(173, 138);
            this.checkBoxLogicSimulationSortResultsDescending.Name = "checkBoxLogicSimulationSortResultsDescending";
            this.checkBoxLogicSimulationSortResultsDescending.Size = new System.Drawing.Size(143, 17);
            this.checkBoxLogicSimulationSortResultsDescending.TabIndex = 84;
            this.checkBoxLogicSimulationSortResultsDescending.Text = "Sort Results Descending";
            this.checkBoxLogicSimulationSortResultsDescending.UseVisualStyleBackColor = true;
            // 
            // checkBoxLogicSimulationDontUseCache
            // 
            this.checkBoxLogicSimulationDontUseCache.AutoSize = true;
            this.checkBoxLogicSimulationDontUseCache.Location = new System.Drawing.Point(173, 115);
            this.checkBoxLogicSimulationDontUseCache.Name = "checkBoxLogicSimulationDontUseCache";
            this.checkBoxLogicSimulationDontUseCache.Size = new System.Drawing.Size(107, 17);
            this.checkBoxLogicSimulationDontUseCache.TabIndex = 83;
            this.checkBoxLogicSimulationDontUseCache.Text = "Don\'t Use Cache";
            this.checkBoxLogicSimulationDontUseCache.UseVisualStyleBackColor = true;
            // 
            // buttonAbortLogicSimulation
            // 
            this.buttonAbortLogicSimulation.Location = new System.Drawing.Point(83, 60);
            this.buttonAbortLogicSimulation.Name = "buttonAbortLogicSimulation";
            this.buttonAbortLogicSimulation.Size = new System.Drawing.Size(84, 27);
            this.buttonAbortLogicSimulation.TabIndex = 51;
            this.buttonAbortLogicSimulation.Text = "Abort";
            this.buttonAbortLogicSimulation.UseVisualStyleBackColor = true;
            this.buttonAbortLogicSimulation.Click += new System.EventHandler(this.buttonAbortLogicSimulation_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(170, 91);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 13);
            this.label8.TabIndex = 50;
            this.label8.Text = "Clock Ticks:";
            // 
            // checkBoxLogicSimulationMeetThreshold
            // 
            this.checkBoxLogicSimulationMeetThreshold.AutoSize = true;
            this.checkBoxLogicSimulationMeetThreshold.Checked = true;
            this.checkBoxLogicSimulationMeetThreshold.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxLogicSimulationMeetThreshold.Location = new System.Drawing.Point(173, 64);
            this.checkBoxLogicSimulationMeetThreshold.Name = "checkBoxLogicSimulationMeetThreshold";
            this.checkBoxLogicSimulationMeetThreshold.Size = new System.Drawing.Size(100, 17);
            this.checkBoxLogicSimulationMeetThreshold.TabIndex = 47;
            this.checkBoxLogicSimulationMeetThreshold.Text = "Meet Threshold";
            this.checkBoxLogicSimulationMeetThreshold.UseVisualStyleBackColor = true;
            // 
            // checkBoxLogicSimulationRandomSeed
            // 
            this.checkBoxLogicSimulationRandomSeed.AutoSize = true;
            this.checkBoxLogicSimulationRandomSeed.Location = new System.Drawing.Point(173, 41);
            this.checkBoxLogicSimulationRandomSeed.Name = "checkBoxLogicSimulationRandomSeed";
            this.checkBoxLogicSimulationRandomSeed.Size = new System.Drawing.Size(97, 17);
            this.checkBoxLogicSimulationRandomSeed.TabIndex = 46;
            this.checkBoxLogicSimulationRandomSeed.Text = "Random Seed:";
            this.checkBoxLogicSimulationRandomSeed.UseVisualStyleBackColor = true;
            this.checkBoxLogicSimulationRandomSeed.CheckedChanged += new System.EventHandler(this.checkBoxLogicSimulationRandomSeed_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(170, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 13);
            this.label7.TabIndex = 44;
            this.label7.Text = "Random Patterns:";
            // 
            // buttonLogicSimulation
            // 
            this.buttonLogicSimulation.Location = new System.Drawing.Point(83, 15);
            this.buttonLogicSimulation.Name = "buttonLogicSimulation";
            this.buttonLogicSimulation.Size = new System.Drawing.Size(84, 43);
            this.buttonLogicSimulation.TabIndex = 42;
            this.buttonLogicSimulation.Text = "Logic Simulation";
            this.buttonLogicSimulation.UseVisualStyleBackColor = true;
            this.buttonLogicSimulation.Click += new System.EventHandler(this.buttonLogicSimulation_Click);
            // 
            // tabPageLevelizationsAndSlackTimes
            // 
            this.tabPageLevelizationsAndSlackTimes.Controls.Add(this.buttonLevelizeNets);
            this.tabPageLevelizationsAndSlackTimes.Controls.Add(this.buttonSlackTimes);
            this.tabPageLevelizationsAndSlackTimes.Location = new System.Drawing.Point(4, 40);
            this.tabPageLevelizationsAndSlackTimes.Name = "tabPageLevelizationsAndSlackTimes";
            this.tabPageLevelizationsAndSlackTimes.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageLevelizationsAndSlackTimes.Size = new System.Drawing.Size(469, 465);
            this.tabPageLevelizationsAndSlackTimes.TabIndex = 8;
            this.tabPageLevelizationsAndSlackTimes.Text = "Levelization & SlackTime";
            this.tabPageLevelizationsAndSlackTimes.UseVisualStyleBackColor = true;
            // 
            // buttonLevelizeNets
            // 
            this.buttonLevelizeNets.Location = new System.Drawing.Point(150, 37);
            this.buttonLevelizeNets.Name = "buttonLevelizeNets";
            this.buttonLevelizeNets.Size = new System.Drawing.Size(129, 29);
            this.buttonLevelizeNets.TabIndex = 40;
            this.buttonLevelizeNets.Text = "Levelize Nets";
            this.buttonLevelizeNets.UseVisualStyleBackColor = true;
            this.buttonLevelizeNets.Click += new System.EventHandler(this.buttonLevelizeNets_Click);
            // 
            // buttonSlackTimes
            // 
            this.buttonSlackTimes.Location = new System.Drawing.Point(150, 74);
            this.buttonSlackTimes.Name = "buttonSlackTimes";
            this.buttonSlackTimes.Size = new System.Drawing.Size(129, 29);
            this.buttonSlackTimes.TabIndex = 38;
            this.buttonSlackTimes.Text = "Calculate Slack Times";
            this.buttonSlackTimes.UseVisualStyleBackColor = true;
            this.buttonSlackTimes.Click += new System.EventHandler(this.buttonSlackTimes_Click);
            // 
            // tabPagePowerAreaDelay
            // 
            this.tabPagePowerAreaDelay.Controls.Add(this.checkBoxIgnoreKeyInverters);
            this.tabPagePowerAreaDelay.Controls.Add(this.buttonCalculatePowerUser);
            this.tabPagePowerAreaDelay.Controls.Add(this.buttonCalculateDelay);
            this.tabPagePowerAreaDelay.Controls.Add(this.buttonCalculateArea);
            this.tabPagePowerAreaDelay.Controls.Add(this.buttonCalculatePower);
            this.tabPagePowerAreaDelay.Location = new System.Drawing.Point(4, 40);
            this.tabPagePowerAreaDelay.Name = "tabPagePowerAreaDelay";
            this.tabPagePowerAreaDelay.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePowerAreaDelay.Size = new System.Drawing.Size(469, 465);
            this.tabPagePowerAreaDelay.TabIndex = 10;
            this.tabPagePowerAreaDelay.Text = "Power Area Delay";
            this.tabPagePowerAreaDelay.UseVisualStyleBackColor = true;
            // 
            // checkBoxIgnoreKeyInverters
            // 
            this.checkBoxIgnoreKeyInverters.AutoSize = true;
            this.checkBoxIgnoreKeyInverters.Location = new System.Drawing.Point(85, 218);
            this.checkBoxIgnoreKeyInverters.Name = "checkBoxIgnoreKeyInverters";
            this.checkBoxIgnoreKeyInverters.Size = new System.Drawing.Size(121, 17);
            this.checkBoxIgnoreKeyInverters.TabIndex = 27;
            this.checkBoxIgnoreKeyInverters.Text = "Ignore Key Inverters";
            this.checkBoxIgnoreKeyInverters.UseVisualStyleBackColor = true;
            // 
            // buttonCalculatePowerUser
            // 
            this.buttonCalculatePowerUser.Location = new System.Drawing.Point(85, 174);
            this.buttonCalculatePowerUser.Name = "buttonCalculatePowerUser";
            this.buttonCalculatePowerUser.Size = new System.Drawing.Size(269, 38);
            this.buttonCalculatePowerUser.TabIndex = 26;
            this.buttonCalculatePowerUser.Text = "Calculate User Power (User, Correct Key Values)";
            this.buttonCalculatePowerUser.UseVisualStyleBackColor = true;
            this.buttonCalculatePowerUser.Click += new System.EventHandler(this.buttonCalculatePowerUser_Click);
            // 
            // buttonCalculateDelay
            // 
            this.buttonCalculateDelay.Location = new System.Drawing.Point(85, 130);
            this.buttonCalculateDelay.Name = "buttonCalculateDelay";
            this.buttonCalculateDelay.Size = new System.Drawing.Size(269, 38);
            this.buttonCalculateDelay.TabIndex = 2;
            this.buttonCalculateDelay.Text = "Calculate Delay";
            this.buttonCalculateDelay.UseVisualStyleBackColor = true;
            this.buttonCalculateDelay.Click += new System.EventHandler(this.buttonCalculateDelay_Click);
            // 
            // buttonCalculateArea
            // 
            this.buttonCalculateArea.Location = new System.Drawing.Point(85, 87);
            this.buttonCalculateArea.Name = "buttonCalculateArea";
            this.buttonCalculateArea.Size = new System.Drawing.Size(269, 38);
            this.buttonCalculateArea.TabIndex = 1;
            this.buttonCalculateArea.Text = "Calculate Area";
            this.buttonCalculateArea.UseVisualStyleBackColor = true;
            this.buttonCalculateArea.Click += new System.EventHandler(this.buttonCalculateArea_Click);
            // 
            // buttonCalculatePower
            // 
            this.buttonCalculatePower.Location = new System.Drawing.Point(85, 43);
            this.buttonCalculatePower.Name = "buttonCalculatePower";
            this.buttonCalculatePower.Size = new System.Drawing.Size(269, 38);
            this.buttonCalculatePower.TabIndex = 0;
            this.buttonCalculatePower.Text = "Calculate Power (Attacker, Random Key Values)";
            this.buttonCalculatePower.UseVisualStyleBackColor = true;
            this.buttonCalculatePower.Click += new System.EventHandler(this.buttonCalculatePower_Click);
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(559, 564);
            this.tableLayoutPanel10.Margin = new System.Windows.Forms.Padding(0, 0, 6, 0);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(493, 20);
            this.tableLayoutPanel10.TabIndex = 11;
            // 
            // timerClock
            // 
            this.timerClock.Interval = 250;
            this.timerClock.Tick += new System.EventHandler(this.timerClock_Tick);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Iconsmind-Outline-CPU.ico");
            // 
            // timerEncryptor
            // 
            this.timerEncryptor.Enabled = true;
            this.timerEncryptor.Interval = 1000;
            this.timerEncryptor.Tick += new System.EventHandler(this.timerEncryptor_Tick);
            // 
            // checkBoxDetailedInputsOutputReport
            // 
            this.checkBoxDetailedInputsOutputReport.AutoSize = true;
            this.checkBoxDetailedInputsOutputReport.Location = new System.Drawing.Point(115, 404);
            this.checkBoxDetailedInputsOutputReport.Name = "checkBoxDetailedInputsOutputReport";
            this.checkBoxDetailedInputsOutputReport.Size = new System.Drawing.Size(178, 17);
            this.checkBoxDetailedInputsOutputReport.TabIndex = 137;
            this.checkBoxDetailedInputsOutputReport.Text = "Detailed Inputs Outputs Report?";
            this.checkBoxDetailedInputsOutputReport.UseVisualStyleBackColor = true;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1065, 670);
            this.Controls.Add(this.progressBarMain);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(512, 120);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.Resize += new System.EventHandler(this.FormMain_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFaultImpactsRandomPatterns)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFaultImpactsClockTimes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFaultImpactsNumberOfThreads)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFaultImpactsRandomSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLogicSimulationRandomSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLogicSimulationRandomPatterns)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLogicSimulationThreshold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLogicSimulationClockTicks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCheckingsRandomSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCheckingsRandomPatterns)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCheckingsClockTimes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPeriod)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tabControlOutput.ResumeLayout(false);
            this.tabPageOutputLog.ResumeLayout(false);
            this.tabPageOutputLog.PerformLayout();
            this.tabPageLargeOutput.ResumeLayout(false);
            this.tabPageGeneratedNetlist.ResumeLayout(false);
            this.tabPageGeneratedNetlist.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.panelToolBox.ResumeLayout(false);
            this.tabControlCommands.ResumeLayout(false);
            this.tabPageLogicEncryptions.ResumeLayout(false);
            this.tabControlEncryptions.ResumeLayout(false);
            this.tabPageEncryptionAlgorithms.ResumeLayout(false);
            this.tabControlAlgorithms.ResumeLayout(false);
            this.tabPageRandomXORXNOR.ResumeLayout(false);
            this.tabPageRandomXORXNOR.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRandomXORXNORRRandomSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRandomXORXNORKeyLength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRandomXORXNORRandomSeed)).EndInit();
            this.tabPageAntiHardwareTrojanEncryption.ResumeLayout(false);
            this.tabPageAntiHardwareTrojanEncryption.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTRRandomSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTKeyLength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTProbMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTSlackMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTClockTicks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTThreshold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTRandomSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHTRandomPatterns)).EndInit();
            this.tabPageFARajendran.ResumeLayout(false);
            this.tabPageFARajendran.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFARajendranRRandomSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFARajendranKeyLength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFARajendranRandomSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFARajendranNumberOfThreads)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFARajendranClockTimes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFARajendranRandomPatterns)).EndInit();
            this.tabPageGreedyXAlgorithm.ResumeLayout(false);
            this.tabPageGreedyXAlgorithm.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRareThreshold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlg14GreedyNumberOfThreads)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlg14GreedyRRandomSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlg14GreedyKeyLength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlg14GreedyClockTimes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlg14GreedyRandomSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlg14GreedyRandomPatterns)).EndInit();
            this.tabPageSamimi02Combined.ResumeLayout(false);
            this.tabPageSamimi02Combined.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2KeyLength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTClockTicksHT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTRandomPatternsHT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTRandomSeedHT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTMaxHTKeyLength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTProbMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTSlackMin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PHTThresholdHT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PGNumberOfThreads)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PGKeyRandomSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PGClockTimes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PGRandomSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCombined2PGRandomPatterns)).EndInit();
            this.tabPageCheckings.ResumeLayout(false);
            this.tabPageCheckings.PerformLayout();
            this.tabPageEncryptionSettings.ResumeLayout(false);
            this.tabPageEncryptionSettings.PerformLayout();
            this.tabPageTools.ResumeLayout(false);
            this.tabControlTools.ResumeLayout(false);
            this.tabPageSignalPropagationSimulation.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panelSAs.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tableLayoutPanelToolboxOptions.ResumeLayout(false);
            this.tableLayoutPanelToolboxOptions.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanelToolboxLoadButtons.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.panelSignals.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tabPageFaultImpacts.ResumeLayout(false);
            this.tabPageFaultImpacts.PerformLayout();
            this.tabPageProbabilityComputation.ResumeLayout(false);
            this.tabPageProbabilityComputation.PerformLayout();
            this.tabPageLevelizationsAndSlackTimes.ResumeLayout(false);
            this.tabPagePowerAreaDelay.ResumeLayout(false);
            this.tabPagePowerAreaDelay.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxInput;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveOutputToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label labelInput;
        private System.Windows.Forms.Label labelOutput;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonOpen;
        private System.Windows.Forms.ToolStripButton toolStripButtonSaveOutput;
        private System.Windows.Forms.ToolStripMenuItem operationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ParseInputAndCalculateSCOAPParametersToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButtonCalculateSCOAPParameters;
        private System.Windows.Forms.ToolStripMenuItem testSCOAPIntegrityWithInternalSamplesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ProgressBar progressBarMain;
        private System.Windows.Forms.ToolStripButton toolStripButtonExit;
        private System.Windows.Forms.ToolStripMenuItem saveInputAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButtonSaveInputAs;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelTestabilityIndex;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripButton toolStripButtonNew;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.CheckBox checkBoxOutputTestabilityIndexDetails;
        private System.Windows.Forms.CheckBox checkBoxOutputTestabilityIndex;
        private System.Windows.Forms.ToolStripMenuItem findToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem findTextInOtherBoxToolStripMenuItem;
        private System.Windows.Forms.Button buttonFindInInput;
        private System.Windows.Forms.TextBox textBoxFindInInput;
        private System.Windows.Forms.TextBox textBoxFindInOutput;
        private System.Windows.Forms.Button buttonFindInOutput;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.CheckBox checkBoxGenerateFanouts;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Panel panelToolBox;
        private System.Windows.Forms.Timer timerClock;
        private System.Windows.Forms.TabControl tabControlCommands;
        private System.Windows.Forms.TabPage tabPageSignalPropagationSimulation;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showHideToolboxToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButtonToolbox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numericUpDownFaultImpactsClockTimes;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numericUpDownFaultImpactsRandomPatterns;
        private System.Windows.Forms.Button buttonCalculateFaultImpactsMultiThread;
        private System.Windows.Forms.NumericUpDown numericUpDownFaultImpactsNumberOfThreads;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonFARajendranOriginalEncrypt;
        private System.Windows.Forms.NumericUpDown numericUpDownFaultImpactsRandomSeed;
        private System.Windows.Forms.CheckBox checkBoxFaultImpactsUniqueRandomPatterns;
        private System.Windows.Forms.TabControl tabControlOutput;
        private System.Windows.Forms.TabPage tabPageOutputLog;
        private System.Windows.Forms.TextBox textBoxOutput;
        private System.Windows.Forms.TabPage tabPageGeneratedNetlist;
        private System.Windows.Forms.TextBox textBoxGeneratedNetlist;
        private System.Windows.Forms.CheckBox checkBoxFaultImpactsRandomSeed;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TabPage tabPageLargeOutput;
        private System.Windows.Forms.RichTextBox richTextBoxOutput;
        private System.Windows.Forms.TabPage tabPageProbabilityComputation;
        private System.Windows.Forms.Button buttonLogicSimulation;
        private System.Windows.Forms.CheckBox checkBoxLogicSimulationRandomSeed;
        private System.Windows.Forms.NumericUpDown numericUpDownLogicSimulationRandomSeed;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numericUpDownLogicSimulationRandomPatterns;
        private System.Windows.Forms.CheckBox checkBoxLogicSimulationMeetThreshold;
        private System.Windows.Forms.NumericUpDown numericUpDownLogicSimulationThreshold;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numericUpDownLogicSimulationClockTicks;
        private System.Windows.Forms.Button buttonAbortLogicSimulation;
        private System.Windows.Forms.Button buttonSlackTimes;
        private System.Windows.Forms.Button buttonLevelizeNets;
        private System.Windows.Forms.CheckBox checkBoxCheckingsRandomSeed;
        private System.Windows.Forms.CheckBox checkBoxCheckingsUniqueRandomPatterns;
        private System.Windows.Forms.NumericUpDown numericUpDownCheckingsRandomSeed;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxCheckingsKey;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numericUpDownCheckingsRandomPatterns;
        private System.Windows.Forms.Button buttonCheckIntegrity;
        private System.Windows.Forms.Button buttonCalculateHammingDistance;
        private System.Windows.Forms.Label labelCheckingsKeyLength;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.CheckBox checkBoxFaultImpactsDontUseCache;
        private System.Windows.Forms.CheckBox checkBoxLogicSimulationDontUseCache;
        private System.Windows.Forms.Label labelMainKeyInputLength;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBoxMainInputKey;
        private System.Windows.Forms.TabPage tabPageFARajendran;
        private System.Windows.Forms.Label labelFARajendranGeneratedKeyLength;
        private System.Windows.Forms.TextBox textBoxFARajendranGeneratedKey;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.NumericUpDown numericUpDownFARajendranKeyLength;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBoxFARajendranDirectoryComment;
        private System.Windows.Forms.CheckBox checkBoxFARajendranDontUseCache;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBoxFARajendranInlineComment;
        private System.Windows.Forms.CheckBox checkBoxFARajendranRandomSeed;
        private System.Windows.Forms.CheckBox checkBoxFARajendranUniqueRandomPatterns;
        private System.Windows.Forms.NumericUpDown numericUpDownFARajendranRandomSeed;
        private System.Windows.Forms.NumericUpDown numericUpDownFARajendranNumberOfThreads;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.NumericUpDown numericUpDownFARajendranClockTimes;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.NumericUpDown numericUpDownFARajendranRandomPatterns;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button buttonFARajendranAsIPresumeItIsEncrypt;
        private System.Windows.Forms.TabPage tabPageFaultImpacts;
        private System.Windows.Forms.TabPage tabPageLogicEncryptions;
        private System.Windows.Forms.TabControl tabControlAlgorithms;
        private System.Windows.Forms.TabPage tabPageTools;
        private System.Windows.Forms.TabControl tabControlTools;
        private System.Windows.Forms.TabPage tabPageLevelizationsAndSlackTimes;
        private System.Windows.Forms.CheckBox checkBoxReportProbabilitiesAfterEncryption;
        private System.Windows.Forms.CheckBox checkBoxReportHammingDistanceAfterEncryption;
        private System.Windows.Forms.TabControl tabControlEncryptions;
        private System.Windows.Forms.TabPage tabPageEncryptionAlgorithms;
        private System.Windows.Forms.TabPage tabPageEncryptionSettings;
        private System.Windows.Forms.CheckBox checkBoxReportSlackTimesAfterEncryption;
        private System.Windows.Forms.CheckBox checkBoxReportIntegrityAfterEncryption;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.CheckBox checkBoxFARajendranReportProbabilitiesBeforeEncryption;
        private System.Windows.Forms.CheckBox checkBoxOpenResultsDirectory;
        private System.Windows.Forms.NumericUpDown numericUpDownCheckingsClockTimes;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.CheckBox checkBoxLogicSimulationSortResultsDescending;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.NumericUpDown numericUpDownFARajendranRRandomSeed;
        private System.Windows.Forms.Button buttonFARajendranAlg10;
        private System.Windows.Forms.Button buttonAlg11;
        private System.Windows.Forms.TextBox textBoxResultsDirectory;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox textBoxCacheDirectory;
        private System.Windows.Forms.Button buttonOpenResultsFolder;
        private System.Windows.Forms.Button buttonOpenCacheFolder;
        private System.Windows.Forms.Timer timerEncryptor;
        private System.Windows.Forms.CheckBox checkBoxChickingsHammingDistanceForceWrongInputs;
        private System.Windows.Forms.TabPage tabPagePowerAreaDelay;
        private System.Windows.Forms.Button buttonCalculatePower;
        private System.Windows.Forms.Button buttonCalculateArea;
        private System.Windows.Forms.Button buttonCalculateDelay;
        private System.Windows.Forms.CheckBox checkBoxReportDelayAfterEncryption;
        private System.Windows.Forms.CheckBox checkBoxReportPowerAfterEncryption;
        private System.Windows.Forms.CheckBox checkBoxReportAreaAfterEncryption;
        private System.Windows.Forms.TabPage tabPageGreedyXAlgorithm;
        private System.Windows.Forms.CheckBox checkBoxAlg14GreedyHammingDistanceForceWrongInputs;
        private System.Windows.Forms.NumericUpDown numericUpDownAlg14GreedyClockTimes;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.CheckBox checkBoxAlg14GreedyRandomSeed;
        private System.Windows.Forms.CheckBox checkBoxAlg14GreedyUniqueRandomPatterns;
        private System.Windows.Forms.NumericUpDown numericUpDownAlg14GreedyRandomSeed;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.NumericUpDown numericUpDownAlg14GreedyRandomPatterns;
        private System.Windows.Forms.Button buttonAlg14GreedyXKeys;
        private System.Windows.Forms.CheckBox checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label labelAlg14GreedyGeneratedKeyLength;
        private System.Windows.Forms.TextBox textBoxAlg14GreedyGeneratedKey;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.NumericUpDown numericUpDownAlg14GreedyKeyLength;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TextBox textBoxAlg14GreedyDirectoryComment;
        private System.Windows.Forms.CheckBox checkBoxAlg14GreedyDontUseCache;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox textBoxAlg14GreedyInlineComment;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.NumericUpDown numericUpDownAlg14GreedyRRandomSeed;
        private System.Windows.Forms.NumericUpDown numericUpDownAlg14GreedyNumberOfThreads;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.TabPage tabPageSamimi02Combined;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label labelCombined2GeneratedKeyLength;
        private System.Windows.Forms.TextBox textBoxCombined2GeneratedKey;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TextBox textBoxCombined2DirectoryComment;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.TextBox textBoxCombined2InlineComment;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2KeyLength;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2PHTClockTicksHT;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2PHTRandomPatternsHT;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2PHTRandomSeedHT;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.CheckBox checkBoxCombined2PHTReportSlackTimesBeforeEncryption;
        private System.Windows.Forms.CheckBox checkBoxCombined2PHTReportProbabilitiesBeforeEncryption;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2PHTMaxHTKeyLength;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2PHTProbMin;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2PHTSlackMin;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2PHTThresholdHT;
        private System.Windows.Forms.CheckBox checkBoxCombined2PHTMeetThresholdHT;
        private System.Windows.Forms.CheckBox checkBoxCombined2PHTConsiderSlackTime;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2PGNumberOfThreads;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2PGKeyRandomSeed;
        private System.Windows.Forms.CheckBox checkBoxCombined2PGReportProbabilitiesBeforeEncryption;
        private System.Windows.Forms.CheckBox checkBoxCombined2PGDontUseCache;
        private System.Windows.Forms.CheckBox checkBoxCombined2PGHammingDistanceForceWrongInputs;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2PGClockTimes;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.CheckBox checkBoxCombined2PGUniqueRandomPatterns;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2PGRandomSeed;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.NumericUpDown numericUpDownCombined2PGRandomPatterns;
        private System.Windows.Forms.Button buttonSamimi02Encrypt;
        private System.Windows.Forms.CheckBox checkBoxCombined2PHTDontUseCache;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.CheckBox checkBoxAlg24Key;
        private System.Windows.Forms.Button buttonAlg24;
        private System.Windows.Forms.CheckBox checkBoxAlg23Key;
        private System.Windows.Forms.Button buttonAlg23;
        private System.Windows.Forms.CheckBox checkboxGenerateVerilogAfterEncryption;
        private System.Windows.Forms.Button buttonCalculatePowerUser;
        private System.Windows.Forms.CheckBox checkBoxReportUserPowerAfterEncryption;
        private System.Windows.Forms.ToolStripMenuItem signalPropagationSimulationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem encryptionAlgorithmsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem encryptionSettingsToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPageCheckings;
        private System.Windows.Forms.CheckBox checkBoxGreedyInverterMode;
        private System.Windows.Forms.Button buttonCalculateFaultImpacts2MultiThread;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.TextBox textBoxFaultImpacts2Key;
        private System.Windows.Forms.CheckBox checkBoxFARajendranUseFaultImpacts2;
        private System.Windows.Forms.TabPage tabPageRandomXORXNOR;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.NumericUpDown numericUpDownRandomXORXNORRRandomSeed;
        private System.Windows.Forms.CheckBox checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox textBoxRandomXORXNORDirectoryComment;
        private System.Windows.Forms.CheckBox checkBoxRandomXORXNORDontUseCache;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBoxRandomXORXNORInlineComment;
        private System.Windows.Forms.Label labelRandomXORXNORGeneratedKeyLength;
        private System.Windows.Forms.TextBox textBoxRandomXORXNORGeneratedKey;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.NumericUpDown numericUpDownRandomXORXNORKeyLength;
        private System.Windows.Forms.CheckBox checkBoxRandomXORXNORRandomSeed;
        private System.Windows.Forms.NumericUpDown numericUpDownRandomXORXNORRandomSeed;
        private System.Windows.Forms.Button buttonRandomXORXNOREncryption;
        private System.Windows.Forms.TabPage tabPageAntiHardwareTrojanEncryption;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Button buttonAlg22AntiHardwareTrojanEnhancedEncryptionXORXNORSyncNoSlackTime;
        private System.Windows.Forms.Button buttonAlg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.NumericUpDown numericUpDownHTRRandomSeed;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Button buttonAlg20AntiHardwareTrojanEnhancedEncryption2NoSlackTime;
        private System.Windows.Forms.Button buttonAlg18AntiHTOriginalNoSlackTIme;
        private System.Windows.Forms.Button buttonAlg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime;
        private System.Windows.Forms.Button buttonAlg17AntiHardwareTrojanEnhancedEncryption2;
        private System.Windows.Forms.Button buttonAlg13AntiHTOriginal;
        private System.Windows.Forms.CheckBox checkBoxHTReportSlackTimesBeforeEncryption;
        private System.Windows.Forms.CheckBox checkBoxHTReportProbabilitiesBeforeEncryption;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBoxHTDirectoryComment;
        private System.Windows.Forms.CheckBox checkBoxHTDontUseCache;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBoxHTInlineComment;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label labelHTGeneratedKeyLength;
        private System.Windows.Forms.TextBox textBoxHTGeneratedKey;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown numericUpDownHTKeyLength;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown numericUpDownHTProbMin;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown numericUpDownHTSlackMin;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown numericUpDownHTClockTicks;
        private System.Windows.Forms.NumericUpDown numericUpDownHTThreshold;
        private System.Windows.Forms.CheckBox checkBoxHTMeetThreshold;
        private System.Windows.Forms.CheckBox checkBoxHTRandomSeed;
        private System.Windows.Forms.NumericUpDown numericUpDownHTRandomSeed;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown numericUpDownHTRandomPatterns;
        private System.Windows.Forms.Button buttonAlg04AntiHardwareTrojanEnhancedEncryption;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button buttonAlg25;
        private System.Windows.Forms.Label labelRareThreshold;
        private System.Windows.Forms.NumericUpDown numericUpDownRareThreshold;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButtonSmartGreedy;
        private System.Windows.Forms.RadioButton radioButtonHDPower2SmartGreedy;
        private System.Windows.Forms.RadioButton radioButtonHDLRSmartGreedy;
        private System.Windows.Forms.CheckBox checkBoxIgnoreKeyInverters;
        private System.Windows.Forms.Button buttonTemporary;
        private System.Windows.Forms.Button buttonUniqueOutputs;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panelSAs;
        private System.Windows.Forms.Button buttonSignalPropagationSetSA1;
        private System.Windows.Forms.Button buttonSignalPropagationSetNormal;
        private System.Windows.Forms.Button buttonSignalPropagationSetSA0;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton radioButtonSTA1;
        private System.Windows.Forms.RadioButton radioButtonNonStuck;
        private System.Windows.Forms.RadioButton radioButtonSTA0;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelToolboxOptions;
        private System.Windows.Forms.CheckBox checkBoxOutputToTextbox;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton radioButton3SignalValuesMode;
        private System.Windows.Forms.RadioButton radioButton5SignalValuesMode;
        private System.Windows.Forms.CheckBox checkBoxAutoGenerateStuckAtValues;
        private System.Windows.Forms.CheckBox checkBoxAutoPropagateForward;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxClockName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.NumericUpDown numericUpDownPeriod;
        private System.Windows.Forms.CheckBox checkBoxAutoClock;
        private System.Windows.Forms.CheckBox checkBoxAvoidLoop;
        private System.Windows.Forms.CheckBox checkBoxAutoOutput;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelToolboxLoadButtons;
        private System.Windows.Forms.Button buttonSignalPropagationFillListOfNets;
        private System.Windows.Forms.Button buttonSignalPropagationParseInput;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Panel panelSignals;
        private System.Windows.Forms.Button buttonSignalPropagationSetX;
        private System.Windows.Forms.Button buttonSignalPropagationSetD_;
        private System.Windows.Forms.Button buttonSignalPropagationSetD;
        private System.Windows.Forms.Button buttonSignalPropagationSet1;
        private System.Windows.Forms.Button buttonSignalPropagationSet0;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton radioButtonV0;
        private System.Windows.Forms.RadioButton radioButtonVX;
        private System.Windows.Forms.RadioButton radioButtonV1;
        private System.Windows.Forms.RadioButton radioButtonVD_;
        private System.Windows.Forms.RadioButton radioButtonVD;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.ListBox listBoxSignalPropagationOutputNets;
        private System.Windows.Forms.ListBox listBoxSignalPropagationInputNets;
        private System.Windows.Forms.ListBox listBoxSignalPropagationMiddleNets;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBoxSessoinName;
        private System.Windows.Forms.CheckBox checkBoxDetailedInputsOutputReport;
    }
}

