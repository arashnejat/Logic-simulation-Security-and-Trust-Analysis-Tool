﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption 
{
    public partial class FormMain
    {
        private bool SaveOutput()
        {
            saveFileDialog1.Filter = "Text files|*.txt";
            saveFileDialog1.Title = "Save Output";
            if (_outputFileName == null)
            {
                if (_inputFileName == null)
                {
                    saveFileDialog1.InitialDirectory = Application.StartupPath;
                    saveFileDialog1.FileName = null;
                }
                else
                {
                    saveFileDialog1.InitialDirectory = null;
                    saveFileDialog1.FileName = Path.GetFileNameWithoutExtension(_inputFileName) + "_SCOAP_Output.txt";
                }
            }
            else
            {
                saveFileDialog1.InitialDirectory = Path.GetFileNameWithoutExtension(_outputFileName);
                saveFileDialog1.FileName = _outputFileName;
            }

            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return false;

            SamimiIO.WriteAllText(saveFileDialog1.FileName, textBoxOutput.Text);

            _outputFileName = saveFileDialog1.FileName;
            _needToSaveOutput = false;

            return true;
        }

        private bool SaveInputAs()
        {
            saveFileDialog1.Filter = "Supported files|*.txt;*.bench;*.isc|Text files|*.txt|Benchmark files|*.bench|Iscas files|*.isc";
            saveFileDialog1.Title = "Save Input As";
            if (_inputFileName == null)
            {
                saveFileDialog1.InitialDirectory = Application.StartupPath;
                saveFileDialog1.FileName = null;
            }
            else
            {
                saveFileDialog1.InitialDirectory = null;
                saveFileDialog1.FileName = Path.GetFileName(_inputFileName);
            }

            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return false;

            SamimiIO.WriteAllText(saveFileDialog1.FileName, textBoxInput.Text);

            _inputFileName = saveFileDialog1.FileName;
            _needToSaveInput = false;

            return true;
        }

        private bool Visualize(List<Net> nets, string input, SCOAPValue sumOfTsa0s, SCOAPValue sumOfTsa1s, double testabilityIndex, bool? testMode = false, bool? fillInput = true, bool? testabilityIndexDetailsInOutput = false, bool? testabilityIndexInOutput = false, string sampleOutput = "")
        {
            if (fillInput.HasValue && fillInput.Value)
            {
                textBoxInput.Text = textBoxOutput.Text = "";
                _needToSaveInput = false;
            }

            if (testMode.HasValue && testMode.Value)
            {
                testabilityIndexDetailsInOutput = true;
                testabilityIndexInOutput = true;
            }

            var outputList = new List<string>();

            foreach (var net in nets)
            {
                outputList.Add(net.ToString(Net.NetToStringMode.SCOAP));
                if (testabilityIndexDetailsInOutput.HasValue && testabilityIndexDetailsInOutput.Value)
                {
                    outputList.Add("\tT(sa0): " + net.TSa0);
                    outputList.Add("\tT(sa1): " + net.TSa1);
                }
            }

            //------------------------------------------------------------------------------------------
            var netNames = new List<string>();
            var enablePodem = nets.Count > 0;
            foreach (var net in nets)
            {
                if (net is FlipFlop /*|| net is GateCustom*/)
                {
                    enablePodem = false;
                    break;
                }
                netNames.Add(net.Name);
            }

            //------------------------------------------------------------------------------------------
            if (panelToolBox.Visible)
            {
                OutputSignalValues(true);
            }
            //------------------------------------------------------------------------------------------
            if (testabilityIndexInOutput.HasValue && testabilityIndexInOutput.Value)
            {
                outputList.Add("\r\n-----------------------------------");
                outputList.Add("Sum of T(sa0)s: " + sumOfTsa0s);
                outputList.Add("Sum of T(sa1)s: " + sumOfTsa1s);
                outputList.Add("Testability index: " + (testabilityIndex != -1.0 ? testabilityIndex.ToString() : SCOAPValue.SymboleOfInfinity));
            }

            toolStripStatusLabelTestabilityIndex.Text = "Testability index: "
                                                        + (testabilityIndex != -1.0 ? testabilityIndex.ToString() : SCOAPValue.SymboleOfInfinity)
                                                        + "  |  Sum of T(sa0)s: " + sumOfTsa0s + "  |  Sum of T(sa1)s: " + sumOfTsa1s;

            if (fillInput.HasValue && fillInput.Value)
            {
                textBoxInput.Text = input;
                textBoxInput.SelectionStart = 0;
                textBoxInput.SelectionLength = 0;
                _needToSaveInput = false;
            }

            textBoxOutput.Text = (string.Join("\r\n", outputList.ToArray())).Trim();
            textBoxOutput.SelectionStart = 0;
            textBoxOutput.SelectionLength = 0;
            _needToSaveOutput = false;

            labelOutput.Text = "Output: (Contains SCOAP Parameters of " + nets.Count + " nets)";

            var result = false;
            if (testMode.HasValue && testMode == true)
                if (textBoxOutput.Text == sampleOutput)
                {
                    this.BackColor = Color.Green;
                    result = true;
                }
                else
                {
                    this.BackColor = Color.Red;
                    result = false;
                }
            else
            {
                this.BackColor = DefaultBackColor;
                result = true;
            }
            return result;
        }

        private void New()
        {
            DialogResult result;
            if (_needToSaveInput)
                if ((result = MessageBox.Show("Do you want to save changes you made in input text box?", "Save", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)) == DialogResult.Yes)
                {
                    if (!SaveInputAs())
                        return;
                }
                else if (result == System.Windows.Forms.DialogResult.Cancel)
                    return;

            if (_needToSaveOutput)
                if ((result = MessageBox.Show("Do you want to save changes you made in output text box?", "Save", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)) == DialogResult.Yes)
                {
                    if (!SaveOutput())
                        return;
                }
                else if (result == System.Windows.Forms.DialogResult.Cancel)
                    return;

            textBoxInput.Text = textBoxOutput.Text = "";
            _inputFileName = _outputFileName = null;
            _needToSaveInput = false;
            _needToSaveOutput = false;
            toolStripStatusLabelTestabilityIndex.Text = "";
            textBoxFindInInput.Text = textBoxFindInOutput.Text = "";
            this.Text = FormAboutBox.AssemblyTitle;
        }

        public List<string> FileNamesList = new List<string>();

        private void OpenFile()
        {
            if (_needToSaveInput)
                if (MessageBox.Show("Do you want to save changes you made in input text box?", "Save", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
                    if (!SaveInputAs())
                        return;

            if (_needToSaveOutput)
                if (MessageBox.Show("Do you want to save changes you made in output text box?", "Save", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
                    if (!SaveOutput())
                        return;

            openFileDialog1.InitialDirectory = _inputFileName == null ? Application.StartupPath : null;
            openFileDialog1.Title = "Open Netlist";
            openFileDialog1.FileName = null;
            openFileDialog1.Multiselect = true;
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            //==================================================================================================
            progressBarMain.Visible = true;
            progressBarMain.Value = 30;
            Wait(10);

            if (openFileDialog1.FileNames.Length == 1)
            {
                FileNamesList.Clear();
                var fileName = openFileDialog1.FileName;
                FileNamesList.Add(fileName);
                OpenFile(fileName);
            }
            else
            {
                FileNamesList.Clear();
                textBoxInput.Text = openFileDialog1.FileNames.Length + " Files to open:\r\n-------------------------\r\n\r\n";

                foreach (var fileName in openFileDialog1.FileNames)
                {
                    FileNamesList.Add(fileName);
                    textBoxInput.Text += fileName + "\r\n\r\n";
                }
            }

            //_nets = Parser.CreateNets(textBoxInput.Text, generateFanouts: checkBoxGenerateFanouts.Checked);
            var t2 = DateTime.Now;
            progressBarMain.Value = 70;
            Wait(150);

            _needToSaveInput = false;
            //Visualize(nets: _nets, input: input, sumOfTsa0s: sumOfTsa0S, sumOfTsa1s: sumOfTsa1S, testabilityIndex: testabilityIndex, testabilityIndexDetailsInOutput: checkBoxOutputTestabilityIndexDetails.Checked, testabilityIndexInOutput: checkBoxOutputTestabilityIndex.Checked);

            progressBarMain.Value = 100;
            Wait(1000);
            progressBarMain.Visible = false;
        }

        private void OpenFile(string fileName)
        {
            _inputFileName = fileName;
            _outputFileName = null;
            _netlistName = Path.GetFileName(_inputFileName);
            _title = FormAboutBox.AssemblyTitle + " - " + _netlistName;
            this.Text = _title;

            var input = SamimiIO.ReadAllText(_inputFileName); //.Replace("\r","\n").Replace("\n","\r\n");
            if (!input.Contains("\r\n") && input.Contains("\r"))
                input = input.Replace("\r", "\r\n");
            if (!input.Contains("\r\n") && input.Contains("\n"))
                input = input.Replace("\n", "\r\n");
            textBoxInput.Text = input;
        }

        private void InputChanged()
        {
            this.BackColor = DefaultBackColor;
            _needToSaveInput = true;
        }

        private void FormResized()
        {
            if (this.Width <= 760)
            {
                if (toolStrip1.ImageScalingSize.Width != 20)
                {
                    toolStrip1.ImageScalingSize = new Size(18, 18);
                    toolStrip1.Width = 1;
                }
            }
            else
            {
                if (toolStrip1.ImageScalingSize.Width != 30)
                {
                    toolStrip1.ImageScalingSize = new Size(30, 30);
                    toolStrip1.Width = 1;
                }
            }
        }

        private void FindInTextBox(string tofind, TextBox targetTextBox, bool? autoParse = false, bool? forceReset = false)
        {
            if (autoParse.Value)
            {
                string[] formulaSeperators = { "=", "(", ",", ")", " ", "\t", "\r", ":" };
                var parts = tofind.Split(formulaSeperators, StringSplitOptions.RemoveEmptyEntries);

                if (parts.Length == 0)
                    return;
                tofind = parts[0].Trim().ToLower();

                if (string.IsNullOrEmpty(tofind))
                    return;

                if (targetTextBox == textBoxInput)
                    textBoxFindInInput.Text = tofind;
                if (targetTextBox == textBoxOutput)
                    textBoxFindInOutput.Text = tofind;
            }
            else
            {
                tofind = tofind.ToLower();
            }

            var startIndex = 0;
            if (!forceReset.Value)
                startIndex = targetTextBox.SelectionStart + targetTextBox.SelectionLength;

            var index = targetTextBox.Text.ToLower().IndexOf(tofind, startIndex);
            if (index == -1)
                index = targetTextBox.Text.ToLower().IndexOf(tofind, 0);

            if (index > -1)
            {
                targetTextBox.SelectionStart = index;
                targetTextBox.SelectionLength = tofind.Length;
                targetTextBox.ScrollToCaret();
            }
        }

        private void ShowHideToolbox()
        {
            panelToolBox.Visible = !panelToolBox.Visible;
            if (panelToolBox.Visible)
            {
                OutputSignalValues(true);
                //tableLayoutPanel1.SetColumnSpan(this.panelPodem, 3);

                tableLayoutPanel1.ColumnStyles[0].Width = 33F;
                tableLayoutPanel1.ColumnStyles[1].Width = 33F;
                tableLayoutPanel1.ColumnStyles[2] = new ColumnStyle(sizeType: SizeType.Percent, width: 34F);
            }
            else
            {
                tableLayoutPanel1.ColumnStyles[0] = new ColumnStyle(SizeType.Percent, 50F);
                tableLayoutPanel1.ColumnStyles[1] = new ColumnStyle(SizeType.Percent, 50F);
                tableLayoutPanel1.ColumnStyles[2] = new ColumnStyle(SizeType.Percent, 0F);
                //tableLayoutPanel1.SetColumnSpan(this.panelPodem, 2);
            }
        }

        private static DateTime Wait(int wait)
        {
            Application.DoEvents();
            var t1 = DateTime.Now;
            while ((DateTime.Now - t1).TotalMilliseconds < wait)
                Application.DoEvents();
            return t1;
        }

        private void Exit()
        {
            if(_waitForPreviousEncryption)
                if (MessageBox.Show("Are You Sure You Want To Abort & Exit?", "Exit Application", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) != DialogResult.Yes)
                    return;

            SamimiIO.Exiting = true;

            FaultImpacts.Exiting = true;
            LogicSimulation.Abort = true;
            Application.Exit();
        }

        private void ParseInputAndCalculateSCOAPParameters()
        {
            progressBarMain.Visible = true;
            progressBarMain.Value = 30;
            Wait(10);

            double testabilityIndex;
            var sumOfTsa0s = new SCOAPValue();
            var sumOfTsa1s = new SCOAPValue();

            var t1 = DateTime.Now;
            
            ParseInputAgain();
            tabControlCommands.SelectTab(tabPageTools);
            //tabControlCommands.SelectTab(tabPageSignalPropagationSimulation);
            SCOAP.SCOAPMain(nets: _nets, sumOfTsa0s: sumOfTsa0s, sumOfTsa1s: sumOfTsa1s, testabilityIndex: out testabilityIndex, generateFanouts: checkBoxGenerateFanouts.Checked, initializedNets: null);
            var t2 = DateTime.Now;

            progressBarMain.Value = 70;
            Wait(150);

            Visualize(nets: _nets, input: textBoxInput.Text, sumOfTsa0s: sumOfTsa0s, sumOfTsa1s: sumOfTsa1s, testabilityIndex: testabilityIndex, fillInput: false, testabilityIndexDetailsInOutput: checkBoxOutputTestabilityIndexDetails.Checked, testabilityIndexInOutput: checkBoxOutputTestabilityIndex.Checked);
            
            this.Text = _title + (string.IsNullOrEmpty(_title) ? "" : " - ") + "(Total duration: " + (DateTime.Now - t1).TotalSeconds + " seconds (" + (t2 - t1).TotalSeconds + " + " + (DateTime.Now - t2).TotalSeconds + "))";

            progressBarMain.Value = 100;
            Wait(1000);
            progressBarMain.Visible = false;

            buttonSignalPropagationParseInput_Click(null, null);
        }

        private void FormClosingMethod(FormClosingEventArgs e)
        {
            DialogResult result;
            if (_needToSaveInput)
                if (
                    (result =
                        MessageBox.Show("Do you want to save changes you made in input text box?", "Save",
                            MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)) == DialogResult.Yes)
                {
                    if (!SaveInputAs())
                        e.Cancel = true;
                }
                else if (result == System.Windows.Forms.DialogResult.Cancel)
                    e.Cancel = true;

            if (_needToSaveOutput)
                if (
                    (result =
                        MessageBox.Show("Do you want to save changes you made in output text box?", "Save",
                            MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)) == DialogResult.Yes)
                {
                    if (!SaveOutput())
                        e.Cancel = true;
                }
                else if (result == System.Windows.Forms.DialogResult.Cancel)
                    e.Cancel = true;
        }

        private void ShowAboutForm()
        {
            var sI = textBoxInput.SelectionLength;
            var sO = textBoxOutput.SelectionLength;
            (new FormAboutBox()).ShowDialog();
            textBoxInput.SelectionLength = sI;
            textBoxOutput.SelectionLength = sO;
        }

        private void ShowHelpForm()
        {
            var sI = textBoxInput.SelectionLength;
            var sO = textBoxOutput.SelectionLength;
            (new FormHelp()).ShowDialog();
            textBoxInput.SelectionLength = sI;
            textBoxOutput.SelectionLength = sO;
        }

        private void Output(string output, bool? toEnd = false)
        {
            var oldCarret = textBoxOutput.Text.Length;
            textBoxOutput.Text = output;

            if (!toEnd.Value)
            {
                textBoxOutput.SelectionStart = oldCarret;
            }
            else
            {
                textBoxOutput.SelectionStart = output.Length;
            }
            textBoxOutput.ScrollToCaret();
            tabControlOutput.SelectTab(tabPageOutputLog);
        }
    }
}
