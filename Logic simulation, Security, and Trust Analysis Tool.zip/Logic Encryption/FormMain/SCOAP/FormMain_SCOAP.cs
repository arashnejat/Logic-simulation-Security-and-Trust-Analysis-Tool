﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicEncryption
{
    public partial class FormMain
    {
        private void TestSCOAPProgram()
        {
            this.Text = "Test Mode - ";
            _title = "";
            var doneTests = 0;

            if (!DoTestSCOAP(SampleData.SampleInput1, SampleData.SampleOutput1))
            {
                this.Text += "Failed at test 1";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput2, SampleData.SampleOutput2))
            {
                this.Text += "Failed at test 2";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput3, SampleData.SampleOutput3))
            {
                this.Text += "Failed at test 3";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput3G, SampleData.SampleOutput3G, true))
            {
                this.Text += "Failed at test 3G";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput4, SampleData.SampleOutput4))
            {
                this.Text += "Failed at test 4";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput5, SampleData.SampleOutput5))
            {
                this.Text += "Failed at test 5";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput5G, SampleData.SampleOutput5G, true))
            {
                this.Text += "Failed at test 5G";
                return;
            }
            doneTests++;
            if (!DoTestSCOAP(SampleData.SampleInput6, SampleData.SampleOutput6))
            {
                this.Text += "Failed at test 6";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput7, SampleData.SampleOutput7))
            {
                this.Text += "Failed at test 7";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput7G, SampleData.SampleOutput7G, true))
            {
                this.Text += "Failed at test 7G";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput8, SampleData.SampleOutput8))
            {
                this.Text += "Failed at test 8";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput9, SampleData.SampleOutput9))
            {
                this.Text += "Failed at test 9";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput10, SampleData.SampleOutput10))
            {
                this.Text += "Failed at test 10";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput11, SampleData.SampleOutput11))
            {
                this.Text += "Failed at test 11";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput12, SampleData.SampleOutput12))
            {
                this.Text += "Failed at test 12";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput12G, SampleData.SampleOutput12G, true))
            {
                this.Text += "Failed at test 12G";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput13, SampleData.SampleOutput13))
            {
                this.Text += "Failed at test 13";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput14, SampleData.SampleOutput14))
            {
                this.Text += "Failed at test 14";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput15, SampleData.SampleOutput15))
            {
                this.Text += "Failed at test 15";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput16, SampleData.SampleOutput16))
            {
                this.Text += "Failed at test 16";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput17, SampleData.SampleOutput17))
            {
                this.Text += "Failed at test 17";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput17G, SampleData.SampleOutput17G, true))
            {
                this.Text += "Failed at test 17G";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput18, SampleData.SampleOutput18))
            {
                this.Text += "Failed at test 18";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput18G, SampleData.SampleOutput18G, true))
            {
                this.Text += "Failed at test 18G";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput19, SampleData.SampleOutput19))
            {
                this.Text += "Failed at test 19";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput20, SampleData.SampleOutput20))
            {
                this.Text += "Failed at test 20";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput21, SampleData.SampleOutput21))
            {
                this.Text += "Failed at test 21";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput22, SampleData.SampleOutput22))
            {
                this.Text += "Failed at test 22";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput22G, SampleData.SampleOutput22G, true))
            {
                this.Text += "Failed at test 22G";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput23, SampleData.SampleOutput23))
            {
                this.Text += "Failed at test 23";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput24, SampleData.SampleOutput24))
            {
                this.Text += "Failed at test 24";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput25, SampleData.SampleOutput25))
            {
                this.Text += "Failed at test 25";
                return;
            }
            doneTests++;

            if (!DoTestSCOAP(SampleData.SampleInput26, SampleData.SampleOutput26))
            {
                this.Text += "Failed at test 26";
                return;
            }
            doneTests++;
            this.Text = "All " + doneTests + " Tests Done successful!";
        }

        private bool DoTestSCOAP(string inputTest, string outputTest, bool? generatedFanouts = false)
        {
            double testabilityIndex;
            Net.ToStringMode = Net.NetToStringMode.SCOAPAndSignal;
            var sumOfTsa0s = new SCOAPValue();
            var sumOfTsa1s = new SCOAPValue();
            var nets = SCOAP.SCOAPOnInputString(inputString: inputTest, sumOfTsa0s: sumOfTsa0s, sumOfTsa1s: sumOfTsa1s, testabilityIndex: out testabilityIndex, generateFanouts: generatedFanouts.Value, initializedNets: null);
            return Visualize(nets: nets, input: inputTest, sumOfTsa0s: sumOfTsa0s, sumOfTsa1s: sumOfTsa1s, testabilityIndex: testabilityIndex, testMode: true, sampleOutput: outputTest);
        }

    }
}
