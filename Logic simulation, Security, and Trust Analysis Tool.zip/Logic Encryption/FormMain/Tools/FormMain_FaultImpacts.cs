﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicEncryption
{
    public partial class FormMain
    {
        private void CalculateFaultImpacts()
        {
            ParseInputAgain();
            if (_nets == null || _nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------

            progressBarMain.Visible = true;

            if (checkBoxFaultImpactsRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownFaultImpactsRandomSeed.Value = random.Next(1, (int)numericUpDownFaultImpactsRandomSeed.Maximum);
            }

            var faultImpactReport = "";
            var randomSeed = (int)numericUpDownFaultImpactsRandomSeed.Value;
            var uniqueRandomPatterns = checkBoxFaultImpactsUniqueRandomPatterns.Checked;
            var clockTimes = (int)numericUpDownFaultImpactsClockTimes.Value;
            var threadsCount = (int)numericUpDownFaultImpactsNumberOfThreads.Value;
            var randomNumbers = (int)(numericUpDownFaultImpactsRandomPatterns.Value);
            var netlistName = _netlistName;
            var header = "Fault Impacts Calculation:\r\n";

            string loadReport;
            var faultImpactNets = FaultImpacts.LoadOrCalculateFaultImpacts(
                nets: _nets,
                randomSeed: randomSeed,
                uniqueRandomPatterns: uniqueRandomPatterns,
                textBox: textBoxOutput,
                clockTimes: clockTimes,
                threadsCount: threadsCount,
                randomNumbers: randomNumbers,
                netlistName: netlistName,
                header: header,
                createReport: true,
                report: out faultImpactReport,
                progressBar: progressBarMain,
                loadReport: out loadReport,
                forceCalculate: checkBoxFaultImpactsDontUseCache.Checked,
                allowSaveResults: false);

            var detailedReport = "\r\n";
            foreach (var net in faultImpactNets)
            {
                detailedReport += net.Name + "\t" + net.FaultImpact + "\r\n";
            }
            textBoxOutput.Text = loadReport + (string.IsNullOrEmpty(faultImpactReport) ? detailedReport : faultImpactReport);

            progressBarMain.Visible = false;

            tabControlOutput.SelectTab(tabPageOutputLog);
        }

        private void CalculateFaultImpacts2()
        {
            ParseInputAgain();
            if (_nets == null || _nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------

            progressBarMain.Visible = true;

            if (checkBoxFaultImpactsRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownFaultImpactsRandomSeed.Value = random.Next(1, (int)numericUpDownFaultImpactsRandomSeed.Maximum);
            }

            var faultImpactReport = "";
            var randomSeed = (int)numericUpDownFaultImpactsRandomSeed.Value;
            var uniqueRandomPatterns = checkBoxFaultImpactsUniqueRandomPatterns.Checked;
            var clockTimes = (int)numericUpDownFaultImpactsClockTimes.Value;
            var threadsCount = (int)numericUpDownFaultImpactsNumberOfThreads.Value;
            var randomNumbers = (int)(numericUpDownFaultImpactsRandomPatterns.Value);
            var netlistName = _netlistName;
            var header = "Fault Impacts Calculation:\r\n";
            var key = textBoxFaultImpacts2Key.Text;

            string loadReport;
            var faultImpactNets = FaultImpacts2.LoadOrCalculateFaultImpacts(
                nets: _nets,
                randomSeed: randomSeed,
                uniqueRandomPatterns: uniqueRandomPatterns,
                textBox: textBoxOutput,
                clockTimes: clockTimes,
                threadsCount: threadsCount,
                randomNumbers: randomNumbers,
                netlistName: netlistName,
                header: header,
                createReport: true,
                report: out faultImpactReport,
                progressBar: progressBarMain,
                loadReport: out loadReport,
                forceCalculate: checkBoxFaultImpactsDontUseCache.Checked,
                allowSaveResults: false,
                key: key);

            var detailedReport = "\r\n";
            foreach (var net in faultImpactNets)
            {
                detailedReport += net.Name + "\t" + net.FaultImpact + "\r\n";
            }
            textBoxOutput.Text = loadReport + (string.IsNullOrEmpty(faultImpactReport) ? detailedReport : faultImpactReport);

            progressBarMain.Visible = false;
           
            tabControlOutput.SelectTab(tabPageOutputLog);
        }

    }
}
