﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public partial class FormMain
    {
        private void LogicSimulate()
        {
            var generateFanouts = false; //checkBoxGenerateFanouts.Checked
            List<Net> outputNets;
            var nets = Parser.CreateNets(textBoxInput.Text, generateFanouts, out outputNets);

            if (nets == null || nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------

            var randomPatternsCount = (int)numericUpDownLogicSimulationRandomPatterns.Value;
            if (checkBoxLogicSimulationRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownLogicSimulationRandomSeed.Value = random.Next(1,
                    (int)numericUpDownLogicSimulationRandomSeed.Maximum);
            }

            tabControlOutput.SelectedTab = tabPageOutputLog;

            LogicSimulation.TextBox = textBoxOutput;
            buttonLogicSimulation.Enabled = false;

            var startTime = DateTime.Now;
            string loadReport;
            var totalSamples = LogicSimulation.LoadOrCalculateProbabilities(
                                nets: nets, 
                                clockTimes: (int)numericUpDownLogicSimulationClockTicks.Value, 
                                randomSeed: (int)numericUpDownLogicSimulationRandomSeed.Value, 
                                totalTimes: randomPatternsCount,
                                meetThreshold: checkBoxLogicSimulationMeetThreshold.Checked, 
                                threshold: (double)numericUpDownLogicSimulationThreshold.Value, 
                                textBox: null, 
                                netlistName: _netlistName,
                                loadReport: out loadReport,
                                forceCalculate: checkBoxLogicSimulationDontUseCache.Checked,
                                allowSaveResults: false);

            var endTime = DateTime.Now;

            buttonLogicSimulation.Enabled = true;
            var probabilityPropagationOutput = loadReport +
                "Total Samples: " + totalSamples.ToString("N0") + "\r\n" +
                "Total Duration: " + (endTime - startTime).ToString("g") + "\r\n" +
                "\r\n \r\n \r\n \r\n \r\n";

            if (!checkBoxLogicSimulationSortResultsDescending.Checked)
            {
                int maxLevel;
                LogicSimulation.LevelizeNets(nets, out maxLevel);
                probabilityPropagationOutput += LogicSimulation.ReportLogicSimulation(nets, maxLevel);
            }
            else
            {
                nets.Sort((net1,net2) => Math.Sign(net2.SimulatedProbability - net1.SimulatedProbability));

                foreach (var net in nets)
                {
                    probabilityPropagationOutput += net.Name + "\t" + net.SimulatedProbability + "\r\n";
                }
            }
            textBoxOutput.Text = probabilityPropagationOutput;
            tabControlOutput.SelectTab(tabPageOutputLog);

            Application.DoEvents();
            Console.Beep(100, 100);
            Console.Beep(300, 100);
            Console.Beep(400, 100);
            Console.Beep(500, 100);
            Console.Beep(600, 100);
        }
    }
}
