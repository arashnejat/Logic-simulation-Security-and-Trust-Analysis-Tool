﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicEncryption
{
    public partial class FormMain
    {
        private void LevelizeNetsForSimulationAndSlackTime()
        {
            var generateFanouts = checkBoxGenerateFanouts.Checked;
            List<Net> outputNets;
            var nets = Parser.CreateNets(textBoxInput.Text, generateFanouts, out outputNets);

            if (nets == null || nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------

            int maxLevel;
            LogicSimulation.LevelizeNets(nets, out maxLevel);

            var output = "\r\nLevelization Results: \r\n";
            output += "______________________\r\n";

            for (int i = 0; i <= maxLevel; i++)
            {
                var netsOfLevel = LogicSimulation.GetNetsOfLevel(nets, i);

                output += "Level " + i + ":\r\n";
                foreach (var net in netsOfLevel)
                {
                    output += "Name: " + net.Name + "\r\n"; // +
                }
                output += "______________________\r\n";
            }
            textBoxOutput.Text = output;
            tabControlOutput.SelectTab(tabPageOutputLog);

            Console.Beep();
        }

        private void CalculateSlackTimes()
        {
            var generateFanouts = checkBoxGenerateFanouts.Checked;
            List<Net> outputNets;
            var nets = Parser.CreateNets(textBoxInput.Text, generateFanouts, out outputNets);

            if (nets == null || nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------

            string loadReport;
            int maxLevel;
            ASAPALAPSlackTime.LoadOrCalculateASAPALAPSlackTimeOfNets(
                nets: nets, 
                maxLevel: out maxLevel, 
                netlistName: _netlistName,
                loadReport: out loadReport,
                forceCalculate: checkBoxHTDontUseCache.Checked, 
                allowSaveResults: false);
            var output = "\r\nSlack Time Calculation Results: \r\n";
            output += "______________________\r\n";

            var str = ASAPALAPSlackTime.ReportASAPALAPSLackTime(nets, maxLevel);

            Output(loadReport + "\r\n" + output + str);
            tabControlOutput.SelectTab(tabPageOutputLog);

        }
    }
}
