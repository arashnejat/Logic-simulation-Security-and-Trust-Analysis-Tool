﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public partial class FormMain
    {
        private delegate void MyFunction();
        private class encryptionQueueObject
        {
            public MyFunction Function;
            public Button Button;
            public string OldCaption;
        }
        private Queue<encryptionQueueObject> EncryptionQueue = new Queue<encryptionQueueObject>();

        private bool _waitForPreviousEncryption = false;

        /// <summary>
        /// توضیح: Adds a function to the queue of running functions
        /// and disables a button while running that function.
        /// </summary>
        /// <param name="button">توضیح: Function to enqueu</param>
        /// <param name="function">توضیح: Button to disable while running that function</param>
        private void EnqueueEncryptionAlgorithm(Button button, MyFunction function)
        {
            if (function == null)
                return;

            button.Enabled = false;
            var oldCaption = button.Text;
            button.Text = "Waiting...\r\n" + oldCaption;
            EncryptionQueue.Enqueue(new encryptionQueueObject() { Button = button, Function = function, OldCaption = oldCaption });
        }

        private bool _showCompletionDialogue = false;

        public int fileIndex;
        private void TimerEncryptorTick()
        {
            if (_waitForPreviousEncryption)
            {
                if (EncryptionQueue.Count > 0)
                    _showCompletionDialogue = true;

                return;
            }

            _waitForPreviousEncryption = true;

            if (EncryptionQueue.Count > 0)
            {
                var toDo = EncryptionQueue.Dequeue();

                if (EncryptionQueue.Count > 0)
                    _showCompletionDialogue = true;

                toDo.Button.Text = "Running...\r\n" + toDo.OldCaption;

                fileIndex = 0;
                if (FileNamesList.Count <= 1)
                {
                    fileIndex = FileNamesList.Count;
                    toDo.Function();
                }
                else
                {
                    foreach (var fileName in FileNamesList)
                    {
                        fileIndex++;
                        OpenFile(fileName);
                        toDo.Function();
                    }
                }

                toDo.Button.Text = toDo.OldCaption;
                toDo.Button.Enabled = true;
            }

            _waitForPreviousEncryption = false;

            if (_showCompletionDialogue && EncryptionQueue.Count == 0)
            {
                _showCompletionDialogue = false;
                MessageBox.Show("End of Encryptions. " + _netlistName, "Logic Encryption - Queue Manager", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }
    }
}
