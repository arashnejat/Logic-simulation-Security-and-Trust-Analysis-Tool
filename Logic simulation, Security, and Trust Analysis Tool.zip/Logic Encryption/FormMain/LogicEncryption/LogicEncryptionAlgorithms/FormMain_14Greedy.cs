﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicEncryption
{
    public partial class FormMain
    {
        private void Alg14GreedyXKeys()
        {
            ParseInputAgain();
            if (_nets == null || _nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            if (checkBoxAlg14GreedyRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownAlg14GreedyRandomSeed.Value = random.Next(1, (int)numericUpDownAlg14GreedyRandomSeed.Maximum);
            }

            progressBarMain.Visible = true;
            textBoxGeneratedNetlist.Text = "";

            var keyLength = (int)numericUpDownAlg14GreedyKeyLength.Value;
            var randomSeed = (int)numericUpDownAlg14GreedyRandomSeed.Value;
            var uniqueRandomPatterns = checkBoxAlg14GreedyUniqueRandomPatterns.Checked;
            var clockTimes = (int)numericUpDownAlg14GreedyClockTimes.Value;
            var threadsCount = (int)numericUpDownAlg14GreedyNumberOfThreads.Value;
            var randomNumbers = (int)numericUpDownAlg14GreedyRandomPatterns.Value;
            var rRandomSeed = (int)numericUpDownAlg14GreedyRRandomSeed.Value;
            var forceWrongInputs = checkBoxAlg14GreedyHammingDistanceForceWrongInputs.Checked;
            var encryptionkey = textBoxMainInputKey.Text.Substring(0, keyLength);
            var inverterMode = checkBoxGreedyInverterMode.Checked;

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: inverterMode ? "Alg14GreedyNOT" : "Alg14Greedy",
                netlistName: _netlistName,
                directoryComment: textBoxAlg14GreedyDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = false;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + (inverterMode ? "Alg14GreedyNOTXKeys" : "Alg14GreedyXKeys") + "\r\n" +
                                             "Comment:\t" + textBoxAlg14GreedyInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "encryptionkey:\t" + encryptionkey + "\r\n" +
                                             "keylength:\t" + keyLength + "\r\n" +
                                             "rRandomSeed:\t" + rRandomSeed + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "uniqueRandomPatterns:\t" + uniqueRandomPatterns + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n" +
                                             "randomNumbers:\t" + randomNumbers + "\r\n" +
                                             "forceWrongInputs:\t" + forceWrongInputs + "\r\n" +
                                             "threadsCount:\t" + threadsCount + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(_nets, textBoxInput.Text, forceCalculate: checkBoxAlg14GreedyDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            string addedKeyValues;
            Greedy.Alg14GreedyXKeys(
                nets: _nets,
                encryptionKey: encryptionkey,
                rRandomSeed: rRandomSeed,
                textBox: textBoxOutput,
                progressBar: progressBarMain,
                randomSeed: randomSeed,
                uniqueRandomPatterns: uniqueRandomPatterns,
                reportObject: reportObject,
                clockTimes: clockTimes,
                threadsCount: threadsCount,
                randomNumbers: randomNumbers,
                netlistName: _netlistName,
                forceWrongInputs: forceWrongInputs,
                forceCalculate: checkBoxAlg14GreedyDontUseCache.Checked,
                addedKeyValues: out addedKeyValues,
                inverterMode: inverterMode);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            progressBarMain.Visible = false;
            textBoxAlg14GreedyGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }


        private void Alg25SmartGreedyXKeys()
        {
            ParseInputAgain();
            if (_nets == null || _nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            if (checkBoxAlg14GreedyRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownAlg14GreedyRandomSeed.Value = random.Next(1, (int)numericUpDownAlg14GreedyRandomSeed.Maximum);
            }

            progressBarMain.Visible = true;
            textBoxGeneratedNetlist.Text = "";

            var keyLength = (int)numericUpDownAlg14GreedyKeyLength.Value;
            var randomSeed = (int)numericUpDownAlg14GreedyRandomSeed.Value;
            var uniqueRandomPatterns = checkBoxAlg14GreedyUniqueRandomPatterns.Checked;
            var clockTimes = (int)numericUpDownAlg14GreedyClockTimes.Value;
            var threadsCount = (int)numericUpDownAlg14GreedyNumberOfThreads.Value;
            var randomNumbers = (int)numericUpDownAlg14GreedyRandomPatterns.Value;
            var rRandomSeed = (int)numericUpDownAlg14GreedyRRandomSeed.Value;
            var forceWrongInputs = checkBoxAlg14GreedyHammingDistanceForceWrongInputs.Checked;
            var encryptionkey = textBoxMainInputKey.Text.Substring(0, keyLength);
            var inverterMode = checkBoxGreedyInverterMode.Checked;
            var rareThreshold = (double) numericUpDownRareThreshold.Value;

            var hDPower1 = radioButtonSmartGreedy.Checked;
            var hDPower2 = radioButtonHDPower2SmartGreedy.Checked;
            var hDLR = radioButtonHDLRSmartGreedy.Checked;

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: inverterMode ? "Alg25SmartGreedyNOT" : "Alg25SmartGreedy" + (hDPower1 ? "" : "") + (hDPower2 ? "HDP2" : "") + (hDLR ? "HDLR" : ""),
                netlistName: _netlistName,
                directoryComment: textBoxAlg14GreedyDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = checkBoxAlg14GreedyReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = false;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + (inverterMode ? "Alg25SmartGreedyNOTXKeys" : "Alg25SmartGreedyXKeys") + (hDPower1 ? "" : "") + (hDPower2 ? "HDP2" : "") + (hDLR ? "HDLR" : "") + "\r\n" +
                                             "Comment:\t" + textBoxAlg14GreedyInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "encryptionkey:\t" + encryptionkey + "\r\n" +
                                             "keylength:\t" + keyLength + "\r\n" +
                                             "rRandomSeed:\t" + rRandomSeed + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "uniqueRandomPatterns:\t" + uniqueRandomPatterns + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n" +
                                             "randomNumbers:\t" + randomNumbers + "\r\n" +
                                             "forceWrongInputs:\t" + forceWrongInputs + "\r\n" +
                                             "threadsCount:\t" + threadsCount + "\r\n" +
                                             "rareThreshold:\t" + rareThreshold + "\r\n";

            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(_nets, textBoxInput.Text, forceCalculate: checkBoxAlg14GreedyDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            string addedKeyValues;
            Greedy.Alg25SmartGreedyXKeys(
                nets: _nets,
                encryptionKey: encryptionkey,
                rRandomSeed: rRandomSeed,
                textBox: textBoxOutput,
                progressBar: progressBarMain,
                randomSeed: randomSeed,
                uniqueRandomPatterns: uniqueRandomPatterns,
                reportObject: reportObject,
                clockTimes: clockTimes,
                threadsCount: threadsCount,
                randomNumbers: randomNumbers,
                netlistName: _netlistName,
                forceWrongInputs: forceWrongInputs,
                forceCalculate: checkBoxAlg14GreedyDontUseCache.Checked,
                addedKeyValues: out addedKeyValues,
                rareThreshold: rareThreshold,
                hdPower1: hDPower1,
                hdPower2: hDPower2,
                hdLR: hDLR,
                inverterMode: inverterMode);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            progressBarMain.Visible = false;
            textBoxAlg14GreedyGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }

    }
}
