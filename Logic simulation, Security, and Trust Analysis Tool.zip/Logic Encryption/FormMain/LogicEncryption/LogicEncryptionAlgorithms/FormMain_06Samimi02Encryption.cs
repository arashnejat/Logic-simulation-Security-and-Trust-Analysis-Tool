﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public partial class FormMain
    {
        private void Samimi02Encryption()
        {
            var generateFanouts = checkBoxGenerateFanouts.Checked;
            List<Net> outputNets;
            var nets = Parser.CreateNets(textBoxInput.Text, generateFanouts, out outputNets);

            if (nets == null || nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            var originalNetlist = textBoxInput.Text;

            var clockTimesHT = (int)numericUpDownCombined2PHTClockTicksHT.Value;
            var randomPatternsCountHT = (int)numericUpDownCombined2PHTRandomPatternsHT.Value;
            var randomSeedHT = (int)numericUpDownCombined2PHTRandomSeedHT.Value;
            var meetThresholdHT = checkBoxCombined2PHTMeetThresholdHT.Checked;
            var thresholdHT = (double)numericUpDownCombined2PHTThresholdHT.Value;
            var considerSlackTime = checkBoxCombined2PHTConsiderSlackTime.Checked;
            var SLACK_MIN = (int)numericUpDownCombined2PHTSlackMin.Value;
            var PROBA_MIN = (double)numericUpDownCombined2PHTProbMin.Value;
            var dontUseCacheHT = checkBoxCombined2PHTDontUseCache.Checked;
            var keyLength = (int)numericUpDownCombined2KeyLength.Value;
            var encryptionKey = textBoxMainInputKey.Text.Substring(0, keyLength);
            var maxHTKeyLength = (int)numericUpDownCombined2PHTMaxHTKeyLength.Value;

            var randomPatternsCountGreedy = (int)numericUpDownCombined2PGRandomPatterns.Value;
            var uniqueRandomPatternsGreedy = checkBoxCombined2PGUniqueRandomPatterns.Checked;
            var clockTimesGreedy = (int)numericUpDownCombined2PGClockTimes.Value;
            var threadsCountGreedy = (int)numericUpDownCombined2PGNumberOfThreads.Value;
            var randomSeedGreedy = (int)numericUpDownCombined2PGRandomSeed.Value;
            var rRandomSeed = (int)numericUpDownCombined2PGKeyRandomSeed.Value;
            var forceWrongInputsGreedy = checkBoxCombined2PGHammingDistanceForceWrongInputs.Checked;
            var dontUseCacheGreedy = checkBoxCombined2PGDontUseCache.Checked;

            var textBox = textBoxOutput;

            string addedKeyValues;

            var methodName = "Combined2HTG";

            if (considerSlackTime)
            {
                methodName = "Alg23HTG";
            }
            if (!considerSlackTime)
            {
                methodName = "Alg24HTGNST";
            }

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: methodName,// : (Enum.GetName(typeof(SamimiEncryption01.HTAncestorSelectionBasedOnEnum), htAncestorSelectionBasedOn) + "_")) + (Enum.GetName(typeof(SamimiEncryption01.XKeySelectionBasedOnEnum), xKeySelectionBasedOn)),
                netlistName: _netlistName,
                directoryComment: textBoxCombined2DirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = checkBoxCombined2PHTReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = considerSlackTime; //&& checkBoxCombined2PHTReportSlackTimesBeforeEncryption.Checked;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t(" + methodName +
                                             ") Combined2PHT (XOR/XNOR + NOR Gates + Inverter)" + "\r\n" +
                                             "Comment:\t" + textBoxCombined2InlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +

                                             "keyLength:\t" + keyLength + "\r\n" +
                                             "encryptionKey:\t" + encryptionKey + "\r\n" +
                                             "maxHTKeyLength:\t" + maxHTKeyLength + "\r\n" +

                                             "randomPatternsCountHT:\t" + randomPatternsCountHT + "\r\n" +
                                             "clockTimesHT:\t" + clockTimesHT + "\r\n" +
                                             "randomSeedHT:\t" + randomSeedHT + "\r\n" +
                                             "meetThresholdHT:\t" + meetThresholdHT + "\r\n" +
                                             "thresholdHT:\t" + thresholdHT + "\r\n" +
                                             "considerSlackTime:\t" + considerSlackTime + "\r\n" +
                                             "SLACK_MIN:\t" + SLACK_MIN + "\r\n" +
                                             "PROBA_MIN:\t" + PROBA_MIN + "\r\n" +
                                             "dontUseCacheHT:\t" + dontUseCacheHT + "\r\n" +

                                             "randomPatternsCountGreedy:\t" + randomPatternsCountGreedy + "\r\n" +
                                             "uniqueRandomPatternsGreedy:\t" + uniqueRandomPatternsGreedy + "\r\n" +
                                             "clockTimesGreedy:\t" + clockTimesGreedy + "\r\n" +
                                             "threadsCountGreedy:\t" + threadsCountGreedy + "\r\n" +
                                             "randomSeedGreedy:\t" + randomSeedGreedy + "\r\n" +
                                             "rRandomSeed:\t" + rRandomSeed + "\r\n" +
                                             "forceWrongInputsGreedy:\t" + forceWrongInputsGreedy + "\r\n" +
                                             "dontUseCacheGreedy:\t" + dontUseCacheGreedy + "\r\n";

            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(nets: nets, originalNetlist: originalNetlist, forceCalculate: dontUseCacheHT);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            SamimiEncryption02.EncryptProposedAlg3Combined2(
                nets: nets,
                randomPatternsCountGreedy: randomPatternsCountGreedy,
                uniqueRandomPatternsGreedy: uniqueRandomPatternsGreedy,
                clockTimesGreedy: clockTimesGreedy,
                threadsCountGreedy: threadsCountGreedy,
                randomSeedGreedy: randomSeedGreedy,
                rRandomSeed: rRandomSeed,
                forceWrongInputsGreedy: forceWrongInputsGreedy,

                clockTimesHT: clockTimesHT,
                randomPatternsCountHT: randomPatternsCountHT,
                randomSeedHT: randomSeedHT,
                meetThresholdHT: meetThresholdHT,
                thresholdHT: thresholdHT,
                considerSlackTime: considerSlackTime,
                SLACK_MIN: SLACK_MIN,
                PROBA_MIN: PROBA_MIN,
                maxHTKeyLength: maxHTKeyLength,

                encryptionKey: encryptionKey,

                netlistName: _netlistName,
                forceCalculateHT: dontUseCacheHT,
                forceCalculateGreedy: dontUseCacheGreedy,

                reportObject: reportObject,

                addedKeyValues: out addedKeyValues,
                textBox: textBox,
                createReport: false,
                progressBar: progressBarMain);

            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.EncryptionDetails += "generated key:\t" + addedKeyValues + "\r\n" +
                                              "generated key length:\t" + addedKeyValues.Length + "\r\n";

            //GenerateAfterEncryptionReport(reportObject: reportObject, nets: nets, clockTimes: clockTimes, randomSeed: randomSeed, randomPatternsCount: randomPatternsCount, meetThreshold: meetThreshold, threshold: threshold, addedKeyValues: addedKeyValues, originalNetlist: originalNetlist);
            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            textBoxCombined2GeneratedKey.Text = addedKeyValues;
            labelCombined2GeneratedKeyLength.Text = addedKeyValues.Length.ToString();
            textBoxCheckingsKey.Text = addedKeyValues;
        }

        public void Alg23()
        {
            checkBoxCombined2PHTConsiderSlackTime.Checked = true;

            if (checkBoxAlg23Key.Checked)
            {
                numericUpDownCombined2PHTMaxHTKeyLength.Value = 64;
                numericUpDownCombined2KeyLength.Value = 128;
            }

            Samimi02Encryption();
        }

        public void Alg24()
        {
            checkBoxCombined2PHTConsiderSlackTime.Checked = false;

            if (checkBoxAlg24Key.Checked)
            {
                numericUpDownCombined2PHTMaxHTKeyLength.Value = 64;
                numericUpDownCombined2KeyLength.Value = 128;
            }

            Samimi02Encryption();
        }

    }
}
