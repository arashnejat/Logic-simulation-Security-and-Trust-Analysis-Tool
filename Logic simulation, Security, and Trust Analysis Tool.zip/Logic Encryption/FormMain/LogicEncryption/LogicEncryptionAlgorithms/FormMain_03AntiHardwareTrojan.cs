﻿using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class FormMain
    {
        /// <summary>
        /// جمع آوری متغیر های لازم برای اجرای الگوریتم از کنترل های موجود بر فرم
        /// انجام گزارش گیری قبل از اجرای الگوریتم
        /// ارسال به تابع الگوریتم و اجرای الگوریتم
        /// انجام گزارش گیری پس از اجرای الگوریتم
        /// </summary>
        private void Alg13AntiHardwareTrojanOriginalEncryption()
        {
            var generateFanouts = checkBoxGenerateFanouts.Checked;
            List<Net> outputNets;
            var nets = Parser.CreateNets(textBoxInput.Text, generateFanouts, out outputNets);

            if (nets == null || nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            var originalNetlist = textBoxInput.Text;
            var keyLength = (int)numericUpDownHTKeyLength.Value;
            var NB_GATE = keyLength;
            var SLACK_MIN = (int)numericUpDownHTSlackMin.Value;
            var PROBA_MIN = (double)numericUpDownHTProbMin.Value;
            var clockTimes = (int)numericUpDownHTClockTicks.Value;
            var randomSeed = (int)numericUpDownHTRandomSeed.Value;
            var randomPatternsCount = (int)numericUpDownHTRandomPatterns.Value;
            var meetThreshold = checkBoxHTMeetThreshold.Checked;
            var threshold = (double)numericUpDownHTThreshold.Value;
            var textBox = textBoxOutput;
            string addedKeyValues;

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "Alg13AHTOriginal",
                netlistName: _netlistName,
                directoryComment: textBoxHTDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = true;//checkBoxHTReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = true;//checkBoxHTReportSlackTimesBeforeEncryption.Checked;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Alg13 Anti Hardware Trojan (Original)" + "\r\n" +
                                             "Comment:\t" + textBoxHTInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "NB_GATE:\t" + NB_GATE + "\r\n" +
                                             "SLACK_MIN:\t" + SLACK_MIN + "\r\n" +
                                             "PROBA_MIN:\t" + PROBA_MIN + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "randomPatternsCount:\t" + randomPatternsCount + "\r\n" +
                                             "threshold:\t" + threshold + "\r\n" +
                                             "meetThreshold:\t" + meetThreshold + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(nets: nets, originalNetlist: originalNetlist, forceCalculate: checkBoxHTDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            HTEncryption.Alg13EncryptOriginalAlgorithm(
                nets: nets,
                NB_GATE: NB_GATE,
                SLACK_MIN: SLACK_MIN,
                PROBA_MIN: PROBA_MIN,
                addedKeyValues: out addedKeyValues,
                textBox: textBox,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                randomPatternsCount: randomPatternsCount,
                threshold: threshold,
                meetThreshold: meetThreshold,
                reportObject: reportObject,
                netlistName: _netlistName,
                forceCalculate: checkBoxHTDontUseCache.Checked);

            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.EncryptionDetails += "generated key:\t" + addedKeyValues + "\r\n" +
                                              "generated key length:\t" + addedKeyValues.Length + "\r\n";

            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            textBoxHTGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }

        private void Alg18AntiHardwareTrojanOriginalEncryptionNoSlackTime()
        {
            var generateFanouts = checkBoxGenerateFanouts.Checked;
            List<Net> outputNets;
            var nets = Parser.CreateNets(textBoxInput.Text, generateFanouts, out outputNets);

            if (nets == null || nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            var originalNetlist = textBoxInput.Text;
            var keyLength = (int)numericUpDownHTKeyLength.Value;
            var NB_GATE = keyLength;
            var SLACK_MIN = (int)numericUpDownHTSlackMin.Value;
            var PROBA_MIN = (double)numericUpDownHTProbMin.Value;
            var clockTimes = (int)numericUpDownHTClockTicks.Value;
            var randomSeed = (int)numericUpDownHTRandomSeed.Value;
            var randomPatternsCount = (int)numericUpDownHTRandomPatterns.Value;
            var meetThreshold = checkBoxHTMeetThreshold.Checked;
            var threshold = (double)numericUpDownHTThreshold.Value;
            var textBox = textBoxOutput;
            string addedKeyValues;

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "Alg18ATOrigNS",
                netlistName: _netlistName,
                directoryComment: textBoxHTDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = true;//checkBoxHTReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = true;//checkBoxHTReportSlackTimesBeforeEncryption.Checked;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Alg18 Anti Hardware Trojan (Original) NoSlackTime" + "\r\n" +
                                             "Comment:\t" + textBoxHTInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "NB_GATE:\t" + NB_GATE + "\r\n" +
                                             "ConsiderSlackTime:\t" + false + "\r\n" +
                                             "SLACK_MIN:\t" + SLACK_MIN + "\r\n" +
                                             "PROBA_MIN:\t" + PROBA_MIN + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "randomPatternsCount:\t" + randomPatternsCount + "\r\n" +
                                             "threshold:\t" + threshold + "\r\n" +
                                             "meetThreshold:\t" + meetThreshold + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(nets: nets, originalNetlist: originalNetlist, forceCalculate: checkBoxHTDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            HTEncryption.Alg13EncryptOriginalAlgorithm(
                nets: nets,
                NB_GATE: NB_GATE,
                SLACK_MIN: SLACK_MIN,
                PROBA_MIN: PROBA_MIN,
                addedKeyValues: out addedKeyValues,
                textBox: textBox,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                randomPatternsCount: randomPatternsCount,
                threshold: threshold,
                meetThreshold: meetThreshold,
                reportObject: reportObject,
                netlistName: _netlistName,
                forceCalculate: checkBoxHTDontUseCache.Checked,
                considerSlackTime: false);

            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.EncryptionDetails += "generated key:\t" + addedKeyValues + "\r\n" +
                                              "generated key length:\t" + addedKeyValues.Length + "\r\n";

            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            textBoxHTGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }


        private void Alg04AntiHardwareTrojanEnhancedEncryption()
        {
            var generateFanouts = checkBoxGenerateFanouts.Checked;
            List<Net> outputNets;
            var nets = Parser.CreateNets(textBoxInput.Text, generateFanouts, out outputNets);

            if (nets == null || nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            var originalNetlist = textBoxInput.Text;
            var keyLength = (int)numericUpDownHTKeyLength.Value;
            var NB_GATE = keyLength;
            var SLACK_MIN = (int) numericUpDownHTSlackMin.Value;
            var PROBA_MIN = (double) numericUpDownHTProbMin.Value;
            var clockTimes = (int) numericUpDownHTClockTicks.Value;
            var randomSeed = (int) numericUpDownHTRandomSeed.Value;
            var randomPatternsCount = (int) numericUpDownHTRandomPatterns.Value;
            var meetThreshold = checkBoxHTMeetThreshold.Checked;
            var threshold = (double) numericUpDownHTThreshold.Value;
            var textBox = textBoxOutput;
            string addedKeyValues;

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "Alg04AHTEnhanced",
                netlistName: _netlistName,
                directoryComment: textBoxHTDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = true;//checkBoxHTReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = true;//checkBoxHTReportSlackTimesBeforeEncryption.Checked;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Alg04 Anti Hardware Trojan (Enhanced)" + "\r\n" +
                                             "Comment:\t" + textBoxHTInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "NB_GATE:\t" + NB_GATE + "\r\n" +
                                             "SLACK_MIN:\t" + SLACK_MIN + "\r\n" +
                                             "PROBA_MIN:\t" + PROBA_MIN + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "randomPatternsCount:\t" + randomPatternsCount + "\r\n" +
                                             "threshold:\t" + threshold + "\r\n" +
                                             "meetThreshold:\t" + meetThreshold + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(nets: nets, originalNetlist: originalNetlist, forceCalculate: checkBoxHTDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            HTEncryption.Alg04EncryptEnhancedHTEncryptionProposedAlg0(
                nets: nets, 
                NB_GATE: NB_GATE,
                SLACK_MIN: SLACK_MIN, 
                PROBA_MIN: PROBA_MIN, 
                addedKeyValues: out addedKeyValues,
                textBox: textBox,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                randomPatternsCount: randomPatternsCount,
                threshold: threshold,
                meetThreshold: meetThreshold,
                reportObject: reportObject,
                netlistName: _netlistName,
                forceCalculate: checkBoxHTDontUseCache.Checked);

            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.EncryptionDetails += "generated key:\t" + addedKeyValues + "\r\n" +
                                              "generated key length:\t" + addedKeyValues.Length + "\r\n";

            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            textBoxHTGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }

        private void Alg19AntiHardwareTrojanEnhancedEncryptionNoSlackTime()
        {
            var generateFanouts = checkBoxGenerateFanouts.Checked;
            List<Net> outputNets;
            var nets = Parser.CreateNets(textBoxInput.Text, generateFanouts, out outputNets);

            if (nets == null || nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            var originalNetlist = textBoxInput.Text;
            var keyLength = (int)numericUpDownHTKeyLength.Value;
            var NB_GATE = keyLength;
            var SLACK_MIN = (int)numericUpDownHTSlackMin.Value;
            var PROBA_MIN = (double)numericUpDownHTProbMin.Value;
            var clockTimes = (int)numericUpDownHTClockTicks.Value;
            var randomSeed = (int)numericUpDownHTRandomSeed.Value;
            var randomPatternsCount = (int)numericUpDownHTRandomPatterns.Value;
            var meetThreshold = checkBoxHTMeetThreshold.Checked;
            var threshold = (double)numericUpDownHTThreshold.Value;
            var textBox = textBoxOutput;
            string addedKeyValues;

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "Alg19ATEnhNoST",
                netlistName: _netlistName,
                directoryComment: textBoxHTDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = true;//checkBoxHTReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = true;//checkBoxHTReportSlackTimesBeforeEncryption.Checked;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Alg19 Anti Hardware Trojan (Enhanced) NoSlackTime" + "\r\n" +
                                             "Comment:\t" + textBoxHTInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "NB_GATE:\t" + NB_GATE + "\r\n" +
                                             "ConsiderSlackTime:\t" + false + "\r\n" +
                                             "SLACK_MIN:\t" + SLACK_MIN + "\r\n" +
                                             "PROBA_MIN:\t" + PROBA_MIN + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "randomPatternsCount:\t" + randomPatternsCount + "\r\n" +
                                             "threshold:\t" + threshold + "\r\n" +
                                             "meetThreshold:\t" + meetThreshold + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(nets: nets, originalNetlist: originalNetlist, forceCalculate: checkBoxHTDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            HTEncryption.Alg04EncryptEnhancedHTEncryptionProposedAlg0(
                nets: nets,
                NB_GATE: NB_GATE,
                SLACK_MIN: SLACK_MIN,
                PROBA_MIN: PROBA_MIN,
                addedKeyValues: out addedKeyValues,
                textBox: textBox,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                randomPatternsCount: randomPatternsCount,
                threshold: threshold,
                meetThreshold: meetThreshold,
                reportObject: reportObject,
                netlistName: _netlistName,
                forceCalculate: checkBoxHTDontUseCache.Checked,
                considerSlackTime: false);

            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.EncryptionDetails += "generated key:\t" + addedKeyValues + "\r\n" +
                                              "generated key length:\t" + addedKeyValues.Length + "\r\n";

            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            textBoxHTGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }


        private void Alg17AntiHardwareTrojanEnhancedEncryption()
        {
            var generateFanouts = checkBoxGenerateFanouts.Checked;
            List<Net> outputNets;
            var nets = Parser.CreateNets(textBoxInput.Text, generateFanouts, out outputNets);

            if (nets == null || nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            var originalNetlist = textBoxInput.Text;
            var keyLength = (int)numericUpDownHTKeyLength.Value;
            var NB_GATE = keyLength;
            var SLACK_MIN = (int)numericUpDownHTSlackMin.Value;
            var PROBA_MIN = (double)numericUpDownHTProbMin.Value;
            var clockTimes = (int)numericUpDownHTClockTicks.Value;
            var randomSeed = (int)numericUpDownHTRandomSeed.Value;
            var randomPatternsCount = (int)numericUpDownHTRandomPatterns.Value;
            var meetThreshold = checkBoxHTMeetThreshold.Checked;
            var threshold = (double)numericUpDownHTThreshold.Value;
            var textBox = textBoxOutput;
            string addedKeyValues;

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "Alg17AHTEnhanced2",
                netlistName: _netlistName,
                directoryComment: textBoxHTDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = true;//checkBoxHTReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = true;//checkBoxHTReportSlackTimesBeforeEncryption.Checked;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Alg17 Anti Hardware Trojan (Enhanced 2)" + "\r\n" +
                                             "Comment:\t" + textBoxHTInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "NB_GATE:\t" + NB_GATE + "\r\n" +
                                             "SLACK_MIN:\t" + SLACK_MIN + "\r\n" +
                                             "PROBA_MIN:\t" + PROBA_MIN + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "randomPatternsCount:\t" + randomPatternsCount + "\r\n" +
                                             "threshold:\t" + threshold + "\r\n" +
                                             "meetThreshold:\t" + meetThreshold + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(nets: nets, originalNetlist: originalNetlist, forceCalculate: checkBoxHTDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            HTEncryption.Alg17EncryptEnhancedHTEncryptionMyIdeaFailed(
                nets: nets,
                NB_GATE: NB_GATE,
                SLACK_MIN: SLACK_MIN,
                PROBA_MIN: PROBA_MIN,
                addedKeyValues: out addedKeyValues,
                textBox: textBox,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                randomPatternsCount: randomPatternsCount,
                threshold: threshold,
                meetThreshold: meetThreshold,
                reportObject: reportObject,
                netlistName: _netlistName,
                forceCalculate: checkBoxHTDontUseCache.Checked);

            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.EncryptionDetails += "generated key:\t" + addedKeyValues + "\r\n" +
                                              "generated key length:\t" + addedKeyValues.Length + "\r\n";

            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            textBoxHTGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }

        private void Alg20AntiHardwareTrojanEnhancedEncryptionNoSlackTime()
        {
            var generateFanouts = checkBoxGenerateFanouts.Checked;
            List<Net> outputNets;
            var nets = Parser.CreateNets(textBoxInput.Text, generateFanouts, out outputNets);

            if (nets == null || nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            var originalNetlist = textBoxInput.Text;
            var keyLength = (int)numericUpDownHTKeyLength.Value;
            var NB_GATE = keyLength;
            var SLACK_MIN = (int)numericUpDownHTSlackMin.Value;
            var PROBA_MIN = (double)numericUpDownHTProbMin.Value;
            var clockTimes = (int)numericUpDownHTClockTicks.Value;
            var randomSeed = (int)numericUpDownHTRandomSeed.Value;
            var randomPatternsCount = (int)numericUpDownHTRandomPatterns.Value;
            var meetThreshold = checkBoxHTMeetThreshold.Checked;
            var threshold = (double)numericUpDownHTThreshold.Value;
            var textBox = textBoxOutput;
            string addedKeyValues;

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "Alg20ATEnh2NST",
                netlistName: _netlistName,
                directoryComment: textBoxHTDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = true;//checkBoxHTReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = true;//checkBoxHTReportSlackTimesBeforeEncryption.Checked;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Alg20 Anti Hardware Trojan (Enhanced 2) NoSlackTime" + "\r\n" +
                                             "Comment:\t" + textBoxHTInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "NB_GATE:\t" + NB_GATE + "\r\n" +
                                             "ConsiderSlackTime:\t" + false + "\r\n" +
                                             "SLACK_MIN:\t" + SLACK_MIN + "\r\n" +
                                             "PROBA_MIN:\t" + PROBA_MIN + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "randomPatternsCount:\t" + randomPatternsCount + "\r\n" +
                                             "threshold:\t" + threshold + "\r\n" +
                                             "meetThreshold:\t" + meetThreshold + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(nets: nets, originalNetlist: originalNetlist, forceCalculate: checkBoxHTDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            HTEncryption.Alg17EncryptEnhancedHTEncryptionMyIdeaFailed(
                nets: nets,
                NB_GATE: NB_GATE,
                SLACK_MIN: SLACK_MIN,
                PROBA_MIN: PROBA_MIN,
                addedKeyValues: out addedKeyValues,
                textBox: textBox,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                randomPatternsCount: randomPatternsCount,
                threshold: threshold,
                meetThreshold: meetThreshold,
                reportObject: reportObject,
                netlistName: _netlistName,
                forceCalculate: checkBoxHTDontUseCache.Checked,
                considerSlackTime: false);

            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.EncryptionDetails += "generated key:\t" + addedKeyValues + "\r\n" +
                                              "generated key length:\t" + addedKeyValues.Length + "\r\n";

            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            textBoxHTGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }

        private void Alg21AntiHardwareTrojanEnhancedEncryptionXORXNORSync()
        {
            var generateFanouts = checkBoxGenerateFanouts.Checked;
            List<Net> outputNets;
            var nets = Parser.CreateNets(textBoxInput.Text, generateFanouts, out outputNets);

            if (nets == null || nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            var originalNetlist = textBoxInput.Text;
            var keyLength = (int)numericUpDownHTKeyLength.Value;
            var SLACK_MIN = (int)numericUpDownHTSlackMin.Value;
            var PROBA_MIN = (double)numericUpDownHTProbMin.Value;
            var clockTimes = (int)numericUpDownHTClockTicks.Value;
            var randomSeed = (int)numericUpDownHTRandomSeed.Value;
            var randomPatternsCount = (int)numericUpDownHTRandomPatterns.Value;
            var meetThreshold = checkBoxHTMeetThreshold.Checked;
            var threshold = (double)numericUpDownHTThreshold.Value;
            var rRandomSeed = (int)numericUpDownHTRRandomSeed.Value;
            var encryptionkey = textBoxMainInputKey.Text.Substring(0, keyLength);

            var textBox = textBoxOutput;
            string addedKeyValues;

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "Alg21AHTEnhX",
                netlistName: _netlistName,
                directoryComment: textBoxHTDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = true;//checkBoxHTReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = true;//checkBoxHTReportSlackTimesBeforeEncryption.Checked;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Alg21 Anti Hardware Trojan (Enhanced) XOR/XNOR Inverter Synced" + "\r\n" +
                                             "Comment:\t" + textBoxHTInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "encryptionkey:\t" + encryptionkey + "\r\n" +
                                             "SLACK_MIN:\t" + SLACK_MIN + "\r\n" +
                                             "PROBA_MIN:\t" + PROBA_MIN + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "rRandomSeed:\t" + rRandomSeed + "\r\n" +
                                             "randomPatternsCount:\t" + randomPatternsCount + "\r\n" +
                                             "threshold:\t" + threshold + "\r\n" +
                                             "meetThreshold:\t" + meetThreshold + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(nets: nets, originalNetlist: originalNetlist, forceCalculate: checkBoxHTDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            HTEncryption.Alg21EncryptEnhancedXHTEncryptionProposedAlg1(
                nets: nets,
                encryptionKey: encryptionkey,
                SLACK_MIN: SLACK_MIN,
                PROBA_MIN: PROBA_MIN,
                addedKeyValues: out addedKeyValues,
                textBox: textBox,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                randomPatternsCount: randomPatternsCount,
                threshold: threshold,
                meetThreshold: meetThreshold,
                reportObject: reportObject,
                netlistName: _netlistName,
                forceCalculate: checkBoxHTDontUseCache.Checked,
                rRandomSeed: rRandomSeed);

            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.EncryptionDetails += "generated key:\t" + addedKeyValues + "\r\n" +
                                              "generated key length:\t" + addedKeyValues.Length + "\r\n";

            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            textBoxHTGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }

        private void Alg22AntiHardwareTrojanEnhancedEncryptionXORXNORNoSlackTimeSync()
        {
            var generateFanouts = checkBoxGenerateFanouts.Checked;
            List<Net> outputNets;
            var nets = Parser.CreateNets(textBoxInput.Text, generateFanouts, out outputNets);

            if (nets == null || nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            var originalNetlist = textBoxInput.Text;
            var keyLength = (int)numericUpDownHTKeyLength.Value;
            var SLACK_MIN = (int)numericUpDownHTSlackMin.Value;
            var PROBA_MIN = (double)numericUpDownHTProbMin.Value;
            var clockTimes = (int)numericUpDownHTClockTicks.Value;
            var randomSeed = (int)numericUpDownHTRandomSeed.Value;
            var randomPatternsCount = (int)numericUpDownHTRandomPatterns.Value;
            var meetThreshold = checkBoxHTMeetThreshold.Checked;
            var threshold = (double)numericUpDownHTThreshold.Value;
            var rRandomSeed = (int)numericUpDownHTRRandomSeed.Value;
            var encryptionkey = textBoxMainInputKey.Text.Substring(0, keyLength);

            var textBox = textBoxOutput;
            string addedKeyValues;

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "Alg22AHTEnhXNST",
                netlistName: _netlistName,
                directoryComment: textBoxHTDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = true;//checkBoxHTReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = true;//checkBoxHTReportSlackTimesBeforeEncryption.Checked;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Alg22 Anti Hardware Trojan (Enhanced) XOR/XNOR Inverter No Slack Time Synced" + "\r\n" +
                                             "Comment:\t" + textBoxHTInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "encryptionkey:\t" + encryptionkey + "\r\n" +
                                             "SLACK_MIN:\t" + SLACK_MIN + "\r\n" +
                                             "PROBA_MIN:\t" + PROBA_MIN + "\r\n" +
                                             "considerSlackTime:\t" + false + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "rRandomSeed:\t" + rRandomSeed + "\r\n" +
                                             "randomPatternsCount:\t" + randomPatternsCount + "\r\n" +
                                             "threshold:\t" + threshold + "\r\n" +
                                             "meetThreshold:\t" + meetThreshold + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(nets: nets, originalNetlist: originalNetlist, forceCalculate: checkBoxHTDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            HTEncryption.Alg21EncryptEnhancedXHTEncryptionProposedAlg1(
                nets: nets,
                encryptionKey: encryptionkey,
                SLACK_MIN: SLACK_MIN,
                PROBA_MIN: PROBA_MIN,
                addedKeyValues: out addedKeyValues,
                textBox: textBox,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                randomPatternsCount: randomPatternsCount,
                threshold: threshold,
                meetThreshold: meetThreshold,
                reportObject: reportObject,
                netlistName: _netlistName,
                forceCalculate: checkBoxHTDontUseCache.Checked,
                rRandomSeed: rRandomSeed,
                considerSlackTime: false);

            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.EncryptionDetails += "generated key:\t" + addedKeyValues + "\r\n" +
                                              "generated key length:\t" + addedKeyValues.Length + "\r\n";

            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            textBoxHTGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }

    }
}
