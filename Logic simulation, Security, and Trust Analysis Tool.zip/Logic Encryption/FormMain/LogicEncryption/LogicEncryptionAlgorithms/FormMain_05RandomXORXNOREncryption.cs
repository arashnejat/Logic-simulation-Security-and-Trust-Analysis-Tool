﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public partial class FormMain
    {
        private void RandomXORXNOREncrypt()
        {
            ParseInputAgain();
            if (_nets == null || _nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            if (checkBoxRandomXORXNORRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownRandomXORXNORRandomSeed.Value = random.Next(1, (int)numericUpDownRandomXORXNORRandomSeed.Maximum);
            }

            progressBarMain.Visible = true;
            textBoxGeneratedNetlist.Text = "";

            var keyLength = (int)numericUpDownRandomXORXNORKeyLength.Value;
            var randomSeed = (int)numericUpDownRandomXORXNORRandomSeed.Value;
            var rRandomSeed = (int)numericUpDownRandomXORXNORRRandomSeed.Value;
            var forceCalculate = checkBoxRandomXORXNORDontUseCache.Checked;
            var encryptionkey = textBoxMainInputKey.Text.Substring(0, keyLength);

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "RandomXORXNOR",
                netlistName: _netlistName,
                directoryComment: textBoxRandomXORXNORDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = checkBoxRandomXORXNORReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = false;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Random XOR XNOR Encryption" + "\r\n" +
                                             "Comment:\t" + textBoxRandomXORXNORInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "encryptionkey:\t" + encryptionkey + "\r\n" +
                                             "keylength:\t" + keyLength + "\r\n" +
                                             "rRandomSeed:\t" + rRandomSeed + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(nets: _nets, originalNetlist: textBoxInput.Text, forceCalculate: checkBoxRandomXORXNORDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            string addedKeyValues;
            RandomXORXNOREncryption.RandomXORXNOREncrypt(
                nets: _nets,
                encryptionKey: encryptionkey,
                textBox: textBoxOutput,
                progressBar: progressBarMain,
                randomSeed: randomSeed,
                rRandomSeed: rRandomSeed,
                reportObject: reportObject,
                netlistName: _netlistName,
                addedKeyValues: out addedKeyValues,
                forceCalculate: forceCalculate);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            progressBarMain.Visible = false;
            textBoxRandomXORXNORGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }
    }
}
