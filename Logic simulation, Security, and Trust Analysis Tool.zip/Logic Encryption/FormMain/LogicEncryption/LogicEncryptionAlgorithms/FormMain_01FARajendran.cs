﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicEncryption
{
    public partial class FormMain
    {
        /// <summary>
        /// جمع آوری متغیر های لازم برای اجرای الگوریتم از کنترل های موجود بر فرم
        /// انجام گزارش گیری قبل از اجرای الگوریتم
        /// ارسال به تابع الگوریتم و اجرای الگوریتم
        /// انجام گزارش گیری پس از اجرای الگوریتم
        /// </summary>
        private void Alg01FARajendranEncryptOriginal()
        {
            ParseInputAgain();
            if (_nets == null || _nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);

            if (checkBoxFARajendranRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownFARajendranRandomSeed.Value = random.Next(1, (int)numericUpDownFARajendranRandomSeed.Maximum);
            }

            progressBarMain.Visible = true;
            textBoxGeneratedNetlist.Text = "";

            var keyLength = (int)numericUpDownFARajendranKeyLength.Value;
            var randomSeed = (int)numericUpDownFARajendranRandomSeed.Value;
            var uniqueRandomPatterns = checkBoxFARajendranUniqueRandomPatterns.Checked;
            var clockTimes = (int)numericUpDownFARajendranClockTimes.Value;
            var threadsCount = (int)numericUpDownFARajendranNumberOfThreads.Value;
            var randomNumbers = (int)numericUpDownFARajendranRandomPatterns.Value;
            var rRandomSeed = (int) numericUpDownFARajendranRRandomSeed.Value;
            var encryptionKey = textBoxMainInputKey.Text.Substring(0, keyLength);
            var useFaultImpacts2 = checkBoxFARajendranUseFaultImpacts2.Checked;

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "Alg01FARO",
                netlistName: _netlistName,
                directoryComment: textBoxFARajendranDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = checkBoxFARajendranReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = false;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound= checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Alg01 FA Rajendran (Original)" + "\r\n" +
                                             "Comment:\t" + textBoxFARajendranInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "encryptionKey:\t" + encryptionKey + "\r\n" +
                                             "keylength:\t" + keyLength + "\r\n" +
                                             "rRandomSeed:\t" + rRandomSeed + "\r\n" + 
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "uniqueRandomPatterns:\t" + uniqueRandomPatterns + "\r\n" +
                                             "useFaultImpacts2:\t" + useFaultImpacts2 + "\r\n" +  /**/
                                             "clockTimes:\t" + clockTimes + "\r\n" +
                                             "randomNumbers:\t" + randomNumbers + "\r\n" +
                                             "threadsCount:\t" + threadsCount + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(_nets, textBoxInput.Text, forceCalculate: checkBoxFARajendranDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            string addedKeyValues;
            FARajendran.Alg01FARajendranOriginalEncrypt(
                nets: _nets,
                encryptionKey: encryptionKey,
                rRandomSeed: rRandomSeed,
                textBox: textBoxOutput,
                progressBar: progressBarMain,
                randomSeed: randomSeed,
                uniqueRandomPatterns: uniqueRandomPatterns,
                reportObject: reportObject,
                clockTimes: clockTimes,
                threadsCount: threadsCount,
                randomNumbers: randomNumbers,
                netlistName: _netlistName,
                
                createReport: false,
                forceCalculate: checkBoxFARajendranDontUseCache.Checked,
                addedKeyValues: out addedKeyValues,
                useFaultImpacts2: useFaultImpacts2);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            progressBarMain.Visible = false;
            textBoxFARajendranGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }

        private void Alg02FARajendranEnrcyptAsIPresumeItIs()
        {
            ParseInputAgain();
            if (_nets == null || _nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);


            if (checkBoxFARajendranRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownFARajendranRandomSeed.Value = random.Next(1, (int)numericUpDownFARajendranRandomSeed.Maximum);
            }

            progressBarMain.Visible = true;
            textBoxGeneratedNetlist.Text = "";

            var keyLength = (int)numericUpDownFARajendranKeyLength.Value;
            var randomSeed = (int)numericUpDownFARajendranRandomSeed.Value;
            var rRandomSeed = (int)numericUpDownFARajendranRRandomSeed.Value;
            var uniqueRandomPatterns = checkBoxFARajendranUniqueRandomPatterns.Checked;
            var clockTimes = (int)numericUpDownFARajendranClockTimes.Value;
            var threadsCount = (int)numericUpDownFARajendranNumberOfThreads.Value;
            var randomNumbers = (int)numericUpDownFARajendranRandomPatterns.Value;
            var encryptionKey = textBoxMainInputKey.Text.Substring(0, keyLength);

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "Alg02FARMA",
                netlistName: _netlistName,
                directoryComment: textBoxFARajendranDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = checkBoxFARajendranReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = false;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Alg02 FA Rajendran (As I Presume It Is)" + "\r\n" +
                                             "Comment:\t" + textBoxFARajendranInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "encryptionKey:\t" + encryptionKey + "\r\n" +
                                             "keylength:\t" + keyLength + "\r\n" +
                                             "rRandomSeed:\t" + rRandomSeed + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "uniqueRandomPatterns:\t" + uniqueRandomPatterns + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n" +
                                             "randomNumbers:\t" + randomNumbers + "\r\n" +
                                             "threadsCount:\t" + threadsCount + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(_nets, textBoxInput.Text, checkBoxFARajendranDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            string addedKeyValues;
            FARajendran.Alg02FARajendranAsIPresumeItIsEncrypt(
                nets: _nets,
                encryptionKey: encryptionKey,
                textBox: textBoxOutput,
                progressBar: progressBarMain,
                randomSeed: randomSeed,
                rRandomSeed: rRandomSeed,
                uniqueRandomPatterns: uniqueRandomPatterns,
                reportObject: reportObject,
                clockTimes: clockTimes,
                threadsCount: threadsCount,
                randomNumbers: randomNumbers,
                netlistName: _netlistName,
                
                createReport: false,
                forceCalculate: checkBoxFARajendranDontUseCache.Checked,
                addedKeyValues: out addedKeyValues);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            progressBarMain.Visible = false;
            textBoxFARajendranGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }

        private void Alg10FARajendranEnrcypt()
        {
            ParseInputAgain();
            if (_nets == null || _nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);


            if (checkBoxFARajendranRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownFARajendranRandomSeed.Value = random.Next(1, (int)numericUpDownFARajendranRandomSeed.Maximum);
            }

            progressBarMain.Visible = true;
            textBoxGeneratedNetlist.Text = "";

            var keyLength = (int)numericUpDownFARajendranKeyLength.Value;
            var randomSeed = (int)numericUpDownFARajendranRandomSeed.Value;
            var rRandomSeed = (int)numericUpDownFARajendranRRandomSeed.Value;
            var uniqueRandomPatterns = checkBoxFARajendranUniqueRandomPatterns.Checked;
            var clockTimes = (int)numericUpDownFARajendranClockTimes.Value;
            var threadsCount = (int)numericUpDownFARajendranNumberOfThreads.Value;
            var randomNumbers = (int)numericUpDownFARajendranRandomPatterns.Value;
            var encryptionKey = textBoxMainInputKey.Text.Substring(0, keyLength);

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "Alg10FAR",
                netlistName: _netlistName,
                directoryComment: textBoxFARajendranDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = checkBoxFARajendranReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = false;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Alg10 FA Rajendran (Algorithm 10)" + "\r\n" +
                                             "Comment:\t" + textBoxFARajendranInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "encryptionKey:\t" + encryptionKey + "\r\n" +
                                             "keylength:\t" + keyLength + "\r\n" +
                                             "rRandomSeed:\t" + rRandomSeed + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "uniqueRandomPatterns:\t" + uniqueRandomPatterns + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n" +
                                             "randomNumbers:\t" + randomNumbers + "\r\n" +
                                             "threadsCount:\t" + threadsCount + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(_nets, textBoxInput.Text, checkBoxFARajendranDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            string addedKeyValues;
            FARajendran.Alg10FARajendran(
                nets: _nets,
                encryptionKey: encryptionKey,
                textBox: textBoxOutput,
                progressBar: progressBarMain,
                randomSeed: randomSeed,
                rRandomSeed: rRandomSeed,
                uniqueRandomPatterns: uniqueRandomPatterns,
                reportObject: reportObject,
                clockTimes: clockTimes,
                threadsCount: threadsCount,
                randomNumbers: randomNumbers,
                netlistName: _netlistName,
                
                createReport: false,
                forceCalculate: checkBoxFARajendranDontUseCache.Checked,
                addedKeyValues: out addedKeyValues);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            progressBarMain.Visible = false;
            textBoxFARajendranGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }

        private void Alg11FARajendranEnrcypt()
        {
            ParseInputAgain();
            if (_nets == null || _nets.Count == 0)
                return;
            //-------------------------------------------------------------------------------
            tabControlOutput.SelectTab(tabPageOutputLog);


            if (checkBoxFARajendranRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownFARajendranRandomSeed.Value = random.Next(1, (int)numericUpDownFARajendranRandomSeed.Maximum);
            }

            progressBarMain.Visible = true;
            textBoxGeneratedNetlist.Text = "";

            var keyLength = (int)numericUpDownFARajendranKeyLength.Value;
            var randomSeed = (int)numericUpDownFARajendranRandomSeed.Value;
            var rRandomSeed = (int)numericUpDownFARajendranRRandomSeed.Value;
            var uniqueRandomPatterns = checkBoxFARajendranUniqueRandomPatterns.Checked;
            var clockTimes = (int)numericUpDownFARajendranClockTimes.Value;
            var threadsCount = (int)numericUpDownFARajendranNumberOfThreads.Value;
            var randomNumbers = (int)numericUpDownFARajendranRandomPatterns.Value;
            var encryptionkey = textBoxMainInputKey.Text.Substring(0, keyLength);

            var reportObject = new SimulationReporter(
                archiveDirectoryPath: ResultsDirectory,
                methodName: "Alg11FAR",
                netlistName: _netlistName,
                directoryComment: textBoxFARajendranDirectoryComment.Text,
                textBox: textBoxOutput,
                keyLength: keyLength);

            reportObject.ReportProbabilitiesBefore = checkBoxFARajendranReportProbabilitiesBeforeEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsBefore = false;
            reportObject.ReportHammingDistanceAfterRound = checkBoxReportHammingDistanceAfterEncryption.Checked;
            reportObject.ReportIntegrityOfEncryption = checkBoxReportIntegrityAfterEncryption.Checked;
            reportObject.ReportProbabilitiesAfterRound = checkBoxReportProbabilitiesAfterEncryption.Checked;
            reportObject.ReportSlackTimesAndLevelizationsAfterRound = checkBoxReportSlackTimesAfterEncryption.Checked;

            reportObject.EncryptionDetails = "Encryption:\t" + "Alg11 FA Rajendran (Algorithm 11)" + "\r\n" +
                                             "Comment:\t" + textBoxFARajendranInlineComment.Text + "\r\n" +
                                             "NetlistName:\t" + _netlistName + "\r\n" +
                                             "encryptionkey:\t" + encryptionkey + "\r\n" +
                                             "keylength:\t" + keyLength + "\r\n" +
                                             "rRandomSeed:\t" + rRandomSeed + "\r\n" +
                                             "randomSeed:\t" + randomSeed + "\r\n" +
                                             "uniqueRandomPatterns:\t" + uniqueRandomPatterns + "\r\n" +
                                             "clockTimes:\t" + clockTimes + "\r\n" +
                                             "randomNumbers:\t" + randomNumbers + "\r\n" +
                                             "threadsCount:\t" + threadsCount + "\r\n";
            //-------------------------------------------------------------------------------
            PrepareSimulationReporterForPowerAeraDelay(reportObject);
            PrepareSimulationReporterForCheckings(reportObject);
            PrepareSimulationReporterForProbabilityAnalysis(reportObject);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog(reportObject.EncryptionDetails);
            //-------------------------------------------------------------------------------
            reportObject.Step01CreateBeforeEncryptionReport(_nets, textBoxInput.Text, checkBoxFARajendranDontUseCache.Checked);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Started");
            reportObject.AddToConsoleLog("Key Length:\t" + keyLength);
            //-------------------------------------------------------------------------------
            string addedKeyValues;
            FARajendran.Alg11FARajendran(
                nets: _nets,
                encryptionKey: encryptionkey,
                textBox: textBoxOutput,
                progressBar: progressBarMain,
                randomSeed: randomSeed,
                rRandomSeed: rRandomSeed,
                uniqueRandomPatterns: uniqueRandomPatterns,
                reportObject: reportObject,
                clockTimes: clockTimes,
                threadsCount: threadsCount,
                randomNumbers: randomNumbers,
                netlistName: _netlistName,
                
                createReport: false,
                forceCalculate: checkBoxFARajendranDontUseCache.Checked,
                addedKeyValues: out addedKeyValues);
            //-------------------------------------------------------------------------------
            reportObject.AddToConsoleLog("Encryption Finished");
            reportObject.AddToConsoleLog("Generated key:\t" + addedKeyValues);
            reportObject.AddToConsoleLog("Generated key length:\t" + addedKeyValues.Length);
            //-------------------------------------------------------------------------------
            reportObject.Step03CreateAfterEncryptionReport();
            //-------------------------------------------------------------------------------

            textBoxGeneratedNetlist.Text = reportObject.GeneratedNetlistAfterRound;
            progressBarMain.Visible = false;
            textBoxFARajendranGeneratedKey.Text = addedKeyValues;
            textBoxCheckingsKey.Text = addedKeyValues;
        }
    }
}
