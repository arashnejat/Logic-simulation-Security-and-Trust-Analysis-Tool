﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    
    public partial class FormMain
    {
        


        /// <summary>
        /// عملکرد مدار رمزگذاری شده درون تکستباکس جنریتد نتلیست را با عملکرد مدار موجود در تکستباکس اینپوت مقایسه می کند
        /// و بررسی می کند تا با ورودی های یکسان، خروجی های یکسان تولید کنند
        /// </summary>
        private string CheckIntegrityOfEncryptedCircuit(bool? loud = true)
        {
            if (checkBoxCheckingsRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownCheckingsRandomSeed.Value = random.Next(minValue: 1, maxValue: (int) numericUpDownCheckingsRandomSeed.Maximum);
            }

            var oldText = textBoxOutput.Text;
            if (!string.IsNullOrEmpty(oldText))
                oldText += "\r\n" + "_______________________" + "\r\n";

            List<Net> outputNets;
            var encryptedNets = Parser.CreateNets(input: textBoxGeneratedNetlist.Text, generateFanouts: checkBoxGenerateFanouts.Checked, outputNets: out outputNets);
            if (encryptedNets.Count == 0)
            {
                return "Error - No nets in encrypted netlist";
            }

            List<Net> outputNetsNormal;
            var normalNets = Parser.CreateNets(input: textBoxInput.Text, generateFanouts: checkBoxGenerateFanouts.Checked, outputNets: out outputNetsNormal);
            if (normalNets.Count == 0)
            {
                return "Error - No nets in normal netlist";
            }

            int randomPatternsCount = (int) numericUpDownCheckingsRandomPatterns.Value;
            var uniqueRandomPatterns = checkBoxCheckingsUniqueRandomPatterns.Checked;
            var randomSeed = (int) numericUpDownCheckingsRandomSeed.Value;
            var key = textBoxCheckingsKey.Text;
            var integrityReport = EncryptionChecker.CheckIntegrity(
                encryptedNets: encryptedNets, 
                normalNets: normalNets,
                uniqueRandomPatterns: uniqueRandomPatterns, 
                randomPatterns: randomPatternsCount, 
                randomSeed: randomSeed,
                key: key, 
                clockTimes: (int) numericUpDownCheckingsClockTimes.Value);

            if (loud.Value)
            {
                Output(oldText + integrityReport, true);
            }
            return integrityReport;
        }

        private string CalculateHammingDistanceBetweenOriginalCircuitAndEncryptedCircuit(bool? loud = true)
        {
            if (checkBoxCheckingsRandomSeed.Checked)
            {
                var random = new Random(DateTime.Now.Millisecond);
                numericUpDownCheckingsRandomSeed.Value = random.Next(1, (int)numericUpDownCheckingsRandomSeed.Maximum);
            }

            List<Net> outputNets;
            var encryptedNetlist = Parser.CreateNets(textBoxGeneratedNetlist.Text, checkBoxGenerateFanouts.Checked, out outputNets);
            if (encryptedNetlist.Count == 0)
            {
                MessageBox.Show("Error - No Nets", "Hamming Distance Check", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return "Error - No Nets";
            }

            int? randomPatterns = (int)numericUpDownCheckingsRandomPatterns.Value;
            var uniqueRandomPatterns = checkBoxCheckingsUniqueRandomPatterns.Checked;
            var randomSeed = (int)numericUpDownCheckingsRandomSeed.Value;
            var key = textBoxCheckingsKey.Text;
            var forceWrongInputs = checkBoxChickingsHammingDistanceForceWrongInputs.Checked;


            string statisticalReport = "";
            EncryptionChecker.HammingDistanceStatisticalResultHolder resultsHolder;
            var hammingDistanceReport = EncryptionChecker.CalculateHammingDistanceOfEncryptedNetlist(
                encryptedNetList: encryptedNetlist, 
                uniqueRandomPatterns: uniqueRandomPatterns, 
                randomPatterns: randomPatterns, 
                randomSeed: randomSeed, 
                forceWrongInputs: forceWrongInputs,
                key: key, 
                statisticalReport: out statisticalReport, 
                clockTimes: (int)numericUpDownCheckingsClockTimes.Value,
                resultsHolder: out resultsHolder);

            var oldText = textBoxOutput.Text;
            var newText = "";
            if (!string.IsNullOrEmpty(oldText))
                newText = oldText + "\r\n" + "_______________________" + "\r\n";

            hammingDistanceReport += statisticalReport;

            if (loud.Value)
            {
                Output(newText + hammingDistanceReport, true);
            }

            return hammingDistanceReport;
        }
    }
}
