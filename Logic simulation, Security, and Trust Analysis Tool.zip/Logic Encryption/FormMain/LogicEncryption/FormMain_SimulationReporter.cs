﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public partial class FormMain
    {
        public string ResultsDirectory = @"D:\Results (Simulation Reporter)";

        private void PrepareSimulationReporterForProbabilityAnalysis(SimulationReporter reportObject)
        {
            reportObject.ProbabiliySimulatorData.clockTimes = (int)numericUpDownLogicSimulationClockTicks.Value;
            reportObject.ProbabiliySimulatorData.meetThreshold = checkBoxLogicSimulationMeetThreshold.Checked;
            reportObject.ProbabiliySimulatorData.randomPatternsCount = (int)numericUpDownLogicSimulationRandomPatterns.Value;
            reportObject.ProbabiliySimulatorData.randomSeed = (int)numericUpDownLogicSimulationRandomSeed.Value;
            reportObject.ProbabiliySimulatorData.threshold = (double)numericUpDownLogicSimulationThreshold.Value;
            reportObject.EncryptionDetails += "ProbabiliySimulatorData.ClockTimes\t" +
                                              reportObject.ProbabiliySimulatorData.clockTimes + "\r\n" +
                                              "ProbabiliySimulatorData.meetThreshold\t" +
                                              reportObject.ProbabiliySimulatorData.meetThreshold + "\r\n" +
                                              "ProbabiliySimulatorData.randomPatternsCount\t" +
                                              reportObject.ProbabiliySimulatorData.randomPatternsCount + "\r\n" +
                                              "ProbabiliySimulatorData.randomSeed\t" +
                                              reportObject.ProbabiliySimulatorData.randomSeed + "\r\n" +
                                              "ProbabiliySimulatorData.threshold\t" +
                                              reportObject.ProbabiliySimulatorData.threshold + "\r\n";
        }

        private void PrepareSimulationReporterForCheckings(SimulationReporter reportObject)
        {
            reportObject.CheckingsInputDataObject.ClockTimes = (int)numericUpDownCheckingsClockTimes.Value;
            reportObject.CheckingsInputDataObject.GenerateFanout = checkBoxGenerateFanouts.Checked;
            reportObject.CheckingsInputDataObject.RandomSeed = (int)numericUpDownCheckingsRandomSeed.Value;
            reportObject.CheckingsInputDataObject.UseRandomSeeds = checkBoxCheckingsRandomSeed.Checked;
            reportObject.CheckingsInputDataObject.randomPatternsCount = (int)numericUpDownCheckingsRandomPatterns.Value;
            reportObject.CheckingsInputDataObject.uniqueRandomPatterns = checkBoxCheckingsUniqueRandomPatterns.Checked;
            reportObject.CheckingsInputDataObject.ForceWrongInputs = checkBoxChickingsHammingDistanceForceWrongInputs.Checked;
            reportObject.EncryptionDetails += "CheckingsInputDataObject.ClockTimes\t" +
                                              reportObject.CheckingsInputDataObject.ClockTimes + "\r\n" +
                                              "CheckingsInputDataObject.GenerateFanout\t" +
                                              reportObject.CheckingsInputDataObject.GenerateFanout + "\r\n" +
                                              "CheckingsInputDataObject.RandomSeed\t" +
                                              reportObject.CheckingsInputDataObject.RandomSeed + "\r\n" +
                                              "CheckingsInputDataObject.UseRandomSeeds\t" +
                                              reportObject.CheckingsInputDataObject.UseRandomSeeds + "\r\n" +
                                              "CheckingsInputDataObject.randomPatternsCount\t" +
                                              reportObject.CheckingsInputDataObject.randomPatternsCount + "\r\n" +
                                              "CheckingsInputDataObject.uniqueRandomPatterns\t" +
                                              reportObject.CheckingsInputDataObject.uniqueRandomPatterns + "\r\n" +
                                              "CheckingsInputDataObject.ForceWrongInputs\t" +
                                              reportObject.CheckingsInputDataObject.ForceWrongInputs + "\r\n";
        }

        private void PrepareSimulationReporterForPowerAeraDelay(SimulationReporter reportObject)
        {
            reportObject.ReportAreaAfterRound = checkBoxReportAreaAfterEncryption.Checked;
            reportObject.ReportPowerAfterRound = checkBoxReportPowerAfterEncryption.Checked;
            reportObject.ReportUserPowerAfterRound = checkBoxReportUserPowerAfterEncryption.Checked;
            reportObject.ReportDelayAfterRound = checkBoxReportDelayAfterEncryption.Checked;
            reportObject.GenerateVerilogAfterRound = checkboxGenerateVerilogAfterEncryption.Checked;
        }
    }
}
