﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicEncryption
{
    public partial class Net
    {
        public double HD;//Hamming Distance in greedy algorithm

        public double TempSmartSimulatedProbability = -1;//مقدار احتمال یک شدن سیگنال محاسبه شده
        public int numberOfRareSignalsForThisNet = 0;
    }
}
