﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateEqual : Net
    {
        public GateEqual()
        {
            GateType = GateTypes.GateEqual;
        }

        #region SCOAP Methods
        public override void SetControllabilities()
        {
            CC0.Set(Inputs[0].Net.CC0);
            CC1.Set(Inputs[0].Net.CC1);
            SC0.Set(Inputs[0].Net.SC0);
            SC1.Set(Inputs[0].Net.SC1);
        }

        public override void SetObservabilities()
        {
            var minCO = CO;
            var minSO = SO;
            foreach (var fanout in Inputs[0].Net.FanOuts)
            {
                if (fanout.CO < minCO)
                    minCO = fanout.CO;
                if (fanout.SO < minSO)
                    minSO = fanout.SO;
            }
            Inputs[0].Net.CO.SetMin(minCO);
            Inputs[0].Net.SO.SetMin(minSO);
        }
        #endregion

        //===================================================================================

        #region Signal Propagation Methods
        public Signal CalculateSignalValue()
        {
            return Inputs[0].Net.SignalValue;
        }

        public override void CalculateAndAssignSignalValue()
        {
            AssignStuckAtSignalValue(CalculateSignalValue());
        }
        #endregion

        public static Signal CalculateSValue(List<Input> Inputs)
        {
            return Inputs[0].Net.SignalValue;
        }
    }
}
