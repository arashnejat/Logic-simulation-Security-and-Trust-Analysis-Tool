﻿using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateNot : Net
    {
        public GateNot()
        {
            GateType = GateTypes.GateNot;
        }

        #region SCOAP Methods
        public override SCOAPValue CalculateCC0()
        {
            return Inputs[0].Net.CC1 + 1;
        }

        public override SCOAPValue CalculateSC0()
        {
            return Inputs[0].Net.SC1;
        }

        public override SCOAPValue CalculateCC1()
        {
            return Inputs[0].Net.CC0 + 1;
        }

        public override SCOAPValue CalculateSC1()
        {
            return Inputs[0].Net.SC0;
        }

        public override SCOAPValue COInputI(int i)
        {
            return CO + 1;
        }

        public override SCOAPValue SOInputI(int i)
        {
            return SO;
        }

        public override void SetObservabilities()
        {
            SetCOs();
            SetSOs();
        }

        public override void SetControllabilities()
        {
            SetCCs();
            SetSCs();
        }
        #endregion

        //===================================================================================

        #region Signal Propagation Methods
        public static Signal Function(Signal a)
        {
            switch (a)
            {
                case Signal.D:
                    return Signal.D_;
                case Signal.D_:
                    return Signal.D;
                case Signal.V1:
                    return Signal.V0;
                case Signal.V0:
                    return Signal.V1;
                default:
                    return Signal.X;
            }
        }

        public Signal CalculateSignalValue()
        {
            return Function(Inputs[0].Net.SignalValue);
        }

        public override void CalculateAndAssignSignalValue()
        {
            AssignStuckAtSignalValue(CalculateSignalValue());
        }
        #endregion

        public static Signal CalculateSValue(List<Input> Inputs)
        {
            return Function(Inputs[0].Net.SValue);
        }
    }
}
