﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public static class CustomGateLibrary
    {
        public static List<CustomGateLibraryObject> Library = new List<CustomGateLibraryObject>();
    }
    public class CustomGateLibraryObject
    {
        public List<string> TruthTable = new List<string>();
        public string TypeName;
        public string Description;
        public bool IsSequential;
        public string FilePath;
        public override string ToString()
        {
            return TypeName;
        }
    }
    public class GateCustom : Net
    {
        public GateCustom()
        {
            GateType = GateTypes.GateCustom;
        }

        public static bool ValidateTruthTable(string truthTableString)
        {
            string[] lineSeperators = { "\n", "\r\n" };
            var lines = truthTableString.Split(lineSeperators, StringSplitOptions.RemoveEmptyEntries);
            if (lines.Length == 0)
                return false;

            var valid = true;
            if (lines.Length != (int)Math.Pow(2, lines[0].Length - 1))
            {
                valid = false;
            }
            else
            {
                for (var i = 0; i < lines.Length; i++)
                {
                    var line = lines[i];
                    if (line.Length != lines[0].Length)
                    {
                        valid = false;
                        break;
                    }
                    foreach (var chr in line)
                    {
                        if (chr != '0' && chr != '1')
                        {
                            valid = false;
                            break;
                        }
                    }
                    if (valid == false)
                        break;
                }
            }
            return valid;
        }

        public CustomGateLibraryObject Library;
        private string _typeName;
        public string TypeName
        {
            set
            {
                _typeName = value;
                var notFoundInLibrary = true;
                foreach (var customGateLibraryObject in CustomGateLibrary.Library)
                {
                    if (customGateLibraryObject.TypeName.ToLower() == _typeName.ToLower())
                    {
                        Library = customGateLibraryObject;
                        notFoundInLibrary = false;
                    }
                }
                if(notFoundInLibrary)
                    throw new Exception("Custom gate not found in library. TypeName: \"" + _typeName + "\"");

            }
            get { return _typeName; }
        }

        #region SCOAP Methods
        private SCOAPValue CalculateCustomGateControllability(char targetControllability, bool sequential)
        {
            var lastRowFound = "";
            var count = 0;

            var lastOppositRowFound = "";
            var oppositCount = 0;

            for (var i = 0; i < Library.TruthTable.Count; i++)
            {
                if (Library.TruthTable[i][Library.TruthTable[1].Length - 1] == targetControllability)
                {
                    lastRowFound = Library.TruthTable[i];
                    count ++;
                }
                else
                {
                    lastOppositRowFound = Library.TruthTable[i];
                    oppositCount++;
                }
            }

            var minimumValue = new SCOAPValue { Amount = 0, Infinity = true };

            if (count == 1 || count == Library.TruthTable.Count - 1) //Special Mode
            {
                if (count == 1)
                {
                    var rowSum = new SCOAPValue { Infinity = false, Amount = 0 };

                    if (lastRowFound[lastRowFound.Length - 1] == targetControllability)
                    {
                        for (var i = 0; i < lastRowFound.Length - 1; i++)
                            rowSum = (lastRowFound[i] == '0' ? rowSum + (sequential ? Inputs[i].Net.SC0 : Inputs[i].Net.CC0) : rowSum + (sequential ? Inputs[i].Net.SC1 : Inputs[i].Net.CC1));
                        minimumValue = rowSum;
                    }
                }
                else
                {
                    for (var i = 0; i < lastOppositRowFound.Length - 1; i++)
                    {
                        var rowSum = lastOppositRowFound[i] == '1'
                            ? (sequential ? Inputs[i].Net.SC0 : Inputs[i].Net.CC0)
                            : (sequential ? Inputs[i].Net.SC1 : Inputs[i].Net.CC1);
                        if (rowSum < minimumValue)
                            minimumValue = rowSum;
                    }
                }
            }
            else
            {
                minimumValue = NormalControllability(targetControllability, sequential);
            }

            if ((sequential && Library.IsSequential) || (!sequential && !Library.IsSequential))
                minimumValue = minimumValue + 1;

            return minimumValue;
        }

        private SCOAPValue NormalControllability(char targetControllability, bool sequential)
        {
            var minimumValue = new SCOAPValue {Amount = 0, Infinity = true};

            foreach (var row in Library.TruthTable)
            {
                var rowSum = new SCOAPValue {Infinity = false, Amount = 0};

                if (row[row.Length - 1] == targetControllability)
                {
                    for (var i = 0; i < row.Length - 1; i++)
                        rowSum = (row[i] == '0'
                            ? rowSum + (sequential ? Inputs[i].Net.SC0 : Inputs[i].Net.CC0)
                            : rowSum + (sequential ? Inputs[i].Net.SC1 : Inputs[i].Net.CC1));

                    if (rowSum < minimumValue)
                        minimumValue = rowSum;
                }
            }
            return minimumValue;
        }

        private SCOAPValue CalculateCustomGateObservability(int index, bool sequential)
        {
            var minimumValue = new SCOAPValue {Amount = 0, Infinity = true};

            foreach (var row1 in Library.TruthTable)
            {
                foreach (var row2 in Library.TruthTable)
                {
                    if ((Convert.ToInt64(row1, 2) ^ Convert.ToInt64(row2, 2)) == (int)Math.Pow(2, row1.Length - 1 - index) + 1)
                    {
                        var row1Sum = new SCOAPValue { Infinity = false, Amount = 0 };

                        for (var i = 0; i < row1.Length - 1; i++)
                        {
                            if (i == index)
                                continue;
                            row1Sum = (row1[i] == '0'
                                ? row1Sum + (sequential ? Inputs[i].Net.SC0 : Inputs[i].Net.CC0)
                                : row1Sum + (sequential ? Inputs[i].Net.SC1 : Inputs[i].Net.CC1));
                        }
                        if (row1Sum < minimumValue)
                            minimumValue = row1Sum;
                        //--------------------------------------------------------------------------------------------------
                        var row2Sum = new SCOAPValue { Infinity = false, Amount = 0 };

                        for (var i = 0; i < row1.Length - 1; i++)
                        {
                            if (i == index)
                                continue;
                            row2Sum = (row2[i] == '0'
                                ? row2Sum + (sequential ? Inputs[i].Net.SC0 : Inputs[i].Net.CC0)
                                : row2Sum + (sequential ? Inputs[i].Net.SC1 : Inputs[i].Net.CC1));
                        }
                        if (row2Sum < minimumValue)
                            minimumValue = row2Sum;
                    }
                }
            }

            if ((sequential && Library.IsSequential) || (!sequential && !Library.IsSequential))
                minimumValue = minimumValue + 1;

            if (sequential)
                return minimumValue + SO;
            else
                return minimumValue + CO;
        }

        public override SCOAPValue CalculateCC0()
        {
            return CalculateCustomGateControllability('0', false);
        }

        public override SCOAPValue CalculateSC0()
        {
            return CalculateCustomGateControllability('0', true);
        }

        public override SCOAPValue CalculateCC1()
        {
            return CalculateCustomGateControllability('1', false);
        }

        public override SCOAPValue CalculateSC1()
        {
            return CalculateCustomGateControllability('1', true);
        }

        public override SCOAPValue COInputI(int i)
        {
            return CalculateCustomGateObservability(i, false);
        }

        public override SCOAPValue SOInputI(int i)
        {
            return CalculateCustomGateObservability(i, true);
        }

        public override void SetControllabilities()
        {
            var min = Library.TruthTable[0].Length - 1;
            if (Inputs.Count != Library.TruthTable[0].Length - 1)
                throw new Exception("CustomeGate \"" + Library.TypeName + "\" takes " + min + " parameter" + (min > 1 ? "s" : "") + ". Net: \"" + Name + "\" currently has " + Inputs.Count + " parameter" + (Inputs.Count > 0 ? "s" : "") + ".");

            SetCCs();
            SetSCs();
        }

        public override void SetObservabilities()
        {
            var min = Library.TruthTable[0].Length - 1;
            if (Inputs.Count != Library.TruthTable[0].Length - 1)
                throw new Exception("CustomeGate \"" + Library.TypeName + "\" takes " + min + " parameter" + (min > 1 ? "s" : "") + ". Net: \"" + Name + "\" currently has " + Inputs.Count + " parameter" + (Inputs.Count>0?"s":"") + ".");

            SetCOs();
            SetSOs();
        }

        #endregion

        //===================================================================================

        #region Signal Propagation Methods
        //public static Signal Function(Signal a, Signal b)
        //{
        //    if (a == Signal.V0 || b == Signal.V0)
        //        return Signal.V0;
        //    if (a == Signal.V1)
        //        return b;
        //    if (b == Signal.V1)
        //        return a;
        //    if (a == Signal.X || b == Signal.X)
        //        return Signal.X;
        //    if (a == b)
        //        return a;
        //    return Signal.V0;
        //}

        //public Signal CalculateSignalValue()
        //{
        //    var value = Function(Inputs[0].Net.SignalValue, Inputs[1].Net.SignalValue);
        //    for (var i = 2; i < Inputs.Count; i++)
        //        value = Function(value, Inputs[i].Net.SignalValue);
        //    return value;
        //}

        //public override void CalculateAndAssignSignalValue()
        //{
        //    AssignStuckAtSignalValue(CalculateSignalValue());
        //}
        #endregion
    }
}
