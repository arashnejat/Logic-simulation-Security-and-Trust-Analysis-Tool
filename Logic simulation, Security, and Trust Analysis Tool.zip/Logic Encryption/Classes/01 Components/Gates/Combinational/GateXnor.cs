﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateXnor : Net
    {
        public GateXnor()
        {
            GateType = GateTypes.GateXnor;
        }

        #region SCOAP Methods
        public override SCOAPValue CalculateCC0()
        {
            if (Inputs.Count == 2)
                return SCOAPValue.Min(Inputs[0].Net.CC1 + Inputs[1].Net.CC0, Inputs[0].Net.CC0 + Inputs[1].Net.CC1) + 1;
            return SCOAPValue.Min(
                Inputs[0].Net.CC0 + Inputs[1].Net.CC0 + Inputs[2].Net.CC1,
                Inputs[0].Net.CC0 + Inputs[1].Net.CC1 + Inputs[2].Net.CC0,
                Inputs[0].Net.CC1 + Inputs[1].Net.CC0 + Inputs[2].Net.CC0,
                Inputs[0].Net.CC1 + Inputs[1].Net.CC1 + Inputs[2].Net.CC1) + 1;
        }

        public override SCOAPValue CalculateSC0()
        {
            if (Inputs.Count == 2)
                return SCOAPValue.Min(Inputs[0].Net.SC1 + Inputs[1].Net.SC0, Inputs[0].Net.SC0 + Inputs[1].Net.SC1);
            return SCOAPValue.Min(
                Inputs[0].Net.SC0 + Inputs[1].Net.SC0 + Inputs[2].Net.SC1,
                Inputs[0].Net.SC0 + Inputs[1].Net.SC1 + Inputs[2].Net.SC0,
                Inputs[0].Net.SC1 + Inputs[1].Net.SC0 + Inputs[2].Net.SC0,
                Inputs[0].Net.SC1 + Inputs[1].Net.SC1 + Inputs[2].Net.SC1);
        }

        public override SCOAPValue CalculateCC1()
        {
            if (Inputs.Count == 2)
                return SCOAPValue.Min(Inputs[0].Net.CC0 + Inputs[1].Net.CC0, Inputs[0].Net.CC1 + Inputs[1].Net.CC1) + 1;
            return SCOAPValue.Min(
                Inputs[0].Net.CC0 + Inputs[1].Net.CC0 + Inputs[2].Net.CC0,
                Inputs[0].Net.CC0 + Inputs[1].Net.CC1 + Inputs[2].Net.CC1,
                Inputs[0].Net.CC1 + Inputs[1].Net.CC0 + Inputs[2].Net.CC1,
                Inputs[0].Net.CC1 + Inputs[1].Net.CC1 + Inputs[2].Net.CC0) + 1;
        }

        public override SCOAPValue CalculateSC1()
        {
            if (Inputs.Count == 2)
                return SCOAPValue.Min(Inputs[0].Net.SC0 + Inputs[1].Net.SC0, Inputs[0].Net.SC1 + Inputs[1].Net.SC1);
            return SCOAPValue.Min(
                Inputs[0].Net.SC0 + Inputs[1].Net.SC0 + Inputs[2].Net.SC0,
                Inputs[0].Net.SC0 + Inputs[1].Net.SC1 + Inputs[2].Net.SC1,
                Inputs[0].Net.SC1 + Inputs[1].Net.SC0 + Inputs[2].Net.SC1,
                Inputs[0].Net.SC1 + Inputs[1].Net.SC1 + Inputs[2].Net.SC0);
        }

        public override SCOAPValue COInputI(int i)
        {
            if (Inputs.Count == 2)
            {
                if (i == 0)
                    return CO + SCOAPValue.Min(Inputs[1].Net.CC0, Inputs[1].Net.CC1) + 1;
                if (i == 1)
                    return CO + SCOAPValue.Min(Inputs[0].Net.CC0, Inputs[0].Net.CC1) + 1;
            }
            else if(Inputs.Count == 3)
            {
                if (i == 0)
                    return CO + SCOAPValue.Min(
                        Inputs[1].Net.CC0 + Inputs[2].Net.CC0,
                        Inputs[1].Net.CC1 + Inputs[2].Net.CC1,
                        Inputs[1].Net.CC0 + Inputs[2].Net.CC1,
                        Inputs[1].Net.CC1 + Inputs[2].Net.CC0) + 1;
                if(i == 1)
                    return CO + SCOAPValue.Min(
                        Inputs[0].Net.CC0 + Inputs[2].Net.CC0,
                        Inputs[0].Net.CC1 + Inputs[2].Net.CC1,
                        Inputs[0].Net.CC0 + Inputs[2].Net.CC1,
                        Inputs[0].Net.CC1 + Inputs[2].Net.CC0) + 1;
                if (i == 2)
                    return CO + SCOAPValue.Min(
                        Inputs[0].Net.CC0 + Inputs[1].Net.CC0,
                        Inputs[0].Net.CC1 + Inputs[1].Net.CC1,
                        Inputs[0].Net.CC0 + Inputs[1].Net.CC1,
                        Inputs[0].Net.CC1 + Inputs[1].Net.CC0) + 1;
            }
            throw new Exception("Xnor with more than 3 inputs is not implemented. Net: " + Name);
        }

        public override SCOAPValue SOInputI(int i)
        {
            if (Inputs.Count == 2)
            {
                if (i == 0)
                    return SO + SCOAPValue.Min(Inputs[1].Net.SC0, Inputs[1].Net.SC1);
                if (i == 1)
                    return SO + SCOAPValue.Min(Inputs[0].Net.SC0, Inputs[0].Net.SC1);
            }
            else if (Inputs.Count == 3)
            {
                if (i == 0)
                    return CO + SCOAPValue.Min(
                        Inputs[1].Net.SC0 + Inputs[2].Net.SC0,
                        Inputs[1].Net.SC1 + Inputs[2].Net.SC1,
                        Inputs[1].Net.SC0 + Inputs[2].Net.SC1,
                        Inputs[1].Net.SC1 + Inputs[2].Net.SC0);
                if (i == 1)
                    return CO + SCOAPValue.Min(
                        Inputs[0].Net.SC0 + Inputs[2].Net.SC0,
                        Inputs[0].Net.SC1 + Inputs[2].Net.SC1,
                        Inputs[0].Net.SC0 + Inputs[2].Net.SC1,
                        Inputs[0].Net.SC1 + Inputs[2].Net.SC0);
                if (i == 2)
                    return CO + SCOAPValue.Min(
                        Inputs[0].Net.SC0 + Inputs[1].Net.SC0,
                        Inputs[0].Net.SC1 + Inputs[1].Net.SC1,
                        Inputs[0].Net.SC0 + Inputs[1].Net.SC1,
                        Inputs[0].Net.SC1 + Inputs[1].Net.SC0);
            }
            throw new Exception("Xnor with more than three inputs is not implemented. Net: " + Name);
        }

        //## More Inputs will be added in here too ## (Just For Gates Xor and Xnor)
        public override void SetObservabilities()
        {
            if (Inputs.Count < 2)
                throw new Exception("Gate Xnor takes at least two parameters. Net: " + Name);
            if (Inputs.Count > 3)
                throw new Exception("Gate Xnor with more than 3 parameters is not implemented. Net: " + Name);

            SetCOs();
            SetSOs();
        }

        public override void SetControllabilities()
        {
            if (Inputs.Count < 2)
                throw new Exception("Gate Xnor takes at least two parameters. Net: " + Name);
            if (Inputs.Count > 3)
                throw new Exception("Gate Xnor with more than 3 parameters is not implemented. Net: " + Name);

            SetCCs();
            SetSCs();
        }
        #endregion

        //===================================================================================

        #region Signal Propagation Methods
        public static Signal Function(Signal a, Signal b)
        {
            if (a == Signal.X || b == Signal.X)
                return Signal.X; //?????
            if (a == Signal.V1)
                return b;
            if (b == Signal.V1)
                return a;
            if (a == Signal.V0)
                return GateNot.Function(b);
            if (b == Signal.V0)
                return GateNot.Function(a);
            return a == b ? Signal.V1 : Signal.V0;
        }

        public static Signal Function(Signal a, Signal b, Signal c)
        {
            //## More Inputs will be added in here too ## (Just For Gates Xor and Xnor)

            if (a == Signal.X || b == Signal.X || c == Signal.X)
                return Signal.X; ////?????

            if (a == b)
                return GateNot.Function(c);
            if (a == c)
                return GateNot.Function(b);
            if (b == c)
                return GateNot.Function(a);

            if (a == GateNot.Function(b))
                return c;
            if (a == GateNot.Function(c))
                return b;
            if (b == GateNot.Function(c))
                return a;

            return Signal.X;
        }

        public Signal CalculateSignalValue()
        {
            //## More Inputs will be added in here too ## (Just For Gates Xor and Xnor)

            if (Inputs.Count == 2)
                return Function(Inputs[0].Net.SignalValue, Inputs[1].Net.SignalValue);
            if (Inputs.Count == 3)
                return Function(Inputs[0].Net.SignalValue, Inputs[1].Net.SignalValue, Inputs[2].Net.SignalValue);
            throw new Exception("Not enough inputs for gate Xnor. Net: " + Name);
        }

        public override void CalculateAndAssignSignalValue()
        {
            AssignStuckAtSignalValue(CalculateSignalValue());
        }
        #endregion

        public static Signal CalculateSValue(List<Input> Inputs, string Name)
        {
            //## More Inputs will be added in here too ## (Just For Gates Xor and Xnor)

            if (Inputs.Count == 2)
                return Function(Inputs[0].Net.SValue, Inputs[1].Net.SValue);
            if (Inputs.Count == 3)
                return Function(Inputs[0].Net.SValue, Inputs[1].Net.SValue, Inputs[2].Net.SValue);
            throw new Exception("Not enough inputs for gate Xnor. Net: " + Name);
        }
    }
}
