﻿using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateBuffer : Net
    {
        public GateBuffer()
        {
            GateType = GateTypes.GateBuffer;
        }

        #region SCOAP Methods
        public override SCOAPValue CalculateCC0()
        {
            return Inputs[0].Net.CC0 + 1;
        }

        public override SCOAPValue CalculateSC0()
        {
            return Inputs[0].Net.SC0;
        }

        public override SCOAPValue CalculateCC1()
        {
            return Inputs[0].Net.CC1 + 1;
        }

        public override SCOAPValue CalculateSC1()
        {
            return Inputs[0].Net.SC1;
        }

        public override SCOAPValue COInputI(int i)
        {
            return CO + 1;
        }

        public override SCOAPValue SOInputI(int i)
        {
            return SO;
        }

        public override void SetObservabilities()
        {
            SetCOs();
            SetSOs();
        }

        public override void SetControllabilities()
        {
            SetCCs();
            SetSCs();
        }
        #endregion

        //===================================================================================

        #region Signal Propagation Methods

        public Signal CalculateSignalValue()
        {
            return Inputs[0].Net.SignalValue;
        }

        public override void CalculateAndAssignSignalValue()
        {
            AssignStuckAtSignalValue(CalculateSignalValue());
        }
        #endregion

        public static Signal CalculateSValue(List<Input> Inputs)
        {
            return Inputs[0].Net.SignalValue;
        }
    }
}
