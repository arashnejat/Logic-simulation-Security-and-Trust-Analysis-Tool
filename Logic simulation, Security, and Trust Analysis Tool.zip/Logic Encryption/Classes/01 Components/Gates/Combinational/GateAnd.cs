﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateAnd : Net
    {
        public GateAnd ()
        {
            GateType = GateTypes.GateAnd;
        }

        #region SCOAP Methods
        public override SCOAPValue CalculateCC0()
        {
            var values = new List<SCOAPValue>();
            foreach (var input in Inputs)
                values.Add(input.Net.CC0);

            return SCOAPValue.Min(values) + 1;
        }

        public override SCOAPValue CalculateSC0()
        {
            var values = new List<SCOAPValue>();
            foreach (var input in Inputs)
                values.Add(input.Net.SC0);

            return SCOAPValue.Min(values);
        }

        public override SCOAPValue CalculateCC1()
        {
            var sum = new SCOAPValue {Infinity = false, Amount = 0};
            sum.InitialSet(sum);

            foreach (var input in Inputs)
                sum = sum + input.Net.CC1;

            return sum + 1;
        }

        public override SCOAPValue CalculateSC1()
        {
            var sum = new SCOAPValue {Infinity = false, Amount = 0};
            sum.InitialSet(sum);

            foreach (var input in Inputs)
                sum = sum + input.Net.SC1;

            return sum;
        }

        public override SCOAPValue COInputI(int i)
        {
            var sum = new SCOAPValue();
            sum.InitialSet(CO);

            for (var j = 0; j < Inputs.Count; j++)
            {
                if (i == j)
                    continue;
                sum = sum + Inputs[j].Net.CC1;
            }

            return sum + 1;
        }

        public override SCOAPValue SOInputI(int i)
        {
            var sum = new SCOAPValue();
            sum.InitialSet(SO);

            for (var j = 0; j < Inputs.Count; j++)
            {
                if (i == j)
                    continue;
                sum = sum + Inputs[j].Net.SC1;
            }

            return sum;
        }

        public override void SetControllabilities()
        {
            if (Inputs.Count < 2)
                throw new Exception("Gate And takes at least two parameters. Net: " + Name);

            SetCCs();
            SetSCs();
        }

        public override void SetObservabilities()
        {
            if (Inputs.Count < 2)
                throw new Exception("Gate And takes at least two parameters. Net: " + Name);

            SetCOs();
            SetSOs();
        }

        #endregion

        //===================================================================================

        #region Signal Propagation Methods
        public static Signal Function(Signal a, Signal b)
        {
            if (a == Signal.V0 || b == Signal.V0)
                return Signal.V0;
            if (a == Signal.V1)
                return b;
            if (b == Signal.V1)
                return a;
            if (a == Signal.X || b == Signal.X)
                return Signal.X;
            if (a == b)
                return a;
            return Signal.V0;
        }

        public Signal CalculateSignalValue()
        {
            var value = Function(Inputs[0].Net.SignalValue, Inputs[1].Net.SignalValue);
            for (var i = 2; i < Inputs.Count; i++)
                value = Function(value, Inputs[i].Net.SignalValue);
            return value;
        }

        public override void CalculateAndAssignSignalValue()
        {
            AssignStuckAtSignalValue(CalculateSignalValue());
        }
        #endregion

        public static Signal CalculateSValue(List<Input> Inputs)
        {
            var value = Function(Inputs[0].Net.SValue, Inputs[1].Net.SValue);
            for (var i = 2; i < Inputs.Count; i++)
                value = Function(value, Inputs[i].Net.SValue);
            return value;
        }
    }
}
