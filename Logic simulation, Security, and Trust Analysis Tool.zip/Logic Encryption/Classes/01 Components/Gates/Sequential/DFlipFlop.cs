﻿using System;

namespace LogicEncryption
{
    public partial class DFlipFlop : FlipFlop
    {
        public DFlipFlop()
        {
            GateType = GateTypes.DFlipFlop;
        }

        #region SCOAP Methods
        private SCOAPValue CalculateCC0(Net Q, Net D, Net C, Net Reset)
        {
            return SCOAPValue.Min(Reset.CC1 + C.CC1 + C.CC0, D.CC0 + C.CC1 + C.CC0);
        }

        private SCOAPValue CalculateSC0(Net Q, Net D, Net C, Net Reset)
        {
            return SCOAPValue.Min(Reset.SC1 + C.SC1 + C.SC0, D.SC0 + C.SC1 + C.SC0) + 1;
        }

        private SCOAPValue CalculateCC1(Net Q, Net D, Net C, Net Reset)
        {
            return D.CC1 + C.CC1 + C.CC0 + Reset.CC0;
        }

        private SCOAPValue CalculateSC1(Net Q, Net D, Net C, Net Reset)
        {
            return D.SC1 + C.SC1 + C.SC0 + Reset.SC0 + 1;
        }

        #region COs

        private SCOAPValue COD(Net Q, Net D, Net C, Net Reset)
        {
            return Q.CO + C.CC1 + C.CC0 + Reset.CC0;
        }

        private SCOAPValue COReset(Net Q, Net D, Net C, Net Reset)
        {
            return Q.CO + Q.CC1 + Reset.CC1 + C.CC1 + C.CC0;
        }

        private SCOAPValue COC(Net Q, Net D, Net C, Net Reset)
        {
            return SCOAPValue.Min(Q.CO + Q.CC1 + D.CC0 + C.CC1 + C.CC0,
                Q.CO + Q.CC1 + Reset.CC1 + C.CC1 + C.CC0,
                Q.CO + Q.CC0 + Reset.CC0 + D.CC1 + C.CC1 + C.CC0);
        }

        #endregion

        #region SOs

        private SCOAPValue SOD(Net Q, Net D, Net C, Net Reset)
        {
            return Q.SO + C.SC1 + C.SC0 + Reset.SC0 + 1;
        }

        private SCOAPValue SOReset(Net Q, Net D, Net C, Net Reset)
        {
            return Q.SO + Q.SC1 + Reset.SC1 + C.SC1 + C.SC0 + 1;
        }

        private SCOAPValue SOC(Net Q, Net D, Net C, Net Reset)
        {
            return SCOAPValue.Min(Q.SO + Q.SC1 + D.SC0 + C.SC1 + C.SC0,
                Q.SO + Q.SC1 + Reset.SC1 + C.SC1 + C.SC0,
                Q.SO + Q.SC0 + Reset.SC0 + D.SC1 + C.SC1 + C.SC0) + 1;
        }

        #endregion

        private void SetCOs(Net Q, Net D, Net C, Net Reset)
        {
            D.CO.SetMin(COD(Q: Q, D: D, C: C, Reset: Reset));
            C.CO.SetMin(COC(Q: Q, D: D, C: C, Reset: Reset));
            Reset.CO.SetMin(COReset(Q: Q, D: D, C: C, Reset: Reset));
        }

        private void SetSOs(Net Q, Net D, Net C, Net Reset)
        {
            D.SO.SetMin(SOD(Q: Q, D: D, C: C, Reset: Reset));
            C.SO.SetMin(SOC(Q: Q, D: D, C: C, Reset: Reset));
            Reset.SO.SetMin(SOReset(Q: Q, D: D, C: C, Reset: Reset));
        }

        private void SetCCs(Net Q, Net D, Net C, Net Reset)
        {
            Q.CC1.Set(CalculateCC1(Q: Q, D: D, C: C, Reset: Reset));
            Q.CC0.Set(CalculateCC0(Q: Q, D: D, C: C, Reset: Reset));
        }

        private void SetSCs(Net Q, Net D, Net C, Net Reset)
        {
            Q.SC1.Set(CalculateSC1(Q: Q, D: D, C: C, Reset: Reset));
            Q.SC0.Set(CalculateSC0(Q: Q, D: D, C: C, Reset: Reset));
        }

        public override void SetObservabilities()
        {
            if (Inputs.Count < 3)
                throw new Exception("Not enough parameters for gates DFFCR or DFFR. Net: " + Name);

            SetCOs(Q: this, D: Inputs[0].Net, C: Inputs[1].Net, Reset: Inputs[2].Net);
            SetSOs(Q: this, D: Inputs[0].Net, C: Inputs[1].Net, Reset: Inputs[2].Net);
        }

        public override void SetControllabilities()
        {
            if (Inputs.Count < 3)
                throw new Exception("Not enough parameters for gates DFFCR or DFFR. Net: " + Name);

            SetCCs(Q: this, D: Inputs[0].Net, C: Inputs[1].Net, Reset: Inputs[2].Net);
            SetSCs(Q: this, D: Inputs[0].Net, C: Inputs[1].Net, Reset: Inputs[2].Net);
        }
        #endregion

        //===================================================================================

        #region Signal Propagation Methods
        public Signal CalculateSignalValue()
        {
            Clock = Inputs[1].Net.SignalValue;

            if (!ClockTicked)
                return SignalValue;

            if (Inputs[2].Net.SignalValue == Signal.V1)
                return Signal.V0;

            return Inputs[0].Net.SignalValue;
        }

        public override void CalculateAndAssignSignalValue()
        {
            AssignStuckAtSignalValue(CalculateSignalValue());
        }
        #endregion

        public static Signal CalculateSValue(DFlipFlop dFlipFlop)
        {
            dFlipFlop.Clock = dFlipFlop.Inputs[1].Net.SValue;

            if (!dFlipFlop.ClockTicked)
                return dFlipFlop.SValue;

            if (dFlipFlop.Inputs[2].Net.SValue == Signal.V1)
                return Signal.V0;

            return dFlipFlop.Inputs[0].Net.SValue;
        }
    }
}
