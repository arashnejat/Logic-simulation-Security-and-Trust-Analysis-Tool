﻿
namespace LogicEncryption
{
    public partial class FlipFlop : Net
    {
        public FlipFlop()
        {
            GateType = GateTypes.FlipFlop;
        }

        private Signal _oldClock;
        private Signal _clock;

        public Signal Clock
        {
            get { return _clock; }
            set
            {
                if (value == _clock)
                {
                    _oldClock = value;
                    return;
                }

                _oldClock = _clock;
                _clock = value;
            }
        }

        public bool ClockTicked
        {
            get
            {
                if (_oldClock == Signal.V0 && _clock == Signal.V1)
                    return true;
                return false;
            }
        }
    }
}
