﻿namespace LogicEncryption
{
    public partial class DFFR : DFlipFlop
    {
        public DFFR()
        {
            GateType = GateTypes.DFFR;
        }
    }
}
