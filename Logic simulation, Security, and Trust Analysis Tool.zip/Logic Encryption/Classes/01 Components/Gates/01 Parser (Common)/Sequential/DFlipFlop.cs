﻿using System;

namespace LogicEncryption
{
    public partial class DFlipFlop : FlipFlop
    {
        public DFlipFlop()
        {
            GateType = GateTypes.DFlipFlop;
        }
    }
}
