﻿namespace LogicEncryption
{
    public partial class DFFCR : DFlipFlop
    {
        public DFFCR()
        {
            GateType = GateTypes.DFFCR;
        }
    }
}
