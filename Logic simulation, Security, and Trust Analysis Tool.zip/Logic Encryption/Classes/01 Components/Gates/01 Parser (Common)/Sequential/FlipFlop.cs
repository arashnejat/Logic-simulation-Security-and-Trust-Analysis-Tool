﻿
namespace LogicEncryption
{
    public partial class FlipFlop : Net
    {
        public FlipFlop()
        {
            GateType = GateTypes.FlipFlop;
            ResetMemory();
        }

        public void ResetMemory()
        {
            Memory = Signal.X;
        }
    }
}
