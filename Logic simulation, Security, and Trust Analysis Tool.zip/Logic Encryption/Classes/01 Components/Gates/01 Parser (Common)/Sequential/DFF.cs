﻿namespace LogicEncryption
{
    public partial class DFF : DFlipFlopNoReset
    {
        public DFF()
        {
            GateType = GateTypes.DFF;
        }
    }
}
