﻿using System;

namespace LogicEncryption
{
    public partial class DFlipFlopNoReset : FlipFlop
    {
        public DFlipFlopNoReset()
        {
            GateType = GateTypes.DFlipFlopNoReset;
        }
    }
}
