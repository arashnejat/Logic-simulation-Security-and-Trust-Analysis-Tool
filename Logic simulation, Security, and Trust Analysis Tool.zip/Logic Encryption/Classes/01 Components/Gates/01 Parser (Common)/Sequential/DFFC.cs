﻿namespace LogicEncryption
{
    public partial class DFFC : DFlipFlopNoReset
    {
        public DFFC()
        {
            GateType = GateTypes.DFFC;
        }
    }
}
