﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateXor : Net
    {
        public GateXor()
        {
            GateType = GateTypes.GateXor;
        }

    }
}
