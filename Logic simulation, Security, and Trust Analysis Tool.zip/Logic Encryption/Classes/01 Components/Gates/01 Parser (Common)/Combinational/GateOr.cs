﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateOr : Net
    {
        public GateOr()
        {
            GateType = GateTypes.GateOr;
        }

    }
}
