﻿using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateBuffer : Net
    {
        public GateBuffer()
        {
            GateType = GateTypes.GateBuffer;
        }
    }
}
