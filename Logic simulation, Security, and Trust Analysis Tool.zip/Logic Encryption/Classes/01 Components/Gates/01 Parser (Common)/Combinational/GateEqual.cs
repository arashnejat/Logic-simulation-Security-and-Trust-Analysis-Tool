﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateEqual : Net
    {
        public GateEqual()
        {
            GateType = GateTypes.GateEqual;
        }
    }
}
