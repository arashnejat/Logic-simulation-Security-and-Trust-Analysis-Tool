﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateXnor : Net
    {
        public GateXnor()
        {
            GateType = GateTypes.GateXnor;
        }

    }
}
