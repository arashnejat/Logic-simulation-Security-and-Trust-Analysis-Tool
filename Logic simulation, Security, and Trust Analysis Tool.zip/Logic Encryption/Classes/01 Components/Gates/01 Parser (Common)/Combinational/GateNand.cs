﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateNand : Net
    {
        public GateNand()
        {
            GateType = GateTypes.GateNand;
        }
    }
}
