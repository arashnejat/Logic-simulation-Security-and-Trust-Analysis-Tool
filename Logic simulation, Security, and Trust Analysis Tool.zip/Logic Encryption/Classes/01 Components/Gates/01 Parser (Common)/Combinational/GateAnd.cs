﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateAnd : Net
    {
        public GateAnd ()
        {
            GateType = GateTypes.GateAnd;
        }

    }
}
