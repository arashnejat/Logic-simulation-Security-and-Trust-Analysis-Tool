﻿using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateNot : Net
    {
        public GateNot()
        {
            GateType = GateTypes.GateNot;
        }

    }
}
