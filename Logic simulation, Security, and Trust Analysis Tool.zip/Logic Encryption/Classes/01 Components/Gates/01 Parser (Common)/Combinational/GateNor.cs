﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateNor : Net
    {

        public GateNor()
        {
            GateType = GateTypes.GateNor;
        }
    }
}
