﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public class Input
    {
        public Net Net;
        public string Name;
        public bool IsGeneratedClock = false;
    }

    public partial class Net
    {
        public string Name;//نام سیم در مدار
        public bool IsPrimaryOutput = false;//آیا یکی از پایه های خروجی اصلی مدار است
        public bool IsPrimaryInput = false;//آیا یکی از پایه های ورودی اصلی مدار است
        public List<Input> Inputs = new List<Input>(); //لیست ورودی های یک نت که هر عضو آن شامل نام و خود سیم ورودی می شود 
        public List<Net> NextNets = new List<Net>();// لیست نت های بعدی

        /// <summary>
        /// جهت تعیین نوع گیت هنگام انتشار مقدار سیگنال استفاده می گردد
        /// </summary>
        public GateTypes GateType = GateTypes.Net;

        public override bool Equals(object obj)
        {
            if (obj is Net)
            {
                var net = (Net) obj;
                return net.Name == this.Name;
            }
            else
            {
                return false;
            }
        }

        public enum GateTypes
        {
            Net,

            GateAnd,
            GateBuffer,
            GateCustom,
            GateEqual,
            GateNand,
            GateNor,
            GateNot,
            GateOr,
            GateXnor,
            GateXor,

            DFF,
            DFFC,
            DFFCR,
            DFFR,

            FlipFlop,
            DFlipFlop,
            DFlipFlopNoReset
        }

        public static Net FindNetWithException(string name, List<Net> nets)
        {
            var retVal = nets.Find(item => item.Name == name);
            if (retVal == null)
                throw new Exception("Parser Error. " + "Could not find net \"" + name + "\"");
            //MessageBox.Show("Could not find net \"" + name + "\"", "Parser Error", MessageBoxButtons.OK,MessageBoxIcon.Error);
            return retVal;
        }

        public static Net NetGenerator(string type, string name)
        {
            switch (type.ToLower())
            {
                //case "input":
                //    return Functions.Input;       // Not necessary
                //    break;
                case "and":
                    return new GateAnd { Name = name };
                case "buff":
                    return new GateBuffer { Name = name };
                case "=":
                    return new GateEqual { Name = name };
                case "nand":
                    return new GateNand { Name = name };
                case "nor":
                    return new GateNor { Name = name };
                case "not":
                    return new GateNot { Name = name };
                case "or":
                    return new GateOr { Name = name };
                case "xor":
                    return new GateXor { Name = name };
                case "xnor":
                    return new GateXnor { Name = name };
                case "dff":
                    return new DFF { Name = name };
                case "dffc":
                    return new DFFC { Name = name };
                case "dffcr":
                    return new DFFCR { Name = name };
                case "dffr":
                    return new DFFR { Name = name };
                default:
                    //return new Net { Name = name };

                    //return new GateCustom { Name = name, TypeName = type };
                throw new Exception("Unknown gate. Name: " + type);
            }
        }
        
    }
}
