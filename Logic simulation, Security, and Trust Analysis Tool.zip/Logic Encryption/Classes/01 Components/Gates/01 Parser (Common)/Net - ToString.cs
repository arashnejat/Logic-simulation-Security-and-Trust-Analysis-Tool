﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class Net
    {
        /// <summary>
        /// پارامتری که تعیین می کند هنگام نمایش متنی یک سیم، چه مشخصاتی باید نمایش داده شوند
        /// </summary>
        public static NetToStringMode ToStringMode = NetToStringMode.SCOAPAndSignal;

        public enum NetToStringMode
        {
            SCOAP,
            SValueFull,
            SCOAPAndSignal,
            InitializingSCOAP,
            ProbabilityPropagationExpression,
            LevelNumberInSCOAP,
            LevelNumberInLogicSimulation,
            SimulatedProbability,
            FaultImpact,
            SValue,
            HD
        }

        public override string ToString()
        {
            return ToString(ToStringMode);
        }

        public string ToString(NetToStringMode mode)
        {
            switch (mode)
            {
                case NetToStringMode.SCOAP:
                    return NetToStringSCOAP();

                case NetToStringMode.SValueFull:
                    return NetToStringSValueFull();

                case NetToStringMode.SCOAPAndSignal:
                    return NetToStringSCOAPAndSignal();

                case NetToStringMode.InitializingSCOAP:
                    return NetToStringInitializingSCOAP();
                
                case NetToStringMode.LevelNumberInSCOAP:
                    return NetToStringLevelNumberInSCOAP();

                case NetToStringMode.LevelNumberInLogicSimulation:
                    return NetToStringLevelNumberInLogicSimulation();

                case NetToStringMode.SimulatedProbability:
                    return NetToStringSimulatedProbability();

                case NetToStringMode.FaultImpact:
                    return NetToStringFaultImpact();

                case NetToStringMode.SValue:
                    return NetToStringSValue();

                case NetToStringMode.HD:
                    return NetToStringHD();

                default:
                    return Name;
            }
        }

        private string NetToStringHD()
        {
            return Name + ":\t" + HD;
        }

        private string NetToStringSValue()
        {
            return Name + ":\t" + SValue;
        }

        private string NetToStringFaultImpact()
        {
            return Name + ":\t" + FaultImpact;
        }

        private string NetToStringSimulatedProbability()
        {
            return Name + ":\t" + SimulatedProbability;
        }

        private string NetToStringLevelNumberInLogicSimulation()
        {
            return Name + ":\t" + LevelNumberInLogicSimulation;
        }

        private string NetToStringLevelNumberInSCOAP()
        {
            return Name + ":\t" + LevelNumberInSCOAP;
        }

        private string NetToStringInitializingSCOAP()
        {
            return Name + ":\t\t(" + CC0 + "," + CC1 + ") " + CO + " \t " + "[" + SC0 + "," + SC1 + "] " + SO;
        }

        private string NetToStringSCOAPAndSignal()
        {
            return Name + ": " + SignalToString(SValue) + "   (" +
                   ((!Sta0 && !Sta1) ? "Normal" : (Sta0 ? "STA-0" : "STA-1")) + ")" + " \r\n" +
                   "\t(" + CC0 + "," + CC1 + ") " + CO + "\r\n" +
                   "\t[" + SC0 + "," + SC1 + "] " + SO;
        }

        private string NetToStringSCOAP()
        {
            return Name + ":\r\n" +
                   "\t(" + CC0 + "," + CC1 + ") " + CO + "\r\n" +
                   "\t[" + SC0 + "," + SC1 + "] " + SO;
        }

        private string NetToStringSValueFull()
        {
            return Name + ":\t" + SignalToString(SValue) + "   (" +
                   ((!Sta0 && !Sta1) ? "Normal" : (Sta0 ? "STA-0" : "STA-1")) + ")";
        }
    }
}
