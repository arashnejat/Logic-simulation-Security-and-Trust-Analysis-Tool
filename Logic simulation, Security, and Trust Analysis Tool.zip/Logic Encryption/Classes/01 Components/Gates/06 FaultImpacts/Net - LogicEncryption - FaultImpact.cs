﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class Net
    {
        public int NoP0;//تعداد الگوهای ورودی که خطای چسبیده به صفر را به خروجی منتقل کرده اند
        public int NoO0;//تعداد پایه های خروجی که تحت تاثیر خطای چسبیده به صفر قرار گرفته اند

        public int NoP1;//تعداد الگوهای ورودی که خطای چسبیده به یک را به خروجی منتقل کرده اند
        public int NoO1;//تعداد پایه های خروجی که تحت تاثیر خطای چسبیده به یک قرار گرفته اند

        public int FaultImpact;//پارامتر فالت ایمپمت محاسبه شده برای سیم
    }
}
