﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class Net
    {
        public double Zeros;//تعداد دفعاتی که مقدار این سیگنال در شبیه سازی منطق صفر بوده است
        public double Ones;//تعداد دفعاتی که مقدار این سیگنال در شبیه سازی منطق یک بوده است

        public double SimulatedProbability = -1;//مقدار احتمال یک شدن سیگنال محاسبه شده
        public double SimulatedProbabilityTempForAlgAHTOrighnalAlg13 = -1;//پارامتر موقتی برای نگهدری مقدار احتمال سیگنال

        public int LevelNumberInLogicSimulation = -1;//سطح این نت هنگام شبیه سازی منطق
        public bool TemporaryIsNotGateEqual;//در سطح بندی هنگام شبیه سازی منطق استفاده خواهد شد
        public int TemporaryIdentifier;//در سطح بندی هنگام شبیه سازی منطق استفاده خواهد شد


    }
}
