﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public partial class LogicSimulation
    {

        /// <summary>
        /// در این سطح بندی، تنها ورودی های اصلی در سطح صفر قرار می گیرند
        /// </summary>
        /// <param name="nets">کلیه نت های مدار</param>
        /// <param name="maxLevel">حداکثر سطوح گیت های مدار را بر می گرداند</param>
        public static void LevelizeNets(List<Net> nets, out int maxLevel)
        {
            //الگوریتم عملکرد بدین ترتیب است که 
            //سطح هر نت برابر است با حداکثر تعداد گیتهایی که
            //با شروع از یک ورودی اصلی 
            //و بدون عبور از حلقه یعنی بدون وجود نت تکراری در مسیر 
            //باید از روی آنها عبور کنیم تا به این نت برسیم

            //برای تسریع در شناسایی نت هایی که از آنها عبور کرده ایم
            //از یک آرایه بولین به نام
            //container
            //استفاده می شود که طول آن برابر با کلیه نت های مدار است
            //و با عبور از هر گیتی، عنصر مربوطه به آن گیت در آرایه ترو می شود
            //و با اتمام کار هر گیت، مقدار مربوطه فالس می گردد

            //به منظور ممکن سازی اندیس گذاری در آرایه بولین، از متغیری از نوع عدد صحیح با نام
            //temporaryIdentifier 
            //استفاده شده است 
            //و در ابتدای الگوریتم، با شروع از صفر تا تعداد کل نت های مدار، مقدار مربوط به هر نت، مشخص و تعیین می گردد

            //به منظور تسریع در شناسایی سیم های فن اوت
            //و مشخص کردن اینکه آیا یک نت، از نوع گیت است یا فن اوت نیز از متغیر بولینی با نام
            //temporaryIsNotGateEqual
            //استفاده شده است


            //ریست کردن همه نت ها
            foreach (var net in nets)
                net.LevelNumberInLogicSimulation = -1;

            Net.ToStringMode = Net.NetToStringMode.LevelNumberInLogicSimulation;

            var inputNets = new List<Net>();
            var i = 0;
            var noFlipFlop = true;
            foreach (var net in nets)
            {
                if(net.Inputs.Count == 0)
                    inputNets.Add(net);
                net.TemporaryIdentifier = i++;
                net.TemporaryIsNotGateEqual = !(net is GateEqual);
                if (net is FlipFlop)
                    noFlipFlop = false;
            }


            var clockNets = new List<Net>();
            foreach (var net in nets)
                if (net is FlipFlop)
                    clockNets.Add(net.Inputs[1].Net);

            foreach (var clockNet in clockNets)
            {
                inputNets.Remove(clockNet);
                clockNet.LevelNumberInLogicSimulation = 0;
            }

            //اگر در مدار فلیپ فلاپی وجود ندارد از روش قدیمی که بسیار سریعتر است استفاده گردد
            if (noFlipFlop)
            {
                LevelizeCombinationalNets(nets, out maxLevel);
            }
            else
            {
                var container = new bool[nets.Count];
                var actualPathLength = 0;
                var hashSet = new HashSet<Net>();
                foreach (var net in inputNets)
                {
                    LevelizeSequentialInputNetExactly(net, container, ref actualPathLength, hashSet: hashSet);
                    //Console.Beep(500,30);
                }
                maxLevel = -1;
                foreach (var net in nets)
                {
                    if (net.LevelNumberInLogicSimulation > maxLevel)
                        maxLevel = net.LevelNumberInLogicSimulation;

                    if (net.LevelNumberInLogicSimulation == -1)
                        MessageBox.Show("Bad net found (Net with no level): " + net.Name);
                }
            }


        }

        private static void LevelizeSequentialInputNetExactly(Net net, bool[] container, ref int actualPathLength, HashSet<Net> hashSet)
        {
            //if (container[net.TemporaryIdentifier])
            //{
            //    var deadEndPath = "";
            //    foreach (var net1 in hashSet)
            //    {
            //        deadEndPath += net1.Name + "->";
            //    }
            //    Debug.WriteLine(deadEndPath + net.Name);
            //    return;
            //}
            //تنها در صورتی سطح نت آپدیت شود که طول مسیر پیموده شده از قبلی بیشتر باشد
            if (actualPathLength > net.LevelNumberInLogicSimulation)
                net.LevelNumberInLogicSimulation = actualPathLength;
            //else
            //{
            //    //if (net.LevelNumberInLogicSimulation != -1)
            //    //{
            //        //return; //G1 G12 G15 -> G9 G11 G6 G8 G16
            //    //}
            //}
            hashSet.Add(net);
            container[net.TemporaryIdentifier] = true;
            if (net.TemporaryIsNotGateEqual)
                actualPathLength++;

            foreach (var nextNet in net.NextNets)
            {
                if (!container[nextNet.TemporaryIdentifier])
                    LevelizeSequentialInputNetExactly(nextNet, container, ref actualPathLength, hashSet);
            }
            hashSet.Remove(net);
            container[net.TemporaryIdentifier] = false;
            if (net.TemporaryIsNotGateEqual)
                actualPathLength--;

        }

        public static List<Net> GetNetsOfLevel(List<Net> nets, int levelNumber)
        {
            return nets.FindAll(item => item.LevelNumberInLogicSimulation == levelNumber);
        }

        /// <summary>
        /// از بین سطح ورودی های یک گیت، سطح ورودی که ماکزیمم سطح را دارد را بر می گرداند
        /// </summary>
        /// <param name="inputs">ورودی های گیت</param>
        /// <returns>ماکزیمم سطح ورودی ها</returns>
        private static int MaxLevel(List<Input> inputs)
        {
            var max = int.MinValue;
            foreach (var input in inputs)
            {
                if (input.Net.LevelNumberInLogicSimulation > max)
                    max = input.Net.LevelNumberInLogicSimulation;
            }
            return max;
        }

        /// <summary>
        /// گیت ها را سطح بندی می کند
        /// در این سطح بندی، تنها ورودی های اصلی و فلیپ فلاپ ها در سطح صفر قرار می گیرند
        /// تنها برای مدارات ترکیبی کار می کند
        /// </summary>
        /// <param name="nets">کلیه نت های یک مدار</param>
        /// <param name="maxLevel">حداکثر سطوح گیت های مدار را بر می گرداند</param>
        private static void LevelizeCombinationalNets(List<Net> nets, out int maxLevel)
        {
            maxLevel = -1;
            foreach (var net in nets)
                net.LevelNumberInLogicSimulation = -1;

            var notFinished = true;
            while (notFinished)
            {
                foreach (var net in nets)
                {
                    if (net.LevelNumberInLogicSimulation != -1)
                        continue;

                    if (net.IsPrimaryInput)// || net is DFlipFlop || net is DFlipFlopNoReset)// || net.IsPrimaryOutput)// || net.Function == "output")
                        net.LevelNumberInLogicSimulation = 0;
                    else
                    {
                        if (net.Inputs.Count == 1)
                        {
                            if (net.Inputs[0].Net.LevelNumberInLogicSimulation != -1)
                                net.LevelNumberInLogicSimulation = net.Inputs[0].Net.LevelNumberInLogicSimulation + (net is GateEqual ? 0 : 1);
                        }
                        else
                        {
                            var unknowInputExists = false;

                            foreach (var input in net.Inputs)
                                if (input.Net.LevelNumberInLogicSimulation == -1)
                                    unknowInputExists = true;

                            if (!unknowInputExists)
                                net.LevelNumberInLogicSimulation = MaxLevel(net.Inputs) + 1;
                        }
                    }
                }

                notFinished = false;
                foreach (var net in nets)
                {
                    if (net.LevelNumberInLogicSimulation == -1)
                    {
                        notFinished = true;
                        break;
                    }
                    if (net.LevelNumberInLogicSimulation > maxLevel)
                        maxLevel = net.LevelNumberInLogicSimulation;
                }
            }
        }


        //public static int MaxLevel2(List<Input> inputs)
        //{
        //    var max = -1;
        //    foreach (var input in inputs)
        //    {
        //        if (input.Net.LevelNumberInLogicSimulation > max)
        //            max = input.Net.LevelNumberInLogicSimulation;
        //    }
        //    return max;
        //}

        //public static void Proceed2(Net net, HashSet<Net> traversedNets)
        //{
        //    if (traversedNets.Contains(net))
        //    {
        //        return;
        //    }
            
        //    var newLevelNumber = MaxLevel2(net.Inputs) + (net is GateEqual ? 0 : 1);
        //    //if (newLevelNumber <= net.LevelNumberInLogicSimulation)
        //      //  return;

        //    net.LevelNumberInLogicSimulation = newLevelNumber;

        //    traversedNets.Add(net);
        //    foreach (var nextNet in net.NextNets)
        //        Proceed2(nextNet, traversedNets);
        //    traversedNets.Remove(net);
        //}

        //public static void proceed(Net net, HashSet<Net> breakNets)
        //{
        //    //if (breakNets.Contains(net))
        //        //return;

        //    foreach (var nextNet in net.NextNets)
        //    {
        //        if (breakNets.Contains(nextNet))
        //            continue;

        //        //if (net is FlipFlop)
        //        //{
        //        if (nextNet.LevelNumberInLogicSimulation != -1 && nextNet.LevelNumberInLogicSimulation < net.LevelNumberInLogicSimulation)
        //          continue;
        //        //}
        //        var maxLevelInInputs = MaxLevel(nextNet.Inputs);
        //        var zeroOrOne = (nextNet is GateEqual ? 0 : 1);
        //        nextNet.LevelNumberInLogicSimulation = maxLevelInInputs + zeroOrOne;
        //    }

        //    foreach (var nextNet in net.NextNets)
        //    {
        //        if (breakNets.Contains(nextNet))
        //            continue;

        //        //if (net is FlipFlop)
        //        //{
        //            //if (nextNet.LevelNumberInLogicSimulation != -1 && nextNet.LevelNumberInLogicSimulation < net.LevelNumberInLogicSimulation)
        //                //continue;
        //        //}
        //        //if (!(net is DFlipFlop || net is DFlipFlopNoReset))
        //        //if(breakNets.Count == 0 != null)
        //          //  proceed(nextNet, breakNet);
        //        //else
        //        //if(!breakNets.Contains(net))
        //            //breakNets.Add(net);
        //        breakNets.Add(nextNet);

        //        proceed(nextNet, breakNets);

        //        breakNets.Remove(nextNet);
        //    }
        //}

        //public static int MaxLevelInNonFFInputs(List<Input> inputs)
        //{
        //    var max = int.MinValue;
        //    foreach (var input in inputs)
        //    {
        //        if (input.Net is DFlipFlop || input.Net is DFlipFlopNoReset)
        //            continue;
        //        if (input.Net.LevelNumberInLogicSimulation > max)
        //            max = input.Net.LevelNumberInLogicSimulation;
        //    }
        //    return max;
        //}

        ///// <summary>
        ///// از بین سطح ورودی های یک گیت، سطح ورودی که ماکزیمم سطح را دارد را بر می گرداند
        ///// </summary>
        ///// <param name="inputs">ورودی های گیت</param>
        ///// <returns>ماکزیمم سطح ورودی ها</returns>
        //public static int MaxLevel(List<Input> inputs)
        //{
        //    var max = int.MinValue;
        //    foreach (var input in inputs)
        //    {
        //        if (input.Net.LevelNumberInLogicSimulation > max)
        //            max = input.Net.LevelNumberInLogicSimulation;
        //    }
        //    return max;
        //}
    }
}
