﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LogicEncryption
{
    public partial class LogicSimulation
    {
        public static bool Abort = false;
        public static TextBox TextBox;


        /// <summary>
        ///مشکلی که وجود داشت این بود که وقتی لود می کرد و بعد سورت می کرد
        ///با اینکه داده های یکسانی لود می شدند ولی
        ///ترتیب با زمانی که محاسبه می کرد متفاوت بود
        ///لذا تابع سورتی نوشتم تا اول تا 10 رقم اعشار روند کند و بعد سورت کند
        /// </summary>
        /// <param name="nets"></param>
        /// <returns></returns>
        public static List<Net> SortBySimulatedProbabilityFromMaxDistanceToHalfToMin(List<Net> nets)
        {
            var sortedNets = new List<Net>();
            while (nets.Count > 0)
            {
                Net maxNet = nets[0];

                for (int i = 1; i < nets.Count; i++)
                {
                    //نت ای که بیشترین فاصله را از یک دوم دارد را پیدا می کند
                    if (Math.Round(Math.Abs(0.5 - nets[i].SimulatedProbability), 10) > Math.Round(Math.Abs(0.5 - maxNet.SimulatedProbability), 10))
                        maxNet = nets[i];
                }

                nets.Remove(maxNet);
                sortedNets.Add(maxNet);
            }
            return sortedNets;
        }


        #region CacheManager

        public static int LoadOrCalculateProbabilities(List<Net> nets, int clockTimes, int randomSeed, int totalTimes, bool meetThreshold, double threshold, string netlistName, TextBox textBox, bool forceCalculate, bool allowSaveResults, out string loadReport, string key = "")
        {
            var cacheFileName = netlistName +
                                CacheManager.GetHashFromNets(nets) + 
                                (!string.IsNullOrEmpty(key) ? "Key," : "") + //مخصوص اندازه گیری توان مصرفی پویا از نگاه کاربر نهایی
                                "Count=" + totalTimes + "," +
                                "Seed=" + randomSeed + "," +
                                "Ticks=" + clockTimes + "," +
                                "MThrshld=" + meetThreshold + "," +
                                "Thrshld=" + threshold +
                                ".SP";

            var cacheFilePath = CacheManager.CacheDirectory + cacheFileName;

            foreach (var net in nets)
            {
                net.SimulatedProbability = -1;
                net.Zeros = 0;
                net.Ones = 0;
                net.SValue = Net.Signal.X; //جدید NEW
                if (net is FlipFlop)
                    ((FlipFlop)net).ResetMemory();
            }

            int totalSamples;
            if (!forceCalculate && !string.IsNullOrEmpty(netlistName) )
            {
                if (SamimiIO.Exists(cacheFilePath))
                {
                    if (LoadProbabilitiesFromFile(cacheFilePath, nets, out totalSamples))
                    {
                        loadReport = "Probabilities Loaded From File:\t" + cacheFileName;
                        return totalSamples;
                    }
                }
            }

            var s = new Stopwatch();
            s.Start();

            totalSamples = LogicSimulation.LogicSimulateAndEstimateProbabilities(nets: nets, clockTimes: clockTimes, randomSeed: randomSeed, totalTimes: totalTimes, meetThreshold: meetThreshold, threshold: threshold, textBox: textBox, key: key);

            s.Stop();
            loadReport = "Probabilities Calculation Duration:\t" + s.Elapsed;

            if (allowSaveResults)
            {
                SaveProbabilitiesToFile(cacheFilePath, nets, totalSamples);
                loadReport += "\r\n" + "Saved To File:\t" + cacheFileName;
            }
            return totalSamples;
        }

        private static void SaveProbabilitiesToFile(string cacheFilePath, List<Net> nets, int totalSamples)
        {
            if (SamimiIO.Exiting)
                return;
            
            var dataToSave = new List<string>();

            dataToSave.Add(totalSamples.ToString());
            foreach (var net in nets)
            {
                dataToSave.Add(net.Name + "\t" + net.SimulatedProbability + "\t" + net.Zeros + "\t" + net.Ones);
            }

            var str = string.Join("\r\n", dataToSave);

            SamimiIO.WriteAllText(cacheFilePath, str);
        }

        private static bool LoadProbabilitiesFromFile(string cacheFilePath, List<Net> nets, out int totalSamples)
        {
            var oldNets = new List<Net>(nets);
            try
            {
                var str = SamimiIO.ReadAllText(cacheFilePath);

                string[] seperators = { "\r\n", "\t" };

                var data = str.Split(seperators, StringSplitOptions.RemoveEmptyEntries);

                nets.Clear();

                totalSamples = int.Parse(data[0]);

                var loadedNetsCount = 0;
                for (int i = 1; i < data.Length; i += 4)
                {
                    var foundNet = oldNets.Find(net => net.Name == data[i]);
                    loadedNetsCount++;

                    foundNet.SimulatedProbability = double.Parse(data[i + 1]);
                    foundNet.Zeros = int.Parse(data[i + 2]);
                    foundNet.Ones = int.Parse(data[i + 3]);
                    
                    nets.Add(foundNet);
                }

                if (loadedNetsCount != oldNets.Count)
                    throw new Exception("Count not equal, Load failed.");

                return true;
            }
            catch (Exception)
            {
                nets.Clear();
                foreach (var net in oldNets)
                    nets.Add(net);

                totalSamples = 0;
                return false;
            }
        }

        //private static bool LoadProbabilitiesFromFile(string cacheFilePath, List<Net> nets, out int totalSamples)
        //{
        //    try
        //    {
        //        var str = SamimiIO.ReadAllText(cacheFilePath);

        //        string[] seperators = { "\r\n", "\t" };

        //        var data = str.Split(seperators, StringSplitOptions.RemoveEmptyEntries);

        //        totalSamples = int.Parse(data[0]);

        //        var loadedNetsCount = 0;
        //        for (int i = 1; i < data.Length; i += 4)
        //        {
        //            var foundNet = nets.Find(net => net.Name == data[i]);
        //            loadedNetsCount++;

        //            foundNet.SimulatedProbability = double.Parse(data[i + 1]);
        //            foundNet.Zeros = int.Parse(data[i + 2]);
        //            foundNet.Ones = int.Parse(data[i + 3]);
        //        }

        //        if (loadedNetsCount != nets.Count)
        //            throw new Exception("Count not equal, Load failed.");

        //        return true;
        //    }
        //    catch (Exception)
        //    {
        //        totalSamples = 0;
        //        return false;
        //    }
        //}

        #endregion

        //public static void TestCircuit(List<Net> nets)
        //{
        //    var inputs = 1000;
        //    int maxLevel;

        //    LevelizeNets(nets: nets, maxLevel: out maxLevel);
        //    var inputNets = Net.GetNetsOfLevel(nets: nets, levelNumber: 0);

        //    ProbabilityExpressionPropagation.Limit = inputNets.Count;
        //    ProbabilityExpressionPropagation.ParametersHolder = new ParametersHolder();

        //    PrepareInputNets(inputNets: inputNets);

        //    var netCounter = inputNets.Count;

        //    for (int levelIndex = 0; levelIndex <= maxLevel; levelIndex++)
        //    {
        //        var netsOfLevel = Net.GetNetsOfLevel(nets: nets, levelNumber: levelIndex);

        //        //محاسبه عبارت احتمالی برای نت های هر سطح
        //        for (var netInThisLevelIndex = 0; netInThisLevelIndex < netsOfLevel.Count; netInThisLevelIndex++)
        //        {
        //            if (ProbabilityExpressionPropagation.Abort)
        //                continue;
        //        }
        //    }

        //}

        public static string GenerateSingleRandomPattern(Random random, int length)
        {
            var strRandom = "";
            for (int i = 0; i < length; i++)
            {
                strRandom += random.Next(0, 2);
            }
            return strRandom;
        }

        /// <summary>
        /// نیازی به سطح بندی و استفاده از سطوح مدار ندارد
        /// </summary>
        /// <param name="nets"></param>
        /// <param name="clockTimes"></param>
        /// <param name="randomSeed"></param>
        /// <param name="totalTimes"></param>
        /// <param name="meetThreshold"></param>
        /// <param name="threshold"></param>
        /// <param name="textBox"></param>
        /// <returns></returns>
        public static int LogicSimulateAndEstimateProbabilities(List<Net> nets, int clockTimes, int randomSeed, int totalTimes, bool meetThreshold , double threshold, TextBox textBox, string key = "")
        {
            LogicSimulation.Abort = false;
            foreach (var net in nets)
            {
                net.SimulatedProbability = -1;
                net.Zeros = 0;
                net.Ones = 0;
                net.SValue = Net.Signal.X; //NEW جدید
                if (net is FlipFlop)
                    ((FlipFlop)net).ResetMemory();
            }

            var lastTime = DateTime.Now;
            var startTime = DateTime.Now;
            var oldText = "";
            if (textBox != null)
            {
                oldText = textBox.Text;
            }
            List<Net> outputNets;
            List<Net> middleNets;
            List<Net> inputNets;
            //LevelizeNets(nets: nets, maxLevel: out maxLevel);
            Parser.ClassifyInputMiddleOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets);
            var clockNet = CommonMethods.GetMainClockNet(nets);
            
            inputNets.Remove(clockNet);

            var random = new Random(randomSeed);

            var samplesCount = 0;

            bool thresholdMet = false;
            string oldPattern = "";
            for (int i = 0; i < totalTimes || meetThreshold; i++)
            {
                //-------------------------------------------------------------------------------------------
                if ((DateTime.Now - lastTime).TotalSeconds > 1)
                {
                    lastTime = DateTime.Now;

                    var totalElapsed = (DateTime.Now - startTime);
                    if (textBox != null)
                    {
                        textBox.Text = oldText +
                                                       "Total Samples: " + samplesCount.ToString("N0") + "\r\n" +
                                                       "Elapsed Time: " + totalElapsed.ToString("g") + "\r\n";
                    }
                    Application.DoEvents();
                }
                //-------------------------------------------------------------------------------------------

                if (LogicSimulation.Abort)
                {
                    AnalyzeSValueOfNets(nets);
                    return samplesCount;
                }

                //مطمئن میشه که یک ورودی رو دوبار پشت سر هم به نت های ورودی مدار اعمال نکنیم
                string newRandomPattern;
                while ((newRandomPattern = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(random, inputNets.Count)) == oldPattern)
                {
                    
                }
                oldPattern = newRandomPattern;

                if (!string.IsNullOrEmpty(key))
                {
                    List<Net> middleNets1;
                    List<Net> outputNets1;
                    List<Net> inputNets1;
                    Parser.ClassifyInputMiddleOutputNets(nets: nets, inputNets: out inputNets1, outputNets: out outputNets1, middleNets: out middleNets1);
                    var clockNet1 = CommonMethods.GetMainClockNet(nets);
                    inputNets1.Remove(clockNet1);

                    var correctedPatternList = new List<char>();
                    for (int index = 0; index < inputNets1.Count; index++)
                    {
                        if (SMSSKeyManager.IsSMSKeyNet(inputNets1[index].Name))
                        {
                            var keyIndex = SMSSKeyManager.ExtractKeyIndexFromSMSSKeyName(inputNets1[index].Name);
                            correctedPatternList.Add(key[keyIndex - 1]);
                        }
                        else
                        {
                            correctedPatternList.Add(newRandomPattern[index]);
                        }
                    }
                    var correctedPattern = (string.Join("", correctedPatternList.ToArray())).Trim();
                    //------------------------------------------------------------------------------
                    newRandomPattern = correctedPattern;
                }

                //ورودی جدید را در نت های ورودی مدار اعمال می کنیم
                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets, newRandomPattern);
                samplesCount++;
                
                //حال بخاطر وارد شدن ورودی جدید آمار کل نت ها را می گیرد
                AnalyzeAllNets(nets, meetThreshold, threshold, ref thresholdMet);

                //اگر کلاک داشت
                //به تعداد مورد نظر کلاک بزند و
                //با هر کلاک، آمار کل نت ها را نیز بگیرد
                if (clockNet != null)
                    for (int k = 0; k < clockTimes; k++)
                    {
                        //بعد کلاک صفر وارد مدار می شود و آمار کل مدار گرفته می شود
                        Net.SValueMethods.Imply(clockNet, Net.Signal.V0);
                        AnalyzeAllNets(nets, meetThreshold, threshold, ref thresholdMet);

                        //بعد کلاک یک وارد مدار می شود و آمار کل مدار گرفته می شود
                        Net.SValueMethods.Imply(clockNet, Net.Signal.V1);
                        AnalyzeAllNets(nets, meetThreshold, threshold, ref thresholdMet);
                    }

                //اگر نیاز به رسیدن به ترشولد بود و ترشولد ملاقات شده بود و
                //از تعداد داده مورد نظر فراتر رفته بودیم
                //بس است
                if ((meetThreshold && thresholdMet) && i>= totalTimes)
                    break;
            }

            if (!meetThreshold)
            {
                //مقدار دهی نهایی احتمال ها
                foreach (var net in nets)
                {
                    if(net.Ones + net.Zeros > 0)//New
                        net.SimulatedProbability = net.Ones/(net.Ones + net.Zeros);
                }
            }

            if (textBox != null)
            {
                textBox.Text = oldText;
            }

            return samplesCount;
        }

        private static void AnalyzeAllNets(List<Net> nets, bool meetThreshold, double threshold, ref bool thresholdMet)
        {
            if (meetThreshold)
                thresholdMet = AnalyzeSValueOfNets(nets, threshold);
            else
                AnalyzeSValueOfNets(nets);
        }

        public static void AnalyzeSValueOfNets(List<Net> nets)
        {
            foreach (var net in nets)
            {
                if (net.SValue == Net.Signal.V1)
                    net.Ones++;
                else if(net.SValue == Net.Signal.V0)
                    net.Zeros++;
            }
        }

        //در صورتی که میانگین یک شدن های جدید فاصله اش با میانگین یک شدن های قدیم برای یک نت از ترشولد کمتر باشد، ترو بر میگرداند
        private static bool AnalyzeSValueOfNets(List<Net> nets, double threshold)
        {
            bool thresholdMet = true;

            foreach (var net in nets)
            {
                double oldProbability = net.Ones/(net.Ones + net.Zeros);
                if (double.IsNaN(oldProbability))
                    oldProbability = 0.0;

                if (net.SValue == Net.Signal.V1)
                    net.Ones++;
                else if (net.SValue == Net.Signal.V0)
                    net.Zeros++;
                

                var newProbability = net.Ones / (net.Ones + net.Zeros);

                if (Math.Abs(newProbability - oldProbability) > threshold)
                    thresholdMet = false;

                if(net.Ones + net.Zeros > 0)//New
                    net.SimulatedProbability = newProbability;
            }

            return thresholdMet;
        }

        //private static void AnalyzeSignalValueOfNets(List<Net> nets)
        //{
        //    foreach (var net in nets)
        //    {
        //        if (net.SignalValue == Net.Signal.V1)
        //            net.Ones++;
        //        else if (net.SignalValue == Net.Signal.V0)
        //        {
        //            net.Zeros++;
        //        }
        //    }
        //}

        //private static bool AnalyzeSignalValueOfNets(List<Net> nets, double threshold)
        //{
        //    bool thresholdMet = true;

        //    foreach (var net in nets)
        //    {
        //        double oldProbability = net.Ones / (net.Ones + net.Zeros);
        //        if (double.IsNaN(oldProbability))
        //            oldProbability = 0.0;

        //        if (net.SignalValue == Net.Signal.V1)
        //            net.Ones++;
        //        else if (net.SignalValue == Net.Signal.V0)
        //        {
        //            net.Zeros++;
        //        }

        //        var newProbability = net.Ones / (net.Ones + net.Zeros);

        //        if (Math.Abs(newProbability - oldProbability) > threshold)
        //            thresholdMet = false;
        //    }

        //    return thresholdMet;
        //}

        public static string ReportLogicSimulation(List<Net> nets, int maxLevel)
        {
            var str = "";
            for (int i = 0; i <= maxLevel; i++)
            {
                var netsInLevel = LogicSimulation.GetNetsOfLevel(nets: nets, levelNumber: i);

                str += "Level " + i + ":\r\n";
                foreach (var net in netsInLevel)
                {
                    str += "Name: " + net.Name + "\tP =\t" + (net.Ones / (net.Ones + net.Zeros)) + "\r\n";
                }
                str += "______________________\r\n";
            }
            return str;
        }

        public static string ReportLogicSimulation(List<Net> nets)
        {
            var sortedNets = new List<Net>(nets);
            sortedNets.Sort((net1, net2) => Math.Sign(net1.SimulatedProbability - net2.SimulatedProbability));

            var str = "Name\tSignal Probability\r\n";

            foreach (var net in sortedNets)
            {
                str += net.Name + "\t" + (net.Ones / (net.Ones + net.Zeros)) + "\r\n";
            }
            return str;
        }
    }
}
