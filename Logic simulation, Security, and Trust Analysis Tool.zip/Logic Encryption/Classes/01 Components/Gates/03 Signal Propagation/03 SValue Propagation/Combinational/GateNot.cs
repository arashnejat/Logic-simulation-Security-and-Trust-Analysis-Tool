﻿using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateNot : Net
    {
        public static Signal CalculateSValue(List<Input> Inputs)
        {
            return Function(Inputs[0].Net.SValue);
        }
    }
}
