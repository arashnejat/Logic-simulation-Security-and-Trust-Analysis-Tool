﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateNand : Net
    {
        public static Signal CalculateSValue(List<Input> Inputs)
        {
            var value = GateAnd.Function(Inputs[0].Net.SValue, Inputs[1].Net.SValue);
            for (var i = 2; i < Inputs.Count; i++)
                value = GateAnd.Function(value, Inputs[i].Net.SValue);
            return GateNot.Function(value);
        }
    }
}
