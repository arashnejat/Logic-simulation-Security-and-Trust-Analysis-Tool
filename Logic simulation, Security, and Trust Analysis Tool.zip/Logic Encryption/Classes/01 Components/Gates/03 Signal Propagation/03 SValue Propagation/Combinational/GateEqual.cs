﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateEqual : Net
    {
        public static Signal CalculateSValue(List<Input> Inputs)
        {
            return Inputs[0].Net.SValue;
        }
    }
}
