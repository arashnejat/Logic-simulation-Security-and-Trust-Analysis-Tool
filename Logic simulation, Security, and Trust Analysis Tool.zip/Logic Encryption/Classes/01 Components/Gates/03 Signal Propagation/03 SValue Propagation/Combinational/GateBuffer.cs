﻿using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateBuffer : Net
    {
        public static Signal CalculateSValue(List<Input> Inputs)
        {
            return Inputs[0].Net.SValue;
        }
    }
}
