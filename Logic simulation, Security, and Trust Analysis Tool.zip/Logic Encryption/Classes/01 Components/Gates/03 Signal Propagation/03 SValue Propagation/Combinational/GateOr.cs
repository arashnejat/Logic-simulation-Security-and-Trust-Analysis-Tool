﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateOr : Net
    {
        public static Signal CalculateSValue(List<Input> Inputs)
        {
            var value = Function(Inputs[0].Net.SValue, Inputs[1].Net.SValue);
            for (var i = 2; i < Inputs.Count; i++)
                value = Function(value, Inputs[i].Net.SValue);
            return value;
        }
    }
}
