﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateXnor : Net
    {
        public static Signal CalculateSValue(List<Input> Inputs, string Name)
        {
            //## More Inputs will be added in here too ## (Just For Gates Xor and Xnor)

            if (Inputs.Count == 2)
                return Function(Inputs[0].Net.SValue, Inputs[1].Net.SValue);
            if (Inputs.Count == 3)
                return Function(Inputs[0].Net.SValue, Inputs[1].Net.SValue, Inputs[2].Net.SValue);
            throw new Exception("Not enough inputs for gate Xnor. Net: " + Name);
        }
    }
}
