﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateNor : Net
    {
        public static Signal CalculateSValue(List<Input> Inputs)
        {
            var value = GateOr.Function(Inputs[0].Net.SValue, Inputs[1].Net.SValue);
            for (var i = 2; i < Inputs.Count; i++)
                value = GateOr.Function(value, Inputs[i].Net.SValue);
            return GateNot.Function(value);
        }
    }
}
