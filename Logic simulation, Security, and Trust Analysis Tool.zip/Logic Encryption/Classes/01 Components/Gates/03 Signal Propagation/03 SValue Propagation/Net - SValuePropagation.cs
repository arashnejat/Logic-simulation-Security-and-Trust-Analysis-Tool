﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class Net
    {
        public enum Signal
        {
            V0,
            V1,
            X,
            D,
            D_
        }
        public enum SignalValueMode
        {
            ThreeValues01X,
            FiveValues01XDD_
        }

        public Signal SValue = Signal.X;//مقدار سیگنال در این سیم

        public bool Sta0 = false;//آیا در این سیم خطای چسبیده به صفر رخ داده است
        public bool Sta1 = false;//آیا در این سیم خطای چسبیده به یک رخ داده است

        public static Signal GetSignalFromString(string name)
        {
            switch (name.ToLower())
            {
                case "one":
                case "1":
                    return Net.Signal.V1;
                case "zero":
                case "0":
                    return Net.Signal.V0;
                case "x":
                    return Net.Signal.X;
                case "d":
                    return Net.Signal.D;
                case "d'":
                case "d_":
                    return Net.Signal.D_;
                default:
                    return Net.Signal.X;
            }
        }

        public static string SignalToString(Signal signal)
        {
            return signal.ToString().Replace("V", "").Replace("_", "'");
        }

        public static string SignalString(Signal signal)
        {
            switch (signal)
            {
                case Signal.V0:
                    return "0";
                    break;
                case Signal.V1:
                    return "1";
                    break;
                case Signal.X:
                    return "X";
                    break;
                case Signal.D:
                    return "D";
                    break;
                case Signal.D_:
                    return "E";
                    break;
                default:
                    return "U";
                    break;
            }
        }

        public class SValueMethods
        {
            public static SignalValueMode SignalMode = SignalValueMode.FiveValues01XDD_;
            public static bool AvoidLoop = true;
            public static bool AutoPropagateForward = true;
            public static bool AutoGenerateStuckAtValues = false;

            public static void Imply(Net net, Signal signal)
            {
                if (SignalMode == Net.SignalValueMode.FiveValues01XDD_)
                {
                    if (net.Sta0 && signal == Net.Signal.V1)
                        signal = Net.Signal.D_;

                    if (net.Sta1 && signal == Net.Signal.V0)
                        signal = Net.Signal.D;

                    if(signal == Signal.X && AutoGenerateStuckAtValues)
                        signal = net.Sta0 ? Signal.V0 : Signal.V1;

                    if (net.Sta1 && signal == Signal.D_)
                        signal = Signal.V1;

                    if (net.Sta0 && signal == Signal.D)
                        signal = Signal.V0;
                }
                else if (SignalMode == SignalValueMode.ThreeValues01X)
                {
                    //حذف منطق 5 مقداره بخاطر تست فالت ایمپکتز 2
                    if (net.Sta0)
                        signal = Net.Signal.V0;
                    else if (net.Sta1)
                        signal = Net.Signal.V1;
                    else
                    {
                        if (net.SValue == Signal.D_)
                            signal = Signal.V1;

                        if (net.SValue == Signal.D)
                            signal = Signal.V0;
                    }
                }
                
                if (net.SValue == signal && AvoidLoop)
                    return;

                net.SValue = signal;

                if (!AutoPropagateForward)
                    return;

                foreach (var nextNet in net.NextNets)
                {
                    switch (nextNet.GateType)
                    {
                        case GateTypes.DFF:
                        case GateTypes.DFFC:
                        case GateTypes.DFFCR:
                        case GateTypes.DFFR:
                            PropagateSValue(nextNet);

                            //اگر این نت ورودی کلاک یا ریست فلیپ فلاپ بعدیش بود ادامه دهد
                            //اگر سیم نت، سیم ورودی کلاک یا سیم ورودی ریست فلیپ فلاپ بود
                            if (nextNet.Inputs[0].Name != net.Name) 
                            {
                                PropagateSValue(nextNet);
                            }
                            //اگر سیم نت، سیم ورودی فلیپ فلاپ بود
                            else
                            {
                                //((FlipFlop)nextNet).OldValue = signal;
                                PropagateSValue(nextNet, false);
                            }
                            break;

                        default:
                            PropagateSValue(nextNet);
                            break;
                    }
                }
            }

            private static void PropagateSValue(Net net, bool isClock = true )
            {
                Signal outputSignal;
                switch (net.GateType)
                {
                    case GateTypes.GateNot:
                        outputSignal = GateNot.CalculateSValue(net.Inputs);
                        Imply(net, outputSignal);
                        break;
                    case GateTypes.GateAnd:
                        outputSignal = GateAnd.CalculateSValue(net.Inputs);
                        Imply(net, outputSignal);
                        break;
                    case GateTypes.GateOr:
                        outputSignal = GateOr.CalculateSValue(net.Inputs);
                        Imply(net, outputSignal);
                        break;
                    case GateTypes.GateNand:
                        outputSignal = GateNand.CalculateSValue(net.Inputs);
                        Imply(net, outputSignal);
                        break;
                    case GateTypes.GateNor:
                        outputSignal = GateNor.CalculateSValue(net.Inputs);
                        Imply(net, outputSignal);
                        break;
                    case GateTypes.GateXor:
                        outputSignal = GateXor.CalculateSValue(net.Inputs, net.Name);
                        Imply(net, outputSignal);
                        break;
                    case GateTypes.GateXnor:
                        outputSignal = GateXnor.CalculateSValue(net.Inputs, net.Name);
                        Imply(net, outputSignal);
                        break;
                    case GateTypes.GateEqual:
                        outputSignal = GateEqual.CalculateSValue(net.Inputs);
                        Imply(net, outputSignal);
                        break;
                    case GateTypes.GateBuffer:
                        outputSignal = GateBuffer.CalculateSValue(net.Inputs);
                        Imply(net, outputSignal);
                        break;
                    case GateTypes.DFF:
                        outputSignal = DFlipFlopNoReset.CalculateSValue((DFlipFlopNoReset) net, isClock);
                        Imply(net, outputSignal);
                        break;
                    case GateTypes.DFFC:
                        outputSignal = DFlipFlopNoReset.CalculateSValue((DFlipFlopNoReset) net, isClock);
                        Imply(net, outputSignal);
                        break;
                    case GateTypes.DFFCR:
                        outputSignal = DFlipFlop.CalculateSValue((DFlipFlop) net, isClock);
                        Imply(net, outputSignal);
                        break;
                    case GateTypes.DFFR:
                        outputSignal = DFlipFlop.CalculateSValue((DFlipFlop) net, isClock);
                        Imply(net, outputSignal);
                        break;
                }
            }

            public static void ImplyPatternOnSValueOfInputNets(List<Net> inputNets, string pattern)
            {
                if (inputNets == null || inputNets.Count == 0)
                    return;
                if (String.IsNullOrEmpty(pattern))
                    return;
                if (inputNets.Count != pattern.Length)
                    return;

                for (int i = 0; i < inputNets.Count; i++)
                {
                    var svalue = (pattern[i] == '0' ? Net.Signal.V0 : Net.Signal.V1);
                    Imply(inputNets[i], svalue);
                }
            }

            public static void ImplyPatternOnSValueOfInputNetsNotEqual(List<Net> inputNets, string pattern)
            {
                if (inputNets == null || inputNets.Count == 0)
                    return;
                if (String.IsNullOrEmpty(pattern))
                    return;
                if (inputNets.Count > pattern.Length) //Difference
                    return;

                for (int i = 0; i < inputNets.Count; i++)
                {
                    var svalue = (pattern[i] == '0' ? Net.Signal.V0 : Net.Signal.V1);
                    Imply(inputNets[i], svalue);
                }
            }

            public static void ClockSValue(Net clockNet)
            {
                if (clockNet.SValue == Net.Signal.X)
                    clockNet.SValue = Net.Signal.V0;
                Imply(clockNet, GateNot.Function(clockNet.SValue));
            }

            public static void ResetSValuesAndSta0AndSta1AndFaultImpactsOfNets(List<Net> nets)
            {
                foreach (var net in nets)
                {
                    net.SValue = Net.Signal.X;
                    if (net is FlipFlop)
                        ((FlipFlop)net).ResetMemory();

                    net.Sta0 = net.Sta1 = false;
                    net.NoP0 = net.NoP1 = net.NoO0 = net.NoO1 = net.FaultImpact = 0;
                }
            }

            public static void ResetSValuesOfNets(List<Net> nets)
            {
                foreach (var net in nets)
                {
                    net.SValue = Net.Signal.X;
                    if (net is FlipFlop)
                        ((FlipFlop)net).ResetMemory();
                }
            }

            private static int FindNet(List<Net> nets, string name)
            {
                for (int i = 0; i < nets.Count; i++)
                {
                    if (nets[i].Name == name)
                        return i;
                }
                return -1;
            }

            internal static IEnumerable<List<Net>> DuplicateNetlist(List<Net> nets, int count)
            {
                var netlistsHolder = new List<List<Net>>();

                for (int i = 0; i < count; i++)
                {
                    netlistsHolder.Add(new List<Net>());
                    foreach (var net in nets)
                        netlistsHolder[i].Add(DuplicateNet(net));
                }

                for (var j = 0; j < nets.Count; j++)
                {
                    var net = nets[j];

                    foreach (var input in net.Inputs)
                    {
                        var index = FindNet(netlistsHolder[0], input.Name);
                        for (var i = 0; i < count; i++)
                        {
                            netlistsHolder[i][j].Inputs.Add(new Input()
                            {
                                IsGeneratedClock = input.IsGeneratedClock,
                                Name = input.Name,
                                Net = netlistsHolder[i][index]
                            });
                        }
                    }

                    foreach (var nextNet in net.NextNets)
                    {
                        var index = FindNet(netlistsHolder[0], nextNet.Name);

                        for (var i = 0; i < count; i++)
                            netlistsHolder[i][j].NextNets.Add(netlistsHolder[i][index]);
                    }
                }
                return netlistsHolder;
            }

            public static List<Net> DuplicateNetlist(List<Net> nets)
            {
                var duplicateList = new List<Net>();

                foreach (var net in nets)
                    duplicateList.Add(DuplicateNet(net));

                for (var i = 0; i < nets.Count; i++)
                {
                    var net = nets[i];
                    var duplicateNet = duplicateList[i];

                    foreach (var input in net.Inputs)
                    {
                        duplicateNet.Inputs.Add(new Input()
                        {
                            IsGeneratedClock = input.IsGeneratedClock,
                            Name = input.Name,
                            Net = duplicateList.Find(net1 => net1.Name == input.Name)
                        });
                    }

                    foreach (var nextNet in net.NextNets)
                    {
                        duplicateNet.NextNets.Add(duplicateList.Find(net1 => net1.Name == nextNet.Name));
                    }
                }

                return duplicateList;
            }

            private static Net DuplicateNet(Net net)
            {
                Net duplicateNet;

                switch (net.GateType)
                {
                    case GateTypes.GateNot:
                        duplicateNet = new GateNot();
                        break;
                    case GateTypes.GateAnd:
                        duplicateNet = new GateAnd();
                        break;
                    case GateTypes.GateOr:
                        duplicateNet = new GateOr();
                        break;
                    case GateTypes.GateNand:
                        duplicateNet = new GateNand();
                        break;
                    case GateTypes.GateNor:
                        duplicateNet = new GateNor();
                        break;
                    case GateTypes.GateXor:
                        duplicateNet = new GateXor();
                        break;
                    case GateTypes.GateXnor:
                        duplicateNet = new GateXnor();
                        break;
                    case GateTypes.GateEqual:
                        duplicateNet = new GateEqual();
                        break;
                    case GateTypes.GateBuffer:
                        duplicateNet = new GateBuffer();
                        break;
                    
                    case GateTypes.DFF:
                        duplicateNet = new DFF();
                        break;
                    case GateTypes.DFFC:
                        duplicateNet = new DFFC();
                        break;
                    case GateTypes.DFFCR:
                        duplicateNet = new DFFCR();
                        break;
                    case GateTypes.DFFR:
                        duplicateNet = new DFFR();
                        break;

                    case GateTypes.DFlipFlop:
                        duplicateNet = new DFlipFlop();
                        break;
                    case GateTypes.DFlipFlopNoReset:
                        duplicateNet = new DFlipFlopNoReset();
                        break;

                    case GateTypes.FlipFlop:
                        duplicateNet = new FlipFlop();
                        break;

                    default:
                        duplicateNet = new Net();
                        break;
                }

                duplicateNet.GateType = net.GateType;
                duplicateNet.CC0 = net.CC0;
                duplicateNet.CC1 = net.CC1;
                duplicateNet.CO = net.CO;
                duplicateNet.FaultImpact = net.FaultImpact;
                duplicateNet.IsGeneratedFanout = net.IsGeneratedFanout;
                duplicateNet.IsPrimaryInput = net.IsPrimaryInput;
                duplicateNet.IsPrimaryOutput = net.IsPrimaryOutput;
                duplicateNet.LevelNumberInSCOAP = net.LevelNumberInSCOAP;
                duplicateNet.NoO0 = net.NoO0;
                duplicateNet.NoO1 = net.NoO1;
                duplicateNet.NoP0 = net.NoP0;
                duplicateNet.NoP1 = net.NoP1;
                duplicateNet.TSa0 = net.TSa0;
                duplicateNet.TSa1 = net.TSa1;
                duplicateNet.SC0 = net.SC0;
                duplicateNet.SC1 = net.SC1;
                duplicateNet.SO = net.SO;
                duplicateNet.Sta0 = net.Sta0;
                duplicateNet.Sta1 = net.Sta1;
                duplicateNet.Observed = net.Observed;
                duplicateNet.Name = net.Name;
                duplicateNet.Inputs = new List<Input>(); /*Needs To Be Completed Later*/
                duplicateNet.NextNets = new List<Net>() /*Needs To Be Completed Later*/;

                duplicateNet.SValue = net.SValue;

                return duplicateNet;
            }
        }
    }
}