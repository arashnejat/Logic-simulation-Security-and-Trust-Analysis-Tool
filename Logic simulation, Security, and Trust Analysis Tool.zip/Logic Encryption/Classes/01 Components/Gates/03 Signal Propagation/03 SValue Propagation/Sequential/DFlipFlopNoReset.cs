﻿using System;

namespace LogicEncryption
{
    public partial class DFlipFlopNoReset : FlipFlop
    {
        public static Signal CalculateSValue(DFlipFlopNoReset dFlipFlop, bool isClock = true)
        {
            dFlipFlop.Clock = dFlipFlop.Inputs[1].Net.SValue;

            if (!isClock)
                dFlipFlop.Memory = dFlipFlop.Inputs[0].Net.SValue;
            //if (!dFlipFlop.ClockTicked)
            //    return dFlipFlop.SValue;


            //if (dFlipFlop.Inputs[2].Net.SValue == Net.Signal.V1)
            //{
            //    dFlipFlop.OldInputByClockValue = Net.Signal.V0;
            //    return Net.Signal.V0;
            //}

            if (!dFlipFlop.ClockTicked)
                return dFlipFlop.SValue;

            //return dFlipFlop.Inputs[0].Net.SValue;

            var retVal = dFlipFlop.Memory;
            dFlipFlop.Memory = dFlipFlop.Inputs[0].Net.SValue;
            return retVal;
        }


        //public static Signal CalculateSValue(DFlipFlopNoReset dFlipFlopNoReset)
        //{
        //    dFlipFlopNoReset.Clock = dFlipFlopNoReset.Inputs[1].Net.SValue;

        //    //if (!dFlipFlopNoReset.ClockTicked)
        //    //    return dFlipFlopNoReset.SValue;
        //    //return dFlipFlopNoReset.Inputs[0].Net.SValue;
        //    if (!dFlipFlopNoReset.ClockTicked)
        //        return dFlipFlopNoReset.OldInputByClockValue ;


        //    var retVal = dFlipFlopNoReset.OldInputByClockValue;
        //    dFlipFlopNoReset.OldInputByClockValue = dFlipFlopNoReset.Inputs[0].Net.SValue;
        //    return retVal;
        //}
    }
}
