﻿using System;

namespace LogicEncryption
{
    public partial class DFlipFlop : FlipFlop
    {
        public static Signal CalculateSValue(DFlipFlop dFlipFlop, bool isClock = true)
        {
            dFlipFlop.Clock = dFlipFlop.Inputs[1].Net.SValue;

            if (!isClock)
                dFlipFlop.Memory = dFlipFlop.Inputs[0].Net.SValue;
            //if (!dFlipFlop.ClockTicked)
            //    return dFlipFlop.SValue;


            if (dFlipFlop.Inputs[2].Net.SValue == Net.Signal.V1)
            {
                dFlipFlop.Memory  = Net.Signal.V0;
                return Net.Signal.V0;
            }

            if (!dFlipFlop.ClockTicked)
                return dFlipFlop.SValue;

            //return dFlipFlop.Inputs[0].Net.SValue;

            var retVal = dFlipFlop.Memory;
            dFlipFlop.Memory = dFlipFlop.Inputs[0].Net.SValue;
            return retVal;
        }
    }
}