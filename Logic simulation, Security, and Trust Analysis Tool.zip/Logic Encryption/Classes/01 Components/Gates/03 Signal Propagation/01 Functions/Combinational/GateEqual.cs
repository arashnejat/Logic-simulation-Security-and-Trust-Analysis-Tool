﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateEqual : Net
    {
        public Signal Function(Signal a)
        {
            return a;
        }
    }
}
