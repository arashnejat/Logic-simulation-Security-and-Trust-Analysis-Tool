﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateOr : Net
    {
        public static Signal Function(Signal a, Signal b)
        {
            if (a == Net.Signal.V1 || b == Net.Signal.V1)
                return Net.Signal.V1;
            if (a == Net.Signal.V0)
                return b;
            if (b == Net.Signal.V0)
                return a;
            if (a == Net.Signal.X || b == Net.Signal.X)
                return Net.Signal.X;
            if (a == b)
                return a;
            return Net.Signal.V0;
        }
    }
}
