﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateNand : Net
    {
        public static Signal Function(Signal a, Signal b)
        {
            return GateNot.Function(GateAnd.Function(a, b));
        }
    }
}
