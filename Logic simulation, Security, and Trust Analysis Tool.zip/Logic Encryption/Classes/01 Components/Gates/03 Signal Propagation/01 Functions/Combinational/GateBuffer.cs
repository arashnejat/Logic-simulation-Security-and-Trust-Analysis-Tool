﻿using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateBuffer : Net
    {
        public Signal Function(Signal a)
        {
            return a;
        }
    }
}
