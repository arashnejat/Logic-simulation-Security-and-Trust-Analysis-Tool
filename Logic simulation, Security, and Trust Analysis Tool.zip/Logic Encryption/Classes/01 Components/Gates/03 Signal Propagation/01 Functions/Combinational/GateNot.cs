﻿using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateNot : Net
    {
        public static Signal Function(Signal a)
        {
            switch (a)
            {
                case Net.Signal.D:
                    return Net.Signal.D_;
                case Net.Signal.D_:
                    return Net.Signal.D;
                case Net.Signal.V1:
                    return Net.Signal.V0;
                case Net.Signal.V0:
                    return Net.Signal.V1;
                default:
                    return Net.Signal.X;
            }
        }
    }
}
