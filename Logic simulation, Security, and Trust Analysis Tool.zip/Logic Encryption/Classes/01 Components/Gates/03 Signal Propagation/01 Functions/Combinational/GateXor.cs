﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateXor : Net
    {
        public static Signal Function(Signal a, Signal b)
        {
            if (a == Net.Signal.X || b == Net.Signal.X)
                return Net.Signal.X;////?????
            if (a == Net.Signal.V0)
                return b;
            if (b == Net.Signal.V0)
                return a;
            if (a == Net.Signal.V1)
                return GateNot.Function(b);
            if (b == Net.Signal.V1)
                return GateNot.Function(a);
            return a == b ? Net.Signal.V0 : Net.Signal.V1;
        }

        public static Signal Function(Signal a, Signal b, Signal c)
        {
            //## More Inputs will be added in here too ## (Just For Gates Xor and Xnor)

            if (a == Net.Signal.X || b == Net.Signal.X || c == Net.Signal.X)
                return Net.Signal.X; ////?????

            if (a == b)
                return GateNot.Function(c);
            if (a == c)
                return GateNot.Function(b);
            if (b == c)
                return GateNot.Function(a);

            if (a == GateNot.Function(b))
                return c;
            if (a == GateNot.Function(c))
                return b;
            if (b == GateNot.Function(c))
                return a;

            return Net.Signal.X;
        }
    }
}
