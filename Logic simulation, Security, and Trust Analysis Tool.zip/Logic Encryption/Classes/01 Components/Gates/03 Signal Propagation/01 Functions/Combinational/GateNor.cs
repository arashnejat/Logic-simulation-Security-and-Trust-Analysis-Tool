﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateNor : Net
    {
        public static Signal Function(Signal a, Signal b)
        {
            return GateNot.Function(GateOr.Function(a, b));
        }
    }
}
