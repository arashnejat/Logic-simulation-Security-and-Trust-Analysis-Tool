﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateXnor : Net
    {
        public static Signal Function(Signal a, Signal b)
        {
            if (a == Net.Signal.X || b == Net.Signal.X)
                return Net.Signal.X; //?????
            if (a == Net.Signal.V1)
                return b;
            if (b == Net.Signal.V1)
                return a;
            if (a == Net.Signal.V0)
                return GateNot.Function(b);
            if (b == Net.Signal.V0)
                return GateNot.Function(a);
            return a == b ? Net.Signal.V1 : Net.Signal.V0;
        }

        public static Signal Function(Signal a, Signal b, Signal c)
        {
            //## More Inputs will be added in here too ## (Just For Gates Xor and Xnor)

            if (a == Net.Signal.X || b == Net.Signal.X || c == Net.Signal.X)
                return Net.Signal.X;////?????

            if (a == b)
                return c;
            if (a == c)
                return b;
            if (b == c)
                return a;

            if (a == GateNot.Function(b))
                return GateNot.Function(c);
            if (a == GateNot.Function(c))
                return GateNot.Function(b);
            if (b == GateNot.Function(c))
                return GateNot.Function(a);

            return Net.Signal.X;
        }
    }
}
