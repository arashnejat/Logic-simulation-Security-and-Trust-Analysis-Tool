﻿
using System;

namespace LogicEncryption
{
    public partial class FlipFlop : Net
    {
        private Signal _oldClock;
        private Signal _clock;
        public Signal Memory;

        public void ResetClock()
        {
            _oldClock = _clock = Net.Signal.X;
            ResetMemory(); //جدید
        }

        public Signal Clock
        {
            get { return _clock; }
            set
            {
                if (value == _clock)
                {
                    _oldClock = value;
                    return;
                }

                _oldClock = _clock;
                _clock = value;
            }
        }

        public bool ClockTicked
        {
            get
            {
                if (_oldClock == Net.Signal.V0 && _clock == Net.Signal.V1)
                {
                    //از آنجا که در کلیه محاسبات خروجی فلیپ فلاپ ها، ابتدا کلاک مقدار می گیرد، نیازی به این دستور نیست
                    //_oldClock = _clock;
                    return true;
                }
                return false;
            }
        }
    }
}
