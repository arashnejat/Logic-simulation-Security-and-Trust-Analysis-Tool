﻿using System;

namespace LogicEncryption
{
    public partial class DFlipFlop : FlipFlop
    {

    }
}
