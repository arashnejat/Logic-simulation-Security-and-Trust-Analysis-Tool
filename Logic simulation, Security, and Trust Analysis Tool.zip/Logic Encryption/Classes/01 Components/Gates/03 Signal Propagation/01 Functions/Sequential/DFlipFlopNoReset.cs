﻿using System;

namespace LogicEncryption
{
    public partial class DFlipFlopNoReset : FlipFlop
    {

    }
}
