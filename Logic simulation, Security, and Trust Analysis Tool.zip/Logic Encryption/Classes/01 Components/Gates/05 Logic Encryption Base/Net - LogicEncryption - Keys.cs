﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class Net
    {
        public bool IsKeyGate;//آیا یکی از گیت های کلید است
        public bool IsKeyInput;//آیا یکی از پایه های ورودی مقادیر کلید است
        public bool IsTempGate;//آیا یک گیت موقتی است که باید بعدا حذف گردد
    }
}
