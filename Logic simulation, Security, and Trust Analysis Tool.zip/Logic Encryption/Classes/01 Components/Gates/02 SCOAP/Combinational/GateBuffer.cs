﻿using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateBuffer : Net
    {
        #region SCOAP Methods
        public override SCOAPValue CalculateCC0()
        {
            return Inputs[0].Net.CC0 + 1;
        }

        public override SCOAPValue CalculateSC0()
        {
            return Inputs[0].Net.SC0;
        }

        public override SCOAPValue CalculateCC1()
        {
            return Inputs[0].Net.CC1 + 1;
        }

        public override SCOAPValue CalculateSC1()
        {
            return Inputs[0].Net.SC1;
        }

        public override SCOAPValue COInputI(int i)
        {
            return CO + 1;
        }

        public override SCOAPValue SOInputI(int i)
        {
            return SO;
        }

        public override void SetObservabilities()
        {
            SetCOs();
            SetSOs();
        }

        public override void SetControllabilities()
        {
            SetCCs();
            SetSCs();
        }
        #endregion
    }
}
