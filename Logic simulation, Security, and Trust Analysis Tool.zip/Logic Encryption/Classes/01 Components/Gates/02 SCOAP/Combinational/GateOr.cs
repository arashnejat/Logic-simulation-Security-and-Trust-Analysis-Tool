﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateOr : Net
    {
        #region SCOAP Methods
        public override SCOAPValue CalculateCC0()
        {
            var sum = new SCOAPValue {Infinity = false, Amount = 0};
            sum.InitialSet(sum);

            foreach (var input in Inputs)
                sum = sum + input.Net.CC0;

            return sum + 1;
        }

        public override SCOAPValue CalculateSC0()
        {
            var sum = new SCOAPValue {Infinity = false, Amount = 0};
            sum.InitialSet(sum);

            foreach (var input in Inputs)
                sum = sum + input.Net.SC0;

            return sum;

        }

        public override SCOAPValue CalculateCC1()
        {
            var values = new List<SCOAPValue>();

            foreach (var input in Inputs)
                values.Add(input.Net.CC1);

            return SCOAPValue.Min(values) + 1;
        }

        public override SCOAPValue CalculateSC1()
        {
            var values = new List<SCOAPValue>();

            foreach (var input in Inputs)
                values.Add(input.Net.SC1);

            return SCOAPValue.Min(values);
        }

        public override SCOAPValue COInputI(int i)
        {
            var sum = new SCOAPValue();
            sum.InitialSet(CO);

            for (var j = 0; j < Inputs.Count; j++)
            {
                if (i == j)
                    continue;
                sum = sum + Inputs[j].Net.CC0;
            }

            return sum + 1;
        }

        public override SCOAPValue SOInputI(int i)
        {
            var sum = new SCOAPValue();
            sum.InitialSet(SO);

            for (var j = 0; j < Inputs.Count; j++)
            {
                if (i == j)
                    continue;
                sum = sum + Inputs[j].Net.SC0;
            }

            return sum;
        }

        public override void SetObservabilities()
        {
            if (Inputs.Count < 2)
                throw new Exception("Gate Or takes at least two parameters. Net: " + Name);

            SetCOs();
            SetSOs();
        }

        public override void SetControllabilities()
        {
            if (Inputs.Count < 2)
                throw new Exception("Gate Or takes at least two parameters. Net: " + Name);

            SetCCs();
            SetSCs();
        }
        #endregion
    }
}
