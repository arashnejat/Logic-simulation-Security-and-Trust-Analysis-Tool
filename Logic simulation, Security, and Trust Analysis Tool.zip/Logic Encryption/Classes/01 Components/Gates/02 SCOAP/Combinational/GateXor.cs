﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateXor : Net
    {
        #region SCOAP Methods
        public override SCOAPValue CalculateCC0()
        {
            if (Inputs.Count == 2)
                return SCOAPValue.Min(Inputs[0].Net.CC0 + Inputs[1].Net.CC0, Inputs[0].Net.CC1 + Inputs[1].Net.CC1) + 1;
            return SCOAPValue.Min(
                Inputs[0].Net.CC0 + Inputs[1].Net.CC0 + Inputs[2].Net.CC0,
                Inputs[0].Net.CC0 + Inputs[1].Net.CC1 + Inputs[2].Net.CC1,
                Inputs[0].Net.CC1 + Inputs[1].Net.CC0 + Inputs[2].Net.CC1,
                Inputs[0].Net.CC1 + Inputs[1].Net.CC1 + Inputs[2].Net.CC0) + 1;
        }

        public override SCOAPValue CalculateSC0()
        {
            if (Inputs.Count == 2) 
                return SCOAPValue.Min(Inputs[0].Net.SC0 + Inputs[1].Net.SC0, Inputs[0].Net.SC1 + Inputs[1].Net.SC1);
            return SCOAPValue.Min(
                Inputs[0].Net.SC0 + Inputs[1].Net.SC0 + Inputs[2].Net.SC0,
                Inputs[0].Net.SC0 + Inputs[1].Net.SC1 + Inputs[2].Net.SC1,
                Inputs[0].Net.SC1 + Inputs[1].Net.SC0 + Inputs[2].Net.SC1,
                Inputs[0].Net.SC1 + Inputs[1].Net.SC1 + Inputs[2].Net.SC0);
        }

        public override SCOAPValue CalculateCC1()
        {
            if(Inputs.Count == 2)
                return SCOAPValue.Min(Inputs[0].Net.CC1 + Inputs[1].Net.CC0, Inputs[0].Net.CC0 + Inputs[1].Net.CC1) + 1;
            return SCOAPValue.Min(
                Inputs[0].Net.CC0 + Inputs[1].Net.CC0 + Inputs[2].Net.CC1,
                Inputs[0].Net.CC0 + Inputs[1].Net.CC1 + Inputs[2].Net.CC0,
                Inputs[0].Net.CC1 + Inputs[1].Net.CC0 + Inputs[2].Net.CC0,
                Inputs[0].Net.CC1 + Inputs[1].Net.CC1 + Inputs[2].Net.CC1) + 1;
        }

        public override SCOAPValue CalculateSC1()
        {
            if (Inputs.Count == 2) 
                return SCOAPValue.Min(Inputs[0].Net.SC1 + Inputs[1].Net.SC0, Inputs[0].Net.SC0 + Inputs[1].Net.SC1);
            return SCOAPValue.Min(
                Inputs[0].Net.SC0 + Inputs[1].Net.SC0 + Inputs[2].Net.SC1,
                Inputs[0].Net.SC0 + Inputs[1].Net.SC1 + Inputs[2].Net.SC0,
                Inputs[0].Net.SC1 + Inputs[1].Net.SC0 + Inputs[2].Net.SC0,
                Inputs[0].Net.SC1 + Inputs[1].Net.SC1 + Inputs[2].Net.SC1);
        }

        public override SCOAPValue COInputI(int i)
        {
            if (Inputs.Count == 2)
            {
                if (i == 0)
                    return CO + SCOAPValue.Min(Inputs[1].Net.CC0, Inputs[1].Net.CC1) + 1;
                if (i == 1)
                    return CO + SCOAPValue.Min(Inputs[0].Net.CC0, Inputs[0].Net.CC1) + 1;
            }
            else if (Inputs.Count == 3)
            {
                if (i == 0)
                    return CO + SCOAPValue.Min(
                        Inputs[1].Net.CC0 + Inputs[2].Net.CC0,
                        Inputs[1].Net.CC1 + Inputs[2].Net.CC1,
                        Inputs[1].Net.CC0 + Inputs[2].Net.CC1,
                        Inputs[1].Net.CC1 + Inputs[2].Net.CC0) + 1;
                if (i == 1)
                    return CO + SCOAPValue.Min(
                        Inputs[0].Net.CC0 + Inputs[2].Net.CC0,
                        Inputs[0].Net.CC1 + Inputs[2].Net.CC1,
                        Inputs[0].Net.CC0 + Inputs[2].Net.CC1,
                        Inputs[0].Net.CC1 + Inputs[2].Net.CC0) + 1;
                if (i == 2)
                    return CO + SCOAPValue.Min(
                        Inputs[0].Net.CC0 + Inputs[1].Net.CC0,
                        Inputs[0].Net.CC1 + Inputs[1].Net.CC1,
                        Inputs[0].Net.CC0 + Inputs[1].Net.CC1,
                        Inputs[0].Net.CC1 + Inputs[1].Net.CC0) + 1;
            }
            throw new Exception("Xor with more than three inputs is not implemented. Net: " + Name);
        }

        public override SCOAPValue SOInputI(int i)
        {
            if (Inputs.Count == 2)
            {
                if (i == 0)
                    return SO + SCOAPValue.Min(Inputs[1].Net.SC0, Inputs[1].Net.SC1);
                if (i == 1)
                    return SO + SCOAPValue.Min(Inputs[0].Net.SC0, Inputs[0].Net.SC1);
            }
            else if (Inputs.Count == 3)
            {
                if (i == 0)
                    return CO + SCOAPValue.Min(
                        Inputs[1].Net.SC0 + Inputs[2].Net.SC0,
                        Inputs[1].Net.SC1 + Inputs[2].Net.SC1,
                        Inputs[1].Net.SC0 + Inputs[2].Net.SC1,
                        Inputs[1].Net.SC1 + Inputs[2].Net.SC0);
                if (i == 1)
                    return CO + SCOAPValue.Min(
                        Inputs[0].Net.SC0 + Inputs[2].Net.SC0,
                        Inputs[0].Net.SC1 + Inputs[2].Net.SC1,
                        Inputs[0].Net.SC0 + Inputs[2].Net.SC1,
                        Inputs[0].Net.SC1 + Inputs[2].Net.SC0);
                if (i == 2)
                    return CO + SCOAPValue.Min(
                        Inputs[0].Net.SC0 + Inputs[1].Net.SC0,
                        Inputs[0].Net.SC1 + Inputs[1].Net.SC1,
                        Inputs[0].Net.SC0 + Inputs[1].Net.SC1,
                        Inputs[0].Net.SC1 + Inputs[1].Net.SC0);
            }
            throw new Exception("Xor with more than three inputs is not implemented. Net: " + Name);
        }

        //## More Inputs will be added in here too ## (Just For Gates Xor and Xnor)
        public override void SetObservabilities()
        {
            if (Inputs.Count < 2)
                throw new Exception("Gate Xor takes at least two parameters. Net: " + Name);
            if (Inputs.Count > 3)
                throw new Exception("Gate Xor with more than 3 parameters is not implemented. Net: " + Name);

            SetCOs();
            SetSOs();
        }

        public override void SetControllabilities()
        {
            if (Inputs.Count < 2)
                throw new Exception("Gate Xor takes at least two parameters. Net: " + Name);
            if (Inputs.Count > 3)
                throw new Exception("Gate Xor with more than 3 parameters is not implemented. Net: " + Name);

            SetCCs();
            SetSCs();
        }
        #endregion
    }
}
