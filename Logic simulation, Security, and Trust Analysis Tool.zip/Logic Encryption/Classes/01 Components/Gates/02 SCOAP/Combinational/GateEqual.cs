﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class GateEqual : Net
    {
        #region SCOAP Methods
        public override void SetControllabilities()
        {
            CC0.Set(Inputs[0].Net.CC0);
            CC1.Set(Inputs[0].Net.CC1);
            SC0.Set(Inputs[0].Net.SC0);
            SC1.Set(Inputs[0].Net.SC1);
        }

        public override void SetObservabilities()
        {
            Inputs[0].Net.CO.SetMin(CO);
            Inputs[0].Net.SO.SetMin(SO);
        }
        #endregion
    }
}
