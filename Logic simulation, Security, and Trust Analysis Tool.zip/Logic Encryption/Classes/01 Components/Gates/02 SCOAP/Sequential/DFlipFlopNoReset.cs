﻿using System;

namespace LogicEncryption
{
    public partial class DFlipFlopNoReset : FlipFlop
    {
        #region SCOAP Methods
        private SCOAPValue CalculateCC0(Net Q, Net D, Net C)
        {
            return D.CC0 + C.CC1 + C.CC0;
        }

        private SCOAPValue CalculateSC0(Net Q, Net D, Net C)
        {
            return D.SC0 + C.SC1 + C.SC0 + 1;
        }

        private SCOAPValue CalculateCC1(Net Q, Net D, Net C)
        {
            return D.CC1 + C.CC1 + C.CC0;
        }

        private SCOAPValue CalculateSC1(Net Q, Net D, Net C)
        {
            return D.SC1 + C.SC1 + C.SC0 + 1;
        }

        #region COs

        private SCOAPValue COD(Net Q, Net D, Net C)
        {
            return Q.CO + C.CC1 + C.CC0;
        }

        private SCOAPValue COC(Net Q, Net D, Net C)
        {
            return Q.CO + Q.CC1 + D.CC0 + C.CC1 + C.CC0;
        }

        #endregion

        #region SOs

        private SCOAPValue SOD(Net Q, Net D, Net C)
        {
            return Q.SO + C.SC1 + C.SC0 + 1;
        }

        private SCOAPValue SOC(Net Q, Net D, Net C)
        {
            return Q.SO + Q.SC1 + D.SC0 + C.SC1 + C.SC0 + 1;
        }

        #endregion

        private void SetCOs(Net Q, Net D, Net C)
        {
            D.CO.SetMin(COD(Q: Q, D: D, C: C));
            C.CO.SetMin(COC(Q: Q, D: D, C: C));
        }

        private void SetSOs(Net Q, Net D, Net C)
        {
            D.SO.SetMin(SOD(Q: Q, D: D, C: C));
            C.SO.SetMin(SOC(Q: Q, D: D, C: C));
        }

        private void SetCCs(Net Q, Net D, Net C)
        {
            Q.CC1.Set(CalculateCC1(Q: Q, D: D, C: C));
            Q.CC0.Set(CalculateCC0(Q: Q, D: D, C: C));
        }

        private void SetSCs(Net Q, Net D, Net C)
        {
            Q.SC1.Set(CalculateSC1(Q: Q, D: D, C: C));
            Q.SC0.Set(CalculateSC0(Q: Q, D: D, C: C));
        }

        public override void SetObservabilities()
        {
            if (Inputs.Count < 2)
                throw new Exception("Not enough parameters for gates DFF or DFFC. Net: " + Name);

            SetCOs(Q: this, D: Inputs[0].Net, C: Inputs[1].Net);
            SetSOs(Q: this, D: Inputs[0].Net, C: Inputs[1].Net);
        }

        public override void SetControllabilities()
        {
            if (Inputs.Count < 2)
                throw new Exception("Not enough parameters for gates DFF or DFFC. Net: " + Name);

            SetCCs(Q: this, D: Inputs[0].Net, C: Inputs[1].Net);
            SetSCs(Q: this, D: Inputs[0].Net, C: Inputs[1].Net);
        }
        #endregion
    }
}
