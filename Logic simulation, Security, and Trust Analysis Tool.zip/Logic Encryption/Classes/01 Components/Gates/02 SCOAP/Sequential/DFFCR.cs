﻿namespace LogicEncryption
{
    public partial class DFFCR : DFlipFlop
    {

    }
}
