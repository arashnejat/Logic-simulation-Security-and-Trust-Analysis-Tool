﻿namespace LogicEncryption
{
    public partial class DFF : DFlipFlopNoReset
    {

    }
}
