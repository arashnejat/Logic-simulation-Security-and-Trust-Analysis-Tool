﻿
namespace LogicEncryption
{
    public partial class FlipFlop : Net
    {

    }
}
