﻿namespace LogicEncryption
{
    public partial class DFFR : DFlipFlop
    {

    }
}
