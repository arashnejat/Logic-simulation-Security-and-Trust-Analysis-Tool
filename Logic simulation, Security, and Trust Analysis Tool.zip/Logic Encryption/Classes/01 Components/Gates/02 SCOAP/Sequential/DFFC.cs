﻿namespace LogicEncryption
{
    public partial class DFFC : DFlipFlopNoReset
    {

    }
}
