﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace LogicEncryption
{
    public partial class Net
    {
        public int LevelNumberInSCOAP = -1;
        public bool Observed = false;//در محاسبه پارامتر مشاهده پذیری اسکوپ کاربرد دارد
        public bool IsGeneratedFanout;//آیا سیم فن اوتی است که توسط پارسر به مدار اضافه شده است

        public SCOAPValue CC0 = new SCOAPValue();//Combinational Controllability of 0
        public SCOAPValue CC1 = new SCOAPValue();//Combinational Controllability of 1
        public SCOAPValue SC0 = new SCOAPValue();//Sequential Controllability of 0
        public SCOAPValue SC1 = new SCOAPValue();//Sequential Controllability of 1

        public SCOAPValue CO = new SCOAPValue();//Combinational Observability
        public SCOAPValue SO = new SCOAPValue();//Sequential Observability

        public SCOAPValue TSa0 = new SCOAPValue();//one of SCOAP Parameters
        public SCOAPValue TSa1 = new SCOAPValue();//one of SCOAP Parameters

        /// <summary>
        /// آیا محاسبات کنترل پذیری اسکوپ پایدار شده و پایان یافته اند یا خیر
        /// </summary>
        public bool ControllabilitiesStabilized
        {
            get { return SC0.Stabilized && SC1.Stabilized && CC0.Stabilized && CC1.Stabilized; }
        }

        /// <summary>
        /// آیا محاسبات مشاهده پذیری اسکوپ پایدار شده و پایان یافته اند یا خیر
        /// </summary>
        public bool ObservabilitiesStabilized
        {
            get { return CO.Stabilized && SO.Stabilized; }
        }

        public void SetTSas()
        {
            TSa0 = CC1 + CO;
            TSa1 = CC0 + CO;
        }
        
        //===================================================================================

        #region Common SCOAP Methods
        public virtual SCOAPValue CalculateCC1()
        {
            throw new NotImplementedException();
        }

        public virtual SCOAPValue CalculateCC0()
        {
            throw new NotImplementedException();
        }

        public virtual SCOAPValue CalculateSC1()
        {
            throw new NotImplementedException();
        }

        public virtual SCOAPValue CalculateSC0()
        {
            throw new NotImplementedException();
        }

        public virtual SCOAPValue COInputI(int i)
        {
            throw new NotImplementedException();
        }
        public virtual SCOAPValue SOInputI(int i)
        {
            throw new NotImplementedException();
        }

        protected void SetCCs()
        {
            CC0.Set(CalculateCC0());
            CC1.Set(CalculateCC1());
        }

        protected void SetSCs()
        {
            SC0.Set(CalculateSC0());
            SC1.Set(CalculateSC1());
        }

        protected void SetCOs()
        {
            for (var i = 0; i < Inputs.Count; i++)
                Inputs[i].Net.CO.SetMin(COInputI(i));
        }

        protected void SetSOs()
        {
            for (var i = 0; i < Inputs.Count; i++)
                Inputs[i].Net.SO.SetMin(SOInputI(i));
        }

        public virtual void SetControllabilities() { }

        public virtual void SetObservabilities() { }
        #endregion

        //===================================================================================
    }
}
