﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public class SCOAPValue
    {
        public const string SymboleOfInfinity = "∞";

        private bool _oldInfinity = true;
        private long _oldAmount = 0;

        public bool Infinity = true;
        public long Amount = 0;
        
        public bool Stabilized
        {
            get
            {
                return (Infinity == _oldInfinity) && (Amount == _oldAmount);
            }
        }

        public void Set(SCOAPValue v)
        {
            _oldInfinity = Infinity;
            _oldAmount = Amount;

            Infinity = v.Infinity;
            Amount = v.Amount;
        }

        public void SetMin(SCOAPValue v) //با این استدلال که آبزروبیلیتی هیچگاه افزایش نمی یابد، از مقدار کمینه استفاده می شود
        {
            if (v <= this)
            {
                _oldInfinity = Infinity;
                _oldAmount = Amount;

                Infinity = v.Infinity;
                Amount = v.Amount;
            }
        }

        public void InitialSet(SCOAPValue v)
        {
            _oldInfinity = v.Infinity;
            _oldAmount = v.Amount;

            Infinity = v.Infinity;
            Amount = v.Amount;
        }

        public override string ToString()
        {
            return Infinity ? SymboleOfInfinity : Amount.ToString();
        }

        public static SCOAPValue operator +(SCOAPValue v1, SCOAPValue v2)
        {
            var retValue = new SCOAPValue();

            if (v1.Infinity || v2.Infinity)
            {
                retValue.Infinity = true;
            }
            else
            {
                retValue.Infinity = false;
                retValue.Amount = v1.Amount + v2.Amount;
            }

            return retValue;
        }

        public static SCOAPValue operator +(SCOAPValue v1, int number)
        {
            var retValue = new SCOAPValue();

            if (v1.Infinity)
            {
                retValue.Infinity = true;
            }
            else
            {
                retValue.Infinity = false;
                retValue.Amount = v1.Amount + number;
            }

            return retValue;
        }

        public static bool operator <(SCOAPValue v1, SCOAPValue v2)
        {
            if (v2.Infinity && !v1.Infinity)
                return true;
            if (v1.Infinity && !v2.Infinity)
                return false;
            if (v1.Infinity && v2.Infinity)
                return false;
            return v1.Amount < v2.Amount;
        }

        public static bool operator >(SCOAPValue v1, SCOAPValue v2)
        {
            if (v2.Infinity && !v1.Infinity)
                return false;
            if (v1.Infinity && !v2.Infinity)
                return true;
            if (v1.Infinity && v2.Infinity)
                return false;
            return v1.Amount > v2.Amount;
        }

        public static bool operator <=(SCOAPValue v1, SCOAPValue v2)
        {
            if (v2.Infinity && !v1.Infinity)
                return true;
            if (v1.Infinity && !v2.Infinity)
                return false;
            if (v1.Infinity && v2.Infinity)
                return true;
            return v1.Amount <= v2.Amount;
        }

        public static bool operator >=(SCOAPValue v1, SCOAPValue v2)
        {
            if (v2.Infinity && !v1.Infinity)
                return false;
            if (v1.Infinity && !v2.Infinity)
                return true;
            if (v1.Infinity && v2.Infinity)
                return true;
            return v1.Amount >= v2.Amount;
        }

        public static SCOAPValue Min(SCOAPValue v1, SCOAPValue v2)
        {
            var v = new SCOAPValue();
            v.InitialSet(v1 <= v2 ? v1 : v2);
            return v;
        }

        public static SCOAPValue Min(SCOAPValue v1, SCOAPValue v2, SCOAPValue v3)
        {
            return Min(Min(v1, v2), v3);
        }
        public static SCOAPValue Min(SCOAPValue v1, SCOAPValue v2, SCOAPValue v3, SCOAPValue v4)
        {
            return Min(Min(v1, v2), Min(v3, v4));
        }

        public static SCOAPValue Min(List<SCOAPValue> values)
        {
            if (values.Count == 0)
                throw new Exception("Count must be >= 1");

            var v = new SCOAPValue();
            v.InitialSet(values[0]);

            foreach (var value in values)
            {
                if (value <= v)
                    v.InitialSet(value);
            }

            return v;
        }

        public static SCOAPValue Max(SCOAPValue v1, SCOAPValue v2)
        {
            var v = new SCOAPValue();
            v.InitialSet(v1 >= v2 ? v1 : v2);
            return v;
        }

        public static SCOAPValue Max(SCOAPValue v1, SCOAPValue v2, SCOAPValue v3)
        {
            return Max(Max(v1, v2), v3);
        }
        public static SCOAPValue Max(SCOAPValue v1, SCOAPValue v2, SCOAPValue v3, SCOAPValue v4)
        {
            return Max(Min(v1, v2), Max(v3, v4));
        }
    }
}
