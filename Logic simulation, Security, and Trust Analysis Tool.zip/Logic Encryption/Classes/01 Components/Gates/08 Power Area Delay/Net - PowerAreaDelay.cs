﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicEncryption
{
    public partial class Net
    {
        //Power Area Delay related parameters:

        public double inputc;

        public double tplh_fix;
        public double tphl_fix;

        public double tplh_load;
        public double tphl_load;

        public double tplh;
        public double tphl;

        public double gd;
        public double gd_min;

        public double load;

        public double delay;

        public double area;

        public double TempZerosForUserPower;//پارامتر موقتی برای نگهداری تعداد دفعات صفر شدن سیگنال جهت محاسبه توان مصرفی مدار از نگاه کاربر نهایی
        public double TempOnesForUserPower;//پارامتر موقتی برای نگهداری تعداد دفعات یک شدن سیگنال جهت محاسبه توان مصرفی مدار از نگاه کاربر نهایی
        public double TempSimulatedProbabilityForUserPower;//پارامتر موقتی برای نگهداری مقدار احتمال یک شدن سیگنال جهت محاسبه توان مصرفی مدار از نگاه کاربر نهایی
    }
}
