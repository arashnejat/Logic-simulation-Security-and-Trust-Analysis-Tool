﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class Net
    {
        public int ASAP = -1;
        public int? ALAP = Int32.MaxValue;

        /// <summary>
        /// میزان زمان لختی این سیگنال (تعریف شده در مقاله
        /// A Novel Hardware Logic Encryption Technique for thwarting Illegal Overproduction and Hardware Trojans
        /// </summary>
        public int? SlackTime = -1;
    }
}
