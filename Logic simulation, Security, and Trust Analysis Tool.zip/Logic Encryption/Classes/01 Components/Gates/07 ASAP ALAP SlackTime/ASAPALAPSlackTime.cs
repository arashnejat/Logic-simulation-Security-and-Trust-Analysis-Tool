﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LogicEncryption
{
    public class ASAPALAPSlackTime
    {
        #region CacheManager

        public static void LoadOrCalculateASAPALAPSlackTimeOfNets(List<Net> nets, string netlistName, out int maxLevel, bool forceCalculate, bool allowSaveResults, out string loadReport)
        {
            var cacheFileName = netlistName + 
                                 CacheManager.GetHashFromNets(nets) + 
                                ".SlackTimes";

            var cacheFilePath = CacheManager.CacheDirectory + cacheFileName;

            foreach (var net in nets)
            {
                net.ASAP = -1;
                net.ALAP = Int32.MaxValue;
                net.SlackTime = -1;
                net.LevelNumberInLogicSimulation = -1; //NEW جدید
            }

            if (!forceCalculate && !string.IsNullOrEmpty(netlistName))
            {
                if (SamimiIO.Exists(cacheFilePath))
                {
                    if (LoadSlackTimesFromFile(cacheFilePath, nets, out maxLevel))
                    {
                        loadReport = "ASAPALAPSlackTimes Loaded From File:\t" + cacheFileName;
                        return;
                    }
                }
            }

            var s = new Stopwatch();
            s.Start();

            CalculateASAPALAPSlackTimeOfNets(nets: nets, maxLevel: out maxLevel);

            s.Stop();
            loadReport = "ASAPALAPSlackTimes Calculation Duration:\t" + s.Elapsed;

            if (allowSaveResults)
            {
                SaveSlackTimesToFile(cacheFilePath, nets, maxLevel);
                loadReport += "\r\n" + "Saved To File:\t" + cacheFileName;
            }
        }

        private static void SaveSlackTimesToFile(string cacheFilePath, List<Net> nets, int maxLevel)
        {
            if (SamimiIO.Exiting)
                return;
            
            var dataToSave = new List<string>();

            dataToSave.Add(maxLevel.ToString());
            foreach (var net in nets)
            {
                dataToSave.Add(net.Name + "\t" + net.LevelNumberInLogicSimulation + "\t" + net.ASAP + "\t" + net.ALAP + "\t" + net.SlackTime);
            }

            var str = string.Join("\r\n", dataToSave);

            SamimiIO.WriteAllText(cacheFilePath, str);
        }

        private static bool LoadSlackTimesFromFile(string cacheFilePath, List<Net> nets, out int maxLevel)
        {
            var oldNets = new List<Net>(nets);
            try
            {
                var str = SamimiIO.ReadAllText(cacheFilePath);

                string[] seperators = { "\r\n", "\t" };

                var data = str.Split(seperators, StringSplitOptions.RemoveEmptyEntries);

                nets.Clear();

                maxLevel = int.Parse(data[0]);

                var loadedNetsCount = 0;
                for (int i = 1; i < data.Length; i += 5)
                {
                    var foundNet = oldNets.Find(net => net.Name == data[i]);
                    loadedNetsCount++;

                    foundNet.LevelNumberInLogicSimulation = int.Parse(data[i + 1]);
                    foundNet.ASAP = int.Parse(data[i + 2]);
                    foundNet.ALAP = int.Parse(data[i + 3]);
                    foundNet.SlackTime = int.Parse(data[i + 4]);
                    
                    nets.Add(foundNet);
                }

                if (loadedNetsCount != oldNets.Count)
                    throw new Exception("Count not equal, Load failed.");

                return true;
            }
            catch (Exception)
            {
                nets.Clear();
                foreach (var net in oldNets)
                    nets.Add(net);

                maxLevel = 0;
                return false;
            }
        }

        #endregion

        public static string ReportASAPALAPSLackTime(List<Net> nets, int maxLevel)
        {
            var str = "";
            for (int i = 0; i <= maxLevel; i++)
            {
                var netsOfLevel = LogicSimulation.GetNetsOfLevel(nets, i);

                str += "Level " + i + ":\r\n";
                foreach (var net in netsOfLevel)
                {
                    str += "Name: " + net.Name + ": (" + net.ASAP + ", " + net.ALAP + ") " + net.SlackTime + "\r\n"; 
                }
                str += "______________________\r\n";
            }
            return str;
        }

        public static string ReportASAPALAPSLackTime(List<Net> nets)
        {
            var sortedNets = new List<Net>(nets);
            sortedNets.Sort((net1, net2) => Math.Sign(net1.SlackTime.Value - net2.SlackTime.Value));

            var str = "Name\tASAP\tALAP\tSlackTime\tLevel\r\n";
            foreach (var net in sortedNets)
            {
                //str += "Name: " + net.Name + ": (" + net.ASAP + ", " + net.ALAP + ") " + net.SlackTime + "\r\n"; // +
                str += net.Name + "\t" + net.ASAP + "\t" + net.ALAP + "\t" + net.SlackTime + "\t" + net.LevelNumberInLogicSimulation + "\r\n"; // +
            }
            return str;
        }


        private static void CalculateASAPALAPSlackTimeOfNets(List<Net> nets, out int maxLevel)
        {
            foreach (var net in nets)
            {
                net.ASAP = -1;
                net.ALAP = Int32.MaxValue;
                net.SlackTime = -1;
                net.LevelNumberInLogicSimulation = -1; //NEW جدید
            }

            LogicSimulation.LevelizeNets(nets, out maxLevel);
            
            //محاسبه ASAP
            for (var i = 0; i <= maxLevel; i++)
            {
                var netsInLevel = LogicSimulation.GetNetsOfLevel(nets: nets, levelNumber: i);

                foreach (var net in netsInLevel)
                {
                    net.ASAP = net.LevelNumberInLogicSimulation;
                }
            }

            //هر نتی، ایلپ ورودی هاش رو میسازه
            
            //محاسبه ALAP
            for (var i = maxLevel; i >= 0; i--)
            {
                var netsInLevel = LogicSimulation.GetNetsOfLevel(nets: nets, levelNumber: i);

                var fanouts = new List<Net>();
                fanouts.AddRange(netsInLevel.OfType<GateEqual>());

               //اول تکلیف فن اوت ها مشخص گردد
                foreach (var fanoutNet in fanouts)
                {
                    netsInLevel.Remove(fanoutNet);
                    if (i == maxLevel || fanoutNet.IsPrimaryOutput)
                    {
                        fanoutNet.ALAP = fanoutNet.LevelNumberInLogicSimulation;
                        fanoutNet.SlackTime = fanoutNet.ALAP - fanoutNet.ASAP;
                    }

                    //اونقدر عقب میریم تا دیگه به فن اوت نرسیم
                    var tmpNet = fanoutNet;
                    while (tmpNet is GateEqual)
                    {
                        var tmpNewALAP = tmpNet.ALAP;
                        tmpNet = fanoutNet.Inputs[0].Net;
                        if (tmpNewALAP < tmpNet.ALAP || tmpNet.ALAP == null)//اینجا داریم بین فن اوت ها مینیمم می گیریم که ایهام داره
                        {
                            tmpNet.ALAP = tmpNewALAP;
                            tmpNet.SlackTime = tmpNewALAP - tmpNet.ASAP;
                        }
                    }
                }

                foreach (var net in netsInLevel)
                {
                    if (i == maxLevel || net.IsPrimaryOutput)
                    {
                        net.ALAP = net.LevelNumberInLogicSimulation;
                        net.SlackTime = net.ALAP - net.ASAP;
                    }

                    var newALAP = net.ALAP - 1;
                    foreach (var input in net.Inputs)
                    {
                        if (newALAP < input.Net.ALAP || input.Net.ALAP == null)
                        {
                            input.Net.ALAP = newALAP;
                            input.Net.SlackTime = newALAP - input.Net.ASAP;
                        }
                    }
                }
            }
        }
    }
}
