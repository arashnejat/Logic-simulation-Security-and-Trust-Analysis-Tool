﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows.Forms;


namespace LogicEncryption
{
    public class SimulationReporter
    {
        private Stopwatch _simulatorStopwatch=new Stopwatch();

        public static bool OpenDirectory = true;
        private readonly string _netlistNamePure;
        private readonly string _netlistNameWithMethodName;
        private readonly TextBox _textboxConsoleLog = null;
        private readonly string _goalBits;
        private int _roundsCount = 0;

        public bool ReportSlackTimesAndLevelizationsBefore;//
        public bool ReportSlackTimesAndLevelizationsAfterRound;//

        public bool ReportProbabilitiesBefore;//
        public bool ReportProbabilitiesAfterRound;//


        public bool ReportUserPowerAfterRound;//
        public bool ReportAreaAfterRound;//
        public bool ReportPowerAfterRound;//
        public bool ReportDelayAfterRound;//

        public bool ReportIntegrityOfEncryption; //
        public bool ReportHammingDistanceAfterRound;//

        public SimulationReporter(string archiveDirectoryPath, string methodName, string netlistName, string directoryComment, int keyLength, TextBox textBox = null)
        {
            _goalBits = " " + keyLength + "bits";
            _netlistNamePure = netlistName;
            _netlistNameWithMethodName = methodName + " " + netlistName;
            _directoryPathMain =    archiveDirectoryPath.EndsWith("\\") ? archiveDirectoryPath : archiveDirectoryPath + "\\" +
                                    _netlistNameWithMethodName + " " + 
                                    DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss") + 
                                    (string.IsNullOrEmpty(directoryComment) ? "" : " " + directoryComment) + 
                                    _goalBits + "\\";

            _textboxConsoleLog = textBox;

            SamimiIO.CreateDirectory(_directoryPathMain);
            if (OpenDirectory)
                Process.Start(_directoryPathMain);
        }

        #region Paths Region
        private readonly string _directoryPathMain;

        public string GetMainDirectoryPath
        {
            get { return _directoryPathMain; }
        }

        private string GetRoundSubdirectoryPath(int length)
        {
            return _directoryPathMain + _netlistNameWithMethodName + " " + length + " Bits\\";
        }

        private string GetFinalResultsSubdirectoryPath()
        {
            return _directoryPathMain + _netlistNameWithMethodName + " Final Results\\";
        }

        private string GetBeforeEncryptionSubdirectoryPath()
        {
            return _directoryPathMain + _netlistNameWithMethodName + " 00 Bits (Before Encryption)\\";
        }

        #endregion

        //-------------------------------------------------------------------------------

        #region IO Region

        public static void AddToCSVRow(ref string csvRow, string value)
        {
            if (value.IndexOfAny(new char[] {'"', ','}) != -1)
            {
                value.Replace("\"", "\"\"");
                csvRow += "\"" +  value + "\"" + ',' ;
            }
            else
            {
                csvRow += value + ',';
            }
        }

        public void WriteToFile(string title, string value, string path = null, bool csv = false, bool bench = false, bool noDotSpace = false)
        {
            var ext = ".txt";
            if (csv)
                ext = ".csv";
            if (bench)
                ext = ".bench";

            var pathToWrite = "";

            if (string.IsNullOrEmpty(path))
            {
                var fileName = _netlistNameWithMethodName + " " + title + _goalBits;

                if (noDotSpace)
                    fileName = fileName.Replace(' ', '_').Replace('.', '_');

                pathToWrite = _directoryPathMain + fileName + ext;
                SamimiIO.WriteAllText(pathToWrite, value);
            }
            else
            {
                SamimiIO.CreateDirectory(path);
                var fileName = _netlistNameWithMethodName + " " + title;

                if (noDotSpace)
                    fileName = fileName.Replace(' ', '_').Replace('.', '_');

                pathToWrite = path + fileName + ext;
                SamimiIO.WriteAllText(pathToWrite, value);
            }

            if (bench && GenerateVerilogAfterRound)
            {
                var benchToVerilogPath = CacheManager.GetLocalAppPath() + "BenchToVerilog.exe";
                Process.Start(new ProcessStartInfo(benchToVerilogPath, '"' + pathToWrite + '"'));
            }
        }

        private string _consoleLog;
        public string ConsoleLog
        {
            get { return _consoleLog; }
            set { _consoleLog = value; WriteToFile("ConsoleLog", value); }
        }

        public void AddToConsoleLog(string data)
        {
            if (ConsoleLog == null)
                ConsoleLog = "";
            ConsoleLog += DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\t" + data + "\r\n";

            if (_textboxConsoleLog != null)
            {
                _textboxConsoleLog.Text = ConsoleLog;
                _textboxConsoleLog.SelectionStart = ConsoleLog.Length - 1;
                _textboxConsoleLog.ScrollToCaret();
                Application.DoEvents();
            }
        }

        #endregion

        //-------------------------------------------------------------------------------

        #region NetLists Region

        #region OriginalNeltistBeforeEncryption

        private string _originalNetlistBeforeEncryption; //

        public string OriginalNetlistBeforeEncryption
        {
            get { return _originalNetlistBeforeEncryption; }
            set
            {
                _originalNetlistBeforeEncryption = value;
                WriteToFile(title: "Netlist_OriginalNetlist", value: value, path: GetBeforeEncryptionSubdirectoryPath(), bench: true, noDotSpace: true);
            }
        }

        #endregion

        #region GeneratedNetlistAfterRound

        public string DecryptionKeyOfRound; //

        private string _generatedNetlistAfterRound; //

        public string GeneratedNetlistAfterRound
        {
            get { return _generatedNetlistAfterRound; }
            set
            {
                _generatedNetlistAfterRound = value;
                WriteToFile("Netlist_GeneratedNetlist" + " " + _roundsCount + " Bits", value, path: GetRoundSubdirectoryPath(_roundsCount), bench: true, noDotSpace: true);
            }
        }

        private void GenerateEncryptedNetlistAfterRound(List<Net> nets, string addedKeyValues)
        {
            AddToConsoleLog("Generating encrypted netlist after round " + _roundsCount + " started...");

            DecryptionKeyOfRound = addedKeyValues;
            GeneratedNetlistAfterRound = "#Key:\t" + addedKeyValues + "\r\n" +
                                         "#KeyLength:\t" + addedKeyValues.Length + "\r\n" +
                                         Parser.GenerateNetlistFromListOfNets(nets);
            AddToConsoleLog("Generating encrypted netlist after round " + _roundsCount + " ended");
        }

        #endregion

        #endregion

        //-------------------------------------------------------------------------------

        #region Encryption Details Region

        private string _encryptionDetails; //

        public string EncryptionDetails
        {
            get { return _encryptionDetails; }
            set
            {
                _encryptionDetails = value;
                WriteToFile("EncryptionDetails", value);
            }
        }

        #endregion

        //-------------------------------------------------------------------------------

        #region Probabilities Region

        public class ProbabiliySimulatorDataHolder
        {
            public int clockTimes;
            public int randomSeed;
            public int randomPatternsCount;
            public bool meetThreshold;
            public double threshold;
        }

        public ProbabiliySimulatorDataHolder ProbabiliySimulatorData = new ProbabiliySimulatorDataHolder();


        #region ProbabilitiesBeforeEncryption Region

        #region ProbabilitiesBeforeEncryption

        private string _probabilitiesBeforeEncryption; //

        private string ProbabilitiesBeforeEncryption
        {
            get { return _probabilitiesBeforeEncryption; }
            set
            {
                _probabilitiesBeforeEncryption = value;
                WriteToFile("ProbabilitiesBefore", value, path: GetBeforeEncryptionSubdirectoryPath());
            }
        }

        #endregion

        #region ProbabilityAnalysisBeforeEncryption

        private string _probabilityAnalysisBefore; //

        private string ProbabilityAnalysisBefore
        {
            get { return _probabilityAnalysisBefore; }
            set
            {
                _probabilityAnalysisBefore = value;
                WriteToFile("ProbabilityAnalysisBefore", value, path: GetBeforeEncryptionSubdirectoryPath());
            }
        }

        #endregion

        private void GenerateProbabilityAnalysisBeforeEncryption(List<Net> nets, bool forceCalculate)
        {
            if (ReportProbabilitiesBefore)
            {
                AddToConsoleLog("Simulating netlist before encryption started...");

                string loadReport;
                var totalSamples = LogicSimulation.LoadOrCalculateProbabilities(
                    nets: nets, 
                    clockTimes: ProbabiliySimulatorData.clockTimes,
                    randomSeed: ProbabiliySimulatorData.randomSeed,
                    totalTimes: ProbabiliySimulatorData.randomPatternsCount,
                    meetThreshold: ProbabiliySimulatorData.meetThreshold, 
                    threshold: ProbabiliySimulatorData.threshold,
                    textBox: null, 
                    netlistName: _netlistNamePure,
                    loadReport: out loadReport,
                    forceCalculate: forceCalculate, 
                    allowSaveResults: true);

                ProbabilitiesBeforeEncryption = LogicSimulation.ReportLogicSimulation(nets);
                
                AddToConsoleLog(loadReport);

                AddToConsoleLog("Total Samples:\t" + totalSamples);

                ProbabilityAnalysisStatisticalResultHolder resultsHolder;
                ProbabilityAnalysisBefore = ProbabilityAnalyzer.AnalyzeProbabilities(nets, out resultsHolder);

                AddToFinalProbabilities(nets, 0);
                AddToFinalProbabilityAnalysis(bits: "0", resultsHolder: resultsHolder);

                AddToConsoleLog("Simulating netlist before encryption ended");
            }
        }

        #endregion

        //-------------------------------------------------------------------------------

        #region ProbabilitiesAfterRound Region

        #region ProbabilitiesAfterRound

        private string _probabilitiesAfterRound; //

        private string ProbabilitiesAfterRound
        {
            get { return _probabilitiesAfterRound; }
            set
            {
                _probabilitiesAfterRound = value;
                WriteToFile("ProbabilitiesAfter" + " " + _roundsCount + " Bits", value,
                    path: GetRoundSubdirectoryPath(_roundsCount));
            }
        }

        #endregion

        #region ProbabilityAnalysisAfterRound

        private string _probabilityAnalysisAfterRound; //

        private string ProbabilityAnalysisAfterRound
        {
            get { return _probabilityAnalysisAfterRound; }
            set
            {
                _probabilityAnalysisAfterRound = value;
                WriteToFile("ProbabilityAnalysisAfter" + " " + _roundsCount + " Bits", value,
                    path: GetRoundSubdirectoryPath(_roundsCount));
            }
        }

        #endregion

        private void GenerateProbabilityAnalysisAfterRound(List<Net> nets, bool forceCalculate)
        {
            if (ReportProbabilitiesAfterRound)
            {
                AddToConsoleLog("Simulating netlist after round " + _roundsCount + " started...");
                string loadReport;
                var totalSamples = LogicSimulation.LoadOrCalculateProbabilities(
                    nets: nets, 
                    clockTimes: ProbabiliySimulatorData.clockTimes,
                    randomSeed: ProbabiliySimulatorData.randomSeed,
                    totalTimes: ProbabiliySimulatorData.randomPatternsCount,
                    meetThreshold: ProbabiliySimulatorData.meetThreshold, 
                    threshold: ProbabiliySimulatorData.threshold,
                    textBox: null, 
                    netlistName: _netlistNamePure,
                    loadReport: out loadReport,
                    forceCalculate: forceCalculate, 
                    allowSaveResults: true);

                AddToConsoleLog(loadReport);
                AddToConsoleLog("Total Samples:\t" + totalSamples);

                ProbabilitiesAfterRound = LogicSimulation.ReportLogicSimulation(nets);
                ProbabilityAnalysisStatisticalResultHolder resultsHolder;
                ProbabilityAnalysisAfterRound = ProbabilityAnalyzer.AnalyzeProbabilities(nets, out resultsHolder);

                //در راند صفرم، این مقادیر قبلا در پیش محاسبه قبل رمزگذاری محاسبه شده اند و نیازی به ثبت مجددشان نیست
                if (!ReportProbabilitiesBefore || _roundsCount > 0)
                {
                    AddToFinalProbabilities(nets, _roundsCount);
                    AddToFinalProbabilityAnalysis(bits: _roundsCount.ToString(), resultsHolder: resultsHolder);
                }

                AddToConsoleLog("Simulating netlist after round " + _roundsCount + " ended");
            }
        }

        private void GeneratePowerAreaDelayAnalysisReportAfterRound(List<Net> nets, string key)
        {
            if (ReportUserPowerAfterRound)
            {
                AddToConsoleLog("Calculating User Power after round " + _roundsCount + " started...");

                //نگهداری تعداد 1 ها و صفر ها و احتمال سیگنال ها در متغیر های موقتی
                foreach (var net in nets)
                {
                    net.TempOnesForUserPower = net.Ones;
                    net.TempZerosForUserPower = net.Zeros;
                    net.TempSimulatedProbabilityForUserPower = net.SimulatedProbability;
                }

                PowerAreaDelay.CalculateOrLoadProbabilities(nets: nets, netlistName: _netlistNamePure, allowSaveResults: true, key: key);
                var power = PowerAreaDelay.CalculatePowerOfNetlist(nets);
                UserPowerAfterRound = "User Power:\t" + power;
                AddToFinalUserPowerAnalysis(_roundsCount.ToString(), power);

                //بازگردانی تعداد 1 ها و صفر ها و احتمال سیگنال ها از متغیر های موقتی
                foreach (var net in nets)
                {
                    net.Ones = net.TempOnesForUserPower;
                    net.Zeros = net.TempZerosForUserPower;
                    net.SimulatedProbability = net.TempSimulatedProbabilityForUserPower;
                }

                AddToConsoleLog("Calculating User Power after round " + _roundsCount + " ended");
            }

            if (ReportPowerAfterRound)
            {
                AddToConsoleLog("Calculating Power after round " + _roundsCount + " started...");

                var power = PowerAreaDelay.CalculatePowerOfNetlist(nets);

                AddToConsoleLog("Power:\t" + power);

                PowerAfterRound = "Power:\t" + power;

                AddToFinalPowerAnalysis(_roundsCount.ToString(), power);

                AddToConsoleLog("Calculating Power after round " + _roundsCount + " ended");
            }

            if (ReportAreaAfterRound)
            {
                AddToConsoleLog("Calculating Area after round " + _roundsCount + " started...");

                var Area = PowerAreaDelay.CalculateAreaOfNetlist(nets);

                AddToConsoleLog("Area:\t" + Area);

                AreaAfterRound = "Area:\t" + Area;

                AddToFinalAreaAnalysis(_roundsCount.ToString(), Area);

                AddToConsoleLog("Calculating Area after round " + _roundsCount + " ended");
            }

            if (ReportDelayAfterRound)
            {
                AddToConsoleLog("Calculating Delay after round " + _roundsCount + " started...");

                var Delay = PowerAreaDelay.CalculateDelayOfNetlist(nets);

                AddToConsoleLog("Delay:\t" + Delay);

                DelayAfterRound = "Delay:\t" + Delay;

                AddToFinalDelayAnalysis(_roundsCount.ToString(), Delay);

                AddToConsoleLog("Calculating Delay after round " + _roundsCount + " ended");
            }
        }

        #endregion

        //-------------------------------------------------------------------------------

        #region FinalProbabilities (Step By Step After Each Round) (Writes At once After Whole Encryption)

        private string _finalProbabilites;

        public string FinalProbabilities
        {
            get { return _finalProbabilites; }
            set
            {
                _finalProbabilites = value;
                WriteToFile("FinalProbabilities", value, GetFinalResultsSubdirectoryPath(), csv: true);
            }
        }

        private void AddToFinalProbabilities(List<Net> nets, int bits)
        {
            foreach (var net in nets)
                AddToFinalProbabilitiesDictionary(net.Name, bits, net.SimulatedProbability);
        }

        public void WriteFinalWholeProbabilitieReport()
        {
            if (ReportProbabilitiesAfterRound || ReportProbabilitiesBefore)
            {
                var report = "";
                //ساخت هدر
                if (string.IsNullOrEmpty(FinalProbabilities))
                {
                    var csvRowHeader = "sep=,\n";
                    AddToCSVRow(ref csvRowHeader, "Name");

                    for (int i = 0; i <= _roundsCount; i++)
                    {
                        AddToCSVRow(ref csvRowHeader, i + " Bits");
                    }

                    report += csvRowHeader + "\n";
                }

                //ساخت داده ها
                var csvRowData = "";
                foreach (KeyValuePair<string, Dictionary<int, double>> keyValuePair in FinalProbabilitiesDictionary)
                {
                    csvRowData = ""; 
                    AddToCSVRow(ref csvRowData, keyValuePair.Key);

                    for (int i = 0; i <= _roundsCount; i++)
                    {
                        var dictionaryBitsDouble = keyValuePair.Value;
                        double probabilityValue;
                        if (dictionaryBitsDouble.TryGetValue(i, out probabilityValue))
                        {
                            AddToCSVRow(ref csvRowData, probabilityValue.ToString());
                        }
                        else
                        {
                            AddToCSVRow(ref csvRowData, "");
                        }
                    }
                    report += csvRowData + "\n";
                }

                FinalProbabilities = report;
            }
        }

        #region FinalProbabilitisDictionaryMethods

        public Dictionary<string, Dictionary<int, double>> FinalProbabilitiesDictionary =
            new Dictionary<string, Dictionary<int, double>>();

        private void AddToFinalProbabilitiesDictionary(string name, int bits, double value)
        {
            Dictionary<int, double> dictionaryBitsDouble;
            if (FinalProbabilitiesDictionary.TryGetValue(name, out dictionaryBitsDouble))
            {
                dictionaryBitsDouble[bits] = value;
            }
            else
            {
                dictionaryBitsDouble = new Dictionary<int, double>();
                dictionaryBitsDouble[bits] = value;
                FinalProbabilitiesDictionary[name] = dictionaryBitsDouble;
            }
        }

        //private bool ReadFromFinalProbabilitiesDictionary(string name, int bits, out double value)
        //{
        //    value = 0;
        //    Dictionary<int, double> dictionaryBitsDouble;

        //    if (FinalProbabilitiesDictionary.TryGetValue(name, out dictionaryBitsDouble))
        //    {
        //        if (dictionaryBitsDouble.TryGetValue(bits, out value))
        //        {
        //            return true;
        //        }
        //        else
        //        {
        //            return false;
        //        }
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}

        #endregion

        #endregion

        #region FinalProbabilityAnalysis (Step By Step After Each Round)

        private string _finalProbabilityAnalysis;

        public string FinalProbabilityAnalysis
        {
            get { return _finalProbabilityAnalysis; }
            set
            {
                _finalProbabilityAnalysis = value;
                WriteToFile("FPA", value, GetFinalResultsSubdirectoryPath(), csv: true);
            }
        }

        private void AddToFinalProbabilityAnalysis(string bits, ProbabilityAnalysisStatisticalResultHolder resultsHolder)
        {
            if (string.IsNullOrEmpty(FinalProbabilityAnalysis))
            {
                var csvRowHeader = "sep=,\n";
                AddToCSVRow(ref csvRowHeader, "Bits");
                AddToCSVRow(ref csvRowHeader, "RMSD");
                AddToCSVRow(ref csvRowHeader, "Average");
                AddToCSVRow(ref csvRowHeader, "StandardDeviation");

                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.499, 0.50]");
                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.498, 0.50]");
                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.497, 0.50]");
                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.496, 0.50]");
                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.495, 0.50]");
                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.494, 0.50]");
                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.493, 0.50]");
                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.492, 0.50]");
                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.491, 0.50]");

                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.490, 0.50]");
                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.480, 0.50]");
                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.470, 0.50]");
                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.460, 0.50]");
                AddToCSVRow(ref csvRowHeader, "D(0.5) ~ [0.450, 0.50]");

                AddToCSVRow(ref csvRowHeader, "[0.00, 0.00]");
                AddToCSVRow(ref csvRowHeader, "(0.00, 0.01)");
                AddToCSVRow(ref csvRowHeader, "[0.01 ,0.05)");
                AddToCSVRow(ref csvRowHeader, "[0.05 ,0.10)");
                AddToCSVRow(ref csvRowHeader, "[0.10 ,0.20)");
                AddToCSVRow(ref csvRowHeader, "[0.20 ,0.30)");
                AddToCSVRow(ref csvRowHeader, "[0.30 ,0.40)");
                AddToCSVRow(ref csvRowHeader, "[0.40 ,0.50)");
                AddToCSVRow(ref csvRowHeader, "[0.50 ,0.60)");
                AddToCSVRow(ref csvRowHeader, "[0.60 ,0.70)");
                AddToCSVRow(ref csvRowHeader, "[0.70 ,0.80)");
                AddToCSVRow(ref csvRowHeader, "[0.80 ,0.90)");
                AddToCSVRow(ref csvRowHeader, "[0.90 ,0.95)");
                AddToCSVRow(ref csvRowHeader, "[0.95 ,0.99)");
                AddToCSVRow(ref csvRowHeader, "[0.99 ,1.00)");
                AddToCSVRow(ref csvRowHeader, "[1.00, 1.00]");

                FinalProbabilityAnalysis += csvRowHeader + "\n";
            }

            var csvRowData = "";
            AddToCSVRow(ref csvRowData, bits); //Bits
            AddToCSVRow(ref csvRowData, resultsHolder.RMSD.ToString()); //RMSD
            AddToCSVRow(ref csvRowData, resultsHolder.Average.ToString()); //Average
            AddToCSVRow(ref csvRowData, resultsHolder.StandardDeviation.ToString()); //StandardDeviation

            AddToCSVRow(ref csvRowData, resultsHolder.d49950.ToString());   //"D(0.5) ~ [0.499, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d49850.ToString());   //"D(0.5) ~ [0.498, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d49750.ToString());   //"D(0.5) ~ [0.497, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d49650.ToString());   //"D(0.5) ~ [0.496, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d49550.ToString());   //"D(0.5) ~ [0.495, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d49450.ToString());   //"D(0.5) ~ [0.494, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d49350.ToString());   //"D(0.5) ~ [0.493, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d49250.ToString());   //"D(0.5) ~ [0.492, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d49150.ToString());   //"D(0.5) ~ [0.491, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d4950.ToString());    //"D(0.5) ~ [0.490, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d4850.ToString());    //"D(0.5) ~ [0.480, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d4750.ToString());    //"D(0.5) ~ [0.470, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d4650.ToString());    //"D(0.5) ~ [0.460, 0.50]"
            AddToCSVRow(ref csvRowData, resultsHolder.d4550.ToString());    //"D(0.5) ~ [0.450, 0.50]"

            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary0.ToString()); //"[0.00, 0.00]"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary0_01.ToString()); //"(0.00, 0.01)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary01_05.ToString()); //"[0.01 ,0.05)
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary05_1.ToString()); //"[0.05 ,0.10)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary1_2.ToString()); //"[0.10 ,0.20)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary2_3.ToString()); //"[0.20 ,0.30)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary3_4.ToString()); //"[0.30 ,0.40)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary4_5.ToString()); //"[0.40 ,0.50)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary5_6.ToString()); //"[0.50 ,0.60)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary6_7.ToString()); //"[0.60 ,0.70)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary7_8.ToString()); //"[0.70 ,0.80)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary8_9.ToString()); //"[0.80 ,0.90)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary9_95.ToString()); //"[0.90 ,0.95)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary95_99.ToString()); //"[0.95 ,0.99)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary99_1.ToString()); //"[0.99 ,1.00)"
            AddToCSVRow(ref csvRowData, resultsHolder.netsInBoundary1.ToString()); //"[1.00, 1.00]"

            FinalProbabilityAnalysis += csvRowData + "\n";
        }

        #endregion

        #endregion

        //-------------------------------------------------------------------------------

        #region PowerAreaDelay

        public bool GenerateVerilogAfterRound;

        #region UserPowerAfterRound

        private string _userPowerAfterRound; //

        private string UserPowerAfterRound
        {
            get { return _userPowerAfterRound; }
            set
            {
                _userPowerAfterRound = value;
                WriteToFile("UserPowerAfter" + " " + _roundsCount + " Bits", value, path: GetRoundSubdirectoryPath(_roundsCount));
            }
        }

        #endregion

        #region PowerAfterRound

        private string _powerAfterRound; //

        private string PowerAfterRound
        {
            get { return _powerAfterRound; }
            set
            {
                _powerAfterRound = value;
                WriteToFile("PowerAfter" + " " + _roundsCount + " Bits", value, path: GetRoundSubdirectoryPath(_roundsCount));
            }
        }

        #endregion

        #region AreaAfterRound

        private string _AreaAfterRound; //

        private string AreaAfterRound
        {
            get { return _AreaAfterRound; }
            set
            {
                _AreaAfterRound = value;
                WriteToFile("AreaAfter" + " " + _roundsCount + " Bits", value, path: GetRoundSubdirectoryPath(_roundsCount));
            }
        }

        #endregion

        #region DelayAfterRound

        private string _DelayAfterRound; //

        private string DelayAfterRound
        {
            get { return _DelayAfterRound; }
            set
            {
                _DelayAfterRound = value;
                WriteToFile("DelayAfter" + " " + _roundsCount + " Bits", value, path: GetRoundSubdirectoryPath(_roundsCount));
            }
        }

        #endregion


        #region FinalUserPowerAnalysis (Step By Step After Each Round)

        private string _finalUserPowerAnalysis;

        public string FinalUserPowerAnalysis
        {
            get { return _finalUserPowerAnalysis; }
            set
            {
                _finalUserPowerAnalysis = value;
                WriteToFile("FUPowA", value, GetFinalResultsSubdirectoryPath(), csv: true);
            }
        }

        private double _round0UserPower;
        private void AddToFinalUserPowerAnalysis(string bits, double UserpowerOfRound)
        {
            if (bits == "0")
                _round0UserPower = UserpowerOfRound;

            if (string.IsNullOrEmpty(FinalUserPowerAnalysis))
            {
                var csvRowHeader = "sep=,\n";
                SimulationReporter.AddToCSVRow(ref csvRowHeader, "Bits");
                SimulationReporter.AddToCSVRow(ref csvRowHeader, "UserPower");
                SimulationReporter.AddToCSVRow(ref csvRowHeader, "Ratio");
                FinalUserPowerAnalysis += csvRowHeader + "\n";
            }

            var csvRowData = "";
            SimulationReporter.AddToCSVRow(ref csvRowData, bits); //Bits
            SimulationReporter.AddToCSVRow(ref csvRowData, UserpowerOfRound.ToString()); //Bits
            SimulationReporter.AddToCSVRow(ref csvRowData, (UserpowerOfRound / _round0UserPower).ToString()); //Bits

            FinalUserPowerAnalysis += csvRowData + "\n";
        }

        #endregion

        #region FinalPowerAnalysis (Step By Step After Each Round)

        private string _finalPowerAnalysis;

        public string FinalPowerAnalysis
        {
            get { return _finalPowerAnalysis; }
            set
            {
                _finalPowerAnalysis = value;
                WriteToFile("FPowA", value, GetFinalResultsSubdirectoryPath(), csv: true);
            }
        }

        private double _round0Power;
        private void AddToFinalPowerAnalysis(string bits, double powerOfRound)
        {
            if (bits == "0")
                _round0Power = powerOfRound;

            if (string.IsNullOrEmpty(FinalPowerAnalysis))
            {
                var csvRowHeader = "sep=,\n";
                AddToCSVRow(ref csvRowHeader, "Bits");
                AddToCSVRow(ref csvRowHeader, "Power");
                AddToCSVRow(ref csvRowHeader, "Ratio");
                FinalPowerAnalysis += csvRowHeader + "\n";
            }

            var csvRowData = "";
            AddToCSVRow(ref csvRowData, bits); //Bits
            AddToCSVRow(ref csvRowData, powerOfRound.ToString()); //Bits
            AddToCSVRow(ref csvRowData, (powerOfRound / _round0Power).ToString()); //Bits

            FinalPowerAnalysis += csvRowData + "\n";
        }

        #endregion

        #region FinalAreaAnalysis (Step By Step After Each Round)

        private string _finalAreaAnalysis;

        public string FinalAreaAnalysis
        {
            get { return _finalAreaAnalysis; }
            set
            {
                _finalAreaAnalysis = value;
                WriteToFile("FAreaA", value, GetFinalResultsSubdirectoryPath(), csv: true);
            }
        }

        private double _round0Area;
        private void AddToFinalAreaAnalysis(string bits, double AreaOfRound)
        {
            if (bits == "0")
                _round0Area = AreaOfRound;

            if (string.IsNullOrEmpty(FinalAreaAnalysis))
            {
                var csvRowHeader = "sep=,\n";
                AddToCSVRow(ref csvRowHeader, "Bits");
                AddToCSVRow(ref csvRowHeader, "Area");
                AddToCSVRow(ref csvRowHeader, "Ratio");
                FinalAreaAnalysis += csvRowHeader + "\n";
            }

            var csvRowData = "";
            AddToCSVRow(ref csvRowData, bits); //Bits
            AddToCSVRow(ref csvRowData, AreaOfRound.ToString()); //Bits
            AddToCSVRow(ref csvRowData, (AreaOfRound / _round0Area).ToString()); //Bits

            FinalAreaAnalysis += csvRowData + "\n";
        }

        #endregion

        #region FinalDelayAnalysis (Step By Step After Each Round)

        private string _finalDelayAnalysis;

        public string FinalDelayAnalysis
        {
            get { return _finalDelayAnalysis; }
            set
            {
                _finalDelayAnalysis = value;
                WriteToFile("FDelayA", value, GetFinalResultsSubdirectoryPath(), csv: true);
            }
        }

        private double _round0Delay;
        private void AddToFinalDelayAnalysis(string bits, double DelayOfRound)
        {
            if (bits == "0")
                _round0Delay = DelayOfRound;

            if (string.IsNullOrEmpty(FinalDelayAnalysis))
            {
                var csvRowHeader = "sep=,\n";
                AddToCSVRow(ref csvRowHeader, "Bits");
                AddToCSVRow(ref csvRowHeader, "Delay");
                AddToCSVRow(ref csvRowHeader, "Ratio");
                FinalDelayAnalysis += csvRowHeader + "\n";
            }

            var csvRowData = "";
            AddToCSVRow(ref csvRowData, bits); //Bits
            AddToCSVRow(ref csvRowData, DelayOfRound.ToString()); //Bits
            AddToCSVRow(ref csvRowData, (DelayOfRound / _round0Delay).ToString()); //Bits

            FinalDelayAnalysis += csvRowData + "\n";
        }

        #endregion

        #endregion

        //-------------------------------------------------------------------------------

        #region SlackTimes Region

        private string GenerateSlackTimesCsvReport(List<Net> nets)
        {
            var sortedNets = new List<Net>(nets);
            sortedNets.Sort((net1, net2) => Math.Sign(net1.SlackTime.Value - net2.SlackTime.Value));

            var slackTimesCSVReport = "";

            var csvRow = "sep=,\n";
            AddToCSVRow(ref csvRow, "Name");
            AddToCSVRow(ref csvRow, "ASAP");
            AddToCSVRow(ref csvRow, "ALAP");
            AddToCSVRow(ref csvRow, "SlackTimes");
            AddToCSVRow(ref csvRow, "Level");
            slackTimesCSVReport += csvRow + "\n";

            foreach (var net in sortedNets)
            {
                var csvRowData = "";
                AddToCSVRow(ref csvRowData, net.Name);
                AddToCSVRow(ref csvRowData, net.ASAP.ToString());
                AddToCSVRow(ref csvRowData, net.ALAP.ToString());
                AddToCSVRow(ref csvRowData, net.SlackTime.ToString());
                AddToCSVRow(ref csvRowData, net.LevelNumberInLogicSimulation.ToString());
                slackTimesCSVReport += csvRowData + "\n";
            }
            return slackTimesCSVReport;
        }


        #region SlackTimesBeforeEncryption

        private string _slackTimesBeforeEncryption; //
        public string SlackTimesBeforeEncryption
        {
            get { return _slackTimesBeforeEncryption; }
            set
            {
                _slackTimesBeforeEncryption = value;
                WriteToFile("SlackTimesBefore", value, path: GetBeforeEncryptionSubdirectoryPath(), csv: true);
            }
        }

        private void GenerateSlackTimesReportBeforeEncryption(List<Net> nets, bool forceCalculate)
        {
            if (ReportSlackTimesAndLevelizationsBefore)
            {
                AddToConsoleLog("Computing slack times before encryption started...");

                string loadReport;
                int maxLevel;
                ASAPALAPSlackTime.LoadOrCalculateASAPALAPSlackTimeOfNets(
                    nets: nets, 
                    maxLevel: out maxLevel, 
                    netlistName: _netlistNamePure,
                    loadReport: out loadReport,
                    forceCalculate: forceCalculate, 
                    allowSaveResults: true);

                SlackTimesBeforeEncryption = GenerateSlackTimesCsvReport(nets);
                AddToConsoleLog(loadReport);
                AddToConsoleLog("Computing slack times before encryption ended");
            }
        }


        #endregion

        #region SlackTimesAfterRound

        private string _slackTimesAfterRound; //

        public string SlackTimesAfterRound
        {
            get { return _slackTimesAfterRound; }
            set
            {
                _slackTimesAfterRound = value;
                WriteToFile("SlackTimesAfter", value, path: GetRoundSubdirectoryPath(_roundsCount), csv: true);
            }
        }

        private void GenerateSlackTimesReportAfterRound(List<Net> nets, bool forceCalculate)
        {
            if (ReportSlackTimesAndLevelizationsAfterRound)
            {
                AddToConsoleLog("Computing slack times after round " + _roundsCount + " started...");

                string loadReport;
                int maxLevel;
                ASAPALAPSlackTime.LoadOrCalculateASAPALAPSlackTimeOfNets(
                    nets: nets, 
                    maxLevel: out maxLevel, 
                    netlistName: _netlistNamePure,
                    loadReport: out loadReport,
                    forceCalculate: forceCalculate, 
                    allowSaveResults: true /*false*/);

                SlackTimesAfterRound = GenerateSlackTimesCsvReport(nets);

                AddToConsoleLog(loadReport);
                AddToConsoleLog("Computing slack times after round " + _roundsCount + " ended");
            }
        }

        #endregion

        #endregion

        //-------------------------------------------------------------------------------

        #region Checkings Region

        public class CheckingsInputData
        {
            public int randomPatternsCount;
            public bool uniqueRandomPatterns;
            public bool GenerateFanout;
            public bool UseRandomSeeds;
            public bool ForceWrongInputs;

            public int RandomSeed;
            public int ClockTimes;
        }

        public CheckingsInputData CheckingsInputDataObject = new CheckingsInputData();

        #region IntegrityReportAfterEncryption

        private string _integrityReportAfterEncryption; //
        public string IntegrityReportAfterEncryption
        {
            get { return _integrityReportAfterEncryption; }
            set
            {
                _integrityReportAfterEncryption = value;
                WriteToFile("IntegrityReport", value, path: GetFinalResultsSubdirectoryPath());
            }
        }

        private void GenerateIntegrityReportAfterEncryption()
        {
            if (ReportIntegrityOfEncryption)
            {
                AddToConsoleLog("Checking integrity of generated netlist started...");

                if (CheckingsInputDataObject.UseRandomSeeds)
                {
                    CheckingsInputDataObject.RandomSeed = DateTime.Now.Millisecond;
                }

                var checkingDetails = "randomPatterns:\t" + CheckingsInputDataObject.randomPatternsCount + "\r\n" +
                                      "uniqueRandom:\t" + CheckingsInputDataObject.uniqueRandomPatterns + "\r\n" +
                                      "randomSeed:\t" + CheckingsInputDataObject.RandomSeed + "\r\n" +
                                      "key:\t" + DecryptionKeyOfRound + "\r\n";

                List<Net> outputNets;
                var encryptedNets = Parser.CreateNets(input: GeneratedNetlistAfterRound,
                    generateFanouts: CheckingsInputDataObject.GenerateFanout, outputNets: out outputNets);
                if (encryptedNets.Count == 0)
                {
                    AddToConsoleLog("Error - No nets in encrypted netlist");
                }

                List<Net> outputNetsNormal;
                var normalNets = Parser.CreateNets(input: OriginalNetlistBeforeEncryption,
                    generateFanouts: CheckingsInputDataObject.GenerateFanout, outputNets: out outputNetsNormal);
                if (normalNets.Count == 0)
                {
                    AddToConsoleLog("Error - No nets in normal netlist");
                }

                var integrityReport = EncryptionChecker.CheckIntegrity(
                    encryptedNets: encryptedNets,
                    normalNets: normalNets,
                    uniqueRandomPatterns: CheckingsInputDataObject.uniqueRandomPatterns,
                    randomPatterns: CheckingsInputDataObject.randomPatternsCount,
                    randomSeed: CheckingsInputDataObject.RandomSeed,
                    key: DecryptionKeyOfRound,
                    clockTimes: CheckingsInputDataObject.ClockTimes);

                IntegrityReportAfterEncryption = integrityReport;

                EncryptionDetails += "Integrity Report:\t" + integrityReport + "\r\n" + checkingDetails;
                AddToConsoleLog("Integrity Report:\t" + integrityReport);

                AddToConsoleLog("Checking integrity of generated netlist ended");
            }
        }

        #endregion

        #region HammingDistanceReportAfterRound

        private void GenerateHammigDistanceAndGatesAnalysisReportAfterRound()
        {
            if (ReportHammingDistanceAfterRound)
            {
                AddToConsoleLog("Checking hamming distance of generated netlist after round " + _roundsCount +
                                " started...");

                if (CheckingsInputDataObject.UseRandomSeeds)
                {
                    CheckingsInputDataObject.RandomSeed = DateTime.Now.Millisecond;
                }

                var checkingDetails = "randomPatterns:\t" + CheckingsInputDataObject.randomPatternsCount + "\r\n" +
                                      "uniqueRandom:\t" + CheckingsInputDataObject.uniqueRandomPatterns + "\r\n" +
                                      "randomSeed:\t" + CheckingsInputDataObject.RandomSeed + "\r\n" +
                                      "forceWrongInputs:\t" + CheckingsInputDataObject.ForceWrongInputs + "\r\n" +
                                      "key:\t" + DecryptionKeyOfRound + "\r\n";

                List<Net> outputNets;
                var encryptedNets = Parser.CreateNets(input: GeneratedNetlistAfterRound,
                    generateFanouts: CheckingsInputDataObject.GenerateFanout, outputNets: out outputNets);
                if (encryptedNets.Count == 0)
                {
                    AddToConsoleLog("Error - No nets in encrypted netlist");
                }

                string statisticalReport;
                EncryptionChecker.HammingDistanceStatisticalResultHolder hammingDistanceAnalysisResultsHolder;
                var hammingDistanceReport = EncryptionChecker.CalculateHammingDistanceOfEncryptedNetlist(
                    encryptedNetList: encryptedNets,
                    uniqueRandomPatterns: CheckingsInputDataObject.uniqueRandomPatterns,
                    randomPatterns: CheckingsInputDataObject.randomPatternsCount,
                    randomSeed: CheckingsInputDataObject.RandomSeed,
                    forceWrongInputs: CheckingsInputDataObject.ForceWrongInputs,
                    key: DecryptionKeyOfRound,
                    clockTimes: CheckingsInputDataObject.ClockTimes,
                    statisticalReport: out statisticalReport,
                    resultsHolder: out hammingDistanceAnalysisResultsHolder);

                GatesAnalysisStatisticalResultsHolder gatesAnalysisResultsHolder;
                var encryptionGatesAnalysisResult =
                    GatesAnalyzer.AnalyzeEncryptedNetlistGates(generatedNetlistString: GeneratedNetlistAfterRound,
                        generatedKey: DecryptionKeyOfRound, generateFanouts: CheckingsInputDataObject.GenerateFanout,
                        resultsHolder: out gatesAnalysisResultsHolder);


                HammingDistanceReportAfterRound = hammingDistanceReport + "\r\n" + checkingDetails + "\r\n" +
                                                  encryptionGatesAnalysisResult;
                AddToConsoleLog("Hamming Distance Report :\r\n\r\n" + hammingDistanceReport);

                AddToFinalHammingDistanceAndGatesAnalysis(roundIndex: _roundsCount,
                    hDResultHolder: hammingDistanceAnalysisResultsHolder, gResultsHolder: gatesAnalysisResultsHolder);

                AddToConsoleLog("Checking hamming distance of generated netlist after round " + _roundsCount + " ended");
            }
        }

        #endregion

        #region HammingDistance&GatesAnalysisAfterRound

        private string _hammingDistanceReportAfterRound; //

        public string HammingDistanceReportAfterRound
        {
            get { return _hammingDistanceReportAfterRound; }
            set
            {
                _hammingDistanceReportAfterRound = value;
                WriteToFile("HammingDistanceReport", value, path: GetRoundSubdirectoryPath(_roundsCount));
            }
        }

        #endregion

        #region FinalHammingDistanceAnalysis (Step By Step After Each Round)
        private string _finalHammingAndGatesDistanceAnalysis;
        public string FinalHammingAndGatesDistanceAnalysis
        {
            get { return _finalHammingAndGatesDistanceAnalysis; }
            set
            {
                _finalHammingAndGatesDistanceAnalysis = value;
                WriteToFile("FHA", value, GetFinalResultsSubdirectoryPath(), csv: true);
            }
        }

        private void AddToFinalHammingDistanceAndGatesAnalysis(int roundIndex, EncryptionChecker.HammingDistanceStatisticalResultHolder hDResultHolder, GatesAnalysisStatisticalResultsHolder gResultsHolder)
        {
            if (string.IsNullOrEmpty(FinalHammingAndGatesDistanceAnalysis))
            {
                var csvRowHeader = "sep=,\n";
                AddToCSVRow(ref csvRowHeader, "Bits");

                AddToCSVRow(ref csvRowHeader, "HammingDistance(%)");
                AddToCSVRow(ref csvRowHeader, "RMSD");
                AddToCSVRow(ref csvRowHeader, "Average");
                AddToCSVRow(ref csvRowHeader, "StandardDeviation");
                AddToCSVRow(ref csvRowHeader, "xRatio(%)");


                AddToCSVRow(ref csvRowHeader, "All Gates");

                AddToCSVRow(ref csvRowHeader, "Total Added Gates");

                AddToCSVRow(ref csvRowHeader, "Total Added Gates (Except Inverters)");

                AddToCSVRow(ref csvRowHeader, "In Output Key Gates");
                AddToCSVRow(ref csvRowHeader, "Not In Output Key Gates");

                AddToCSVRow(ref csvRowHeader, "XOR Gates");
                AddToCSVRow(ref csvRowHeader, "XOR Key Gates");

                AddToCSVRow(ref csvRowHeader, "XNOR Gates");
                AddToCSVRow(ref csvRowHeader, "XNOR Key Gates");

                AddToCSVRow(ref csvRowHeader, "INVERTER Gates");
                AddToCSVRow(ref csvRowHeader, "INVERTER Key Gates");

                AddToCSVRow(ref csvRowHeader, "AND Gates");
                AddToCSVRow(ref csvRowHeader, "And Key Gates");

                AddToCSVRow(ref csvRowHeader, "OR Gates");
                AddToCSVRow(ref csvRowHeader, "OR Key Gates");

                AddToCSVRow(ref csvRowHeader, "NAND Gates");
                AddToCSVRow(ref csvRowHeader, "NAND Key Gates");

                AddToCSVRow(ref csvRowHeader, "NOR Gates");
                AddToCSVRow(ref csvRowHeader, "NOR Key Gates");

                AddToCSVRow(ref csvRowHeader, "BUFFER Gates");
                AddToCSVRow(ref csvRowHeader, "FLIPFLOP Gates");

                FinalHammingAndGatesDistanceAnalysis += csvRowHeader + "\n";
            }

            var csvRowData = "";
            AddToCSVRow(ref csvRowData, roundIndex.ToString());                         //Bits
            AddToCSVRow(ref csvRowData, hDResultHolder.HammingDistancePercent + "%");   //RHammingDistance(%)

            AddToCSVRow(ref csvRowData, hDResultHolder.RMSD.ToString());                //RMSD
            AddToCSVRow(ref csvRowData, hDResultHolder.Average.ToString());             //Average
            AddToCSVRow(ref csvRowData, hDResultHolder.StandardDeviation.ToString());   //StandardDeviation

            AddToCSVRow(ref csvRowData, hDResultHolder.XRatio.ToString() + "%");        //xRatio(%)

            AddToCSVRow(ref csvRowData, gResultsHolder.encryptedNetlistGates.ToString());//"All Gates"

            AddToCSVRow(ref csvRowData, gResultsHolder.totalAddedGates.ToString());      //"Total Added Gates"

            AddToCSVRow(ref csvRowData, gResultsHolder.totalAddedGatesExceptInverters.ToString()); //"Total Added Gates (Except Inverters)"

            AddToCSVRow(ref csvRowData, gResultsHolder.outputKeyGates.ToString());      //"In Output Key Gates"
            AddToCSVRow(ref csvRowData, gResultsHolder.notOutputKeyGates.ToString());   //"Not In Output Key Gates"

            AddToCSVRow(ref csvRowData, gResultsHolder.xorGates.ToString());            //"XOR Gates"
            AddToCSVRow(ref csvRowData, gResultsHolder.xorKeyGates.ToString());         //"XOR Key Gates"

            AddToCSVRow(ref csvRowData, gResultsHolder.xnorGates.ToString());           //"XNOR Gatess"
            AddToCSVRow(ref csvRowData, gResultsHolder.xnorKeyGates.ToString());        //"XNOR Key Gates"

            AddToCSVRow(ref csvRowData, gResultsHolder.inverters.ToString());           //"INVERTER Gates"
            AddToCSVRow(ref csvRowData, gResultsHolder.invertersKey.ToString());        //"INVERTER Key Gates"

            AddToCSVRow(ref csvRowData, gResultsHolder.andGates.ToString());            //"AND Gates"
            AddToCSVRow(ref csvRowData, gResultsHolder.andKeyGates.ToString());         //"And Key Gates"

            AddToCSVRow(ref csvRowData, gResultsHolder.orGates.ToString());             //"OR Gates"
            AddToCSVRow(ref csvRowData, gResultsHolder.orKeyGates.ToString());          //"OR Key Gates"

            AddToCSVRow(ref csvRowData, gResultsHolder.nandGates.ToString());           //"NAND Gates"
            AddToCSVRow(ref csvRowData, gResultsHolder.nandKeyGates.ToString());        //"NAND Key Gates"

            AddToCSVRow(ref csvRowData, gResultsHolder.norGates.ToString());            //"NOR Gates"
            AddToCSVRow(ref csvRowData, gResultsHolder.norKeyGates.ToString());         //"NOR Key Gates"

            AddToCSVRow(ref csvRowData, gResultsHolder.buffersNormal.ToString());       //"BUFFER Gates"
            AddToCSVRow(ref csvRowData, gResultsHolder.flipFlopsNormal.ToString());     //"FLIPFLOP Gates"

            FinalHammingAndGatesDistanceAnalysis += csvRowData + "\n";
        }

        #endregion

        #endregion

        //-------------------------------------------------------------------------------

        #region MainMethods Region

        public void Step01CreateBeforeEncryptionReport(List<Net> nets, string originalNetlist, bool forceCalculate)
        {
            _simulatorStopwatch.Reset();
            _simulatorStopwatch.Start();

            OriginalNetlistBeforeEncryption = originalNetlist;
            _roundsCount = 0;

            //-------------------------------------------------------------------------------

            GenerateProbabilityAnalysisBeforeEncryption(nets, forceCalculate);

            GenerateSlackTimesReportBeforeEncryption(nets, forceCalculate);
        }

        public void Step02FinishRound(List<Net> nets, string addedKeyValues, bool forceCalculate)
        {
            if (SamimiIO.Exiting)
                return;

            _roundsCount = addedKeyValues.Length;

            //-------------------------------------------------------------------------------
            //در راند صفرم با توجه به اینکه درست در لحظه قبل 
            //احتمالات و اسلک تایم ها (در صورت نیاز) حساب شده بوده اند، می توان استثنائا از کش خواند
            //ولی در باقی راند ها، الزاما هربار باید از نو محاسبه شوند
            //const bool forceCalculateThisRound = false;
            //if (string.IsNullOrEmpty(addedKeyValues))
            //    forceCalculateThisRound = false;
            //-------------------------------------------------------------------------------
            AddToConsoleLog("Gate insertion of round " + _roundsCount + " ended");

            GenerateEncryptedNetlistAfterRound(nets, addedKeyValues);

            GenerateHammigDistanceAndGatesAnalysisReportAfterRound();

            GenerateProbabilityAnalysisAfterRound(nets, forceCalculate);

            GenerateSlackTimesReportAfterRound(nets, forceCalculate);

            GeneratePowerAreaDelayAnalysisReportAfterRound(nets, addedKeyValues);


            AddToConsoleLog("Round " + _roundsCount + " Finished");
            AddToConsoleLog("------------------------------------\r\n\r\n");

            //Console.Beep();
        }

        public void Step03CreateAfterEncryptionReport()
        {
            if (SamimiIO.Exiting)
                return;
            
            _simulatorStopwatch.Stop();

            //فرض می شود که نت لیست رمز شده بخاطر آخرین راند قبلا ساخته شده است
            //و کلید نیز برابر با کلید آخرین راند است
            //لذا مجددا نت لیست متنی رمز شده تولید نمی گردد
            GenerateIntegrityReportAfterEncryption();

            WriteFinalWholeProbabilitieReport();

            AddToConsoleLog("Total Simulation Time:\t" + _simulatorStopwatch.Elapsed);
            AddToConsoleLog("The End.");

            var oldName = _directoryPathMain;
            var newName = _directoryPathMain.Substring(0, _directoryPathMain.Length - 1) + " Done";

            SamimiIO.MoveDirectory(oldName, newName);

            Application.DoEvents();
            Console.Beep(100, 100);
            Console.Beep(300, 100);
            Console.Beep(400, 100);
            Console.Beep(500, 100);
            Console.Beep(600, 100);
        }
        #endregion
    }
}
