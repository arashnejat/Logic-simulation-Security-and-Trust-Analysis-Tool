﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicEncryption
{
    public class ProbabilityAnalysisStatisticalResultHolder
    {
        public double RMSD;
        public double Average;
        public double StandardDeviation;

        public double d49950;
        public double d49850;
        public double d49750;
        public double d49650;
        public double d49550;
        public double d49450;
        public double d49350;
        public double d49250;
        public double d49150;

        public double d4950;
        public double d4850;
        public double d4750;
        public double d4650;
        public double d4550;

        public double netsInBoundary0;
        public double netsInBoundary0_01;
        public double netsInBoundary01_05;
        public double netsInBoundary05_1;
        public double netsInBoundary1_2;
        public double netsInBoundary2_3;
        public double netsInBoundary3_4;
        public double netsInBoundary4_5;
        public double netsInBoundary5_6;
        public double netsInBoundary6_7;
        public double netsInBoundary7_8;
        public double netsInBoundary8_9;
        public double netsInBoundary9_95;
        public double netsInBoundary95_99;
        public double netsInBoundary99_1;
        public double netsInBoundary1;
    }

    public class ProbabilityAnalyzer  
    {
        public static string AnalyzeProbabilities(List<Net> nets, out ProbabilityAnalysisStatisticalResultHolder resultsHolder)
        {
            var sortedNets = new List<Net>(nets);
            sortedNets.Sort((net1, net2) => Math.Sign(net1.SimulatedProbability - net2.SimulatedProbability));

            var analysisReport = "";
            resultsHolder = new ProbabilityAnalysisStatisticalResultHolder();
            //===============================================================================================
            //اندازه گیری مقدار انحراف کلیه نت های مدار از یک دوم
            //هرچقدر کوچکتر شود به هدف مورد نظر نزدیکتر شده ایم
            double averageDistanceFromHalf = 0.0;
            foreach (var net in nets)
            {
                averageDistanceFromHalf += Math.Pow(net.SimulatedProbability - 0.5, 2) / nets.Count;
            }
            resultsHolder.RMSD = Math.Pow(averageDistanceFromHalf, 0.5);
            analysisReport += "RMSD (Root Mean Square Deviation From 0.5):\t" + resultsHolder.RMSD + "\r\n";
            //---------------------------------------------------------

            resultsHolder.Average = 0.0;
            foreach (var net in nets)
            {
                resultsHolder.Average += net.SimulatedProbability / nets.Count;
            }
            analysisReport += "Average:\t" + resultsHolder.Average + "\r\n";

            //---------------------------------------------------------
            //اندازه گیری انحراف معیار کلیه نت های مدار از میانگین آنها
            //تنها پراکندگی نت ها را نشان می دهد 
            //و هرچقدر کوچکتر باشد یعنی نت ها به یک مقدار (که همان میانگینشان است) نزدیکترند
            double averageDistanceFromAverage = 0.0;
            foreach (var net in nets)
            {
                averageDistanceFromAverage += Math.Pow(net.SimulatedProbability - resultsHolder.Average, 2) / nets.Count;
            }
            resultsHolder.StandardDeviation = Math.Pow(averageDistanceFromAverage, 0.5);
            analysisReport += "Standard Deviation:\t" + resultsHolder.StandardDeviation + "\r\n";
            analysisReport += "\r\n";
            //===============================================================================================

            var d49950 = AnalyzeThisRareBoundary(sortedNets, 0.499, 0.50);
            var d49850 = AnalyzeThisRareBoundary(sortedNets, 0.498, 0.50);
            var d49750 = AnalyzeThisRareBoundary(sortedNets, 0.497, 0.50);
            var d49650 = AnalyzeThisRareBoundary(sortedNets, 0.496, 0.50);
            var d49550 = AnalyzeThisRareBoundary(sortedNets, 0.495, 0.50);
            var d49450 = AnalyzeThisRareBoundary(sortedNets, 0.494, 0.50);
            var d49350 = AnalyzeThisRareBoundary(sortedNets, 0.493, 0.50);
            var d49250 = AnalyzeThisRareBoundary(sortedNets, 0.492, 0.50);
            var d49150 = AnalyzeThisRareBoundary(sortedNets, 0.491, 0.50);

            var d4950 = AnalyzeThisRareBoundary(sortedNets, 0.49, 0.50);
            var d4850 = AnalyzeThisRareBoundary(sortedNets, 0.48, 0.50);
            var d4750 = AnalyzeThisRareBoundary(sortedNets, 0.47, 0.50);
            var d4650 = AnalyzeThisRareBoundary(sortedNets, 0.46, 0.50);
            var d4550 = AnalyzeThisRareBoundary(sortedNets, 0.45, 0.50);

            var netsInBoundary0     = AnalyzeThisValue(sortedNets, 0.0); // == 0.0
            var netsInBoundary0_01  = AnalyzeThisBoundaryLowerIsNotContained(sortedNets, 0.00, 0.01); // (0.00 ~ 0.01)
            var netsInBoundary01_05 = AnalyzeThisBoundary(sortedNets, 0.01, 0.05); // [0.01 ~ 0.05)
            var netsInBoundary05_1  = AnalyzeThisBoundary(sortedNets, 0.05, 0.10); // [0.05 ~ 0.1)
            var netsInBoundary1_2   = AnalyzeThisBoundary(sortedNets, 0.1, 0.2); // [0.1 ~ 0.2)
            var netsInBoundary2_3   = AnalyzeThisBoundary(sortedNets, 0.2, 0.3); // [0.2 ~ 0.3)
            var netsInBoundary3_4   = AnalyzeThisBoundary(sortedNets, 0.3, 0.4);
            var netsInBoundary4_5   = AnalyzeThisBoundary(sortedNets, 0.4, 0.5);
            var netsInBoundary5_6   = AnalyzeThisBoundary(sortedNets, 0.5, 0.6);
            var netsInBoundary6_7   = AnalyzeThisBoundary(sortedNets, 0.6, 0.7);
            var netsInBoundary7_8   = AnalyzeThisBoundary(sortedNets, 0.7, 0.8);
            var netsInBoundary8_9   = AnalyzeThisBoundary(sortedNets, 0.8, 0.9);
            var netsInBoundary9_95  = AnalyzeThisBoundary(sortedNets, 0.90, 0.95); // [0.90 ~ 0.95)
            var netsInBoundary95_99 = AnalyzeThisBoundary(sortedNets, 0.95, 0.99); // [0.95 ~ 0.99)
            var netsInBoundary99_1  = AnalyzeThisBoundary(sortedNets, 0.99, 1.00); // [0.99 ~ 1.00)
            var netsInBoundary1 = AnalyzeThisValue(sortedNets, 1.0); // == 1.0

            resultsHolder.d49950 = d49950.Count;
            resultsHolder.d49850 = d49850.Count;
            resultsHolder.d49750 = d49750.Count;
            resultsHolder.d49650 = d49650.Count;
            resultsHolder.d49550 = d49550.Count;
            resultsHolder.d49450 = d49450.Count;
            resultsHolder.d49350 = d49350.Count;
            resultsHolder.d49250 = d49250.Count;
            resultsHolder.d49150 = d49150.Count;
            resultsHolder.d4950 = d4950.Count;
            resultsHolder.d4850 = d4850.Count;
            resultsHolder.d4750 = d4750.Count;
            resultsHolder.d4650 = d4650.Count;
            resultsHolder.d4550 = d4550.Count;

            resultsHolder.netsInBoundary0 = netsInBoundary0.Count;
            resultsHolder.netsInBoundary0_01 = netsInBoundary0_01.Count;
            resultsHolder.netsInBoundary01_05 = netsInBoundary01_05.Count;
            resultsHolder.netsInBoundary05_1 = netsInBoundary05_1.Count;
            resultsHolder.netsInBoundary1_2 = netsInBoundary1_2.Count;
            resultsHolder.netsInBoundary2_3 = netsInBoundary2_3.Count;
            resultsHolder.netsInBoundary3_4 = netsInBoundary3_4.Count;
            resultsHolder.netsInBoundary4_5 = netsInBoundary4_5.Count;
            resultsHolder.netsInBoundary5_6 = netsInBoundary5_6.Count;
            resultsHolder.netsInBoundary6_7 = netsInBoundary6_7.Count;
            resultsHolder.netsInBoundary7_8 = netsInBoundary7_8.Count;
            resultsHolder.netsInBoundary8_9 = netsInBoundary8_9.Count;
            resultsHolder.netsInBoundary9_95 = netsInBoundary9_95.Count;
            resultsHolder.netsInBoundary95_99 = netsInBoundary95_99.Count;
            resultsHolder.netsInBoundary99_1 = netsInBoundary99_1.Count;
            resultsHolder.netsInBoundary1 = netsInBoundary1.Count;

            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.499, 0.50]", d49950);
            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.498, 0.50]", d49850);
            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.497, 0.50]", d49750);
            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.496, 0.50]", d49650);
            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.495, 0.50]", d49550);
            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.494, 0.50]", d49450);
            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.493, 0.50]", d49350);
            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.492, 0.50]", d49250);
            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.491, 0.50]", d49150);

            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.49, 0.50]", d4950);
            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.48, 0.50]", d4850);
            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.47, 0.50]", d4750);
            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.46, 0.50]", d4650);
            analysisReport += ReportThisBoundaryCount("D(0.5) ~ [0.45, 0.50]", d4550);

            analysisReport += "\r\n";

            analysisReport += ReportThisBoundaryCount("Exactly 0",    netsInBoundary0);
            analysisReport += ReportThisBoundaryCount("(0.00 ~ 0.01)", netsInBoundary0_01);
            analysisReport += ReportThisBoundaryCount("[0.01 ~ 0.05)", netsInBoundary01_05);
            analysisReport += ReportThisBoundaryCount("[0.05 ~ 0.1)", netsInBoundary05_1);
            analysisReport += ReportThisBoundaryCount("[0.1 ~ 0.2)",  netsInBoundary1_2);
            analysisReport += ReportThisBoundaryCount("[0.2 ~ 0.3)",  netsInBoundary2_3);
            analysisReport += ReportThisBoundaryCount("[0.3 ~ 0.4)",  netsInBoundary3_4);
            analysisReport += ReportThisBoundaryCount("[0.4 ~ 0.5)",  netsInBoundary4_5);
            analysisReport += ReportThisBoundaryCount("[0.5 ~ 0.6)",  netsInBoundary5_6);
            analysisReport += ReportThisBoundaryCount("[0.6 ~ 0.7)",  netsInBoundary6_7);
            analysisReport += ReportThisBoundaryCount("[0.7 ~ 0.8)",  netsInBoundary7_8);
            analysisReport += ReportThisBoundaryCount("[0.8 ~ 0.9)",  netsInBoundary8_9);
            analysisReport += ReportThisBoundaryCount("[0.90 ~ 0.95)", netsInBoundary9_95);
            analysisReport += ReportThisBoundaryCount("[0.95 ~ 0.99)", netsInBoundary95_99);
            analysisReport += ReportThisBoundaryCount("[0.99 ~ 1.00)", netsInBoundary99_1);
            analysisReport += ReportThisBoundaryCount("Exactly 1",    netsInBoundary1);

            analysisReport += "_______________________\r\n";

            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.499, 0.50]", d49950);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.498, 0.50]", d49850);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.497, 0.50]", d49750);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.496, 0.50]", d49650);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.495, 0.50]", d49550);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.494, 0.50]", d49450);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.493, 0.50]", d49350);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.492, 0.50]", d49250);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.491, 0.50]", d49150);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.49, 0.50]", d4950);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.48, 0.50]", d4850);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.47, 0.50]", d4750);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.46, 0.50]", d4650);
            analysisReport += ReportThisBoundaryFull("D(0.5) ~ [0.45, 0.50]", d4550);

            analysisReport += "\r\n";

            analysisReport += ReportThisBoundaryFull("Exactly 0", netsInBoundary0);
            analysisReport += ReportThisBoundaryFull("(0.00 ~ 0.01)", netsInBoundary0_01);
            analysisReport += ReportThisBoundaryFull("[0.01 ~ 0.05)", netsInBoundary01_05);
            analysisReport += ReportThisBoundaryFull("[0.05 ~ 0.1)", netsInBoundary05_1);
            analysisReport += ReportThisBoundaryFull("[0.1 ~ 0.2)", netsInBoundary1_2);
            analysisReport += ReportThisBoundaryFull("[0.2 ~ 0.3)", netsInBoundary2_3);
            analysisReport += ReportThisBoundaryFull("[0.3 ~ 0.4)", netsInBoundary3_4);
            analysisReport += ReportThisBoundaryFull("[0.4 ~ 0.5)", netsInBoundary4_5);
            analysisReport += ReportThisBoundaryFull("[0.5 ~ 0.6)", netsInBoundary5_6);
            analysisReport += ReportThisBoundaryFull("[0.6 ~ 0.7)", netsInBoundary6_7);
            analysisReport += ReportThisBoundaryFull("[0.7 ~ 0.8)", netsInBoundary7_8);
            analysisReport += ReportThisBoundaryFull("[0.8 ~ 0.9)", netsInBoundary8_9);
            analysisReport += ReportThisBoundaryFull("[0.90 ~ 0.95)", netsInBoundary9_95);
            analysisReport += ReportThisBoundaryFull("[0.95 ~ 0.99)", netsInBoundary95_99);
            analysisReport += ReportThisBoundaryFull("[0.99 ~ 1.00)", netsInBoundary99_1);
            analysisReport += ReportThisBoundaryFull("Exactly 1", netsInBoundary1);

            return analysisReport;
        }

        private static string ReportThisBoundaryCount(string title, List<Net> netsInBoundary)
        {
            return title + ":\t" + netsInBoundary.Count + "\r\n";
        }

        private static string ReportThisBoundaryFull(string title, List<Net> netsInBoundary)
        {
            var log = title + ":\r\n";
            foreach (var net in netsInBoundary)
            {
                log += net.Name + ":\t" + net.SimulatedProbability + "\r\n";
            }
            log += "_______________________\r\n";
            return log;
        }

        private static List<Net> AnalyzeThisValue(List<Net> nets, double value)
        {
            var netsInBoundary = new List<Net>();

            foreach (var net in nets)
            {
                if (net.SimulatedProbability == value)
                {
                    netsInBoundary.Add(net);
                }
            }

            return netsInBoundary;
        }

        private static List<Net> AnalyzeThisRareBoundary(List<Net> nets, double lowerBoundary, double upperBoundary)
        {
            var rareNets = new List<Net>();

            foreach (var net in nets)
            {
                var difference = Math.Abs(net.SimulatedProbability - 0.5);

                if (difference >= lowerBoundary && difference <= upperBoundary)
                    rareNets.Add(net);
            }

            return rareNets;
        }

        private static List<Net> AnalyzeThisBoundary(List<Net> nets, double lowerBoundary, double upperBoundary)
        {
            var netsInBoundary = new List<Net>();

            foreach (var net in nets)
            {
                if (net.SimulatedProbability >= lowerBoundary && net.SimulatedProbability < upperBoundary)
                {
                    netsInBoundary.Add(net);
                }
            }

            return netsInBoundary;
        }

        private static List<Net> AnalyzeThisBoundaryLowerIsNotContained(List<Net> nets, double lowerBoundary,
            double upperBoundary)
        {
            var netsInBoundary = new List<Net>();

            foreach (var net in nets)
            {
                if (net.SimulatedProbability > lowerBoundary && net.SimulatedProbability < upperBoundary)
                {
                    netsInBoundary.Add(net);
                }
            }

            return netsInBoundary;
        }
    }

    
}
