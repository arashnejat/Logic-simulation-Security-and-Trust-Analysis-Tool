﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicEncryption
{
    public class GatesAnalysisStatisticalResultsHolder
    {
        public int andGates = 0;
        public int andKeyGates = 0;
        public int andNormalGates = 0;

        public int orGates = 0;
        public int orKeyGates = 0;
        public int orNormalGates = 0;

        public int nandGates = 0;
        public int nandKeyGates = 0;
        public int nandNormalGates = 0;

        public int norGates = 0;
        public int norKeyGates = 0;
        public int norNormalGates = 0;

        public int xorGates = 0;
        public int xorKeyGates = 0;
        public int xorNormalGates = 0;

        public int xnorGates = 0;
        public int xnorKeyGates = 0;
        public int xnorNormalGates = 0;

        public int inverters = 0;
        public int invertersKey = 0;
        public int invertersNormal = 0;

        public int buffersNormal = 0;
        public int flipFlopsNormal = 0;

        public int originalNetlistGates = 0;    //تعداد کل گیت های غیر کلید با تعداد کل گیت های مدار رمز نشده یکی فرض می شود
        public int encryptedNetlistGates = 0;   //تعداد کل گیت های موجود در مدار رمز شده

        public int totalAddedGates = 0;
        public int totalAddedGatesExceptInverters = 0;

        public int outputKeyGates = 0;
        public int notOutputKeyGates = 0;

    }
    public class GatesAnalyzer
    {
        public static string AnalyzeEncryptedNetlistGates(string generatedNetlistString, string generatedKey, bool generateFanouts, out GatesAnalysisStatisticalResultsHolder resultsHolder)
        {
            List<Net> outputNets;
            var encryptedNetlist = Parser.CreateNets(generatedNetlistString, generateFanouts, out outputNets);
            resultsHolder = new GatesAnalysisStatisticalResultsHolder();

            foreach (var net in encryptedNetlist)
            {
                if (!(net is GateEqual) && !(net.IsPrimaryInput))
                    resultsHolder.encryptedNetlistGates++;

                if (net.NextNets.Count == 0 || net.IsPrimaryOutput)
                {
                    if (SMSSKeyManager.IsSMSKeyNet(net.Name))
                    {
                        resultsHolder.outputKeyGates++;
                    }
                }

                if (net is GateAnd)
                {
                    resultsHolder.andGates++;
                    if (SMSSKeyManager.IsSMSKeyNet(net.Name))
                    {
                        resultsHolder.andKeyGates++;
                        resultsHolder.totalAddedGates++;
                    }
                    else
                    {
                        resultsHolder.andNormalGates++;
                    }
                }
                else if (net is GateOr)
                {
                    resultsHolder.orGates++;
                    if (SMSSKeyManager.IsSMSKeyNet(net.Name))
                    {
                        resultsHolder.orKeyGates++;
                        resultsHolder.totalAddedGates++;
                    }
                    else
                    {
                        resultsHolder.orNormalGates++;
                    }
                }
                else if (net is GateNand)
                {
                    resultsHolder.nandGates++;
                    if (SMSSKeyManager.IsSMSKeyNet(net.Name))
                    {
                        resultsHolder.nandKeyGates++;
                        resultsHolder.totalAddedGates++;
                    }
                    else
                    {
                        resultsHolder.nandNormalGates++;
                    }
                }
                else if (net is GateNor)
                {
                    resultsHolder.norGates++;
                    if (SMSSKeyManager.IsSMSKeyNet(net.Name))
                    {
                        resultsHolder.norKeyGates++;
                        resultsHolder.totalAddedGates++;
                    }
                    else
                    {
                        resultsHolder.norNormalGates++;
                    }
                }
                else if (net is GateXor)
                {
                    resultsHolder.xorGates++;
                    if (SMSSKeyManager.IsSMSKeyNet(net.Name))
                    {
                        resultsHolder.xorKeyGates++;
                        resultsHolder.totalAddedGates++;
                    }
                    else
                    {
                        resultsHolder.xorNormalGates++;
                    }
                }
                else if (net is GateXnor)
                {
                    resultsHolder.xnorGates++;
                    if (SMSSKeyManager.IsSMSKeyNet(net.Name))
                    {
                        resultsHolder.xnorKeyGates++;
                        resultsHolder.totalAddedGates++;
                    }
                    else
                    {
                        resultsHolder.xnorNormalGates++;
                    }
                }
                else if (net is GateNot)
                {
                    resultsHolder.inverters++;
                    if (SMSSKeyManager.IsSMSKeyNet(net.Name))
                    {
                        resultsHolder.invertersKey++;
                        resultsHolder.totalAddedGates++;
                    }
                    else
                    {
                        resultsHolder.invertersNormal++;
                    }
                }
                else if (net is GateBuffer)
                {
                    resultsHolder.buffersNormal++;
                }
                else if (net is FlipFlop)
                {
                    resultsHolder.flipFlopsNormal++;
                }
            }

            resultsHolder.originalNetlistGates = resultsHolder.encryptedNetlistGates - resultsHolder.totalAddedGates;
            resultsHolder.totalAddedGatesExceptInverters = resultsHolder.totalAddedGates - resultsHolder.invertersKey;
            resultsHolder.notOutputKeyGates = resultsHolder.totalAddedGatesExceptInverters - resultsHolder.outputKeyGates;
            //---------------------------------------------------------------------------
            var report = "Generated Key\t" + generatedKey + "\r\n";
            report += "Generated Key Length\t" + generatedKey.Length + "\r\n";

            report += "\r\n";

            report += "Original Netlist Gates\t" + (resultsHolder.originalNetlistGates) + "\r\n";
            report += "Total Added Gates (Except Inverters)\t" + (resultsHolder.totalAddedGatesExceptInverters) + "\r\n";
            report += "Total Added Gates\t" + (resultsHolder.totalAddedGates) + "\r\n";
            report += "Encrypted Netlist Gates\t" + (resultsHolder.encryptedNetlistGates) + "\r\n";
            report += "Key Gates In Outputs\t" + (resultsHolder.outputKeyGates) + "\r\n";
            report += "Key Gates Not In Outputs\t" + (resultsHolder.notOutputKeyGates) + "\r\n";


            report += "\r\n";

            report += "Total AND Gates\t" + resultsHolder.andGates + "\r\n";
            report += "AND Key Gates\t" + resultsHolder.andKeyGates + "\r\n";
            report += "AND Old Gates\t" + resultsHolder.andNormalGates + "\r\n";

            report += "\r\n";

            report += "Total OR Gates\t" + resultsHolder.orGates + "\r\n";
            report += "OR Key Gates\t" + resultsHolder.orKeyGates + "\r\n";
            report += "OR Old Gates\t" + resultsHolder.orNormalGates + "\r\n";

            report += "\r\n";

            report += "Total NAND Gates\t" + resultsHolder.nandGates + "\r\n";
            report += "NAND Key Gates\t" + resultsHolder.nandKeyGates + "\r\n";
            report += "NAND Old Gates\t" + resultsHolder.nandNormalGates + "\r\n";

            report += "\r\n";

            report += "Total NOR Gates\t" + resultsHolder.norGates + "\r\n";
            report += "NOR Key Gates\t" + resultsHolder.norKeyGates + "\r\n";
            report += "NOR Old Gates\t" + resultsHolder.norNormalGates + "\r\n";

            report += "\r\n";

            report += "Total XOR Gates\t" + resultsHolder.xorGates + "\r\n";
            report += "XOR Key Gates\t" + resultsHolder.xorKeyGates + "\r\n";
            report += "XOR Old Gates\t" + resultsHolder.xorNormalGates + "\r\n";

            report += "\r\n";

            report += "Total XNOR Gates\t" + resultsHolder.xnorGates + "\r\n";
            report += "XNOR Key Gates\t" + resultsHolder.xnorKeyGates + "\r\n";
            report += "XNOR Old Gates\t" + resultsHolder.xnorNormalGates + "\r\n";

            report += "\r\n";

            report += "Total Inverter Gates\t" + resultsHolder.inverters + "\r\n";
            report += "Inverter Key Gates\t" + resultsHolder.invertersKey + "\r\n";
            report += "Inverter Old Gates\t" + resultsHolder.invertersNormal + "\r\n";

            report += "\r\n";

            report += "Total BUFFER Gates\t" + (resultsHolder.buffersNormal) + "\r\n";
            report += "Total FlipFlop Gates\t" + (resultsHolder.flipFlopsNormal) + "\r\n";

            return report;
        }
    }
}
