﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public class CacheManager
    {
        private static byte[] GetHash(string inputString)
        {
            HashAlgorithm algorithm = MD5.Create();  //or use SHA1.Create();
            return algorithm.ComputeHash(Encoding.UTF8.GetBytes(inputString));
        }

        public static string GetHashString(string inputString)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte b in GetHash(inputString))
                sb.Append(b.ToString("X2"));

            return sb.ToString();
        }

        public static string GetHashFromNets(List<Net> nets)
        {
            var netlist =  Parser.GenerateNetlistFromListOfNets(nets);
            return GetHashString(netlist);
        }

        public static string GetLocalCacheDirectory()
        {
            var path = GetLocalAppPath();
            var cacheFolder = path + "Cache";

            SamimiIO.CreateDirectory(cacheFolder);

            return cacheFolder;
        }

        public static string GetLocalAppPath()
        {
            var path = Application.StartupPath;
            if (!path.EndsWith("\\"))
                path += "\\";
            return path;
        }

        private static string _cacheDirectory;

        public static string CacheDirectory
        {
            set
            {
                if (value.EndsWith("\\"))
                    _cacheDirectory = value;
                else
                    _cacheDirectory = value + "\\";
            }
            get
            {
                if (!string.IsNullOrEmpty(_cacheDirectory))
                {
                    try
                    {
                        SamimiIO.CreateDirectory(_cacheDirectory);
                        return _cacheDirectory;
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Error!, Cache directory not available.\r\n" + _cacheDirectory + "\r\nSwitching to local cache directory.");
                        return GetLocalCacheDirectory();
                    }
                }
                else
                {
                    return GetLocalCacheDirectory();
                }
            }
        }
    }
}
