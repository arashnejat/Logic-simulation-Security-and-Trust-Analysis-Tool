﻿using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public class SamimiIO
    {
        public static bool Exiting = false;

        public static void WriteAllText(string filePath, string text)
        {
            if (Exiting)
                return;

            var insist = true;
            while (insist)
            {
                try
                {
                    File.WriteAllText(filePath, text);
                    insist = false;
                }
                catch (Exception exception)
                {
                    Console.Beep(1000, 1000);
                    Thread.Sleep(1000);
                    Console.Beep(1500, 1000);
                    Application.DoEvents();

                    if (Exiting)
                        return;
                }
            }
        }

        public static void CreateDirectory(string path)
        {
            if (Exiting) 
                return;

            Directory.CreateDirectory(path);
        }

        internal static string ReadAllText(string path)
        {
            if (Exiting)
                return null;

            string data = null;
            var insist = true;
            while (insist)
            {
                try
                {
                    data = File.ReadAllText(path);
                    insist = false;
                }
                catch (Exception exception)
                {
                    Console.Beep(1000, 1000);
                    Thread.Sleep(1000);
                    Console.Beep(1500, 1000);
                    Application.DoEvents();

                    if (Exiting)
                        return null;
                }
            }
            return data;
        }

        internal static bool Exists(string path)
        {
            if (File.Exists(path))
                return true;

            //Console.Beep(1000,2000);
            //Console.Beep();
            //MessageBox.Show("File does not exist!\r\n" + path, "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            return false;
        }

        internal static void MoveDirectory(string oldName, string newName)
        {
            if (Exiting)
                return; 

            var insist = true;
            while (insist)
            {
                try
                {
                    Directory.Move(oldName, newName);
                    insist = false;
                }
                catch (Exception exception)
                {
                    Console.Beep(1000, 1000);
                    Thread.Sleep(1000);
                    Console.Beep(1500, 1000);
                    Application.DoEvents();

                    if (Exiting)
                        return;
                }
            }
        }

        internal static string[] GetFiles(string path, string searchPattern)
        {
            return Directory.GetFiles(path, searchPattern);
        }

        internal static string[] GetDirectories(string circuitPath)
        {
            return Directory.GetDirectories(circuitPath);
        }
    }
}
