﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LogicEncryption
{
    public class CommonMethods
    {
        public class RandomPatternGeneration
        {
            public static string GenerateSingleRandomPattern(Random random, int length)
            {
                var strRandom = "";
                for (int i = 0; i < length; i++)
                {
                    strRandom += random.Next(0, 2);
                }
                return strRandom;
            }

            public static List<String> GenerateUniqueRandomPatterns(int lenght, int count, int seed)
            {
                var randomPatterns = new HashSet<string>();
                var random = new Random(seed);
                var maximum = (long)Math.Pow(2, lenght);
                //for (int i = 0; i < count && ((lenght < 32 && i < maximum) || lenght >= 32); i++)
                //for (int i = 0; i < count; i++)
                for (int i = 0; i < count && ((lenght < 31 && i < maximum) || lenght >= 31); i++)
                {
                    var newRandomPattern = GenerateSingleRandomPattern(random, lenght);
                    while (CheckIfPatternAlreadyExists(randomPatterns, newRandomPattern))
                        newRandomPattern = GenerateSingleRandomPattern(random, lenght);
                    randomPatterns.Add(newRandomPattern);
                }
                return randomPatterns.ToList();
            }

            public static List<String> GenerateExtraUniqueRandomPatterns(int lenght, int count)
            {
                return GenerateExtraUniqueRandomPatterns(lenght: lenght, count: count, seed: 1);
            }

            public static List<String> GenerateExtraUniqueRandomPatterns(int lenght, int count, int seed)
            {
                var random = new Random(seed);
                var randomPatterns = GenerateUniqueRandomPatterns(lenght: lenght, count: count, seed: seed);

                var difference = count - randomPatterns.Count;

                if (difference > 0)
                {
                    for (int i = 0; i < difference; i++)
                        randomPatterns.Add(GenerateSingleRandomPattern(random, lenght));
                }
                return randomPatterns;
            }

            private static bool CheckIfPatternAlreadyExists(HashSet<string> randomPatterns, string newRandomPattern)
            {
                return randomPatterns.Contains(newRandomPattern);

                //bool exists = false;
                //foreach (var randomPattern in randomPatterns)
                //{
                //    if (randomPattern == newRandomPattern)
                //    {
                //        exists = true;
                //        break;
                //    }
                //}
                //return exists;
            }
        }

        public static Net GetMainClockNet(List<Net> nets)
        {
            var clockNets = GetClockNets(nets);

            Net mainClockNet = null;
            foreach (var clockNet in clockNets)
            {
                if (GetMainClockNetRecursive(clockNet, ref mainClockNet))
                    return mainClockNet;
            }
            return null;
        }

        public static List<Net> GetClockNets(List<Net> nets)
        {
            var clockNets = new List<Net>();
            foreach (var net in nets)
                if (net is FlipFlop)
                    clockNets.Add(net.Inputs[1].Net);
            return clockNets;
        }

        private static bool GetMainClockNetRecursive(Net clockNet, ref Net mainClockNet)
        {
            if (clockNet.IsPrimaryInput && !clockNet.Name.StartsWith(SMSSKeyManager.StandardSMSSKeyPrefix))
            {
                mainClockNet = clockNet;
                return true;
            }
            //else if ((clockNet.Inputs[0].Net.IsPrimaryInput && !clockNet.Inputs[0].Net.IsKeyInput))
            //{
            //    mainClockNet = clockNet.Inputs[0].Net;
            //    return true;
            //}
            //else if (!(clockNet.Inputs[0].Net is GateEqual))
            //{
            //    mainClockNet = null;  //13951020
            //    return false;
            //}
            else
            {
                foreach (var input in clockNet.Inputs)
                {
                    var res = GetMainClockNetRecursive(input.Net, ref mainClockNet);
                    if (mainClockNet != null)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        /// <summary>
        ///اسلک تایم درنظر گرفته می شود
        ///تنها مناسب برای زمانی که با تک گیت اند و اور رمز گذاری می گردد
        /// </summary>
        /// <param name="newKeyGate"></param>
        /// <param name="keyIndex"></param>
        /// <param name="location"></param>
        /// <returns></returns>
        public static Net CreateAndInsertInputKeyNetConsideringSlackTimes(Net newKeyGate, int keyIndex, Net location)
        {
            var inputKeyNet = new Net
            {
                Name = SMSSKeyManager.NameAnInputKey(keyIndex),
                IsPrimaryInput = true,
                IsPrimaryOutput = false,
                IsGeneratedFanout = false,
                IsKeyInput = true, 
                IsKeyGate = true
            };

            //یک سر گیت کلید از سیم کلید می آید
            var inputKeyInput = new Input
            {
                Net = inputKeyNet,
                Name = inputKeyNet.Name,
                IsGeneratedClock = false
            };

            newKeyGate.Inputs.Add(inputKeyInput);
            inputKeyNet.NextNets.Clear();
            inputKeyNet.NextNets.Add(newKeyGate);

            CommonMethods.CorrectSlackTimeOfNewKeyInput(location, inputKeyNet);
            return inputKeyNet;
        }

        /// <summary>
        ///اسلک تایم درنظر گرفته نمی شود و به اسلک تایم ها دست نمی زند 
        /// </summary>
        /// <param name="newKeyGate"></param>
        /// <param name="keyIndex"></param>
        /// <returns></returns>
        public static Net CreateAndInsertInputKeyNet(Net newKeyGate, int keyIndex)
        {
            var inputKeyNet = new Net
            {
                Name = SMSSKeyManager.NameAnInputKey(keyIndex),
                IsPrimaryInput = true,
                IsPrimaryOutput = false,
                IsGeneratedFanout = false,
                IsKeyInput = true,
                IsKeyGate = true
            };

            //یک سر گیت کلید از سیم کلید می آید
            var inputKeyInput = new Input
            {
                Net = inputKeyNet,
                Name = inputKeyNet.Name,
                IsGeneratedClock = false
            };

            newKeyGate.Inputs.Add(inputKeyInput);
            inputKeyNet.NextNets.Clear();
            inputKeyNet.NextNets.Add(newKeyGate);

            return inputKeyNet;
        }

        public static Net CreateAndInsertInverterAfterLocation(List<Net> nets, Net location, int index, bool temp = false)
        {
            var newInverter = new GateNot();

            if (!temp)
            {
                if (location.IsPrimaryOutput)
                    newInverter.Name = SMSSKeyManager.NameAnOutputkeyInverter(location.Name, index);
                else
                    newInverter.Name = SMSSKeyManager.NameAkeyInverter(index);
            }
            else
            {
                newInverter.Name = SMSSKeyManager.NameAnOutputTempkeyGate(location.Name, SMSSKeyManager.StandardSMSSKeyTempIndex);
                newInverter.IsTempGate = true;
            }

            nets.Add(newInverter);

            InsertNewGateAfterLocation(location: location, newGate: newInverter);

            return newInverter;
        }

        /// <summary>
        ///اسلک تایم در نظر گرفته و اصلاح می گردد
        /// </summary>
        /// <param name="newGate"></param>
        /// <param name="location"></param>
        public static void InsertNewGateAfterLocationConsideringSlackTimes(Net newGate, Net location)
        {
            //اصلاحیات اولیه
            newGate.IsPrimaryOutput = location.IsPrimaryOutput;
            location.IsPrimaryOutput = false;
            newGate.IsGeneratedFanout = location.IsGeneratedFanout;


            var locationIsGeneratedClock = false;
            //گیت های بعدی لوکیشن باید اصلاح شود و 
            //کلیه ورودی هایی از آن که برابر با همین گیت لوکیشن بوده، باید به گیت کلید تغییر داده شوند
            foreach (var nextNet in location.NextNets)
            {
                foreach (var input in nextNet.Inputs)
                {
                    if (input.Net == location)
                    {
                        input.Name = newGate.Name;
                        input.Net = newGate;
                        //input.IsGeneratedClock = false;
                        locationIsGeneratedClock = input.IsGeneratedClock;
                        newGate.NextNets.Add(nextNet);
                    }
                }
            }

            //یک سر گیت، همان ورودی کلید است که قبلا وارد شده است

            //سر دیگر گیت، همان سیگنال لوکیشن است
            //لیست گیت های بعدی نت لوکیشن نیز باید اصلاح شود، بدین ترتیب که تخلیه شود و به تنها گیت کلید، تغییر پیدا کند
            var inputUnbalanced = new Input()
            {
                IsGeneratedClock = locationIsGeneratedClock,
                Name = location.Name,
                Net = location
            };
            newGate.Inputs.Add(inputUnbalanced);
            location.NextNets.Clear();
            location.NextNets.Add(newGate);

            CorrectSlackTimeOfNewGate(location: location, newGate: newGate);
        }

        public static void InsertNewGateAfterLocation(Net newGate, Net location)
        {
            //اصلاحیات اولیه
            newGate.IsPrimaryOutput = location.IsPrimaryOutput;
            location.IsPrimaryOutput = false;
            newGate.IsGeneratedFanout = location.IsGeneratedFanout;

            var locationIsGeneratedClock = false;
            //گیت های بعدی لوکیشن باید اصلاح شود و 
            //کلیه ورودی هایی از آن که برابر با همین گیت لوکیشن بوده، باید به گیت کلید تغییر داده شوند
            foreach (var nextNet in location.NextNets)
            {
                foreach (var input in nextNet.Inputs)
                {
                    if (input.Net == location)
                    {
                        input.Name = newGate.Name;
                        input.Net = newGate;
                        //input.IsGeneratedClock = false;
                        locationIsGeneratedClock = input.IsGeneratedClock;
                        newGate.NextNets.Add(nextNet);
                    }
                }
            }

            //یک سر گیت، همان ورودی کلید است که قبلا وارد شده است

            //سر دیگر گیت، همان سیگنال لوکیشن است
            //لیست گیت های بعدی نت لوکیشن نیز باید اصلاح شود، بدین ترتیب که تخلیه شود و به تنها گیت کلید، تغییر پیدا کند
            var inputUnbalanced = new Input()
            {
                IsGeneratedClock = locationIsGeneratedClock,
                Name = location.Name,
                Net = location
            };
            newGate.Inputs.Add(inputUnbalanced);
            location.NextNets.Clear();
            location.NextNets.Add(newGate);
        }

        public static void ReplaceXORwithXNOR(Net location, List<Net> nets, List<Net> keyGates, HashSet<Net> appliedNets = null)
        {
            var newGate = new GateXnor();
            CommonMethods.ReplaceLocationWithNewNet(location, newGate);

            nets.Remove(location);
            keyGates.Remove(location);

            nets.Add(newGate);
            keyGates.Add(newGate);

            if (appliedNets != null)
            {
                if (appliedNets.Contains(location))
                    appliedNets.Remove(location);
                appliedNets.Add(newGate);
            }
        }

        public static void ReplaceLocationWithNewNet(Net location, Net newNet)
        {
            //اصلاحیات اولیه
            newNet.Name = location.Name;
            newNet.LevelNumberInLogicSimulation = location.LevelNumberInLogicSimulation;

            newNet.IsPrimaryOutput = location.IsPrimaryOutput;
            newNet.IsGeneratedFanout = location.IsGeneratedFanout;
            newNet.IsPrimaryInput = location.IsPrimaryInput;
            newNet.IsKeyGate = location.IsKeyGate;
            newNet.IsGeneratedFanout = location.IsGeneratedFanout;

            newNet.FaultImpact = location.FaultImpact;
            newNet.SimulatedProbability = location.SimulatedProbability;
            newNet.NoO0 = location.NoO0;
            newNet.NoO1 = location.NoO1;
            newNet.NoP0 = location.NoP0;
            newNet.NoP1 = location.NoP1;
            newNet.Zeros = location.Zeros;
            newNet.Ones = location.Ones;

            newNet.ALAP = location.ALAP;
            newNet.ASAP = location.ASAP;
            newNet.SlackTime = location.SlackTime;

            //گیت های بعدی لوکیشن باید اصلاح شود و 
            //کلیه ورودی هایی از آن که برابر با همین گیت لوکیشن بوده، باید به گیت جدید تغییر داده شوند
            foreach (var nextNet in location.NextNets)
            {
                foreach (var input in nextNet.Inputs)
                {
                    if (input.Net == location)
                    {
                        input.Name = newNet.Name;
                        input.Net = newNet;
                        newNet.NextNets.Add(nextNet);
                    }
                }
            }

            //گیت های قبلی لوکیشن نیز اصلاح می شوند
            //تا به عنوان گیت بعدی به جای لوکیشن به گیت جدید اشاره کنند

            foreach (var inputofLocation in location.Inputs)
            {
                newNet.Inputs.Add(inputofLocation);

                inputofLocation.Net.NextNets.Remove(location);
                inputofLocation.Net.NextNets.Add(newNet);
            }
        }

        public static void InsertNewXORGateAfterLocation(List<Net> nets, Net location, List<Net> keyGates, List<Net> keyInputs, HashSet<Net> appliedNets = null, bool temp = false)
        {
            Net newKeyGate = new GateXor();

            CommonMethods.CompleteKeyGate(newKeyGate: newKeyGate, index: temp ? SMSSKeyManager.StandardSMSSKeyTempIndex : keyGates.Count + 1, location: location, temp: temp);

            keyGates.Add(newKeyGate);
            nets.Add(newKeyGate);

            //===============================
            var inputKeyNet = CommonMethods.CreateAndInsertInputKeyNet(newKeyGate: newKeyGate, keyIndex: temp ? SMSSKeyManager.StandardSMSSKeyTempIndex : keyInputs.Count + 1);

            keyInputs.Add(inputKeyNet);
            nets.Add(inputKeyNet);

            CommonMethods.InsertNewGateAfterLocation(newGate: newKeyGate, location: location);
            //===============================

            if (appliedNets != null)
            {
                appliedNets.Add(inputKeyNet);
                appliedNets.Add(newKeyGate);
            }

            if (temp)
            {
                newKeyGate.IsTempGate = true;
                inputKeyNet.IsTempGate = true;
            }
        }
        public static void InsertNewXNORGateAfterLocation(List<Net> nets, Net location, List<Net> keyGates, List<Net> keyInputs, HashSet<Net> appliedNets = null, bool temp = false)
        {
            Net newKeyGate = new GateXnor();

            CommonMethods.CompleteKeyGate(newKeyGate: newKeyGate, index: temp ? SMSSKeyManager.StandardSMSSKeyTempIndex : keyGates.Count + 1, location: location, temp: temp);

            keyGates.Add(newKeyGate);
            nets.Add(newKeyGate);

            //===============================
            var inputKeyNet = CommonMethods.CreateAndInsertInputKeyNet(newKeyGate: newKeyGate, keyIndex: temp ? SMSSKeyManager.StandardSMSSKeyTempIndex : keyInputs.Count + 1);

            keyInputs.Add(inputKeyNet);
            nets.Add(inputKeyNet);

            CommonMethods.InsertNewGateAfterLocation(newGate: newKeyGate, location: location);
            //===============================

            if (appliedNets != null)
            {
                appliedNets.Add(inputKeyNet);
                appliedNets.Add(newKeyGate);
            }

            if (temp)
            {
                newKeyGate.IsTempGate = true;
                inputKeyNet.IsTempGate = true;
            }
        }

        /// <summary>
        /// نام گذاری گیت کلید را انجام می دهد
        /// مشخصه های مربوط به ورودی خروجی بودن گیت را نیز ست می کند
        /// </summary>
        /// <param name="newKeyGate"></param>
        /// <param name="location">همان نتی است که گیت کلید قرار است پس از آن درج شود</param>
        /// <param name="index"></param>
        /// <param name="temp">مشخص کننده اینکه این یک گیت موقتی است</param>
        public static void CompleteKeyGate(Net newKeyGate, int index, Net location, bool temp = false)
        {
            if (location.IsPrimaryOutput || location.NextNets.Count == 0)
            {
                if(temp)
                    newKeyGate.Name = SMSSKeyManager.NameAnOutputTempkeyGate(location.Name, index);
                else
                    newKeyGate.Name = SMSSKeyManager.NameAnOutputkeyGate(location.Name, index);
            }
            else
            {
                newKeyGate.Name = SMSSKeyManager.NameAKeyGate(index);
            }
            newKeyGate.IsPrimaryInput = false;
            newKeyGate.IsPrimaryOutput = location.IsPrimaryOutput;
            newKeyGate.IsKeyGate = true;
        }

        ///// <summary>
        ///// نام گذاری گیت کلید را انجام می دهد
        ///// مشخصه های مربوط به ورودی خروجی بودن گیت را نیز ست می کند
        ///// </summary>
        ///// <param name="newKeyGate"></param>
        ///// <param name="index"></param>
        //public static void CompleteKeyGate(Net newKeyGate, int index)
        //{
            
        //    newKeyGate.Name = SMSSKeyManager.NameAKeyGate(index);
        //    newKeyGate.IsPrimaryInput = false;
        //    newKeyGate.IsPrimaryOutput = false;
        //    newKeyGate.IsKeyGate = true;
        //}

        private static void CorrectSlackTimeOfNewKeyInput(Net location, Net newKeyInput)
        {
            var oldAsap = location.ASAP;
            var oldAlap = location.ALAP;
            var oldSlackTime = location.SlackTime;

            newKeyInput.LevelNumberInLogicSimulation = 0;
            newKeyInput.ASAP = 0;
            newKeyInput.ALAP = oldAlap - 1;
            newKeyInput.SlackTime = newKeyInput.ALAP - newKeyInput.ASAP;
        }

        private static void CorrectSlackTimeOfNewGate(Net location, Net newGate)
        {
            var oldAsap = location.ASAP;
            var oldAlap = location.ALAP;
            var oldSlackTime = location.SlackTime;

            newGate.LevelNumberInLogicSimulation = 1;
            newGate.ASAP = oldAsap + 1;
            newGate.ALAP = oldAlap;
            newGate.SlackTime = newGate.ALAP - newGate.ASAP;// == oldSlackTime - 1

            //mostUnbalancedSignal.LevelNumberInLogicSimulation //Doesn't Change
            location.ASAP = oldAsap; //Doesn't change
            location.ALAP = oldAlap - 1;
            location.SlackTime = location.ALAP - location.ASAP;
        }
    }
}
