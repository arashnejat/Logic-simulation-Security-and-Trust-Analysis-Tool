﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public class PowerAreaDelay
    {
        public static List<Net> LoadNetsFromNetlistString(string netlistString)
        {
            var nets = Parser.CreateNets(netlistString, false);
            return nets;
        }

        public static string CalculateOrLoadProbabilities(List<Net> nets, string netlistName, int clockTimes = 10, int randomSeed = 309302, int randomPatternsCount = 1000, bool meetThreshold = true, double thershold = 0.00002, bool forceCalculate = false, bool allowSaveResults = true, string key = "")
        {
            string loadReport;
            var totalSamples = LogicSimulation.LoadOrCalculateProbabilities(
                nets: nets,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                totalTimes: randomPatternsCount,
                meetThreshold: meetThreshold,
                threshold: thershold,
                textBox: null,
                netlistName: netlistName,
                loadReport: out loadReport,
                forceCalculate: forceCalculate,
                allowSaveResults: allowSaveResults,
                key: key);
            return loadReport;
        }

        public static double CalculatePowerOfNetlist(List<Net> nets)
        {
            double sum = 0;
            foreach (var net in nets)
            {
                if (net.SimulatedProbability == -1)
                    continue;
                    //Console.Beep(2000, 1000);

                //فرمول جدید توان مصرفی
                //توان مصرفی از دید مهاجم در مدارهای محاسبه شده پیشین با فرمول قدیمی و اشتباه محاسبه شده بودند
                //که باید به این نکته توجه گردد
                sum += (net.SimulatedProbability) * (1-net.SimulatedProbability) * net.NextNets.Count;
            }
            return sum;
        }

        public static double CalculateAreaOfNetlist(List<Net> nets, bool ignoreKeyInverters = false)
        {
            double sum = 0;

            foreach (var net in nets)
                InitializeGateDelay(net);

            foreach (var net in nets)
            {
                if (ignoreKeyInverters && net.Name.Contains(SMSSKeyManager.StandardSMSSKeyInverterName))
                    continue;
                sum += net.area;

            }

            return sum;
        }

        public static double CalculateDelayOfNetlist(List<Net> nets)
        {
            foreach (var net in nets)
                InitializeGateDelay(net);

            var notStabled = true;
            while (notStabled)//New
            {
                notStabled = false;//New

                foreach (var gate in nets)
                {
                    if (gate is FlipFlop)
                        continue;
                    //---------------------------------------------------
                    gate.load = 0;
                    foreach (var net in gate.NextNets)
                        gate.load += net.inputc;
                    //---------------------------------------------------
                    gate.tplh = gate.tplh_fix + (gate.tplh_load*gate.load);
                    gate.tphl = gate.tphl_fix + (gate.tphl_load*gate.load);
                    if (gate.tplh > gate.tphl)
                    {
                        gate.gd = gate.tplh;
                        gate.gd_min = gate.tphl;
                    }
                    else
                    {
                        gate.gd = gate.tphl;
                        gate.gd_min = gate.tplh;
                    }
                    //---------------------------------------------------
                    double inputs_delay = 0;
                    foreach (var input in gate.Inputs)
                    {
                        if (input.Net.delay > inputs_delay)
                            inputs_delay = input.Net.delay;
                    }
                    var newDelay = gate.gd + inputs_delay;

                    if (gate.delay != newDelay)
                    {
                        notStabled = true;  //New
                        gate.delay = gate.gd + inputs_delay;
                    }
                    //---------------------------------------------------
                }
            }

            var max_delay = 0.0;
            foreach (var gate in nets)
            {
                if ((gate.delay > max_delay)) // && (gate->type!=7))
                    max_delay = gate.delay;
            }
            return max_delay;
        }

        private static void InitializeGateDelay(Net gate)
        {
            if ((gate is GateXor) || (gate is GateXnor)) //XOR or XNOR
                gate.inputc = 5.321;
            else // All other gates
                gate.inputc = 2.661;


            if (gate is GateNand)
            {
                //NAND
                if (gate.Inputs.Count == 2) //NAND2
                {
                    gate.tplh_fix = 3;
                    gate.tphl_fix = 5;
                    gate.tplh_load = 0.444;
                    gate.tphl_load = 0.706;
                    gate.area = 1458;
                }
                else if (gate.Inputs.Count == 3) //NAND3
                {
                    gate.tplh_fix = 6;
                    gate.tphl_fix = 6;
                    gate.tplh_load = 0.420;
                    gate.tphl_load = 0.661;
                    gate.area = 1944;
                }
                else if (gate.Inputs.Count == 4) //NAND4
                {
                    gate.tplh_fix = 7;
                    gate.tphl_fix = 7;
                    gate.tplh_load = 0.451;
                    gate.tphl_load = 0.663;
                    gate.area = 2430;
                }
                else if (gate.Inputs.Count == 5) //NAND5: constructed by AND5 + INV
                {
                    gate.tplh_fix = 6 + (0.420*2.661) + 3 + 3 + (0.414*2.661);
                    gate.tphl_fix = 6 + (0.661*2.661) + 7 + 3 + (0.694*2.661);
                    gate.tplh_load = 0.516;
                    gate.tphl_load = 0.322;
                    gate.area = 1458 + 1944 + 1458 + 1215;
                }
                else if (gate.Inputs.Count == 8) //NAND8: constructed by AND8 + INV
                {
                    gate.tplh_fix = 7 + (0.451*2.661) + 3 + 3 + (0.414*2.661);
                    gate.tphl_fix = 7 + (0.663*2.661) + 7 + 3 + (0.694*2.661);
                    gate.tplh_load = 0.516;
                    gate.tphl_load = 0.322;
                    gate.area = 2430 + 2430 + 1458 + 1215;
                }
                else // The same as NAND8
                {
                    gate.tplh_fix = 7 + (0.451*2.661) + 3 + 3 + (0.414*2.661);
                    gate.tphl_fix = 7 + (0.663*2.661) + 7 + 3 + (0.694*2.661);
                    gate.tplh_load = 0.516;
                    gate.tphl_load = 0.322;
                    gate.area = 2430 + 2430 + 1458 + 1215;
                    //cout << "ALARM: NAND gate has more than 4 inputs" << endl;
                }
            }
            else if (gate is GateAnd)
            {
                //and
                if (gate.Inputs.Count == 2) //AND2: NAND2 + INV
                {
                    gate.tplh_fix = 3 + (0.706*2.661) + 3;
                    gate.tphl_fix = 5 + (0.444*2.661) + 3;
                    gate.tplh_load = 0.516;
                    gate.tphl_load = 0.322;
                    gate.area = 2673;
                }
                else if (gate.Inputs.Count == 3) //AND3: NAND3 + INV
                {
                    gate.tplh_fix = 6 + (0.661*2.661) + 3;
                    gate.tphl_fix = 6 + (0.420*2.661) + 3;
                    gate.tplh_load = 0.516;
                    gate.tphl_load = 0.322;
                    gate.area = 3159;
                }
                else if (gate.Inputs.Count == 4) //AND4: NAND4 + INV
                {
                    gate.tplh_fix = 7 + (0.663*2.661) + 3;
                    gate.tphl_fix = 7 + (0.451*2.661) + 3;
                    gate.tplh_load = 0.516;
                    gate.tphl_load = 0.322;
                    gate.area = 3645;
                }
                else if (gate.Inputs.Count == 5) //AND5: NAND3 + NAND2 + NOR2
                {
                    gate.tplh_fix = 6 + (0.661*2.661) + 7;
                    gate.tphl_fix = 6 + (0.420*2.661) + 3;
                    gate.tplh_load = 0.694;
                    gate.tphl_load = 0.414;
                    gate.area = 1458 + 1944 + 1458;
                }
                else if (gate.Inputs.Count == 6) //AND6: NAND3 + NAND3 + NOR2
                {
                    gate.tplh_fix = 6 + (0.661*2.661) + 7;
                    gate.tphl_fix = 6 + (0.420*2.661) + 3;
                    gate.tplh_load = 0.694;
                    gate.tphl_load = 0.414;
                    gate.area = 1944 + 1944 + 1458;
                }
                else if (gate.Inputs.Count == 7) //AND7: NAND4 + NAND3 + NOR2
                {
                    gate.tplh_fix = 7 + (0.663*2.661) + 7;
                    gate.tphl_fix = 7 + (0.451*2.661) + 3;
                    gate.tplh_load = 0.694;
                    gate.tphl_load = 0.414;
                    gate.area = 1944 + 2430 + 1458;
                }
                else if (gate.Inputs.Count == 8) //AND8: NAND4 + NAND4 + NOR2
                {
                    gate.tplh_fix = 7 + (0.663*2.661) + 7;
                    gate.tphl_fix = 7 + (0.451*2.661) + 3;
                    gate.tplh_load = 0.694;
                    gate.tphl_load = 0.414;
                    gate.area = 2430 + 2430 + 1458;
                }
                else if (gate.Inputs.Count == 9) //AND9: NAND3 + NAND3 + NAND3 + NOR3
                {
                    gate.tplh_fix = 6 + (0.661*2.661) + 9;
                    gate.tphl_fix = 6 + (0.420*2.661) + 2;
                    gate.tplh_load = 1.016;
                    gate.tphl_load = 0.297;
                    gate.area = 1944 + 1944 + 1944 + 1944;
                }
                else
                {
                    //The same as AND9
                    gate.tplh_fix = 6 + (0.661*2.661) + 9;
                    gate.tphl_fix = 6 + (0.420*2.661) + 2;
                    gate.tplh_load = 1.016;
                    gate.tphl_load = 0.297;
                    gate.area = 1944 + 1944 + 1944 + 1944;
                    //cout << "ALARM: AND gate has more than 8 inputs" << endl;
                }
            }
            else if (gate is GateNor)
            {
                //NOR
                if (gate.Inputs.Count == 2) //NOR2
                {
                    gate.tplh_fix = 7;
                    gate.tphl_fix = 3;
                    gate.tplh_load = 0.694;
                    gate.tphl_load = 0.414;
                    gate.area = 1458;
                }
                else if (gate.Inputs.Count == 3) //NOR3
                {
                    gate.tplh_fix = 9;
                    gate.tphl_fix = 2;
                    gate.tplh_load = 1.016;
                    gate.tphl_load = 0.297;
                    gate.area = 1944;
                }
                else if (gate.Inputs.Count == 4) //NOR4
                {
                    gate.tplh_fix = 17;
                    gate.tphl_fix = 2;
                    gate.tplh_load = 1.292;
                    gate.tphl_load = 0.494;
                    gate.area = 2430;
                }
                else if (gate.Inputs.Count == 8) //NOR8: Constructed by OR8 + INV
                {
                    gate.tplh_fix = 17 + (1.292*2.661) + 3 + 3 + (0.706*2.661);
                    gate.tphl_fix = 2 + (0.494*2.661) + 5 + 3 + (0.444*2.661);
                    gate.tplh_load = 0.516;
                    gate.tphl_load = 0.322;
                    gate.area = 2430 + 2430 + 1458 + 1215;
                }
                else //The same as NOR8
                {
                    gate.tplh_fix = 17 + (1.292*2.661) + 3 + 3 + (0.706*2.661);
                    gate.tphl_fix = 2 + (0.494*2.661) + 5 + 3 + (0.444*2.661);
                    gate.tplh_load = 0.516;
                    gate.tphl_load = 0.322;
                    gate.area = 2430 + 2430 + 1458 + 1215;
                    //cout << "ALARM: NOR gate has more than 8 inputs" << endl;
                }
            }
            else if (gate is GateOr)
            {
                //OR
                if (gate.Inputs.Count == 2) //OR2: NOR2+INV
                {
                    gate.tplh_fix = 3 + (0.414*2.661) + 3;
                    gate.tphl_fix = 7 + (0.694*2.661) + 3;
                    gate.tplh_load = 0.516;
                    gate.tphl_load = 0.322;
                    gate.area = 2673;
                }
                else if (gate.Inputs.Count == 3) //OR3: NOR3+INV
                {
                    gate.tplh_fix = 2 + (0.297*2.661) + 3;
                    gate.tphl_fix = 9 + (1.016*2.661) + 3;
                    gate.tplh_load = 0.516;
                    gate.tphl_load = 0.322;
                    gate.area = 3159;
                }
                else if (gate.Inputs.Count == 4) //OR4: NOR4+INV
                {
                    gate.tplh_fix = 2 + (0.494*2.661) + 3;
                    gate.tphl_fix = 17 + (1.292*2.661) + 3;
                    gate.tplh_load = 0.516;
                    gate.tphl_load = 0.322;
                    gate.area = 3645;
                }
                else if (gate.Inputs.Count == 5) //OR5: NOR3+NOR2+NAND2
                {
                    gate.tplh_fix = 2 + (0.297*2.661) + 5;
                    gate.tphl_fix = 9 + (1.016*2.661) + 3;
                    gate.tplh_load = 0.444;
                    gate.tphl_load = 0.706;
                    gate.area = 1458 + 1944 + 1458;
                }
                else if (gate.Inputs.Count == 6) //OR6: NOR3+NOR3+NAND2
                {
                    gate.tplh_fix = 2 + (0.297*2.661) + 5;
                    gate.tphl_fix = 9 + (1.016*2.661) + 3;
                    gate.tplh_load = 0.444;
                    gate.tphl_load = 0.706;
                    gate.area = 1944 + 1944 + 1458;
                }
                else if (gate.Inputs.Count == 7) //OR7: NOR4+NOR3+NAND2
                {
                    gate.tplh_fix = 2 + (0.494*2.661) + 5;
                    gate.tphl_fix = 17 + (1.292*2.661) + 3;
                    gate.tplh_load = 0.444;
                    gate.tphl_load = 0.706;
                    gate.area = 1944 + 2430 + 1458;
                }
                else if (gate.Inputs.Count == 8) //OR8: NOR4+NOR4+NAND2
                {
                    gate.tplh_fix = 2 + (0.494*2.661) + 5;
                    gate.tphl_fix = 17 + (1.292*2.661) + 3;
                    gate.tplh_load = 0.444;
                    gate.tphl_load = 0.706;
                    gate.area = 2430 + 2430 + 1458;
                }
                else // The same as OR8
                {
                    gate.tplh_fix = 2 + (0.494*2.661) + 5;
                    gate.tphl_fix = 17 + (1.292*2.661) + 3;
                    gate.tplh_load = 0.444;
                    gate.tphl_load = 0.706;
                    gate.area = 2430 + 2430 + 1458;
                    //cout << "ALARM: OR gate has more than 4 inputs" << endl;
                }
            }
            else if (gate is GateXor)
            {
                //XOR
                gate.tplh_fix = 12;
                gate.tphl_fix = 13;
                gate.tplh_load = 0.668;
                gate.tphl_load = 0.266;
                gate.area = 3159;
            }
            else if (gate is GateXnor)
            {
                //XNOR
                gate.tplh_fix = 12;
                gate.tphl_fix = 12;
                gate.tplh_load = 0.551;
                gate.tphl_load = 0.105;
                gate.area = 2916;
            }
            else if (gate is GateNot)
            {
                //INV
                gate.tplh_fix = 3;
                gate.tphl_fix = 3;
                gate.tplh_load = 0.516;
                gate.tphl_load = 0.322;
                gate.area = 1215;
            }
            else if (gate is FlipFlop)
            {
                //DFF: Should be corrected
                gate.tplh_fix = 7;
                gate.tphl_fix = 7;
                gate.tplh_load = 0.387;
                gate.tphl_load = 0.432;
                gate.area = 8505;
            }
            else if (gate is GateBuffer)
            {
                // BUF
                gate.tplh_fix = 7;
                gate.tphl_fix = 7;
                gate.tplh_load = 0.370;
                gate.tphl_load = 0.363;
                gate.area = 1458;
            }


        } //initialize_gate_delay
    }
}
