﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicEncryption
{
    public class SMSSKeyManager
    {
        public const string StandardSMSSKeyPrefix = "SMSSKey";
        public const int StandardSMSSKeyTempIndex = 13660214;

        public const string StandardSMSSKeyInputName = StandardSMSSKeyPrefix + "Input";
        public const string StandardSMSSKeyGateName = StandardSMSSKeyPrefix + "Gate";
        public const string StandardSMSSKeyInverterName = StandardSMSSKeyPrefix + "Inverter";

        public static bool IsSMSKeyNet(string name)
        {
            return name.StartsWith(StandardSMSSKeyPrefix);
        }

        public static int ExtractKeyIndexFromSMSSKeyName(string name)
        {
            string firstRedundantPartRemoved = name.Substring(StandardSMSSKeyInputName.Length, name.Length - StandardSMSSKeyInputName.Length);

            string numbers = "";

            for (int i = 0; i < firstRedundantPartRemoved.Length; i++)
            {
                var ch = firstRedundantPartRemoved[i];
                if (ch == '0' || ch == '1' || ch == '2' || ch == '3' || ch == '4' || ch == '5' || ch == '6' || ch == '7' ||
                    ch == '8' || ch == '9')
                    numbers += ch;
                else
                    break;
            }

            return int.Parse(numbers);
        }

        public static string ExtractOriginalNameFromSMSSKeyNetName(string name)
        {
            var prefix = "";
            if (name.StartsWith(StandardSMSSKeyGateName))
                prefix = StandardSMSSKeyGateName;
            else if (name.StartsWith(StandardSMSSKeyInputName))
                prefix = StandardSMSSKeyInputName;
            else if (name.StartsWith(StandardSMSSKeyInverterName))
                prefix = StandardSMSSKeyInverterName;

            string firstRedundantPartRemoved = name.Substring(prefix.Length, name.Length - prefix.Length);

            int numbersLength = 0;

            for (int i = 0; i < firstRedundantPartRemoved.Length; i++)
            {
                var ch = firstRedundantPartRemoved[i];
                if (ch == '0' || ch == '1' || ch == '2' || ch == '3' || ch == '4' || ch == '5' || ch == '6' || ch == '7' ||
                    ch == '8' || ch == '9')
                    numbersLength++;
                else
                    break;
            }
            // SMSSKeyGate32_oldname
            numbersLength++; // For Underline Symbole! ( '_' )

            return firstRedundantPartRemoved.Substring(numbersLength, firstRedundantPartRemoved.Length - numbersLength); ;
        }

        public static string NameAKeyGate(int index)
        {
            return StandardSMSSKeyGateName + index;
        }

        public static string NameAkeyInverter(int index)
        {
            return StandardSMSSKeyInverterName + index;
        }

        public static string NameAnInputKey(int index)
        {
            return StandardSMSSKeyInputName + index;
        }

        public static string NameAnOutputkeyGate(string name, int index)
        {
            var originalName = name;
            if (IsSMSKeyNet(name))
                originalName = ExtractOriginalNameFromSMSSKeyNetName(name: name);

            return NameAKeyGate(index) + "_" + originalName;
        }

        public static string NameAnOutputTempkeyGate(string name, int index)
        {
            //در نامگذاری گیت موقتی، باید اصل نام گیت قبلی را در نامگذاری لحاظ کنیم
            return NameAKeyGate(index) + "_" + name;
        }

        public static string NameAnOutputkeyInverter(string name, int index)
        {
            var originalName = name;
            if (IsSMSKeyNet(name))
                originalName = ExtractOriginalNameFromSMSSKeyNetName(name: name);

            return NameAkeyInverter(index) + "_" + originalName;
        }
    }

}
