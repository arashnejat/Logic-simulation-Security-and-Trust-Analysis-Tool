﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public class EncryptionChecker
    {
        public class HammingDistanceStatisticalResultHolder
        {
            public double HammingDistancePercent;
            public double XRatio;

            public double RMSD;
            public double Average;
            public double StandardDeviation;
        }       

        public class InputsOutputsVO
        {
            public string Input;
            public string Output;
            public string Clock;
        }

        public static string GetUniqueOutputsCount(List<Net> normalNets, bool uniqueRandomPatterns, int randomPatterns, int randomSeed, int clockTimes, out List<InputsOutputsVO> inputsOutputs, TextBox textBox, bool detailedReport, string netlistName)
        {
            List<Net> middleNetsNormal;
            List<Net> outputNetsNormal;
            List<Net> inputNetsNormal;
            Parser.ClassifyInputMiddleOutputNets(nets: normalNets, inputNets: out inputNetsNormal, outputNets: out outputNetsNormal, middleNets: out middleNetsNormal);
            var clockNetNormal = CommonMethods.GetMainClockNet(normalNets);
            inputNetsNormal.Remove(clockNetNormal);

            //چنانچه گیت کلیدی  (ورودی/اینورتر/گیت ایکسور ...) به خروجی راه پیدا کرده، پیشوند کلید و شماره کلید از نامش حذف میشود
            foreach (var net in outputNetsNormal)
                if (SMSSKeyManager.IsSMSKeyNet(net.Name))
                    net.Name = SMSSKeyManager.ExtractOriginalNameFromSMSSKeyNetName(net.Name);

            outputNetsNormal.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));

            inputNetsNormal.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));

            middleNetsNormal.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));

            // درابتدا یک لیست از رشته های ورودی تصادفی به طول ورودی های مدار عادی درست می کنیم
            List<string> generatedRandomPatterns;
            if (uniqueRandomPatterns)
                generatedRandomPatterns = CommonMethods.RandomPatternGeneration.GenerateUniqueRandomPatterns(lenght: inputNetsNormal.Count, count: randomPatterns, seed: randomSeed);
            else
                generatedRandomPatterns = CommonMethods.RandomPatternGeneration.GenerateExtraUniqueRandomPatterns(lenght: inputNetsNormal.Count, count: randomPatterns, seed: randomSeed);

            var samplesCount = 0;

            inputsOutputs = new List<InputsOutputsVO>();
            var uniqueOutputs = new HashSet<string>();

            int counter = 0;
            var generatedOutputString = "";

            long index;
            index = 0;
            foreach (var randomPattern in generatedRandomPatterns)
            {
                index++;
                if (textBox != null)
                {
                    if (index % 10 == 0)
                    {
                        var percent = ((double)index * 100 / generatedRandomPatterns.Count);
                        var header = netlistName + "\r\n" + "Progress: " + (int)percent + "%\r\n";

                        textBox.Text = header;
                        Application.DoEvents();
                    }
                }

                counter += 1;
                if (counter %100 == 0)
                    Application.DoEvents();
                 
                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets: inputNetsNormal, pattern: randomPattern);

                samplesCount++;
                
                generatedOutputString = "";
                foreach (var net in outputNetsNormal)
                    generatedOutputString += Net.SignalString(net.SValue);
                if (!uniqueOutputs.Contains(generatedOutputString))
                    uniqueOutputs.Add(generatedOutputString);
                if (detailedReport)
                    inputsOutputs.Add(new InputsOutputsVO { Input = randomPattern, Output = generatedOutputString, Clock = "" });

                    

                if (clockNetNormal != null)
                    for (int i = 0; i < clockTimes; i++)
                    {
                        //اول کلاک صفر وارد مدار می شود و آمار کل مدار گرفته می شود
                        Net.SValueMethods.Imply(clockNetNormal, Net.Signal.V0);
                        samplesCount++;

                        generatedOutputString = "";
                        foreach (var net in outputNetsNormal)
                            generatedOutputString += Net.SignalString(net.SValue);
                        if (!uniqueOutputs.Contains(generatedOutputString))
                            uniqueOutputs.Add(generatedOutputString);
                        if (detailedReport)
                            inputsOutputs.Add(new InputsOutputsVO { Input = randomPattern, Output = generatedOutputString, Clock = "0" });

                        //بعد کلاک یک وارد مدار می شود و آمار کل مدار گرفته می شود
                        Net.SValueMethods.Imply(clockNetNormal, Net.Signal.V1);

                        samplesCount++;
                
                        generatedOutputString = "";
                        foreach (var net in outputNetsNormal)
                            generatedOutputString += Net.SignalString(net.SValue);
                        if (!uniqueOutputs.Contains(generatedOutputString))
                            uniqueOutputs.Add(generatedOutputString);
                        if (detailedReport)
                        inputsOutputs.Add(new InputsOutputsVO { Input = randomPattern, Output = generatedOutputString, Clock = "1" });
                    }
            }

            return uniqueOutputs.Count.ToString();
        }


        public static string CheckIntegrity(List<Net> encryptedNets, List<Net> normalNets, bool uniqueRandomPatterns, int randomPatterns, int randomSeed, string key, int clockTimes)
        {
            //double output;

            List<Net> middleNetsEncrypted;
            List<Net> outputNetsEncrypted;
            List<Net> inputNetsEncrypted;
            Parser.ClassifyInputMiddleOutputNets(nets: encryptedNets, inputNets: out inputNetsEncrypted, outputNets: out outputNetsEncrypted, middleNets: out middleNetsEncrypted);
            var clockNetEncrypted = CommonMethods.GetMainClockNet(encryptedNets);
            inputNetsEncrypted.Remove(clockNetEncrypted);

            List<Net> middleNetsNormal;
            List<Net> outputNetsNormal;
            List<Net> inputNetsNormal;
            Parser.ClassifyInputMiddleOutputNets(nets: normalNets, inputNets: out inputNetsNormal, outputNets: out outputNetsNormal, middleNets: out middleNetsNormal);
            var clockNetNormal = CommonMethods.GetMainClockNet(normalNets);
            inputNetsNormal.Remove(clockNetNormal);

            //چنانچه گیت کلیدی  (ورودی/اینورتر/گیت ایکسور ...) به خروجی راه پیدا کرده، پیشوند کلید و شماره کلید از نامش حذف میشود
            foreach (var net in outputNetsEncrypted)
                if (SMSSKeyManager.IsSMSKeyNet(net.Name))
                    net.Name = SMSSKeyManager.ExtractOriginalNameFromSMSSKeyNetName(net.Name);

            //چنانچه گیت کلیدی  (ورودی/اینورتر/گیت ایکسور ...) به خروجی راه پیدا کرده، پیشوند کلید و شماره کلید از نامش حذف میشود
            foreach (var net in outputNetsNormal)
                if (SMSSKeyManager.IsSMSKeyNet(net.Name))
                    net.Name = SMSSKeyManager.ExtractOriginalNameFromSMSSKeyNetName(net.Name);

            outputNetsEncrypted.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));
            outputNetsNormal.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));

            inputNetsEncrypted.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));
            inputNetsNormal.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));

            middleNetsEncrypted.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));
            middleNetsNormal.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));

            // درابتدا یک لیست از رشته های ورودی تصادفی به طول ورودی های مدار عادی درست می کنیم
            List<string> generatedRandomPatterns;
            if (uniqueRandomPatterns)
                generatedRandomPatterns = CommonMethods.RandomPatternGeneration.GenerateUniqueRandomPatterns(lenght: inputNetsNormal.Count, count: randomPatterns, seed: randomSeed);
            else
                generatedRandomPatterns = CommonMethods.RandomPatternGeneration.GenerateExtraUniqueRandomPatterns(lenght: inputNetsNormal.Count, count: randomPatterns, seed: randomSeed);

            double hammingDistanceRatio;

            double sumOfHammingDistanceRatios = 0;
            var samplesCount = 0;

            var allX = 0;
            foreach (var randomPattern in generatedRandomPatterns)
            {
                //باید دو رشته ورودی داشته باشیم که هردو صحیح باشند
                //یک رشته به طول مدار معمولی
                //و یک رشته با طول مدار رمزگذاری شده که در آن کلید ها به درستی سر جای خود قرار گرفته اند

                var normalIndex = 0;
                var encIndex = 0;
                var patternForNormalCircuitList = new List<char>();
                var patternForEncryptedCircuitList = new List<char>();
                while (normalIndex < inputNetsNormal.Count || encIndex < inputNetsEncrypted.Count)
                {
                    if (normalIndex < inputNetsNormal.Count && inputNetsNormal[normalIndex].Name == inputNetsEncrypted[encIndex].Name)
                    {
                        patternForNormalCircuitList.Add(randomPattern[normalIndex]);
                        patternForEncryptedCircuitList.Add(randomPattern[normalIndex]);

                        normalIndex++;
                        encIndex++;
                    }
                    else if (encIndex < inputNetsEncrypted.Count && SMSSKeyManager.IsSMSKeyNet(inputNetsEncrypted[encIndex].Name))
                    {
                        var keyIndex = SMSSKeyManager.ExtractKeyIndexFromSMSSKeyName(inputNetsEncrypted[encIndex].Name);
                        patternForEncryptedCircuitList.Add(key[keyIndex - 1]);

                        encIndex++;
                    }
                }
                var patternForNormalCircuit = (string.Join("", patternForNormalCircuitList.ToArray())).Trim();
                var patternForEncryptedCircuit = (string.Join("", patternForEncryptedCircuitList.ToArray())).Trim();

                //باید هر دو مدار با این دو ورودی عملکرد دقیقا یکسانی از خود نشان دهند
                //یعنی همینگ دیستنس دو مدار در خروجی هایشان باید صفر باشد
                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets: inputNetsNormal, pattern: patternForNormalCircuit);
                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets: inputNetsEncrypted, pattern: patternForEncryptedCircuit);

                samplesCount++;
                hammingDistanceRatio = CountHammingDistance(outputNetsEncrypted, outputNetsNormal, ref allX) / outputNetsEncrypted.Count;
                sumOfHammingDistanceRatios += hammingDistanceRatio;

                if (clockNetEncrypted != null)
                    for (int i = 0; i < clockTimes; i++)
                    {
                        //اول کلاک صفر وارد مدار می شود و آمار کل مدار گرفته می شود
                        Net.SValueMethods.Imply(clockNetEncrypted, Net.Signal.V0);
                        Net.SValueMethods.Imply(clockNetNormal, Net.Signal.V0);

                        samplesCount++;
                        hammingDistanceRatio = CountHammingDistance(outputNetsEncrypted, outputNetsNormal, ref allX) / outputNetsEncrypted.Count;
                        sumOfHammingDistanceRatios += hammingDistanceRatio;

                        //=====================================================================

                        //بعد کلاک یک وارد مدار می شود و آمار کل مدار گرفته می شود
                        Net.SValueMethods.Imply(clockNetEncrypted, Net.Signal.V1);
                        Net.SValueMethods.Imply(clockNetNormal, Net.Signal.V1);

                        samplesCount++;
                        hammingDistanceRatio = CountHammingDistance(outputNetsEncrypted, outputNetsNormal, ref allX) / outputNetsEncrypted.Count;
                        sumOfHammingDistanceRatios += hammingDistanceRatio;
                    }
            }
            var differenceRatio = Math.Round((((sumOfHammingDistanceRatios / samplesCount)) * 100), 2);
            var xRatio = Math.Round(((((double)allX / samplesCount)) * 100), 2);

            if (sumOfHammingDistanceRatios > 0)
                MessageBox.Show("Integrity Check Failed!\r\n Difference Ratio: " + differenceRatio, "Integrity Check", MessageBoxButtons.OK, MessageBoxIcon.Error);

            var integrityReport = "Difference Ratio:\t" + differenceRatio + "%\r\n" + 
                "X Ratio:\t" + xRatio.ToString() + "%\r\n";
            return integrityReport;
        }

        public static string CalculateHammingDistanceOfEncryptedNetlist(List<Net> encryptedNetList, bool uniqueRandomPatterns, int? randomPatterns, int randomSeed, string key, out string statisticalReport, int clockTimes, out HammingDistanceStatisticalResultHolder resultsHolder, bool forceWrongInputs)
        {
            resultsHolder = new HammingDistanceStatisticalResultHolder();

            double averageOfHammingDistanceRatiosPercent;
            var duplicateOfEncryptedNetlist = Net.SValueMethods.DuplicateNetlist(encryptedNetList);

            List<Net> middleNets1;
            List<Net> outputNets1;
            List<Net> inputNets1;
            Parser.ClassifyInputMiddleOutputNets(nets: encryptedNetList, inputNets: out inputNets1, outputNets: out outputNets1, middleNets: out middleNets1);
            var clockNet1 = CommonMethods.GetMainClockNet(encryptedNetList);
            inputNets1.Remove(clockNet1);

            List<Net> middleNets2;
            List<Net> outputNets2;
            List<Net> inputNets2;
            Parser.ClassifyInputMiddleOutputNets(nets: duplicateOfEncryptedNetlist, inputNets: out inputNets2, outputNets: out outputNets2, middleNets: out middleNets2);
            var clockNet2 = CommonMethods.GetMainClockNet(duplicateOfEncryptedNetlist);
            inputNets2.Remove(clockNet2);

            //نیازی به اصلاح نام نیست! چون هردو نت لیست های رمز شده هستند و نام خروجی شان یکی است

            ////چنانچه گیت کلیدی  (ورودی/اینورتر/گیت ایکسور ...) به خروجی راه پیدا کرده، پیشوند کلید و شماره کلید از نامش حذف میشود
            //foreach (var net in outputNets1)
            //    if (SMSSKeyManager.IsSMSKeyNet(net.Name))
            //        net.Name = SMSSKeyManager.ExtractOriginalNameFromSMSSKeyNetName(net.Name);

            ////چنانچه گیت کلیدی  (ورودی/اینورتر/گیت ایکسور ...) به خروجی راه پیدا کرده، پیشوند کلید و شماره کلید از نامش حذف میشود
            //foreach (var net in outputNets2)
            //    if (SMSSKeyManager.IsSMSKeyNet(net.Name))
            //        net.Name = SMSSKeyManager.ExtractOriginalNameFromSMSSKeyNetName(net.Name);

            outputNets1.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));
            outputNets2.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));

            inputNets1.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));
            inputNets2.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));

            middleNets1.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));
            middleNets2.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));

            // درابتدا یک لیست از رشته های ورودی تصادفی به طول ورودی های مدار درست می کنیم
            List<string> generatedRandomPatterns;
            if (uniqueRandomPatterns)
                generatedRandomPatterns = CommonMethods.RandomPatternGeneration.GenerateUniqueRandomPatterns(lenght: inputNets1.Count, count: randomPatterns.Value, seed: randomSeed);
            else
                generatedRandomPatterns = CommonMethods.RandomPatternGeneration.GenerateExtraUniqueRandomPatterns(lenght: inputNets1.Count, count: randomPatterns.Value, seed: randomSeed);

            double hammingDistanceRatio;
            var hammingDistanceRatios = new List<double>();

            double sumOfHammingDistanceRatios = 0;
            var samplesCount = 0;
            var allX = 0; // تعداد کل نت هایی است که مقدار ایکس داشته اند
            foreach (var randomPattern in generatedRandomPatterns)
            {
                //باید دو رشته ورودی داشته باشیم
                //یکی که در آن کلید ها مقدار نادرست دارند
                //و یکی که در آن مقدار هر کلید در سر جای خود به درستی اصلاح شده است

                var correctedPatternList = new List<char>();
                for (int index = 0; index < inputNets1.Count; index++)
                {
                    if (SMSSKeyManager.IsSMSKeyNet(inputNets1[index].Name))
                    {
                        var keyIndex = SMSSKeyManager.ExtractKeyIndexFromSMSSKeyName(inputNets1[index].Name);
                        correctedPatternList.Add(key[keyIndex - 1]);
                    }
                    else
                    {
                        correctedPatternList.Add(randomPattern[index]);
                    }
                }
                var correctedPattern = (string.Join("", correctedPatternList.ToArray())).Trim();
                var wrongPattern = randomPattern;

                //در زمان محاسبه همینگ دیستنس، مهاجم اطلاعی از کلید صحیح ندارد
                //ولذا امکان اینکه ورودی کاملا صحیح را به عنوان پترن تصادفی به مدار تزریق کند نیز وجود خواهد داشت
                //پس نباید جلوی ورودی کاملا صحیح را بگیریم

                if(forceWrongInputs)
                    if (correctedPattern == wrongPattern)
                        continue;

                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets1, wrongPattern);
                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets2, correctedPattern);

                samplesCount++;
                hammingDistanceRatio = CountHammingDistance(outputNets1, outputNets2, ref allX) / outputNets1.Count;
                hammingDistanceRatios.Add(hammingDistanceRatio);
                sumOfHammingDistanceRatios += hammingDistanceRatio;


                if (clockNet1 != null)
                    for (int i = 0; i < clockTimes; i++)
                    {
                        //if (clockNet1.SValue == Net.Signal.X)
                        //    clockNet1.SValue = Net.Signal.V0;
                        //Net.SValueMethods.Imply(clockNet1, GateNot.Function(clockNet1.SValue));
                        ////Net.SValueMethods.ClockSValue(clockNet);

                        Net.SValueMethods.Imply(clockNet1, Net.Signal.V0);
                        Net.SValueMethods.Imply(clockNet2, Net.Signal.V0);//New

                        samplesCount++;
                        hammingDistanceRatio = CountHammingDistance(outputNets1, outputNets2, ref allX) / outputNets1.Count;
                        hammingDistanceRatios.Add(hammingDistanceRatio);
                        sumOfHammingDistanceRatios += hammingDistanceRatio;


                        //if (clockNet2.SValue == Net.Signal.X)
                        //    clockNet2.SValue = Net.Signal.V0;
                        //Net.SValueMethods.Imply(clockNet2, GateNot.Function(clockNet2.SValue));
                        ////Net.SValueMethods.ClockSValue(clockNet2);

                        Net.SValueMethods.Imply(clockNet1, Net.Signal.V1);
                        Net.SValueMethods.Imply(clockNet2, Net.Signal.V1);//New

                        samplesCount++;
                        hammingDistanceRatio = CountHammingDistance(outputNets1, outputNets2, ref allX) / outputNets1.Count;
                        hammingDistanceRatios.Add(hammingDistanceRatio);
                        sumOfHammingDistanceRatios += hammingDistanceRatio;


                        //Net.SValueMethods.ClockSValue(clockNet);
                        //Net.SValueMethods.ClockSValue(clockNet2);

                        //samplesCount++;
                        //hammingDistanceRatio = HammingDistance(outputNets, outputNets2, ref allX) / outputNets.Count;
                        //sumOfHammingDistanceRatios += hammingDistanceRatio;
                    }
            }

            averageOfHammingDistanceRatiosPercent = Math.Round((((sumOfHammingDistanceRatios / samplesCount)) * 100), 2);

            resultsHolder.XRatio = Math.Round(((((double)allX / samplesCount)) * 100), 2);
            resultsHolder.HammingDistancePercent = averageOfHammingDistanceRatiosPercent;

            //===============================================================================================
            statisticalReport = "";

            //اندازه گیری مقدار انحراف کلیه نت های مدار از یک دوم
            //هرچقدر کوچکتر شود به هدف مورد نظر نزدیکتر شده ایم
            double averageDistanceFromHalf = 0.0;
            foreach (var hdRatio in hammingDistanceRatios)
            {
                averageDistanceFromHalf += Math.Pow(hdRatio - 0.5, 2) / hammingDistanceRatios.Count;
            }
            resultsHolder.RMSD = Math.Pow(averageDistanceFromHalf, 0.5);
            statisticalReport += "RMSD (Root Mean Square Deviation From 0.5):\t" + resultsHolder.RMSD + "\r\n";
            //---------------------------------------------------------

            resultsHolder.Average = 0.0;
            foreach (var hdRatio in hammingDistanceRatios)
            {
                resultsHolder.Average += hdRatio / hammingDistanceRatios.Count;
            }
            statisticalReport += "Average:\t" + resultsHolder.Average + "\r\n";

            //---------------------------------------------------------
            //اندازه گیری انحراف معیار کلیه نت های مدار از میانگین آنها
            //تنها پراکندگی نت ها را نشان می دهد 
            //و هرچقدر کوچکتر باشد یعنی نت ها به یک مقدار (که همان میانگینشان است) نزدیکترند
            double averageDistanceFromAverage = 0.0;
            foreach (var hdRatio in hammingDistanceRatios)
            {
                averageDistanceFromAverage += Math.Pow(hdRatio - resultsHolder.Average, 2) / hammingDistanceRatios.Count;
            }
            resultsHolder.StandardDeviation = Math.Pow(averageDistanceFromAverage, 0.5);
            statisticalReport += "Standard Deviation:\t" + resultsHolder.StandardDeviation + "\r\n";
            //===============================================================================================

            var hammingDistanceReport = "Average Hamming Distance:\t" + averageOfHammingDistanceRatiosPercent + "%\r\n" + "X Ratio:\t" + resultsHolder.XRatio + "%\r\n";
            return hammingDistanceReport;
        }

        /// <summary>
        /// خروجی ها باید قبلا بر اساس نام سورت شده باشند
        /// </summary>
        /// <param name="outputNets"></param>
        /// <param name="outputNets2"></param>
        /// <param name="allX"></param>
        /// <returns></returns>
        private static double CountHammingDistance(List<Net> outputNets, List<Net> outputNets2, ref int allX)
        {
            var xcount = 0;
            if (outputNets.Count != outputNets2.Count)
            {
                MessageBox.Show("Count of output nets are not equal!");
                return Math.Max(outputNets.Count, outputNets2.Count);
            }

            double hammingDistance = 0;
            for (int i = 0; i < outputNets.Count; i++)
            {
                if (outputNets[i].SValue != outputNets2[i].SValue)
                    hammingDistance++;

                else if (outputNets[i].SValue == Net.Signal.X && outputNets2[i].SValue == Net.Signal.X)
                    xcount++;
            }
            if (xcount == outputNets.Count)
                allX++;

            return hammingDistance;
        }
    }
}
