﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    internal class Greedy
    {
        public static void Alg14GreedyXKeys(List<Net> nets, string encryptionKey, out string addedKeyValues, int randomSeed, bool uniqueRandomPatterns, TextBox textBox, ProgressBar progressBar, SimulationReporter reportObject, int clockTimes, int threadsCount, int randomNumbers, string netlistName, bool forceWrongInputs, bool forceCalculate, int rRandomSeed, bool inverterMode = false)
        {
            var random = new Random(rRandomSeed);
            var t0 = DateTime.Now;
            var t1 = DateTime.Now;

            var keyInputs = new List<Net>();
            var keyGates = new List<Net>();
            addedKeyValues = "";

            progressBar.Value = 0;
            Application.DoEvents();

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Inserting new key gates ...");

            //Generate R ; //a random number
            var R = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(random, encryptionKey.Length);
            var GateType = FARajendran.Xor(encryptionKey, R);

            reportObject.Step02FinishRound(nets, "", forceCalculate: forceCalculate);
            for (int i = 0; i < encryptionKey.Length; i++)
            {

                var percent = ((double)i * 100 / encryptionKey.Length);
                var header = "Total Progress: " + (int)percent + "%\r\n" +
                             FaultImpacts.TimeEstimationString(t0, t1, percent) + "\r\n\r\n" +
                             "Calculating HammingDistances (" + (i + 1) + "/" + encryptionKey.Length + ")\r\n";

                string hammingDistancesLoadReport;
                List<Net> sortedNetsByHammingDistance = HD2.LoadOrCalculateAverageHammingDistanceForAllPossbileNets(
                    nets: nets,
                    percent: ref percent,
                    keyGates: keyGates,
                    keyInputs: keyInputs,
                    key: encryptionKey.Substring(0, i),
                    newKeyValue: encryptionKey[i], 
                    randomPatterns: randomNumbers, 
                    randomSeed: randomSeed, 
                    uniqueRandomPatterns: uniqueRandomPatterns, 
                    forceWrongInputs: forceWrongInputs, 
                    clockTimes: clockTimes,
                    threadsCount: threadsCount,
                    textBox: textBox,
                    header: header, 
                    loadReport: out hammingDistancesLoadReport,
                    forceCalculate: forceCalculate, 
                    allowSaveResults: true,
                    netlistName: netlistName,
                    inverterMode: inverterMode);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog(hammingDistancesLoadReport);

                Application.DoEvents();
                if (FaultImpacts.Exiting)
                    break;

                Net chosenNet = sortedNetsByHammingDistance[0];
                if (chosenNet == null)
                    break;

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Round " + (i + 1) + " Gate (" + chosenNet.Name + ") (" + chosenNet.HD + ")");

                //اول ایکسور می ذاره
                //به لیست اعمال شده های قبلی هم ورودی کلید و خود گیت کلید ایکسور را اضافه می کند
                //Insert XOR gate and update the Netlist;
                CommonMethods.InsertNewXORGateAfterLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs);

                //بعد اگه بیت کلید یک بود یک اینورتر سر راه ایکسور قرار میده
                if (R[i] == '1')
                {
                    //Insert an inverter at the o/p of corresponding keygate;
                    var newInverter = CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);
                }

                //بعد اگه بیت کلید یک بود، گیت ایکسور را با گیت ایکسنور تعویض می کند
                if (GateType[i] == '1')
                {
                    //گیت ایکسور را با ایکسنور جایگزین می کند

                    //Replace the XOR key-gate with an XNOR key-gate;
                    CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
                }

                addedKeyValues += encryptionKey[i];

                reportObject.Step02FinishRound(nets: nets, addedKeyValues: addedKeyValues, forceCalculate: forceCalculate);
            }

            reportObject.AddToConsoleLog("End of inserting key gates ...");
        }

        public static void Alg25SmartGreedyXKeys(List<Net> nets, string encryptionKey, out string addedKeyValues, int randomSeed, bool uniqueRandomPatterns, TextBox textBox, ProgressBar progressBar, SimulationReporter reportObject, int clockTimes, int threadsCount, int randomNumbers, string netlistName, bool forceWrongInputs, bool forceCalculate, int rRandomSeed, double rareThreshold, bool hdPower1, bool hdPower2, bool hdLR, bool inverterMode = false)
        {
            var random = new Random(rRandomSeed);
            var t0 = DateTime.Now;
            var t1 = DateTime.Now;

            var keyInputs = new List<Net>();
            var keyGates = new List<Net>();
            addedKeyValues = "";

            progressBar.Value = 0;
            Application.DoEvents();

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Inserting new key gates ...");

            //Generate R ; //a random number
            var gateType = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(random, encryptionKey.Length);

            reportObject.Step02FinishRound(nets, "", forceCalculate: forceCalculate);
            for (int i = 0; i < encryptionKey.Length; i++)
            {

                var percent = ((double)i * 100 / encryptionKey.Length);
                var header = "Total Progress: " + (int)percent + "%\r\n" +
                             FaultImpacts.TimeEstimationString(t0, t1, percent) + "\r\n\r\n" +
                             "Calculating HammingDistances (" + (i + 1) + "/" + encryptionKey.Length + ")\r\n";

                string hammingDistancesLoadReport;
                List<Net> sortedNetsByHammingDistance = HD3Smart.LoadOrCalculateAverageHammingDistanceAndNumberOfRareSignalsForAllPossbileNets(
                    nets: nets,
                    percent: ref percent,
                    keyGates: keyGates,
                    keyInputs: keyInputs,
                    key: encryptionKey.Substring(0, i),
                    newKeyValue: encryptionKey[i],
                    randomPatterns: randomNumbers,
                    randomSeed: randomSeed,
                    uniqueRandomPatterns: uniqueRandomPatterns,
                    forceWrongInputs: forceWrongInputs,
                    clockTimes: clockTimes,
                    threadsCount: threadsCount,
                    textBox: textBox,
                    header: header,
                    loadReport: out hammingDistancesLoadReport,
                    forceCalculate: forceCalculate,
                    allowSaveResults: true,
                    netlistName: netlistName,
                    rareThreshold: rareThreshold,
                    hdPower1: hdPower1,
                    hdPower2: hdPower2,
                    hdLR: hdLR,
                    inverterMode: inverterMode);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog(hammingDistancesLoadReport);

                Application.DoEvents();
                if (FaultImpacts.Exiting)
                    break;

                Net chosenNet = sortedNetsByHammingDistance[0];
                if (chosenNet == null)
                    break;

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Round " + (i + 1) + " Gate (" + chosenNet.Name + ") (" + chosenNet.HD + "," + chosenNet.numberOfRareSignalsForThisNet + ")");

                if (encryptionKey[i] == '0')
                {
                    if (gateType[i] == '0')
                    {
                        CommonMethods.InsertNewXORGateAfterLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs);
                    }
                    else
                    {
                        CommonMethods.InsertNewXNORGateAfterLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs);
                        CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);
                    }
                }
                else if (encryptionKey[i] == '1')
                {
                    if (gateType[i] == '0')
                    {
                        CommonMethods.InsertNewXNORGateAfterLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs);
                    }
                    else
                    {
                        CommonMethods.InsertNewXORGateAfterLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs);
                        CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);
                    } 
                }

                addedKeyValues += encryptionKey[i];

                reportObject.Step02FinishRound(nets: nets, addedKeyValues: addedKeyValues, forceCalculate: forceCalculate);
            }

            reportObject.AddToConsoleLog("End of inserting key gates ...");
        }

        //public static void Alg25SmartGreedyXKeys(List<Net> nets, string encryptionKey, out string addedKeyValues, int randomSeed, bool uniqueRandomPatterns, TextBox textBox, ProgressBar progressBar, SimulationReporter reportObject, int clockTimes, int threadsCount, int randomNumbers, string netlistName, bool forceWrongInputs, bool forceCalculate, int rRandomSeed, double rareThreshold, bool inverterMode = false)
        //{
        //    var random = new Random(rRandomSeed);
        //    var t0 = DateTime.Now;
        //    var t1 = DateTime.Now;

        //    var keyInputs = new List<Net>();
        //    var keyGates = new List<Net>();
        //    addedKeyValues = "";

        //    progressBar.Value = 0;
        //    Application.DoEvents();

        //    //++++++++++++++++++++++++++
        //    reportObject.AddToConsoleLog("Inserting new key gates ...");

        //    //Generate R ; //a random number
        //    var R = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(random, encryptionKey.Length);
        //    var GateType = FARajendran.Xor(encryptionKey, R);

        //    reportObject.Step02FinishRound(nets, "", forceCalculate: forceCalculate);
        //    for (int i = 0; i < encryptionKey.Length; i++)
        //    {

        //        var percent = ((double)i * 100 / encryptionKey.Length);
        //        var header = "Total Progress: " + (int)percent + "%\r\n" +
        //                     FaultImpacts.TimeEstimationString(t0, t1, percent) + "\r\n\r\n" +
        //                     "Calculating HammingDistances (" + (i + 1) + "/" + encryptionKey.Length + ")\r\n";

        //        string hammingDistancesLoadReport;
        //        List<Net> sortedNetsByHammingDistance = HD3Smart.LoadOrCalculateAverageHammingDistanceForAllPossbileNets(
        //            nets: nets,
        //            percent: ref percent,
        //            keyGates: keyGates,
        //            keyInputs: keyInputs,
        //            key: encryptionKey.Substring(0, i),
        //            newKeyValue: encryptionKey[i],
        //            randomPatterns: randomNumbers,
        //            randomSeed: randomSeed,
        //            uniqueRandomPatterns: uniqueRandomPatterns,
        //            forceWrongInputs: forceWrongInputs,
        //            clockTimes: clockTimes,
        //            threadsCount: threadsCount,
        //            textBox: textBox,
        //            header: header,
        //            loadReport: out hammingDistancesLoadReport,
        //            forceCalculate: forceCalculate,
        //            allowSaveResults: true,
        //            netlistName: netlistName,
        //            rareThreshold: rareThreshold,
        //            inverterMode: inverterMode);

        //        //++++++++++++++++++++++++++
        //        reportObject.AddToConsoleLog(hammingDistancesLoadReport);

        //        Application.DoEvents();
        //        if (FaultImpacts.Exiting)
        //            break;

        //        Net chosenNet = sortedNetsByHammingDistance[0];
        //        if (chosenNet == null)
        //            break;

        //        //++++++++++++++++++++++++++
        //        reportObject.AddToConsoleLog("Round " + (i + 1) + " Gate (" + chosenNet.Name + ") (" + chosenNet.HD + ")");

        //        //اول ایکسور می ذاره
        //        //به لیست اعمال شده های قبلی هم ورودی کلید و خود گیت کلید ایکسور را اضافه می کند
        //        //Insert XOR gate and update the Netlist;
        //        CommonMethods.InsertNewXORGateAfterLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs);

        //        //بعد اگه بیت کلید یک بود یک اینورتر سر راه ایکسور قرار میده
        //        if (R[i] == '1')
        //        {
        //            //Insert an inverter at the o/p of corresponding keygate;
        //            var newInverter = CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);
        //        }

        //        //بعد اگه بیت کلید یک بود، گیت ایکسور را با گیت ایکسنور تعویض می کند
        //        if (GateType[i] == '1')
        //        {
        //            //گیت ایکسور را با ایکسنور جایگزین می کند

        //            //Replace the XOR key-gate with an XNOR key-gate;
        //            CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
        //        }

        //        addedKeyValues += encryptionKey[i];

        //        reportObject.Step02FinishRound(nets: nets, addedKeyValues: addedKeyValues, forceCalculate: forceCalculate);
        //    }

        //    reportObject.AddToConsoleLog("End of inserting key gates ...");
        //}

    }
}
