﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace LogicEncryption.Classes.LogicEncryption.Greedy
//{
//    public class RandomPatternsForGreedy
//    {
//        public static void GenerateRandomPatterns(List<Net> nets, string key, int randomPatterns, int randomSeed, bool uniqueRandomPatterns, ref List<string> generatedRandomPatterns, ref List<string> correctedPatterns)
//        {
//            List<Net> middleNets;
//            List<Net> outputNets;
//            List<Net> inputNets;
//            Parser.ClassifyInputMiddleOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets);
//            var clockNet = CommonMethods.GetMainClockNet(nets);
//            inputNets.Remove(clockNet);

//            GetGeneratedRandomPatterns(
//                key: key,
//                randomPatterns: randomPatterns,
//                randomSeed: randomSeed,
//                uniqueRandomPatterns: uniqueRandomPatterns,
//                inputNets: inputNets,
//                generatedRandomPatterns: out generatedRandomPatterns,
//                correctedPatterns: out correctedPatterns);
//        }

//        public static void GetGeneratedRandomPatterns(string key, int randomPatterns, int randomSeed, bool uniqueRandomPatterns, List<Net> inputNets, out List<string> generatedRandomPatterns, out List<string> correctedPatterns)
//        {
//            // درابتدا یک لیست از رشته های ورودی تصادفی به طول ورودی های مدار درست می کنیم
//            if (uniqueRandomPatterns)
//                generatedRandomPatterns = CommonMethods.RandomPatternGeneration.GenerateUniqueRandomPatterns(lenght: inputNets.Count + 1 /*//NEW*/ , count: randomPatterns, seed: randomSeed);
//            else
//                generatedRandomPatterns = CommonMethods.RandomPatternGeneration.GenerateExtraUniqueRandomPatterns(lenght: inputNets.Count + 1 /*//NEW*/ , count: randomPatterns, seed: randomSeed);

//            correctedPatterns = new List<string>();
//            foreach (var randomPattern in generatedRandomPatterns)
//            {
//                //باید دو رشته ورودی داشته باشیم
//                //یکی که در آن کلید ها مقدار نادرست دارند
//                //و یکی که در آن مقدار هر کلید در سر جای خود به درستی اصلاح شده است

//                var correctedPatternList = new List<char>();
//                for (int index = 0; index < inputNets.Count; index++)
//                {
//                    if (SMSSKeyManager.IsSMSKeyNet(inputNets[index].Name))
//                    {
//                        var keyIndex = SMSSKeyManager.ExtractKeyIndexFromSMSSKeyName(inputNets[index].Name);
//                        correctedPatternList.Add(key[keyIndex - 1]);
//                    }
//                    else
//                    {
//                        correctedPatternList.Add(randomPattern[index]);
//                    }
//                }

//                //با فرض اینکه ترتیب ها بهم نخورده
//                //و کلید جدید همواره آخرین خواهد بود!!
//                correctedPatternList.Add('0');//New
//                var correctedPattern = (string.Join("", correctedPatternList.ToArray())).Trim();
//                correctedPatterns.Add(correctedPattern);
//            }
//        }

//    }
//}
