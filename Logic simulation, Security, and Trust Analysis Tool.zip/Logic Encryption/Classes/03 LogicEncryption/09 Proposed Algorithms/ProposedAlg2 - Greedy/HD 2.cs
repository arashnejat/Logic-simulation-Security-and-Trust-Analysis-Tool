﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public class HD2
    {
        public static List<Net> LoadOrCalculateAverageHammingDistanceForAllPossbileNets(List<Net> nets, List<Net> keyGates, List<Net> keyInputs, string key, char newKeyValue, int randomPatterns, int randomSeed, bool uniqueRandomPatterns, bool forceWrongInputs, int clockTimes, ref double percent, int threadsCount, TextBox textBox, string header, out string loadReport, bool forceCalculate, bool allowSaveResults, string netlistName, bool inverterMode = false)
        {
            var cacheFileName = netlistName +
                                CacheManager.GetHashFromNets(nets) +
                                "Count=" + randomPatterns + "," +
                                "Unique=" + uniqueRandomPatterns.ToString() + "," +
                                "Seed=" + randomSeed + "," +
                                "Ticks=" + clockTimes + "," +
                                "Frcw=" + forceWrongInputs + 
                                (inverterMode ? "NOT" : "") +
                                ".hds";

            var cacheFilePath = CacheManager.CacheDirectory + cacheFileName;

            List<Net> sortedNetsByHammingDistance;
            if (!forceCalculate && !string.IsNullOrEmpty(netlistName))
            {
                if (SamimiIO.Exists(cacheFilePath))
                {
                    if (LoadAverageHammingDistancesFromFile(cacheFilePath, nets, out sortedNetsByHammingDistance))
                    {
                        loadReport = "HammingDistances Loaded From File:\t" + cacheFileName;
                        return sortedNetsByHammingDistance;
                    }
                }
            }

            var s = new Stopwatch();
            s.Start();

            sortedNetsByHammingDistance = CalculateAverageHammingDistanceForAllPossibleNets(
                    nets: nets,
                    percent: ref percent,
                    keyGates: keyGates,
                    keyInputs: keyInputs,
                    key: key,
                    newKeyValue: newKeyValue,
                    randomPatterns: randomPatterns,
                    randomSeed: randomSeed,
                    uniqueRandomPatterns: uniqueRandomPatterns,
                    forceWrongInputs: forceWrongInputs,
                    clockTimes: clockTimes,
                    threadsCount: threadsCount,
                    textBox: textBox,
                    header: header,
                    inverterMode: inverterMode);

            s.Stop();
            loadReport = "HammingDistances Calculation Duration:\t" + s.Elapsed;

            if (allowSaveResults)
            {
                SaveAverageHammingDistancesToFile(cacheFilePath, sortedNetsByHammingDistance);
                loadReport += "\r\n" + "Saved To File:\t" + cacheFileName;
            }
            return sortedNetsByHammingDistance;
        }

        private static void SaveAverageHammingDistancesToFile(string cacheFilePath, List<Net> nets)
        {
            if (SamimiIO.Exiting)
                return;

            var dataToSave = new List<string>();

            foreach (var net in nets)
            {
                dataToSave.Add(net.Name + "\t" + net.HD);
            }

            var str = string.Join("\r\n", dataToSave);

            SamimiIO.WriteAllText(cacheFilePath, str);
        }

        private static bool LoadAverageHammingDistancesFromFile(string cacheFilePath, List<Net> nets, out List<Net> sortedNetlist)
        {
            try
            {
                var str = SamimiIO.ReadAllText(cacheFilePath);

                string[] seperators = { "\r\n", "\t" };

                var data = str.Split(seperators, StringSplitOptions.RemoveEmptyEntries);

                sortedNetlist = new List<Net>();

                var loadedNetsCount = 0;
                for (int i = 0; i < data.Length; i += 2)
                {
                    var foundNet = nets.Find(net => net.Name == data[i + 0]);
                    loadedNetsCount++;

                    foundNet.HD = double.Parse(data[i + 1]);//2

                    sortedNetlist.Add(foundNet);
                }

                //var goalCountFaultImpactNets = new List<Net>(nets);
                //var clockNet = CommonMethods.GetMainClockNet(nets);
                //goalCountFaultImpactNets.Remove(clockNet);
                //RemoveNonGateNets(goalCountFaultImpactNets);

                if (loadedNetsCount != nets.Count)
                    throw new Exception("Count not equal, Load failed.");

                //faultImpactNets.Sort((net1, net2) => net2.FaultImpact - net1.FaultImpact);

                return true;
            }
            catch (Exception exception)
            {
                sortedNetlist = new List<Net>(nets);
                return false;
            }
        }

        //=======================================================

        public static List<Net> CalculateAverageHammingDistanceForAllPossibleNets(List<Net> nets, List<Net> keyGates, List<Net> keyInputs, string key, char newKeyValue, int randomPatterns, int randomSeed, bool uniqueRandomPatterns, bool forceWrongInputs, int clockTimes, ref double percent, int threadsCount, TextBox textBox, string header, bool inverterMode = false)
        {
            Net.ToStringMode = Net.NetToStringMode.SValue;
            
            List<string> generatedRandomPatterns = null;
            List<string> correctedPatterns = null;
            var t0 = DateTime.Now;

            List<Net> middleNets;
            List<Net> outputNets;
            List<Net> inputNets;
            Parser.ClassifyInputMiddleOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets);
            var clockNet = CommonMethods.GetMainClockNet(nets);
            inputNets.Remove(clockNet);//خطر بر هم زدن نظم ورودی ها درمدارات ترتیبی //Danger

            //توجه: در ابتدا، پترن های اصلاح شده طولشان یک بیت کمتر از پترن های اصلاح نشده است
            RandomPatternsForGreedy2.GetGeneratedRandomPatterns(
                            key: key,
                            randomPatterns: randomPatterns,
                            randomSeed: randomSeed,
                            uniqueRandomPatterns: uniqueRandomPatterns,
                            inputNets: inputNets,
                            generatedRandomPatterns: out generatedRandomPatterns,
                            correctedPatterns: out correctedPatterns,
                            inverterMode: inverterMode);

            //توجه: پترن های اصلاح شده طولشان یک بیت کمتر از پترن های اصلاح نشده است
            //خروجی های مدار را بر اساس اعمال ورودی های صحیح محاسبه کرده و نگهداری می کنیم
            var correctOutputResults = GetCorrectOutputResults(
                    generatedRandomPatterns: generatedRandomPatterns,
                    correctedPatterns: correctedPatterns,
                    nets: nets,
                    clockNet: clockNet,
                    forceWrongInputs: forceWrongInputs,
                    inputNets: inputNets,
                    outputNets: outputNets,
                    clockTimes: clockTimes);

            var netsHolder = new List<List<Net>>();
            var parameterHolder = new List<HD2.HDThreadData2>();

            if (textBox != null)
            {
                textBox.Text = header + "Preparing Threads...";
                Application.DoEvents();
            }

            //Very Important
            foreach (var net in nets)
                net.HD = 0; //Very Important

            //Creating Duplicates Of Netlist for each Thread (First netlist, is the original one)
            netsHolder.Add(nets);
            if (threadsCount > 1)
                netsHolder.AddRange(Net.SValueMethods.DuplicateNetlist(nets, threadsCount - 1));

            //Creating Parameters To Send To Threads
            for (var i = 0; i < threadsCount; i++)
            {
                parameterHolder.Add(new HDThreadData2()
                {
                    ClockTimes = clockTimes,
                    Nets = netsHolder[i],
                    RandomNumbers = randomPatterns,
                    ThreadNumbers = threadsCount,
                    IndexOfThread = i,
                    GeneratedRandomPatterns = generatedRandomPatterns,
                    CorrectedPatterns = correctedPatterns,
                    Percent = 0,
                    forceWrongInputs = forceWrongInputs,
                    key = key,
                    keyGates = new List<Net>(keyGates),
                    keyInputs = new List<Net>(keyInputs),
                    randomSeed = randomSeed,
                    uniqueRandomPatterns = uniqueRandomPatterns,
                    CorrectOutputResults = new List<Dictionary<string, Net.Signal>>(correctOutputResults)
                });
            }

            if (textBox != null)
            {
                textBox.Text = header + "Starting Threads...";
                Application.DoEvents();
            }

            //Creating & Starting Threads
            var threadsHolder = new List<Thread>();
            for (var i = 0; i < threadsCount; i++)
            {
                Thread thread;
                if(inverterMode) 
                    thread = new Thread(TemporaryInverterInsertionThread);//IdeaTesting
                else 
                    thread = new Thread(TemporaryXORInsertionThread);

                threadsHolder.Add(thread);
                thread.Start(parameterHolder[i]);
            }

            string threadsStatus;

            if (textBox != null)
            {
                textBox.Text = header + "Working...";
                Application.DoEvents();
            }

            var t1 = DateTime.Now;
            var allDone = false;
            while (!allDone && !SamimiIO.Exiting)
            {
                threadsStatus = "";
                percent = 0;

                allDone = true;
                for (var i = 0; i < threadsHolder.Count; i++)
                {
                    var thread = threadsHolder[i];

                    if (thread.IsAlive)
                        allDone = false;

                    if (SamimiIO.Exiting)
                        thread.Abort();

                    if (textBox != null)
                    {
                        percent += parameterHolder[i].Percent / threadsHolder.Count;
                        threadsStatus += (int)parameterHolder[i].Percent + "% ";
                    }
                }

                if (textBox != null)
                {
                    textBox.Text = header + "Threads Status: " + threadsStatus + "\r\n";
                    textBox.Text += FaultImpacts.TimeEstimationString(t0, t1, percent);
                    //if (progressBar != null)
                    //    progressBar.Value = (int)percent;
                    Application.DoEvents();
                }

                if (!allDone && nets.Count > 100)
                    Thread.Sleep(1000);
            }

            if (textBox != null)
            {
                textBox.Text = header + "Merging Threads Results...";
                Application.DoEvents();
            }

            //Merging Results
            for (var i = 0; i < nets.Count; i++)
            {
                var net = nets[i];
                for (var j = 1; j < netsHolder.Count; j++)
                    net.HD += netsHolder[j][i].HD;
            }

            //var finalNets = parameterHolder[0].Nets;

            if (SamimiIO.Exiting)
            {
                //report = null;
                return null;
            }
            //===================================================================================

            var sortedNets = nets.OrderBy(net => Math.Abs(net.HD - 0.5)).ThenBy(net => net.Name).ToList();
            return sortedNets;
        }

        public static void ComputeAverageHammingDistanceForExaminingNet(List<Net> nets, int randomPatterns, int randomSeed, bool uniqueRandomPatterns, List<string> generatedRandomPatterns, List<string> correctedPatterns, Net examiningNet, bool forceWrongInputs, int clockTimes, List<Dictionary<string, Net.Signal>> correctOutputResults)
        {
            //توضیح اینکه امکان دارد که قصد درج کلید در خروجی یا ورودی مدار را داشته باشیم و از این رو
            //این امکان وجود دارد که خروجی های مدار تغییر کنند
            //پس باید هربار دوباره پیدا شوند
            List<Net> middleNets;
            List<Net> outputNets;
            List<Net> inputNets;
            Parser.ClassifyInputMiddleOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets);
            var clockNet = CommonMethods.GetMainClockNet(nets);
            inputNets.Remove(clockNet);//خطر //Danger

            double sumOfHammingDistanceRatios = 0;
            double samplesCount = correctOutputResults.Count;

            //Round2:
            foreach (var net in nets)
            {
                net.SValue = Net.Signal.X;
                if (net is FlipFlop)
                    ((FlipFlop)net).ResetMemory();
            }

            var compareIndex = 0;
            for (int index = 0; index < generatedRandomPatterns.Count; index++)
            {
                if (SamimiIO.Exiting)
                    break;

                //چنانچه مدار ترکیبی است
                if (clockNet == null)
                {
                    //!!سرعت را افزایش می دهد ولی تنها برای مدار های ترکیبی!!
                    foreach (var net in nets)
                    {
                        net.SValue = Net.Signal.X;
                        if (net is FlipFlop)
                            ((FlipFlop)net).ResetMemory();
                    }
                }

                var wrongPattern = generatedRandomPatterns[index]; //مهم بیت کلید مربوط به گیت موقتی در پترن تصادفی بصورت تصادفی بین 0 و 1 در نتاوب است
                var correctedPattern = correctedPatterns[index] + '0'; //مهم بیت کلید مربوط به گیت موقتی در پترن صحیح برابر با 0 است

                //بررسی اینکه حداقل یکی از ورودی های کلید در الگوی تصادفی، مقدار اشتباه داشته باشد
                if (forceWrongInputs)
                    if (correctedPattern == wrongPattern)
                        continue;

                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets, wrongPattern);

                sumOfHammingDistanceRatios += CountHammingDistance(outputNets, correctOutputResults, compareIndex++) / outputNets.Count;

                if (clockNet != null)
                    for (int i = 0; i < clockTimes; i++)
                    {
                        Net.SValueMethods.Imply(clockNet, Net.Signal.V0);
                        sumOfHammingDistanceRatios += CountHammingDistance(outputNets, correctOutputResults, compareIndex++) / outputNets.Count;

                        Net.SValueMethods.Imply(clockNet, Net.Signal.V1);
                        sumOfHammingDistanceRatios += CountHammingDistance(outputNets, correctOutputResults, compareIndex++) / outputNets.Count;
                    }
            }

            examiningNet.HD = sumOfHammingDistanceRatios / samplesCount;
        }

        public static void ComputeAverageHammingDistanceForExaminingNetInverter(List<Net> nets, int randomPatterns, int randomSeed, bool uniqueRandomPatterns, List<string> generatedRandomPatterns, List<string> correctedPatterns, Net examiningNet, bool forceWrongInputs, int clockTimes, List<Dictionary<string, Net.Signal>> correctOutputResults)
        {
            //توضیح اینکه امکان دارد که قصد درج کلید در خروجی یا ورودی مدار را داشته باشیم و از این رو
            //این امکان وجود دارد که خروجی های مدار تغییر کنند
            //پس باید هربار دوباره پیدا شوند
            List<Net> middleNets;
            List<Net> outputNets;
            List<Net> inputNets;
            Parser.ClassifyInputMiddleOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets);
            var clockNet = CommonMethods.GetMainClockNet(nets);
            inputNets.Remove(clockNet);//خطر //Danger

            double sumOfHammingDistanceRatios = 0;
            double samplesCount = correctOutputResults.Count;

            //Round2:
            foreach (var net in nets)
            {
                net.SValue = Net.Signal.X;
                if (net is FlipFlop)
                    ((FlipFlop)net).ResetMemory();
            }

            var compareIndex = 0;
            for (int index = 0; index < generatedRandomPatterns.Count; index++)
            {
                if (SamimiIO.Exiting)
                    break;

                //چنانچه مدار ترکیبی است
                if (clockNet == null)
                {
                    //!!سرعت را افزایش می دهد ولی تنها برای مدار های ترکیبی!!
                    foreach (var net in nets)
                    {
                        net.SValue = Net.Signal.X;
                        if (net is FlipFlop)
                            ((FlipFlop)net).ResetMemory();
                    }
                }

                var randomPattern = generatedRandomPatterns[index];
                //var randomPattern = generatedRandomPatterns[index].Substring(0, generatedRandomPatterns[index].Length - 1); //این کار در خود تابع تولید پترن تصادفی انجام می گردد و دیگر نیازی نیست

                //var correctedPattern = correctedPatterns[index];  //در مورد معکوس کننده نیازی نیست

                //if (forceWrongInputs)                         //در مورد معکوس کننده نیازی نیست
                //    if (correctedPattern == wrongPattern)     //در مورد معکوس کننده نیازی نیست
                //        continue;                             //در مورد معکوس کننده نیازی نیست

                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets, randomPattern);

                sumOfHammingDistanceRatios += CountHammingDistance(outputNets, correctOutputResults, compareIndex++) / outputNets.Count;

                if (clockNet != null)
                    for (int i = 0; i < clockTimes; i++)
                    {
                        Net.SValueMethods.Imply(clockNet, Net.Signal.V0);
                        sumOfHammingDistanceRatios += CountHammingDistance(outputNets, correctOutputResults, compareIndex++) / outputNets.Count;

                        Net.SValueMethods.Imply(clockNet, Net.Signal.V1);
                        sumOfHammingDistanceRatios += CountHammingDistance(outputNets, correctOutputResults, compareIndex++) / outputNets.Count;
                    }
            }

            examiningNet.HD = sumOfHammingDistanceRatios / samplesCount;
        }

        public class HDThreadData2
        {
            public List<Net> Nets;
            public double Percent = 0;
            public List<string> GeneratedRandomPatterns = null;
            public List<string> CorrectedPatterns = null;
            public int RandomNumbers = 1000;
            public int ClockTimes = 5;
            public int ThreadNumbers;
            public int IndexOfThread;
            public List<Net> keyGates;
            public List<Net> keyInputs;
            public string key;
            public int randomSeed;
            public bool uniqueRandomPatterns;
            public bool forceWrongInputs;
            public List<Dictionary<string, Net.Signal>> CorrectOutputResults;
        }

        /// <summary>
        /// ترد اصلی محاسبه متوسط فاصله همینگ
        /// </summary>
        /// <param name="o"></param>
        public static void TemporaryXORInsertionThread(object o)
        {
            var p = (HDThreadData2)o;

            var from = (p.Nets.Count * p.IndexOfThread / p.ThreadNumbers);
            var to = ((p.Nets.Count * (p.IndexOfThread + 1) / p.ThreadNumbers));
            if (p.IndexOfThread == p.ThreadNumbers - 1)
                to = p.Nets.Count;

            for (int i = from; i < to; i++)
            {
                if (SamimiIO.Exiting)
                    break;

                var examiningNet = p.Nets[i];
                examiningNet.HD = 0;

                p.Percent = (((i - from) / (double)(to - from)) * 100);

                var keyGatesToUndo = new List<Net>();
                var keyInputsToUndo = new List<Net>();

                //درج یک گیت کلید موقتی در مدار
                //اول ورودی کلید
                //دوم ایکسکی
                CommonMethods.InsertNewXORGateAfterLocation(nets: p.Nets, location: examiningNet, keyGates: p.keyGates, keyInputs: p.keyInputs, temp: true);

                keyGatesToUndo.Add(p.keyGates[p.keyGates.Count - 1]);
                keyInputsToUndo.Add(p.keyInputs[p.keyInputs.Count - 1]);

                ComputeAverageHammingDistanceForExaminingNet(
                        nets: p.Nets,
                        examiningNet: examiningNet,
                        generatedRandomPatterns: p.GeneratedRandomPatterns,
                        correctedPatterns: p.CorrectedPatterns,
                        forceWrongInputs: p.forceWrongInputs,
                        clockTimes: p.ClockTimes,
                        randomPatterns: p.RandomNumbers,
                        randomSeed: p.randomSeed,
                        uniqueRandomPatterns: p.uniqueRandomPatterns,
                        correctOutputResults: p.CorrectOutputResults);

                UndoChanges(nets: p.Nets, keyGates: p.keyGates, keyInputs: p.keyInputs, keyInputsToUndo: keyInputsToUndo, keyGatesToUndo: keyGatesToUndo);
            }
            p.Percent = 100;
        }

        /// <summary>
        /// ترد اصلی محاسبه متوسط فاصله همینگ
        /// </summary>
        /// <param name="o"></param>
        public static void TemporaryInverterInsertionThread(object o)
        {
            var p = (HDThreadData2)o;

            var from = (p.Nets.Count * p.IndexOfThread / p.ThreadNumbers);
            var to = ((p.Nets.Count * (p.IndexOfThread + 1) / p.ThreadNumbers));
            if (p.IndexOfThread == p.ThreadNumbers - 1)
                to = p.Nets.Count;

            for (int i = from; i < to; i++)
            {
                if (SamimiIO.Exiting)
                    break;

                var examiningNet = p.Nets[i];
                examiningNet.HD = 0;

                p.Percent = (((i - from) / (double)(to - from)) * 100);

                var keyGatesToUndo = new List<Net>();
                var keyInputsToUndo = new List<Net>();

                //درج یک گیت کلید موقتی معکوس کننده در مدار
                var insertedInverter = CommonMethods.CreateAndInsertInverterAfterLocation(nets: p.Nets, location: examiningNet, index: 999, temp: true);
                
                keyGatesToUndo.Add(insertedInverter);

                ComputeAverageHammingDistanceForExaminingNetInverter(
                        nets: p.Nets,
                        examiningNet: examiningNet,
                        generatedRandomPatterns: p.GeneratedRandomPatterns,
                        correctedPatterns: p.CorrectedPatterns,
                        forceWrongInputs: p.forceWrongInputs,
                        clockTimes: p.ClockTimes,
                        randomPatterns: p.RandomNumbers,
                        randomSeed: p.randomSeed,
                        uniqueRandomPatterns: p.uniqueRandomPatterns,
                        correctOutputResults: p.CorrectOutputResults);

                UndoChanges(nets: p.Nets, keyGates: p.keyGates, keyInputs: p.keyInputs, keyInputsToUndo: keyInputsToUndo, keyGatesToUndo: keyGatesToUndo);
            }
            p.Percent = 100;
        }

        /// <summary>
        /// ورودی های صحیح را به مدار اعمال می کند و خروجی های صحیح را در دیکشنری نتایج نگه می دارد
        /// </summary>
        /// <param name="generatedRandomPatterns"></param>
        /// <param name="correctedPatterns"></param>
        /// <param name="nets"></param>
        /// <param name="clockNet"></param>
        /// <param name="forceWrongInputs"></param>
        /// <param name="inputNets"></param>
        /// <param name="outputNets"></param>
        /// <param name="clockTimes"></param>
        /// <returns></returns>
        private static List<Dictionary<string, Net.Signal>> GetCorrectOutputResults(List<string> generatedRandomPatterns, List<string> correctedPatterns, List<Net> nets, Net clockNet, bool forceWrongInputs, List<Net> inputNets, List<Net> outputNets, int clockTimes)
        {
            var results = new List<Dictionary<string, Net.Signal>>();

            //Round1:
            foreach (var net in nets)
            {
                net.SValue = Net.Signal.X;
                if (net is FlipFlop)
                    ((FlipFlop)net).ResetMemory();
            }

            for (int index = 0; index < generatedRandomPatterns.Count; index++)
            {
                if (SamimiIO.Exiting)
                    break;

                //چنانچه مدار ترکیبی است
                //هربار مدار را ریست کنیم
                if (clockNet == null)
                {
                    //!!سرعت را افزایش می دهد ولی تنها برای مدار های ترکیبی!!
                    foreach (var net in nets)
                    {
                        net.SValue = Net.Signal.X;
                        if (net is FlipFlop)
                            ((FlipFlop)net).ResetMemory();
                    }
                }

                var wrongPattern = generatedRandomPatterns[index];
                var correctedPattern = correctedPatterns[index];

                //بررسی اینکه حداقل یکی از ورودی های کلید در الگوی تصادفی، مقدار اشتباه داشته باشد
                //توجه: در ابتدا، پترن های اصلاح شده طولشان یک بیت کمتر از پترن های اصلاح نشده است
                if (forceWrongInputs)
                    if (correctedPattern + '0' == wrongPattern)
                        continue;

                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets, correctedPattern);

                StoreResults(outputNets, results);

                if (clockNet != null)
                    for (int i = 0; i < clockTimes; i++)
                    {
                        Net.SValueMethods.Imply(clockNet, Net.Signal.V0);
                        StoreResults(outputNets, results);

                        Net.SValueMethods.Imply(clockNet, Net.Signal.V1);
                        StoreResults(outputNets, results);
                    }
            }

            foreach (var net in nets)
            {
                net.SValue = Net.Signal.X;
                if (net is FlipFlop)
                    ((FlipFlop)net).ResetMemory();
            }

            return results;
        }

        /// <summary>
        /// گیت موقت اضافه شده به مدار را حذف کرده و مدار را به حالت قبل از درج گیت موقت بر می گرداند
        /// </summary>
        /// <param name="nets"></param>
        /// <param name="keyInputs"></param>
        /// <param name="keyGates"></param>
        /// <param name="keyInputsToUndo"></param>
        /// <param name="keyGatesToUndo"></param>
        private static void UndoChanges(List<Net> nets, List<Net> keyInputs, List<Net> keyGates, List<Net> keyInputsToUndo, List<Net> keyGatesToUndo)
        {
            foreach (var net in keyInputsToUndo)
            {
                nets.Remove(net);
                keyInputs.Remove(net);

                var inputDone = false;
                foreach (var nextGate in net.NextNets)
                {
                    foreach (var input in nextGate.Inputs)
                    {
                        if (input.Net == net)
                        {
                            input.Net = null;
                            input.Name = null;

                            inputDone = true;
                            break;
                        }
                    }
                    if (inputDone)
                        break;
                }
            }

            foreach (var net in keyGatesToUndo)
            {
                nets.Remove(net);
                keyGates.Remove(net);

                foreach (var healthyInput in net.Inputs)
                {
                    if (healthyInput.Net == null)
                        continue;

                    foreach (var nextNet in net.NextNets)
                    {
                        foreach (var inputOfNextGate in nextNet.Inputs)
                        {
                            if (inputOfNextGate.Net.Name == net.Name)
                            {
                                inputOfNextGate.Net = healthyInput.Net;
                                inputOfNextGate.Name = healthyInput.Net.Name;

                                //healthyInput.Net.NextNets.Remove(net);
                                healthyInput.Net.NextNets.Add(nextNet);
                            }
                        }
                    }

                    healthyInput.Net.NextNets.Remove(net);

                    healthyInput.Net.IsPrimaryOutput = net.IsPrimaryOutput;
                }
            }
        }

        /// <summary>
        /// طول فاصله همینگرا بین خروجی های فعلی و خروجی های محاسبه شده قبلی ، محاسبه می کند
        /// </summary>
        /// <param name="outputNets"></param>
        /// <param name="results"></param>
        /// <param name="compareIndex"></param>
        /// <returns></returns>
        public static double CountHammingDistance(List<Net> outputNets, List<Dictionary<string, Net.Signal>> results, int compareIndex)
        {
            double hammingDistance = 0;
            
            //خروجی های تولید شده در این سری را با اولین لیست خروجی های موجود در لیست نتایج مقایسه می کند
            for (int i = 0; i < outputNets.Count; i++)
            {
                var outputNet = outputNets[i];
                var name = outputNet.Name;

                //چنانچه یکی از خروجی ها، از نوع گیت موقتی بود
                //نام حقیقی گیت قبلی از نام گیت موقتی استخراج گردد و مقایسه خروجی ها
                //بر طبق نام حقیقی صورت پذیرد
                if (outputNet.IsTempGate)
                    name = SMSSKeyManager.ExtractOriginalNameFromSMSSKeyNetName(name);

                if (results[compareIndex][name] != outputNet.SValue)
                    hammingDistance++;
            }

            //اولین لیست خروجی های موجود در لیست نتایج را پاک می کند
            //results.RemoveAt(0);

            return hammingDistance;
        }

        private static void StoreResults(List<Net> outputNets, List<Dictionary<string, Net.Signal>> results)
        {
            //به ازای هر سری از خروجی ها، دیکشنری درست می کند از ترکیب نام خروجی و مقدار آن خروجی
            var dic = new Dictionary<string, Net.Signal>();
            foreach (var outputNet in outputNets)
                dic.Add(outputNet.Name, outputNet.SValue);
            
            //دیکشنری ایجاد شده را به لیست نتایج اضافه می کند
            results.Add(dic);
        }
    }
}
