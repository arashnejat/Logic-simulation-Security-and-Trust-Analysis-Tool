﻿//using System;
//using System.Collections.Generic;
//using System.Diagnostics;
//using System.Linq;
//using System.Text;
//using System.Threading;
//using System.Threading.Tasks;
//using System.Windows.Forms;
//
//using LogicEncryption.Classes.LogicEncryption.Greedy;

//namespace LogicEncryption
//{
//    public class HD
//    {
//        public static List<Net> LoadOrCalculateHammingDistanceForAllPossbileNets(List<Net> nets, List<Net> keyGates, List<Net> keyInputs, string key, char newKeyValue, int randomPatterns, int randomSeed, bool uniqueRandomPatterns, bool forceWrongInputs, int clockTimes, ref double percent, int threadsCount, TextBox textBox, string header, out string loadReport, bool forceCalculate, bool allowSaveResults, string netlistName)
//        {
//            var cacheFileName = netlistName +
//                                CacheManager.GetHashFromNets(nets) +
//                                "Count=" + randomPatterns + "," +
//                                "Unique=" + uniqueRandomPatterns.ToString() + "," +
//                                "Seed=" + randomSeed + "," +
//                                "Ticks=" + clockTimes + "," +
//                                "Frcw=" + forceWrongInputs +
//                                ".hds";

//            var cacheFilePath = CacheManager.CacheDirectory + cacheFileName;

//            List<Net> sortedNetsByHammingDistance;
//            if (!forceCalculate && !string.IsNullOrEmpty(netlistName))
//            {
//                if (SamimiIO.Exists(cacheFilePath))
//                {
//                    if (LoadHammingDistancesFromFile(cacheFilePath, nets, out sortedNetsByHammingDistance))
//                    {
//                        loadReport = "HammingDistances Loaded From File:\t" + cacheFileName;
//                        return sortedNetsByHammingDistance;
//                    }
//                }
//            }

//            var s = new Stopwatch();
//            s.Start();

//            sortedNetsByHammingDistance = CalculateHammingDistanceForAllPossibleNets(
//                    nets: nets,
//                    percent: ref percent,
//                    keyGates: keyGates,
//                    keyInputs: keyInputs,
//                    key: key,
//                    newKeyValue: newKeyValue,
//                    randomPatterns: randomPatterns,
//                    randomSeed: randomSeed,
//                    uniqueRandomPatterns: uniqueRandomPatterns,
//                    forceWrongInputs: forceWrongInputs,
//                    clockTimes: clockTimes,
//                    threadsCount: threadsCount,
//                    textBox: textBox,
//                    header: header);

//            s.Stop();
//            loadReport = "HammingDistances Calculation Duration:\t" + s.Elapsed;

//            if (allowSaveResults)
//            {
//                SaveHammingDistancesToFile(cacheFilePath, sortedNetsByHammingDistance);
//                loadReport += "\r\n" + "Saved To File:\t" + cacheFileName;
//            }
//            return sortedNetsByHammingDistance;
//        }

//        private static void SaveHammingDistancesToFile(string cacheFilePath, List<Net> nets)
//        {
//            if (SamimiIO.Exiting)
//                return;

//            var dataToSave = new List<string>();

//            foreach (var net in nets)
//            {
//                dataToSave.Add(net.Name + "\t" + net.HD);
//            }

//            var str = string.Join("\r\n", dataToSave);

//            SamimiIO.WriteAllText(cacheFilePath, str);
//        }

//        private static bool LoadHammingDistancesFromFile(string cacheFilePath, List<Net> nets, out List<Net> sortedNetlist)
//        {
//            try
//            {
//                var str = SamimiIO.ReadAllText(cacheFilePath);

//                string[] seperators = { "\r\n", "\t" };

//                var data = str.Split(seperators, StringSplitOptions.RemoveEmptyEntries);

//                sortedNetlist = new List<Net>();

//                var loadedNetsCount = 0;
//                for (int i = 0; i < data.Length; i += 2)
//                {
//                    var foundNet = nets.Find(net => net.Name == data[i + 0]);
//                    loadedNetsCount++;

//                    foundNet.HD = double.Parse(data[i + 1]);//2

//                    sortedNetlist.Add(foundNet);
//                }

//                //var goalCountFaultImpactNets = new List<Net>(nets);
//                //var clockNet = CommonMethods.GetMainClockNet(nets);
//                //goalCountFaultImpactNets.Remove(clockNet);
//                //RemoveNonGateNets(goalCountFaultImpactNets);

//                if (loadedNetsCount != nets.Count)
//                    throw new Exception("Count not equal, Load failed.");

//                //faultImpactNets.Sort((net1, net2) => net2.FaultImpact - net1.FaultImpact);

//                return true;
//            }
//            catch (Exception exception)
//            {
//                sortedNetlist = new List<Net>(nets);
//                return false;
//            }
//        }

//        //=======================================================

//        public static List<Net> CalculateHammingDistanceForAllPossibleNets(List<Net> nets, List<Net> keyGates, List<Net> keyInputs, string key, char newKeyValue, int randomPatterns, int randomSeed, bool uniqueRandomPatterns, bool forceWrongInputs, int clockTimes, ref double percent, int threadsCount, TextBox textBox, string header)
//        {
//            List<string> generatedRandomPatterns = null;
//            List<string> correctedPatterns = null;
//            var t0 = DateTime.Now;

//            RandomPatternsForGreedy.GenerateRandomPatterns(nets: nets, key: key + '0', randomPatterns: randomPatterns, randomSeed: randomSeed, uniqueRandomPatterns: uniqueRandomPatterns, generatedRandomPatterns: ref generatedRandomPatterns, correctedPatterns: ref correctedPatterns);

//            var netsHolder = new List<List<Net>>();
//            var parameterHolder = new List<HD.HDThreadData>();

//            if (textBox != null)
//            {
//                textBox.Text = header + "Preparing Threads...";
//                Application.DoEvents();
//            }

//            //Very Important
//            foreach (var net in nets)
//                net.HD = 0; //Very Important

//            //Creating Duplicates Of Netlist for each Thread (First netlist, is the original one)
//            netsHolder.Add(nets);
//            if (threadsCount > 1)
//                netsHolder.AddRange(Net.SValueMethods.DuplicateNetlist(nets, threadsCount - 1));

//            //Creating Parameters To Send To Threads
//            for (var i = 0; i < threadsCount; i++)
//            {
//                parameterHolder.Add(new HD.HDThreadData()
//                {
//                    ClockTimes = clockTimes,
//                    Nets = netsHolder[i],
//                    RandomNumbers = randomPatterns,
//                    ThreadNumbers = threadsCount,
//                    IndexOfThread = i,
//                    GeneratedRandomPatterns = generatedRandomPatterns,
//                    CorrectedPatterns = correctedPatterns,
//                    Percent = 0,
//                    forceWrongInputs = forceWrongInputs,
//                    key = key,
//                    keyGates = new List<Net>(keyGates),
//                    keyInputs = new List<Net>(keyInputs),
//                    randomSeed = randomSeed,
//                    uniqueRandomPatterns = uniqueRandomPatterns
//                });
//            }

//            if (textBox != null)
//            {
//                textBox.Text = header + "Starting Threads...";
//                Application.DoEvents();
//            }

//            //Creating & Starting Threads
//            var threadsHolder = new List<Thread>();
//            for (var i = 0; i < threadsCount; i++)
//            {
//                var thread = new Thread(Start);
//                threadsHolder.Add(thread);
//                thread.Start(parameterHolder[i]);
//            }

//            string threadsStatus;

//            if (textBox != null)
//            {
//                textBox.Text = header + "Working...";
//                Application.DoEvents();
//            }

//            var t1 = DateTime.Now;
//            var allDone = false;
//            while (!allDone && !SamimiIO.Exiting)
//            {
//                threadsStatus = "";
//                percent = 0;

//                allDone = true;
//                for (var i = 0; i < threadsHolder.Count; i++)
//                {
//                    var thread = threadsHolder[i];

//                    if (thread.IsAlive)
//                        allDone = false;

//                    if (SamimiIO.Exiting)
//                        thread.Abort();

//                    if (textBox != null)
//                    {
//                        percent += parameterHolder[i].Percent / threadsHolder.Count;
//                        threadsStatus += (int)parameterHolder[i].Percent + "% ";
//                    }
//                }

//                if (textBox != null)
//                {
//                    textBox.Text = header + "Threads Status: " + threadsStatus + "\r\n";
//                    textBox.Text += FaultImpacts.TimeEstimationString(t0, t1, percent);
//                    //if (progressBar != null)
//                    //    progressBar.Value = (int)percent;
//                    Application.DoEvents();
//                }

//                if (!allDone && nets.Count > 100)
//                    Thread.Sleep(1000);
//            }

//            if (textBox != null)
//            {
//                textBox.Text = header + "Merging Threads Results...";
//                Application.DoEvents();
//            }

//            //Merging Results
//            for (var i = 0; i < nets.Count; i++)
//            {
//                var net = nets[i];
//                for (var j = 1; j < netsHolder.Count; j++)
//                    net.HD += netsHolder[j][i].HD;
//            }

//            //var finalNets = parameterHolder[0].Nets;

//            if (SamimiIO.Exiting)
//            {
//                //report = null;
//                return null;
//            }
//            //===================================================================================

//            var sortedNets = nets.OrderBy(net => Math.Abs(net.HD - 0.5)).ThenBy(net => net.Name).ToList();
//            return sortedNets;
//        }

//        public static void ComputeHammingDistanceForExaminingNet(List<Net> nets, string key, int randomPatterns, int randomSeed, bool uniqueRandomPatterns, ref List<string> generatedRandomPatterns, ref List<string> correctedPatterns, Net examiningNet, bool forceWrongInputs, int clockTimes)
//        {
//            List<Net> middleNets;
//            List<Net> outputNets;
//            List<Net> inputNets;
//            Parser.ClassifyInputMiddleOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets);
//            var clockNet = CommonMethods.GetMainClockNet(nets);
//            inputNets.Remove(clockNet);

//            //if (generatedRandomPatterns == null && correctedPatterns == null)
//            //{
//            //inputNets.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));
//            //GetGeneratedRandomPatterns(key: key, randomPatterns: randomPatterns, randomSeed: randomSeed, uniqueRandomPatterns: uniqueRandomPatterns, inputNets: inputNets, generatedRandomPatterns: out generatedRandomPatterns, correctedPatterns: out correctedPatterns);

//            //outputNets.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));
//            //}
//            //inputNets.Sort((net1, net2) => string.Compare(net1.Name, net2.Name));

//            var results = new List<Dictionary<string, Signal>>();
//            //examiningNet.HD = 0;

//            //Round1:
//            foreach (var net in nets)
//                net.SValue = Net.Signal.X;
//            for (int index = 0; index < generatedRandomPatterns.Count; index++)
//            {
//                if (SamimiIO.Exiting)
//                    break;

//                //چنانچه مدار ترکیبی است
//                if (clockNet == null)
//                {
//                    //!!سرعت را افزایش می دهد ولی تنها برای مدار های ترکیبی!!
//                    foreach (var net in nets)
//                        net.SValue = Net.Signal.X;
//                }

//                var wrongPattern = generatedRandomPatterns[index];
//                var correctedPattern = correctedPatterns[index];

//                if (forceWrongInputs)
//                    if (correctedPattern == wrongPattern)
//                        continue;

//                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets, correctedPattern);

//                StoreResults(outputNets, results);

//                if (clockNet != null)
//                    for (int i = 0; i < clockTimes; i++)
//                    {
//                        Net.SValueMethods.Imply(clockNet, Net.Signal.V0);
//                        StoreResults(outputNets, results);

//                        Net.SValueMethods.Imply(clockNet, Net.Signal.V1);
//                        StoreResults(outputNets, results);
//                    }
//            }

//            double sumOfHammingDistanceRatios = 0;
//            double samplesCount = results.Count;
//            //Round2:
//            foreach (var net in nets)
//                net.SValue = Net.Signal.X;
//            for (int index = 0; index < generatedRandomPatterns.Count; index++)
//            {
//                if (SamimiIO.Exiting)
//                    break;

//                //چنانچه مدار ترکیبی است
//                if (clockNet == null)
//                {
//                    //!!سرعت را افزایش می دهد ولی تنها برای مدار های ترکیبی!!
//                    foreach (var net in nets)
//                        net.SValue = Net.Signal.X;
//                }

//                var wrongPattern = generatedRandomPatterns[index];
//                var correctedPattern = correctedPatterns[index];

//                if (forceWrongInputs)
//                    if (correctedPattern == wrongPattern)
//                        continue;

//                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets, wrongPattern);

//                sumOfHammingDistanceRatios += CountHammingDistance(outputNets, results) / outputNets.Count;

//                if (clockNet != null)
//                    for (int i = 0; i < clockTimes; i++)
//                    {
//                        Net.SValueMethods.Imply(clockNet, Net.Signal.V0);
//                        sumOfHammingDistanceRatios += CountHammingDistance(outputNets, results) / outputNets.Count;

//                        Net.SValueMethods.Imply(clockNet, Net.Signal.V1);
//                        sumOfHammingDistanceRatios += CountHammingDistance(outputNets, results) / outputNets.Count;
//                    }
//            }

//            //double hammingDistanceRatio;



//            //var averageOfHammingDistanceRatiosPercent = Math.Round((((sumOfHammingDistanceRatios / results.Count)) * 100), 2);

//            //resultsHolder.XRatio = Math.Round(((((double)allX / samplesCount)) * 100), 2);
//            //resultsHolder.HammingDistancePercent = averageOfHammingDistanceRatiosPercent;

//            ////===============================================================================================
//            //statisticalReport = "";

//            examiningNet.HD = sumOfHammingDistanceRatios / samplesCount;
//        }

//        public class HDThreadData
//        {
//            public List<Net> Nets;
//            public double Percent = 0;
//            public List<string> GeneratedRandomPatterns = null;
//            public List<string> CorrectedPatterns = null;
//            public int RandomNumbers = 1000;
//            public int ClockTimes = 5;
//            public int ThreadNumbers;
//            public int IndexOfThread;
//            public List<Net> keyGates;
//            public List<Net> keyInputs;
//            public string key;
//            public int randomSeed;
//            public bool uniqueRandomPatterns;
//            public bool forceWrongInputs;
//        }

//        public static void Start(object o)
//        {
//            var p = (HDThreadData)o;

//            var from = (p.Nets.Count * p.IndexOfThread / p.ThreadNumbers);
//            var to = ((p.Nets.Count * (p.IndexOfThread + 1) / p.ThreadNumbers));
//            if (p.IndexOfThread == p.ThreadNumbers - 1)
//                to = p.Nets.Count;

//            for (int i = from; i < to; i++)
//            {
//                if (SamimiIO.Exiting)
//                    break;

//                var examiningNet = p.Nets[i];
//                examiningNet.HD = 0;

//                p.Percent = (((i - from) / (double)(to - from)) * 100);

//                var keyGatesToUndo = new List<Net>();
//                var keyInputsToUndo = new List<Net>();

//                //اول ورودی کلید
//                //دوم ایکسکی
//                FARajendran.InsertNewXORGateAtLocation(nets: p.Nets, location: examiningNet, keyGates: p.keyGates, keyInputs: p.keyInputs);

//                #region Removed Due To Enhancement

//                ////سوم اینورتر
//                ////بعد اگه بیت کلید یک بود یک اینورتر سر راه ایکسور قرار میده
//                //if (newKeyValue == '1')
//                //{
//                //    //Insert an inverter at the o/p of corresponding keygate;
//                //    var newInverter = CommonMethods.CreateAndInsertInverterAfterLocation(
//                //        nets: nets,
//                //        location: keyGates[keyGates.Count - 1],
//                //        index: keyGates.Count);

//                //    keyGatesToUndo.Add(newInverter);
//                //}

//                ////بعد اگه بیت کلید یک بود، گیت ایکسور را با گیت ایکسنور تعویض می کند
//                //if (newKeyValue == '1')
//                //{
//                //    //گیت ایکسور را با ایکسنور جایگزین می کند
//                //    //Replace the XOR key-gate with an XNOR key-gate;
//                //    CommonMethods.ReplaceXORwithXNOR(location: keyGates[keyGates.Count - 1], nets: nets, keyGates: keyGates);
//                //}

//                #endregion

//                keyGatesToUndo.Add(p.keyGates[p.keyGates.Count - 1]);
//                keyInputsToUndo.Add(p.keyInputs[p.keyInputs.Count - 1]);

//                ComputeHammingDistanceForExaminingNet(
//                        nets: p.Nets,
//                        examiningNet: examiningNet,
//                        generatedRandomPatterns: ref p.GeneratedRandomPatterns,
//                        correctedPatterns: ref p.CorrectedPatterns,
//                    //key: p.key + '0',// newKeyValue, //Removed Due To Enhancement
//                        forceWrongInputs: p.forceWrongInputs,
//                        clockTimes: p.ClockTimes,
//                        key: p.key + '0',
//                        randomPatterns: p.RandomNumbers,
//                        randomSeed: p.randomSeed,
//                        uniqueRandomPatterns: p.uniqueRandomPatterns);

//                UndoChanges(nets: p.Nets, keyGates: p.keyGates, keyInputs: p.keyInputs, keyInputsToUndo: keyInputsToUndo, keyGatesToUndo: keyGatesToUndo);
//            }
//            p.Percent = 100;
//        }

//        private static void UndoChanges(List<Net> nets, List<Net> keyInputs, List<Net> keyGates, List<Net> keyInputsToUndo, List<Net> keyGatesToUndo)
//        {
//            foreach (var net in keyInputsToUndo)
//            {
//                nets.Remove(net);
//                keyInputs.Remove(net);

//                var inputDone = false;
//                foreach (var nextGate in net.NextNets)
//                {
//                    foreach (var input in nextGate.Inputs)
//                    {
//                        if (input.Net == net)
//                        {
//                            input.Net = null;
//                            input.Name = null;

//                            inputDone = true;
//                            break;
//                        }
//                    }
//                    if (inputDone)
//                        break;
//                }
//            }

//            foreach (var net in keyGatesToUndo)
//            {
//                nets.Remove(net);
//                keyGates.Remove(net);

//                foreach (var healthyInput in net.Inputs)
//                {
//                    if (healthyInput.Net == null)
//                        continue;

//                    foreach (var nextNet in net.NextNets)
//                    {
//                        foreach (var inputOfNextGate in nextNet.Inputs)
//                        {
//                            if (inputOfNextGate.Net.Name == net.Name)
//                            {
//                                inputOfNextGate.Net = healthyInput.Net;
//                                inputOfNextGate.Name = healthyInput.Net.Name;

//                                //healthyInput.Net.NextNets.Remove(net);
//                                healthyInput.Net.NextNets.Add(nextNet);
//                            }
//                        }
//                    }

//                    healthyInput.Net.NextNets.Remove(net);

//                    healthyInput.Net.IsPrimaryOutput = net.IsPrimaryOutput;
//                }
//            }
//        }

//        public static double CountHammingDistance(List<Net> outputNets, List<Dictionary<string, Signal>> results)
//        {
//            double hammingDistance = 0;
            
//            //خروجی های تولید شده در این سری را با اولین لیست خروجی های موجود در لیست نتایج مقایسه می کند
//            foreach (var outputNet in outputNets)
//            {
//                if (results[0][outputNet.Name] != outputNet.SValue)
//                    hammingDistance++;
//            }

//            //اولین لیست خروجی های موجود در لیست نتایج را پاک می کند
//            results.RemoveAt(0);

//            return hammingDistance;
//        }

//        private static void StoreResults(List<Net> outputNets, List<Dictionary<string, Signal>> results)
//        {
//            //به ازای هر سری از خروجی ها، دیکشنری درست می کند از ترکیب نام خروجی و مقدار آن خروجی
//            var dic1 = new Dictionary<string, Signal>();
//            foreach (var outputNet in outputNets)
//                dic1[outputNet.Name] = outputNet.SValue;
            
//            //دیکشنری ایجاد شده را به لیست نتایج اضافه می کند
//            results.Add(dic1);
//        }
//    }
//}
