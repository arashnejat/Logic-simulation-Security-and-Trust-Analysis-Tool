﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public partial class HTEncryption
    {
        /// <summary>
        /// بهینه سازی های انجام شده نسبت به مقاله اصلی
        /// A Novel Hardware Logic Encryption Technique for thwarting Illegal Overproduction and Hardware Trojans
        /// عبارتند از:
        /// اول نت هایی که خیلی نامتوازن هستند را اصلاح می کند
        /// انتخاب مجدد نامتوازن ترین نت جلوگیری می شود
        /// از انتخاب مجدد گیت کلید برای درج کلید بعدی جلوگیری می شود
        /// از انتخاب مجدد خود ورودی کلید برای درج کلید بعدی جلوگیری می شود
        /// </summary>
        /// <param name="nets"></param>
        /// <param name="NB_GATE"></param>
        /// <param name="PROBA_MIN">مثلا اگر 0.1 باشد، یعنی نت های با احتمال زیر ده درصد و بالای 90 درصد</param>
        /// <param name="SLACK_MIN"></param>
        /// <param name="considerSlackTime"></param>
        public static void Alg04EncryptEnhancedHTEncryptionProposedAlg0(List<Net> nets, int NB_GATE, double PROBA_MIN, double SLACK_MIN, out string addedKeyValues, TextBox textBox, int clockTimes, int randomSeed, int randomPatternsCount, double threshold, bool meetThreshold, SimulationReporter reportObject, string netlistName, bool forceCalculate, bool considerSlackTime = true)
        {
            var addedKeyInputNets = new List<Net>();
            addedKeyValues = "";
            //----------------------------------------------------------------------
            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Simulating netlist for probabilities before encryption started...");

            string probabilitiesLoadReport;
            //چون گزارش ساز قبلا حساب کرده، اینجا فقط لود میشه
            var totalSamples = LogicSimulation.LoadOrCalculateProbabilities(
                nets: nets,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                totalTimes: randomPatternsCount,
                meetThreshold: meetThreshold,
                threshold: threshold,
                textBox: null,
                netlistName: netlistName,
                loadReport: out probabilitiesLoadReport,
                forceCalculate: forceCalculate,
                allowSaveResults: true);

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Total Samples: " + totalSamples);

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Simulating netlist for probabilities before encryption ended");
            //----------------------------------------------------------------------           
            Net.ToStringMode = Net.NetToStringMode.SimulatedProbability;
            //======================================================================
            var rareSignals = nets.Where(net => net.SimulatedProbability <= PROBA_MIN || net.SimulatedProbability >= (1 - PROBA_MIN)).ToList();

            //ایده خودم! تا اول نت هایی که خیلی نامتوازن هستند را اصلاح کنیم
            //مشکلی که وجود داشت این بود که وقتی لود می کرد و بعد سورت می کرد
            //با اینکه داده های یکسانی لود می شدند ولی
            //ترتیب با زمانی که محاسبه می کرد متفاوت بود
            //لذا تابع سورتی نوشتم تا اول تا 10 رقم اعشار روند کند و بعد سورت کند
            //rareSignals.Sort((net1, net2) => Math.Sign(Math.Abs(0.5 - net2.SimulatedProbability) - Math.Abs(0.5 - net1.SimulatedProbability)));//New
            //rareSignals = rareSignals.OrderBy(o => Math.Abs(0.5 - o.SimulatedProbability)).ToList();
            rareSignals = LogicSimulation.SortBySimulatedProbabilityFromMaxDistanceToHalfToMin(rareSignals);

            reportObject.Step02FinishRound(nets, addedKeyValues, forceCalculate: forceCalculate);
            var appliedMostUnbalancedSignals = new HashSet<Net>();
            var slackTimesAreFresh = false;
            foreach (var rareSignal in rareSignals)
            {
                //اگر به اندازه کافی کلید درج شد، خارج شود
                if (addedKeyInputNets.Count >= NB_GATE)
                    break;
                //----------------------------------------------------------------------
                if (considerSlackTime && !slackTimesAreFresh)
                {
                    //++++++++++++++++++++++++++
                    reportObject.AddToConsoleLog("Computing slack times before encryption started...");

                    //چون گزارش ساز قبلا حساب کرده، اینجا فقط لود میشه
                    int maxLevel;
                    string loadReport;
                    ASAPALAPSlackTime.LoadOrCalculateASAPALAPSlackTimeOfNets(
                        nets: nets,
                        maxLevel: out maxLevel,
                        netlistName: netlistName,
                        loadReport: out loadReport,
                        forceCalculate: forceCalculate,
                        allowSaveResults: true);

                    slackTimesAreFresh = true;
                    //++++++++++++++++++++++++++
                    reportObject.AddToConsoleLog("Computing slack times before encryption ended");
                }
                //----------------------------------------------------------------------
                //بدست آوردن نت های پیش از این نت نادر
                var previousSingalsHashSet = new HashSet<Net>();
                FillPreviousSignals(rareSignal, previousSingalsHashSet);
                if (previousSingalsHashSet.Count == 0)
                {
                    //MessageBox.Show("این نت، نت قبلی ندارد" + " Name: " + rareSignal.Name);
                    continue;
                }
                //----------------------------------------------------------------------
                //انتخاب نت هایی که اسلک تایم کافی دارند
                var previousSingalsWithEnoughSlackTime = new List<Net>();
                foreach (var previousSingal in previousSingalsHashSet)
                {
                    if (!considerSlackTime || previousSingal.SlackTime >= SLACK_MIN)
                        previousSingalsWithEnoughSlackTime.Add(previousSingal);
                }
                if (previousSingalsWithEnoughSlackTime.Count == 0)
                {
                    //MessageBox.Show("این نت، نت قبلی با اسلک تایم مورد نظر ندارد" + " Name: " + rareSignal.Name);
                    continue;
                }
                //----------------------------------------------------------------------
                //انتخاب نامتوازن ترین از میان سیگنال های پیشین

                bool closeToZero;
                var mostUnbalancedSignal = ChooseMostUnbalancedSignal(previousSingalsWithEnoughSlackTime: previousSingalsWithEnoughSlackTime, closeToZero: out closeToZero, appliedMostUnbalancedSignals: appliedMostUnbalancedSignals);//es in paper
                if (mostUnbalancedSignal == null)
                    continue;//ایجا قبلا اشتباها ریترن بود

                //ایده خودم! تا از انتخاب مجدد نامتوازن ترین نت جلوگیری شود
                appliedMostUnbalancedSignals.Add(mostUnbalancedSignal);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Chosen Most Unbalanced Signal:\t" + mostUnbalancedSignal.Name);

                //----------------------------------------------------------------------

                //ساخت گیت کلید
                Net chosenKeyGate;

                //تعیین نوع گیت کلید
                if (closeToZero)
                {
                    chosenKeyGate = new GateOr();
                    addedKeyValues += "0";
                }
                else
                {
                    chosenKeyGate = new GateAnd();
                    addedKeyValues += "1";
                }

                //اضافه کردن گیت کلید به لیست نت های مدار
                nets.Add(chosenKeyGate);

                //ایده خودم! تا از انتخاب مجدد گیت کلید برای درج کلید بعدی جلوگیری شود
                appliedMostUnbalancedSignals.Add(chosenKeyGate); //New

                //کامل کردن مشخصات گیت کلید
                CommonMethods.CompleteKeyGate(newKeyGate: chosenKeyGate, index: addedKeyValues.Length, location: mostUnbalancedSignal);
                //----------------------------------------------------------------------

                //سیم ورودی کلید برای مدار ساخته می شود
                var newInputNet = CommonMethods.CreateAndInsertInputKeyNetConsideringSlackTimes(newKeyGate: chosenKeyGate, keyIndex: addedKeyValues.Length, location: mostUnbalancedSignal);

                //سیم ورودی کلید به لیست نت های مدار اضافه می شود
                nets.Add(newInputNet);

                //ایده خودم! تا از انتخاب مجدد خود ورودی کلید برای درج کلید بعدی جلوگیری شود
                appliedMostUnbalancedSignals.Add(newInputNet); //New

                //اضافه کردن سیم ورودی کلید به لیست سیم های ورودی کلید مدار
                addedKeyInputNets.Add(newInputNet);
                //----------------------------------------------------------------------

                //درج گیت کلید پس از سیگنال نامتوازن
                CommonMethods.InsertNewGateAfterLocationConsideringSlackTimes(newGate: chosenKeyGate, location: mostUnbalancedSignal);

                slackTimesAreFresh = false;

                //توجه، توجه
                //این احتمالات رو بروز رسانی می کنه! که نباید در روش اصلی اینکار انجام بشه
                reportObject.Step02FinishRound(nets, addedKeyValues, forceCalculate: forceCalculate);
            }
            //======================================================================
        }

        public static void Alg21EncryptEnhancedXHTEncryptionProposedAlg1(List<Net> nets, string encryptionKey, double PROBA_MIN, double SLACK_MIN, out string addedKeyValues, TextBox textBox, int clockTimes, int randomSeed, int randomPatternsCount, double threshold, bool meetThreshold, SimulationReporter reportObject, string netlistName, bool forceCalculate, int rRandomSeed, bool considerSlackTime = true)
        {
            //----------------------------------------------------------------------
            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Simulating netlist for probabilities before encryption started...");

            string probabilitiesLoadReport;
            //چون گزارش ساز قبلا حساب کرده، اینجا فقط لود میشه
            var totalSamples = LogicSimulation.LoadOrCalculateProbabilities(
                nets: nets,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                totalTimes: randomPatternsCount,
                meetThreshold: meetThreshold,
                threshold: threshold,
                textBox: null,
                netlistName: netlistName,
                loadReport: out probabilitiesLoadReport,
                forceCalculate: forceCalculate,
                allowSaveResults: true);

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Total Samples: " + totalSamples);

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Simulating netlist for probabilities before encryption ended");
            //----------------------------------------------------------------------           
            Net.ToStringMode = Net.NetToStringMode.SimulatedProbability;
            //======================================================================
            var random = new Random(rRandomSeed);
            var t0 = DateTime.Now;
            var t1 = DateTime.Now;

            var keyInputs = new List<Net>();
            var keyGates = new List<Net>();
            addedKeyValues = "";

            //Generate R ; //a random number
            var R = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(random, encryptionKey.Length);
            var GateType = FARajendran.Xor(encryptionKey, R);

            var rareSignals = nets.Where(net => net.SimulatedProbability <= PROBA_MIN || net.SimulatedProbability >= (1 - PROBA_MIN)).ToList();

            //ایده خودم! تا اول نت هایی که خیلی نامتوازن هستند را اصلاح کنیم
            //مشکلی که وجود داشت این بود که وقتی لود می کرد و بعد سورت می کرد
            //با اینکه داده های یکسانی لود می شدند ولی
            //ترتیب با زمانی که محاسبه می کرد متفاوت بود
            //لذا تابع سورتی نوشتم تا اول تا 10 رقم اعشار روند کند و بعد سورت کند
            //rareSignals.Sort((net1, net2) => Math.Sign(Math.Abs(0.5 - net2.SimulatedProbability) - Math.Abs(0.5 - net1.SimulatedProbability)));//New
            //rareSignals = rareSignals.OrderBy(o => Math.Abs(0.5 - o.SimulatedProbability)).ToList();
            rareSignals = LogicSimulation.SortBySimulatedProbabilityFromMaxDistanceToHalfToMin(rareSignals);

            reportObject.Step02FinishRound(nets, addedKeyValues, forceCalculate: forceCalculate);
            var appliedMostUnbalancedSignals = new HashSet<Net>();
            var slackTimesAreFresh = false;
            foreach (var rareSignal in rareSignals)
            {
                //اگر به اندازه کافی کلید درج شد، خارج شود
                if (keyInputs.Count >= encryptionKey.Length)
                    break;
                //----------------------------------------------------------------------
                if (considerSlackTime && !slackTimesAreFresh)
                {
                    //++++++++++++++++++++++++++
                    reportObject.AddToConsoleLog("Computing slack times before encryption started...");

                    //چون گزارش ساز قبلا حساب کرده، اینجا فقط لود میشه
                    int maxLevel;
                    string loadReport;
                    ASAPALAPSlackTime.LoadOrCalculateASAPALAPSlackTimeOfNets(
                        nets: nets,
                        maxLevel: out maxLevel,
                        netlistName: netlistName,
                        loadReport: out loadReport,
                        forceCalculate: forceCalculate,
                        allowSaveResults: true);

                    slackTimesAreFresh = true;
                    //++++++++++++++++++++++++++
                    reportObject.AddToConsoleLog("Computing slack times before encryption ended");
                }
                //----------------------------------------------------------------------
                //بدست آوردن نت های پیش از این نت نادر
                var previousSingalsHashSet = new HashSet<Net>();
                FillPreviousSignals(rareSignal, previousSingalsHashSet);
                if (previousSingalsHashSet.Count == 0)
                {
                    //MessageBox.Show("این نت، نت قبلی ندارد" + " Name: " + rareSignal.Name);
                    continue;
                }
                //----------------------------------------------------------------------
                //انتخاب نت هایی که اسلک تایم کافی دارند
                var previousSingalsWithEnoughSlackTime = new List<Net>();
                foreach (var previousSingal in previousSingalsHashSet)
                {
                    if (!considerSlackTime || previousSingal.SlackTime >= SLACK_MIN)
                        previousSingalsWithEnoughSlackTime.Add(previousSingal);
                }
                if (previousSingalsWithEnoughSlackTime.Count == 0)
                {
                    //MessageBox.Show("این نت، نت قبلی با اسلک تایم مورد نظر ندارد" + " Name: " + rareSignal.Name);
                    continue;
                }
                //----------------------------------------------------------------------
                bool closeToZero;
                //انتخاب نامتوازن ترین از میان سیگنال های پیشین
                var mostUnbalancedSignal = ChooseMostUnbalancedSignal(previousSingalsWithEnoughSlackTime: previousSingalsWithEnoughSlackTime, closeToZero: out closeToZero, appliedMostUnbalancedSignals: appliedMostUnbalancedSignals);//es in paper
                if (mostUnbalancedSignal == null)
                    continue;//ایجا قبلا اشتباها ریترن بود

                //ایده خودم! تا از انتخاب مجدد نامتوازن ترین نت جلوگیری شود
                appliedMostUnbalancedSignals.Add(mostUnbalancedSignal);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Round " + (keyInputs.Count + 1) + " Gate (" + mostUnbalancedSignal.Name + ")");

                //----------------------------------------------------------------------
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                //اول یه ایکسور در محل می ذاریم
                CommonMethods.InsertNewXORGateAfterLocation(nets: nets, location: mostUnbalancedSignal, keyGates: keyGates, keyInputs: keyInputs);
                addedKeyValues += encryptionKey[keyInputs.Count - 1];

                //بعد یه دونه از اسلک تایم محل کم می کنیم
                mostUnbalancedSignal.SlackTime -= 1;

                //از آنجا که دیگه نمی خوایم تو سر راه گیت کلید، گیت کلید دیگه ای قرار بدیم، اسلک تایمش رو مهم نیست اصلاح کنیم

                ////ایده خودم! تا از انتخاب مجدد گیت کلید برای درج کلید بعدی جلوگیری شود
                appliedMostUnbalancedSignals.Add(keyGates[keyGates.Count - 1]); //New

                ////ایده خودم! تا از انتخاب مجدد خود ورودی کلید برای درج کلید بعدی جلوگیری شود
                appliedMostUnbalancedSignals.Add(keyInputs[keyInputs.Count - 1]); //New
                //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

                //تا اینجا یه ایکسور اضافه کرده و اسلک تایم مکان رو هم درست کرده
                var i = keyInputs.Count - 1;
                if (considerSlackTime && mostUnbalancedSignal.SlackTime == 0)//اگر اسلک تایم مهم بود و محل مورد نظر دیگر جای خالی نداشت
                {
                    if (encryptionKey[i] == '1')//با همین کلیدی که هست سر و تهش رو هم میاره
                    {
                        CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
                    }
                }
                else//اما اگه جای خالی داشت یا اینکه اصلا اسلک تایم مهم نبود، سر راهش در صورت نیاز اینورتر میذاره
                {
                    //بعد اگه بیت کلید یک بود یک اینورتر سر راه ایکسور قرار میده
                    if (R[i] == '1')
                    {
                        //Insert an inverter at the o/p of corresponding keygate;
                        var newInverter = CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);

                        //ایده خودم! تا از انتخاب مجدد گیت اینورتر برای درج کلید بعدی جلوگیری شود
                        appliedMostUnbalancedSignals.Add(newInverter); //New

                        if (considerSlackTime)//اگر اسلک تایم مهم بود، چون اینورتر گذاشتیم، یه دونه دیگه از اسلک تایم محل کم می کنیم
                            mostUnbalancedSignal.SlackTime -= 1;
                    }

                    //بعد اگه بیت کلید یک بود، گیت ایکسور را با گیت ایکسنور تعویض می کند
                    if (GateType[i] == '1')
                    {
                        //گیت ایکسور را با ایکسنور جایگزین می کند

                        //Replace the XOR key-gate with an XNOR key-gate;
                        CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
                    }
                }

                slackTimesAreFresh = false;

                //توجه، توجه
                //این احتمالات رو بروز رسانی می کنه! که نباید در روش اصلی اینکار انجام بشه
                reportObject.Step02FinishRound(nets: nets, addedKeyValues: addedKeyValues, forceCalculate: forceCalculate);
            }
            //======================================================================
        }

        public static void Alg17EncryptEnhancedHTEncryptionMyIdeaFailed(List<Net> nets, int NB_GATE, double PROBA_MIN, double SLACK_MIN, out string addedKeyValues, TextBox textBox, int clockTimes, int randomSeed, int randomPatternsCount, double threshold, bool meetThreshold, SimulationReporter reportObject, string netlistName, bool forceCalculate, bool considerSlackTime = true)
        {
            var addedKeyInputNets = new List<Net>();
            addedKeyValues = "";
            //----------------------------------------------------------------------
            if (considerSlackTime)
            {
                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Computing slack times before encryption started...");

                //چون گزارش ساز قبلا حساب کرده، اینجا فقط لود میشه
                int maxLevel;
                string loadReport;
                ASAPALAPSlackTime.LoadOrCalculateASAPALAPSlackTimeOfNets(
                    nets: nets,
                    maxLevel: out maxLevel,
                    netlistName: netlistName,
                    loadReport: out loadReport,
                    forceCalculate: forceCalculate,
                    allowSaveResults: true);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Computing slack times before encryption ended");
            }
            //----------------------------------------------------------------------
            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Simulating netlist for probabilities before encryption started...");

            string probabilitiesLoadReport;
            //چون گزارش ساز قبلا حساب کرده، اینجا فقط لود میشه
            var totalSamples = LogicSimulation.LoadOrCalculateProbabilities(
                nets: nets,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                totalTimes: randomPatternsCount,
                meetThreshold: meetThreshold,
                threshold: threshold,
                textBox: null,
                netlistName: netlistName,
                loadReport: out probabilitiesLoadReport,
                forceCalculate: forceCalculate,
                allowSaveResults: true);

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Total Samples: " + totalSamples);

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Simulating netlist for probabilities before encryption ended");
            //----------------------------------------------------------------------           
            Net.ToStringMode = Net.NetToStringMode.SimulatedProbability;
            //======================================================================
            List<Net> rareSignals = null;

            rareSignals = GetRareSignals(nets, PROBA_MIN, rareSignals);

            reportObject.Step02FinishRound(nets, addedKeyValues, forceCalculate: forceCalculate);
            var appliedMostUnbalancedSignals = new HashSet<Net>();
            for (int i = 0; i < rareSignals.Count; i++)
            {
                var rareSignal = rareSignals[i];
                //اگر به اندازه کافی کلید درج شد، خارج شود
                if (addedKeyInputNets.Count >= NB_GATE)
                    break;
                //----------------------------------------------------------------------
                //بدست آوردن نت های پیش از این نت نادر
                var previousSingalsHashSet = new HashSet<Net>();
                FillPreviousSignals(rareSignal, previousSingalsHashSet);
                if (previousSingalsHashSet.Count == 0)
                {
                    //MessageBox.Show("این نت، نت قبلی ندارد" + " Name: " + rareSignal.Name);
                    continue;
                }
                //----------------------------------------------------------------------
                //انتخاب نت هایی که اسلک تایم کافی دارند
                var previousSingalsWithEnoughSlackTime = new List<Net>();
                foreach (var previousSingal in previousSingalsHashSet)
                {
                    if (!considerSlackTime || previousSingal.SlackTime >= SLACK_MIN)
                        previousSingalsWithEnoughSlackTime.Add(previousSingal);
                }
                if (previousSingalsWithEnoughSlackTime.Count == 0)
                {
                    //MessageBox.Show("این نت، نت قبلی با اسلک تایم مورد نظر ندارد" + " Name: " + rareSignal.Name);
                    continue;
                }
                //----------------------------------------------------------------------
                //انتخاب نامتوازن ترین از میان سیگنال های پیشین

                bool closeToZero;
                var mostUnbalancedSignal =
                    ChooseMostUnbalancedSignal(previousSingalsWithEnoughSlackTime: previousSingalsWithEnoughSlackTime,
                        closeToZero: out closeToZero, appliedMostUnbalancedSignals: appliedMostUnbalancedSignals);
                //es in paper
                if (mostUnbalancedSignal == null)
                    continue; //ایجا قبلا اشتباها ریترن بود

                //ایده خودم! تا از انتخاب مجدد نامتوازن ترین نت جلوگیری شود
                appliedMostUnbalancedSignals.Add(mostUnbalancedSignal);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Chosen Most Unbalanced Signal:\t" + mostUnbalancedSignal.Name);

                //----------------------------------------------------------------------

                //ساخت گیت کلید
                Net chosenKeyGate;

                //تعیین نوع گیت کلید
                if (closeToZero)
                {
                    chosenKeyGate = new GateOr();
                    addedKeyValues += "0";
                }
                else
                {
                    chosenKeyGate = new GateAnd();
                    addedKeyValues += "1";
                }

                //اضافه کردن گیت کلید به لیست نت های مدار
                nets.Add(chosenKeyGate);

                //ایده خودم! تا از انتخاب مجدد گیت کلید برای درج کلید بعدی جلوگیری شود
                appliedMostUnbalancedSignals.Add(chosenKeyGate); //New

                //کامل کردن مشخصات گیت کلید
                CommonMethods.CompleteKeyGate(newKeyGate: chosenKeyGate, index: addedKeyValues.Length, location: mostUnbalancedSignal);
                //----------------------------------------------------------------------

                //سیم ورودی کلید برای مدار ساخته می شود
                var newInputNet = CommonMethods.CreateAndInsertInputKeyNetConsideringSlackTimes(newKeyGate: chosenKeyGate, keyIndex: addedKeyValues.Length, location: mostUnbalancedSignal);

                //سیم ورودی کلید به لیست نت های مدار اضافه می شود
                nets.Add(newInputNet);

                //ایده خودم! تا از انتخاب مجدد خود ورودی کلید برای درج کلید بعدی جلوگیری شود
                appliedMostUnbalancedSignals.Add(newInputNet); //New

                //اضافه کردن سیم ورودی کلید به لیست سیم های ورودی کلید مدار
                addedKeyInputNets.Add(newInputNet);
                //----------------------------------------------------------------------

                //درج گیت کلید پس از سیگنال نامتوازن
                CommonMethods.InsertNewGateAfterLocationConsideringSlackTimes(newGate: chosenKeyGate, location: mostUnbalancedSignal);

                //توجه، توجه
                //این احتمالات رو بروز رسانی می کنه! که نباید در روش اصلی اینکار انجام بشه
                reportObject.Step02FinishRound(nets, addedKeyValues, forceCalculate: forceCalculate);

                //ایده جدید خودم!! جون لیست احتمالات توسط عملیات تحلیل بروز رسانی شده،
                //از این بروز رسانی استفاده کرده و مجددا لیست نت های نادر را بروز رسانی کرده، و از نو شروع کنیم
                rareSignals = GetRareSignals(nets, PROBA_MIN, rareSignals);
                i = 0;
            }
            //======================================================================
        }

    }
}
