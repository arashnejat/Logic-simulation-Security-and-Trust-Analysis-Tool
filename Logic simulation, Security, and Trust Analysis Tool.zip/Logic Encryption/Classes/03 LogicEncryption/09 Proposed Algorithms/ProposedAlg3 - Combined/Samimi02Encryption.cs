﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public class SamimiEncryption02
    {
        public static void EncryptProposedAlg3Combined2(List<Net> nets, int maxHTKeyLength, int randomPatternsCountGreedy, bool uniqueRandomPatternsGreedy, int clockTimesGreedy, int threadsCountGreedy, int randomSeedGreedy, int rRandomSeed, bool forceWrongInputsGreedy, int clockTimesHT, int randomPatternsCountHT, int randomSeedHT, bool meetThresholdHT, double thresholdHT, bool considerSlackTime, int SLACK_MIN, double PROBA_MIN, string encryptionKey, string netlistName, bool forceCalculateHT, bool forceCalculateGreedy, SimulationReporter reportObject, out string addedKeyValues, TextBox textBox, bool createReport, ProgressBar progressBar)
        {
            #region ProbabilitiesBeforeEncryption

            //----------------------------------------------------------------------
            //اگه اصلا قرار نیست کلید تروجانی بذاریم، پس نیازی هم به محاسبه احتمال ها نیست
            if (maxHTKeyLength > 0)
            {
                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Simulating netlist for probabilities before encryption started...");

                //چون گزارش ساز قبلا حساب کرده، اینجا فقط لود میشه
                //با شرط یکسان بودن ورودی های لاجیک سیمیولیشن و هاردورتروجان، اینجا فقط لود میشه
                string loadReport;
                var totalSamples = LogicSimulation.LoadOrCalculateProbabilities(
                    nets: nets,
                    clockTimes: clockTimesHT,
                    randomSeed: randomSeedHT,
                    totalTimes: randomPatternsCountHT,
                    meetThreshold: meetThresholdHT,
                    threshold: thresholdHT,
                    textBox: null,
                    netlistName: netlistName,
                    loadReport: out loadReport,
                    forceCalculate: forceCalculateHT,
                    allowSaveResults: true);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog(loadReport);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Total samples: " + totalSamples);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Simulating netlist for probabilities before encryption ended");
            }
            //----------------------------------------------------------------------

            #endregion

            //محاسبه نت های کلاک تا بعدا از فرآیند رمز گذاری حذف شود
            var clockNets = CommonMethods.GetClockNets(nets);

            //حذف سیگنال های کلاک از فرایند رمزگذاری
            //faultImpactNets = faultImpactNets.Except(clockNets).ToList();
            //======================================================================
            var random = new Random(rRandomSeed);
            var t0 = DateTime.Now;
            var t1 = DateTime.Now;

            var keyInputs = new List<Net>();
            var keyGates = new List<Net>();

            addedKeyValues = "";
            var insertedHTCount = 0;
            var appliedSignals = new HashSet<Net>();

            //Generate R ("a random number")
            var R = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(random, encryptionKey.Length);
            var GateType = FARajendran.Xor(encryptionKey, R);

            var rareSignals = nets.Where(net => net.SimulatedProbability <= PROBA_MIN || net.SimulatedProbability >= (1 - PROBA_MIN)).ToList();
            rareSignals = LogicSimulation.SortBySimulatedProbabilityFromMaxDistanceToHalfToMin(rareSignals);
            var rareSignalIndex = 0;
            reportObject.Step02FinishRound(nets, addedKeyValues, forceCalculate: forceCalculateHT);

            var HTStillPossible = true;
            var GreedyHDStillPossible = true;

            while (true)
            {
                var i = addedKeyValues.Length;
                var percent = ((double)i * 100 / encryptionKey.Length);
                var header = "Total Progress: " + (int)percent + "%\r\n" +
                             FaultImpacts.TimeEstimationString(t0, t1, percent) + "\r\n\r\n" +
                             "Calculating HammingDistances (" + (i + 1) + "/" + encryptionKey.Length + ")\r\n";

                if (i > encryptionKey.Length)
                    break;

                #region SlackTime
                //----------------------------------------------------------------------
                if (considerSlackTime)
                {
                    reportObject.AddToConsoleLog("Computing slack times before encryption started...");

                    //چون گزارش ساز قبلا حساب کرده، اینجا فقط لود میشه
                    int maxLevel;
                    string loadReport;
                    ASAPALAPSlackTime.LoadOrCalculateASAPALAPSlackTimeOfNets(
                        nets: nets,
                        maxLevel: out maxLevel,
                        netlistName: netlistName,
                        loadReport: out loadReport,
                        forceCalculate: forceCalculateHT,
                        allowSaveResults: true);

                    reportObject.AddToConsoleLog(loadReport);

                    //++++++++++++++++++++++++++
                    reportObject.AddToConsoleLog("Computing slack times before encryption ended");
                }
                //----------------------------------------------------------------------
                #endregion

                if (i%2 == 0 && insertedHTCount < maxHTKeyLength && HTStillPossible)
                {
                    AddHTKeyGate(nets: nets, 
                        considerSlackTime: considerSlackTime, 
                        SLACK_MIN: SLACK_MIN, 
                        encryptionKey: encryptionKey, 
                        rareSignals: rareSignals, 
                        keyInputs: keyInputs, 
                        appliedSignals: appliedSignals, 
                        reportObject: reportObject, 
                        keyGates: keyGates, 
                        R: R, 
                        GateType: GateType, 
                        addedKeyValues: ref addedKeyValues, 
                        rareSignalIndex: ref rareSignalIndex, 
                        HTStillPossible: ref HTStillPossible,
                        forceCalculate: forceCalculateHT,
                        insertedHTCount: ref insertedHTCount);
                }
                else if(GreedyHDStillPossible)
                {
                    AddGreedyHDGate(nets: nets,
                        randomPatternsCountGreedy: randomPatternsCountGreedy,
                        uniqueRandomPatternsGreedy: uniqueRandomPatternsGreedy,
                        clockTimesGreedy: clockTimesGreedy,
                        threadsCountGreedy: threadsCountGreedy,
                        randomSeedGreedy: randomSeedGreedy,
                        forceWrongInputsGreedy: forceWrongInputsGreedy,
                        encryptionKey: encryptionKey,
                        netlistName: netlistName,
                        forceCalculate: forceCalculateGreedy,
                        percent: percent,
                        keyGates: keyGates,
                        keyInputs: keyInputs,
                        i: i, header: header,
                        reportObject: reportObject,
                        R: R, GateType: GateType,
                        addedKeyValues: ref addedKeyValues,
                        textBox: textBox,
                        GreedyHDStillPossible: ref GreedyHDStillPossible,
                        considerSlackTime: considerSlackTime,
                        SLACK_MIN: SLACK_MIN,
                        appliedSignals: appliedSignals);
                }
                else
                {
                    break;
                }
            }
        }

        private static void AddGreedyHDGate(List<Net> nets, int randomPatternsCountGreedy, bool uniqueRandomPatternsGreedy,
            int clockTimesGreedy, int threadsCountGreedy, int randomSeedGreedy, bool forceWrongInputsGreedy,
            string encryptionKey, string netlistName, bool forceCalculate, double percent, List<Net> keyGates, List<Net> keyInputs, int i,
            string header, SimulationReporter reportObject, string R, string GateType, ref string addedKeyValues,
            TextBox textBox, ref bool GreedyHDStillPossible, bool considerSlackTime, HashSet<Net> appliedSignals, int SLACK_MIN)
        {
            //اگر به اندازه کافی کلید درج شد، خارج شود
            if (keyInputs.Count >= encryptionKey.Length)
            {
                GreedyHDStillPossible = false;
                return;
            }

            string hammingDistancesLoadReport;
            List<Net> sortedNetsByHammingDistance = HD2.LoadOrCalculateAverageHammingDistanceForAllPossbileNets(
                nets: nets,
                percent: ref percent,
                keyGates: keyGates,
                keyInputs: keyInputs,
                key: encryptionKey.Substring(0, i),
                newKeyValue: encryptionKey[i],
                randomPatterns: randomPatternsCountGreedy,
                randomSeed: randomSeedGreedy,
                uniqueRandomPatterns: uniqueRandomPatternsGreedy,
                forceWrongInputs: forceWrongInputsGreedy,
                clockTimes: clockTimesGreedy,
                threadsCount: threadsCountGreedy,
                textBox: textBox,
                header: header,
                loadReport: out hammingDistancesLoadReport,
                forceCalculate: forceCalculate,
                allowSaveResults: true,
                netlistName: netlistName);

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog(hammingDistancesLoadReport);

            Application.DoEvents();
            if (FaultImpacts.Exiting)
            {
                GreedyHDStillPossible = false;
                return;
            }

            //Net.ToStringMode = Net.NetToStringMode.FaultImpact;
            Net chosenNet = null;
            if (considerSlackTime)
            {
                foreach (var net in sortedNetsByHammingDistance)
                {
                    if (net.SlackTime < SLACK_MIN)
                        continue;
                    chosenNet = net;
                }
            }
            else
            {
                chosenNet = sortedNetsByHammingDistance[0];
            }

            // = GetNewNetToEncrypt(faultImpactNets: faultImpactNets, appliedNets: appliedNets);
            if (chosenNet == null)
            {
                GreedyHDStillPossible = false;
                return;
            }

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Round " + (i + 1) + " Gate (" + chosenNet.Name + ") (" + chosenNet.HD + ")");

            CreateAndInsertXORXNORInverterKeyGate(nets: nets,
                    considerSlackTime: considerSlackTime,
                    encryptionKey: encryptionKey,
                    keyInputs: keyInputs,
                    appliedSignals: appliedSignals,
                    keyGates: keyGates,
                    R: R,
                    GateType: GateType,
                    addedKeyValues: ref addedKeyValues,
                    location: chosenNet);
            
            reportObject.Step02FinishRound(nets: nets, addedKeyValues: addedKeyValues, forceCalculate: forceCalculate);
        }

        private static void AddHTKeyGate(List<Net> nets, bool considerSlackTime, int SLACK_MIN, string encryptionKey, List<Net> rareSignals, List<Net> keyInputs, HashSet<Net> appliedSignals, SimulationReporter reportObject, List<Net> keyGates, string R, string GateType, ref string addedKeyValues, ref int rareSignalIndex, ref bool HTStillPossible, bool forceCalculate, ref int insertedHTCount)
        {
            while (true)
            {
                if (rareSignals.Count == 0 || rareSignalIndex >= rareSignals.Count)
                {
                    HTStillPossible = false;
                    return;
                }

                var rareSignal = rareSignals[rareSignalIndex++];

                //اگر به اندازه کافی کلید درج شد، خارج شود
                if (keyInputs.Count >= encryptionKey.Length)
                {
                    HTStillPossible = false;
                    return;
                }
                //----------------------------------------------------------------------
                //بدست آوردن نت های پیش از این نت نادر
                var previousSingalsHashSet = new HashSet<Net>();
                HTEncryption.FillPreviousSignals(rareSignal, previousSingalsHashSet);
                if (previousSingalsHashSet.Count == 0)
                {
                    //MessageBox.Show("این نت، نت قبلی ندارد" + " Name: " + rareSignal.Name);
                    continue;
                }
                //----------------------------------------------------------------------
                //انتخاب نت هایی که اسلک تایم کافی دارند
                var previousSingalsWithEnoughSlackTime = new List<Net>();
                foreach (var previousSingal in previousSingalsHashSet)
                {
                    if (!considerSlackTime || previousSingal.SlackTime >= SLACK_MIN)
                        previousSingalsWithEnoughSlackTime.Add(previousSingal);
                }
                if (previousSingalsWithEnoughSlackTime.Count == 0)
                {
                    //MessageBox.Show("این نت، نت قبلی با اسلک تایم مورد نظر ندارد" + " Name: " + rareSignal.Name);
                    continue;
                }
                //----------------------------------------------------------------------
                bool closeToZero;
                //انتخاب نامتوازن ترین از میان سیگنال های پیشین
                var mostUnbalancedSignal = HTEncryption.ChooseMostUnbalancedSignal(previousSingalsWithEnoughSlackTime: previousSingalsWithEnoughSlackTime, closeToZero: out closeToZero, appliedMostUnbalancedSignals: appliedSignals); //es in paper
                if (mostUnbalancedSignal == null)
                {
                    continue;
                }

                //ایده خودم! تا از انتخاب مجدد نامتوازن ترین نت جلوگیری شود
                appliedSignals.Add(mostUnbalancedSignal);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Round " + (keyInputs.Count + 1) + " Gate (" + mostUnbalancedSignal.Name + ")");

                CreateAndInsertXORXNORInverterKeyGate(nets: nets, 
                    considerSlackTime: considerSlackTime, 
                    encryptionKey: encryptionKey, 
                    keyInputs: keyInputs, 
                    appliedSignals: appliedSignals, 
                    keyGates: keyGates, 
                    R: R, 
                    GateType: GateType, 
                    addedKeyValues: ref addedKeyValues, 
                    location: mostUnbalancedSignal);

                insertedHTCount ++;

                //توجه، توجه
                //این احتمالات رو بروز رسانی می کنه! که نباید در روش اصلی اینکار انجام بشه
                reportObject.Step02FinishRound(nets: nets, addedKeyValues: addedKeyValues, forceCalculate: forceCalculate);

                break;
            }
        }

        private static void CreateAndInsertXORXNORInverterKeyGate(List<Net> nets, bool considerSlackTime, string encryptionKey,
            List<Net> keyInputs, HashSet<Net> appliedSignals, List<Net> keyGates, string R, string GateType, ref string addedKeyValues,
            Net location)
        {
//----------------------------------------------------------------------
            //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            //اول یه ایکسور در محل می ذاریم
            CommonMethods.InsertNewXORGateAfterLocation(nets: nets, location: location, keyGates: keyGates, keyInputs: keyInputs);
            addedKeyValues += encryptionKey[keyInputs.Count - 1];

            //بعد یه دونه از اسلک تایم محل کم می کنیم
            location.SlackTime -= 1;

            //از آنجا که دیگه نمی خوایم تو سر راه گیت کلید، گیت کلید دیگه ای قرار بدیم، اسلک تایمش رو مهم نیست اصلاح کنیم

            ////ایده خودم! تا از انتخاب مجدد گیت کلید برای درج کلید بعدی جلوگیری شود
            appliedSignals.Add(keyGates[keyGates.Count - 1]); //New

            ////ایده خودم! تا از انتخاب مجدد خود ورودی کلید برای درج کلید بعدی جلوگیری شود
            appliedSignals.Add(keyInputs[keyInputs.Count - 1]); //New
            //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

            //تا اینجا یه ایکسور اضافه کرده و اسلک تایم مکان رو هم درست کرده
            var i = keyInputs.Count - 1;
            if (considerSlackTime && location.SlackTime == 0) //اگر اسلک تایم مهم بود و محل مورد نظر دیگر جای خالی نداشت
            {
                if (encryptionKey[i] == '1') //با همین کلیدی که هست سر و تهش رو هم میاره
                {
                    CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
                }
            }
            else //اما اگه جای خالی داشت یا اینکه اصلا اسلک تایم مهم نبود، سر راهش در صورت نیاز اینورتر میذاره
            {
                //بعد اگه بیت کلید یک بود یک اینورتر سر راه ایکسور قرار میده
                if (R[i] == '1')
                {
                    //Insert an inverter at the o/p of corresponding keygate;
                    var newInverter = CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);

                    //ایده خودم! تا از انتخاب مجدد گیت اینورتر برای درج کلید بعدی جلوگیری شود
                    appliedSignals.Add(newInverter); //New

                    if (considerSlackTime) //اگر اسلک تایم مهم بود، چون اینورتر گذاشتیم، یه دونه دیگه از اسلک تایم محل کم می کنیم
                        location.SlackTime -= 1;
                }

                //بعد اگه بیت کلید یک بود، گیت ایکسور را با گیت ایکسنور تعویض می کند
                if (GateType[i] == '1')
                {
                    //گیت ایکسور را با ایکسنور جایگزین می کند

                    //Replace the XOR key-gate with an XNOR key-gate;
                    CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
                }
            }
        }


        //public static void EncryptCombined2(List<Net> nets, int randomPatternsCountGreedy, bool uniqueRandomPatternsGreedy, int clockTimesGreedy, int threadsCountGreedy, int randomSeedGreedy, int rRandomSeedGreedy, bool forceWrongInputsGreedy, int clockTimesHT, int randomPatternsCountHT, int randomSeedHT, bool meetThresholdHT, double thresholdHT, bool considerSlackTime, int SLACK_MIN, double PROBA_MIN, int NB_GATE, string xorKey, string netlistName, bool forceCalculate, SimulationReporter reportObject, out List<Net> addedKeyInputNets, out string addedKeyValues, TextBox textBox, bool createReport, ProgressBar progressBar)
        //{
        //    //----------------------------------------------------------------------

        //    //اگه اصلا قرار نیست کلید تروجانی بذاریم، پس نیازی هم به محاسبه احتمال ها نیست
        //    if (NB_GATE > 0)
        //    {
        //        //++++++++++++++++++++++++++
        //        reportObject.AddToConsoleLog("Simulating netlist for probabilities before encryption started...");

        //        //چون گزارش ساز قبلا حساب کرده، اینجا فقط لود میشه
        //        //با شرط یکسان بودن ورودی های لاجیک سیمیولیشن و هاردورتروجان، اینجا فقط لود میشه
        //        string loadReport;
        //        var totalSamples = LogicSimulation.LoadOrCalculateProbabilities(
        //            nets: nets, 
        //            clockTimes: clockTimesHT, 
        //            randomSeed: randomSeedHT, 
        //            totalTimes: randomPatternsCountHT, 
        //            meetThreshold: meetThresholdHT, 
        //            threshold: thresholdHT, 
        //            textBox: null, 
        //            netlistName: netlistName,
        //            loadReport: out loadReport,
        //            forceCalculate: forceCalculate, 
        //            allowSaveResults: true);

        //        //++++++++++++++++++++++++++
        //        reportObject.AddToConsoleLog(loadReport);

        //        //++++++++++++++++++++++++++
        //        reportObject.AddToConsoleLog("Total samples: " + totalSamples);

        //    }

        //    //++++++++++++++++++++++++++
        //    reportObject.AddToConsoleLog("Simulating netlist for probabilities before encryption ended");

        //    //----------------------------------------------------------------------


        //    //++++++++++++++++++++++++++
        //    if (considerSlackTime)
        //    {
        //        reportObject.AddToConsoleLog("Computing slack times before encryption started...");

        //        //چون گزارش ساز قبلا حساب کرده، اینجا فقط لود میشه
        //        int maxLevel;
        //        string loadReport;
        //        ASAPALAPSlackTime.LoadOrCalculateASAPALAPSlackTimeOfNets(
        //            nets: nets, 
        //            maxLevel: out maxLevel, 
        //            netlistName: netlistName,
        //            loadReport: out loadReport,
        //            forceCalculate: forceCalculate, 
        //            allowSaveResults: true);

        //        reportObject.AddToConsoleLog(loadReport);

        //        //++++++++++++++++++++++++++
        //        reportObject.AddToConsoleLog("Computing slack times before encryption ended");
        //    }


        //    //----------------------------------------------------------------------

        //    //محاسبه نت های کلاک تا بعدا از فرآیند رمز گذاری حذف شود
        //    var clockNets = CommonMethods.GetClockNets(nets);

        //    //حذف سیگنال های کلاک از فرایند رمزگذاری
        //    //faultImpactNets = faultImpactNets.Except(clockNets).ToList();

        //    addedKeyInputNets = new List<Net>();
        //    addedKeyValues = "";
        //    var xorKeyIndex = 0;
        //    var appliedSignals = new HashSet<Net>();

        //    //ثبت دور صفرم
        //    reportObject.Step02FinishRound(nets, addedKeyValues, forceCalculate: forceCalculate);

        //    #region HT KeyGates

        //    if (NB_GATE > 0)
        //    {
        //        var randomHT = new Random(randomSeedHT);

        //        //======================================================================
        //        //تعیین پارامتر مشخص کننده معیار درج کلید برای محافظت در برابر تروجان
        //        foreach (var net in nets)
        //        {
        //            net.HTAncestorSelectionParameter = Math.Round(Math.Abs(0.5 - net.SimulatedProbability), 10);
        //        }
        //        //======================================================================
        //        //++++++++++++++++++++++++++
        //        reportObject.AddToConsoleLog("Computing rare signals started...");

        //        //حذف سیگنال های کلاک از فرایند رمزگذاری
        //        var rareSignals =
        //            nets.Where(
        //                net => net.SimulatedProbability <= PROBA_MIN || net.SimulatedProbability >= (1 - PROBA_MIN))
        //                .ToList()
        //                .Except(clockNets)
        //                .ToList();

        //        rareSignals = LogicSimulation.SortBySimulatedProbabilityFromMaxDistanceToHalfToMin(rareSignals);

        //        //++++++++++++++++++++++++++
        //        reportObject.AddToConsoleLog("Computing rare signals ended");

        //        //======================================================================
        //        var addedHTKeyInputNets = new List<Net>();
        //        //var addedHTKeyValues = "";

        //        //++++++++++++++++++++++++++
        //        reportObject.AddToConsoleLog("Inserting HTkey gates started...");

        //        //در ابتدا به تعداد بیت های مورد نظر برای مقابله با تروجان رمز نگاری می کنیم
        //        foreach (var rareSignal in rareSignals)
        //        {
        //            //اگر به اندازه کافی کلید درج شد، خارج شود
        //            if (addedHTKeyInputNets.Count >= NB_GATE)
        //                break;
        //            //----------------------------------------------------------------------
        //            //بدست آوردن نت های پیش از این نت نادر
        //            var previousSingalsHashSet = new HashSet<Net>();
        //            HTEncryption.FillPreviousSignals(rareSignal, previousSingalsHashSet);

        //            //حذف سیگنال های کلاک از فرایند رمزگذاری
        //            previousSingalsHashSet = new HashSet<Net>(previousSingalsHashSet.Except(clockNets));
        //            if (previousSingalsHashSet.Count == 0)
        //            {
        //                //MessageBox.Show("این نت، نت قبلی ندارد" + " Name: " + rareSignal.Name);
        //                continue;
        //            }

        //            //----------------------------------------------------------------------
        //            //انتخاب نت هایی که اسلک تایم کافی دارند
        //            //با درنظر گرفتن اینکه ممکن است اصلا به اسلک تایم نگاه نکنیم
        //            var previousSingalsWithEnoughSlackTime = new List<Net>();
        //            foreach (var previousSingal in previousSingalsHashSet)
        //            {
        //                if (!considerSlackTime || previousSingal.SlackTime >= SLACK_MIN)
        //                    previousSingalsWithEnoughSlackTime.Add(previousSingal);
        //            }
        //            if (previousSingalsWithEnoughSlackTime.Count == 0)
        //            {
        //                //MessageBox.Show("این نت، نت قبلی با اسلک تایم مورد نظر ندارد" + " Name: " + rareSignal.Name);
        //                continue;
        //            }
        //            //----------------------------------------------------------------------

        //            bool closeToZero;
        //            var signalToEncrypt = ChooseProperAncestorSignalToEncrypt(previousSingalsWithEnoughSlackTime,
        //                appliedSignals, out closeToZero); //es in paper
        //            if (signalToEncrypt == null)
        //                continue;

        //            appliedSignals.Add(signalToEncrypt);

        //            //++++++++++++++++++++++++++
        //            reportObject.AddToConsoleLog("Round " + (addedKeyValues.Length + 1) + " Ancestor Gate (" +
        //                                         signalToEncrypt.Name + ") (" +
        //                                         signalToEncrypt.HTAncestorSelectionParameter + ")");

        //            //----------------------------------------------------------------------

        //            //ساخت گیت کلید نند و نور
        //            Net chosenHTKeyGate;

        //            //تعیین نوع گیت کلید
        //            if (closeToZero)
        //            {
        //                chosenHTKeyGate = new GateNand();
        //                addedKeyValues += "1";
        //            }
        //            else
        //            {
        //                chosenHTKeyGate = new GateNor();
        //                addedKeyValues += "0";
        //            }

        //            //اضافه کردن گیت کلید به لیست نت های مدار
        //            nets.Add(chosenHTKeyGate);

        //            //ایده خودم! تا از انتخاب گیت کلید برای درج کلید بعدی جلوگیری شود
        //            appliedSignals.Add(chosenHTKeyGate); //New

        //            //کامل کردن مشخصات گیت کلید
        //            CommonMethods.CompleteKeyGate(newKeyGate: chosenHTKeyGate, index: addedKeyValues.Length,
        //                location: signalToEncrypt);
        //            //----------------------------------------------------------------------

        //            //سیم ورودی کلید نند و نور برای مدار ساخته می شود
        //            //بدون اصلاح اسلک تایم ها
        //            var newInputNet = CommonMethods.CreateAndInsertInputKeyNet(newKeyGate: chosenHTKeyGate,
        //                keyIndex: addedKeyValues.Length);

        //            //سیم ورودی کلید به لیست نت های مدار اضافه می شود
        //            nets.Add(newInputNet);

        //            //ایده خودم! تا از انتخاب خود ورودی کلید برای درج کلید بعدی جلوگیری شود
        //            appliedSignals.Add(newInputNet); //New

        //            //اضافه کردن سیم ورودی کلید به لیست سیم های ورودی کلید مدار
        //            addedHTKeyInputNets.Add(newInputNet);
        //            addedKeyInputNets.Add(newInputNet);
        //            //----------------------------------------------------------------------

        //            //درج گیت کلید ضد تروجان پس از سیگنال نامتوازن
        //            //بدون اصلاح اسلک تایم ها
        //            CommonMethods.InsertNewGateAfterLocation(newGate: chosenHTKeyGate, location: signalToEncrypt);

        //            //تا اینجا یک عدد گیت نند یا نور سر راه سیگنال مورد نظر گذاشته ایم
        //            //پس یک دونه از اسلک تایمش کم می کنیم
        //            signalToEncrypt.SlackTime -= 1;

        //            var newKeyValue = xorKey[xorKeyIndex++];
        //            addedKeyValues += newKeyValue;
        //            var keyIndex = addedKeyValues.Length;

        //            //درج گیت کلید از نوع ایکسور و ایکسنور با عملکرد معکوس کننده برای حفاظت از کلید نند و نور
        //            // در صورتی که اسلک تایم مهم باشد و به اندازه 2 اسلک تایم زمان داشته باشیم
        //            // از ترکیب تصادفی ایکسور و ایکسنور و اینورتر استفاده می کند
        //            // اما چنانچه اسلک تایم مهم باشد و تنها به اندازه 1 واحد زمان اسلک تایم داشته باشیم
        //            // تنها با استفاده از یک گیت ایکسور یا ایکسنور که متناسب با کلید ورودی ساخته می شوند رمز گذاری می شود
        //            CreateAndInsertRandomXORXNORKeyGateInverterWithRespectiveKeyInputNet(
        //                nets: nets,
        //                considerSlackTimes: considerSlackTime,
        //                location: signalToEncrypt,
        //                keyIndex: keyIndex,
        //                newKeyValue: newKeyValue,
        //                addedKeyInputNets: addedKeyInputNets,
        //                appliedSignals: appliedSignals,
        //                random: randomHT);

        //            reportObject.Step02FinishRound(nets, addedKeyValues, forceCalculate: forceCalculate);
        //        }

        //        //++++++++++++++++++++++++++
        //        reportObject.AddToConsoleLog("Inserting HTkey gates ended");
        //    }

        //    #endregion

        //    //======================================================================
        //    //======================================================================
        //    //======================================================================

        //    #region XKeyGates

        //    Net.ToStringMode = Net.NetToStringMode.XKeySelectionParameter;

        //    if (xorKeyIndex < xorKey.Length)
        //    {
        //        Net.ToStringMode = Net.NetToStringMode.HD;

        //        var randomGreedy = new Random(randomSeedGreedy);
               
        //        //الان درج کلید های ضد تروجان تموم شده
        //        //حالا بقیه بیت های باقی مانده از ایکسور و ایکسنور را برای رمز نگاری به روش 
        //        //فالت ایمپکت استفاده می کنیم


        //        //++++++++++++++++++++++++++
        //        reportObject.AddToConsoleLog("Inserting Xkey gates started...");

        //        var t0 = DateTime.Now;
        //        var t1 = DateTime.Now;

        //        var encryptionKey = xorKey.Substring(xorKeyIndex, xorKey.Length - xorKeyIndex);
        //        var keyInputs = new List<Net>();
        //        var keyGates = new List<Net>();
        //        progressBar.Value = 0;

        //        //Generate R ; //a random number
        //        var R = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(randomGreedy, encryptionKey.Length);
        //        var GateType = FARajendran.Xor(encryptionKey, R);

        //        for (int i = 0; i < encryptionKey.Length; i++)
        //        {

        //            var percent = ((double)i * 100 / encryptionKey.Length);
        //            var header = "Total Progress: " + (int)percent + "%\r\n" +
        //                         FaultImpacts.TimeEstimationString(t0, t1, percent) + "\r\n\r\n" +
        //                         "Calculating HammingDistances (" + (i + 1) + "/" + encryptionKey.Length + ")\r\n";

        //            string hammingDistancesLoadReport;
        //            List<Net> sortedNetsByHammingDistance = HD2.LoadOrCalculateAverageHammingDistanceForAllPossbileNets(
        //                nets: nets,
        //                percent: ref percent,
        //                keyGates: keyGates,
        //                keyInputs: keyInputs,
        //                key: encryptionKey.Substring(0, i),
        //                newKeyValue: encryptionKey[i],
        //                randomPatterns: randomPatternsCountGreedy,
        //                randomSeed: randomSeedGreedy,
        //                uniqueRandomPatterns: uniqueRandomPatternsGreedy,
        //                forceWrongInputs: forceWrongInputsGreedy,
        //                clockTimes: clockTimesGreedy,
        //                threadsCount: threadsCountGreedy,
        //                textBox: textBox,
        //                header: header,
        //                loadReport: out hammingDistancesLoadReport,
        //                forceCalculate: forceCalculate,
        //                allowSaveResults: true,
        //                netlistName: netlistName);

        //            //++++++++++++++++++++++++++
        //            reportObject.AddToConsoleLog(hammingDistancesLoadReport);

        //            Application.DoEvents();
        //            if (FaultImpacts.Exiting)
        //                break;

        //            //درصورت لزوم اسلک تایم درنظر گرفته می شود
        //            Net chosenNet = null;
        //            if (considerSlackTime)
        //            {
        //                foreach (var net in sortedNetsByHammingDistance)
        //                {
        //                    if (net.SlackTime == 0)
        //                        continue;
        //                    chosenNet = net;
        //                }
        //            }
        //            else
        //            {
        //                chosenNet = sortedNetsByHammingDistance[0];// = GetNewNetToEncrypt(faultImpactNets: faultImpactNets, appliedNets: appliedNets);
        //            }
        //            if (chosenNet == null)
        //                break;

        //            //++++++++++++++++++++++++++
        //            reportObject.AddToConsoleLog("Round " + (addedKeyValues.Length + 1) + " Gate (" + chosenNet.Name + ") (" + chosenNet.HD + ")");

        //            //اول ایکسور می ذاره
        //            FARajendran.InsertNewXORGateAtLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs);

        //            //اگر باید اسلک تایم درنظر گرفته شود
        //            if (considerSlackTime && chosenNet.SlackTime == 1)
        //            {
        //                if (encryptionKey[i] == '1')
        //                {
        //                    CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
        //                    keyGates[i].SlackTime -= 1;
        //                }
        //            }
        //            else
        //            {
        //                //بعد اگه بیت کلید یک بود یک اینورتر سر راه ایکسور قرار میده
        //                if (R[i] == '1')
        //                {
        //                    //Insert an inverter at the o/p of corresponding keygate;
        //                    var newInverter = CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);
        //                }

        //                //بعد اگه بیت کلید یک بود، گیت ایکسور را با گیت ایکسنور تعویض می کند
        //                if (GateType[i] == '1')
        //                {
        //                    //گیت ایکسور را با ایکسنور جایگزین می کند

        //                    //Replace the XOR key-gate with an XNOR key-gate;
        //                    CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
        //                }

        //                if (considerSlackTime)
        //                    keyGates[i].SlackTime -= 2;
        //            }

        //            addedKeyValues += encryptionKey[i];

        //            reportObject.Step02FinishRound(nets: nets, addedKeyValues: encryptionKey.Substring(0, i + 1), forceCalculate: forceCalculate);
        //        }

        //        //++++++++++++++++++++++++++
        //        reportObject.AddToConsoleLog("Inserting Xkey gates ended");
        //    }

        //    #endregion
        //}






    }
}
