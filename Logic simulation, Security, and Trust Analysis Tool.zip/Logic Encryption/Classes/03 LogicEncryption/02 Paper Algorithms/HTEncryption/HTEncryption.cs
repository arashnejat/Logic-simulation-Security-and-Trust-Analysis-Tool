﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public partial class HTEncryption
    {
        /// <summary>
        /// اصل مقاله
        /// A Novel Hardware Logic Encryption Technique for thwarting Illegal Overproduction and Hardware Trojans
        /// بدون هیچ بهینه سازی
        /// </summary>
        /// <param name="nets"></param>
        /// <param name="NB_GATE"></param>
        /// <param name="PROBA_MIN"></param>
        /// <param name="SLACK_MIN"></param>
        /// <param name="addedKeyInputNets"></param>
        /// <param name="addedKeyValues"></param>
        /// <param name="textBox"></param>
        /// <param name="clockTimes"></param>
        /// <param name="randomSeed"></param>
        /// <param name="randomPatternsCount"></param>
        /// <param name="threshold"></param>
        /// <param name="meetThreshold"></param>
        /// <param name="reportObject"></param>
        /// <param name="netlistName"></param>
        /// <param name="forceCalculate"></param>
        /// <param name="considerSlackTime"></param>
        public static void Alg13EncryptOriginalAlgorithm(List<Net> nets, int NB_GATE, double PROBA_MIN, double SLACK_MIN, out string addedKeyValues, TextBox textBox, int clockTimes, int randomSeed, int randomPatternsCount, double threshold, bool meetThreshold, SimulationReporter reportObject, string netlistName, bool forceCalculate, bool considerSlackTime = true)
        {
            var addedKeyInputNets = new List<Net>();
            addedKeyValues = "";
            //----------------------------------------------------------------------
            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Simulating netlist for probabilities before encryption started...");

            string probabilitiesLoadReport;
            //چون گزارش ساز قبلا حساب کرده، اینجا فقط لود میشه
            var totalSamples = LogicSimulation.LoadOrCalculateProbabilities(
                nets: nets,
                clockTimes: clockTimes,
                randomSeed: randomSeed,
                totalTimes: randomPatternsCount,
                meetThreshold: meetThreshold,
                threshold: threshold,
                textBox: null,
                netlistName: netlistName,
                loadReport: out probabilitiesLoadReport,
                forceCalculate: forceCalculate,
                allowSaveResults: true);

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Total Samples: " + totalSamples);

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Simulating netlist for probabilities before encryption ended");
            //----------------------------------------------------------------------           
            Net.ToStringMode = Net.NetToStringMode.SimulatedProbability;
            //======================================================================
            var rareSignals = nets.Where(net => net.SimulatedProbability <= PROBA_MIN || net.SimulatedProbability >= (1 - PROBA_MIN)).ToList();

            reportObject.Step02FinishRound(nets, addedKeyValues, forceCalculate: forceCalculate);
            var slackTimesAreFresh = false;
            foreach (var rareSignal in rareSignals)
            {
                //اگر به اندازه کافی کلید درج شد، خارج شود
                if (addedKeyInputNets.Count >= NB_GATE)
                    break;
                //----------------------------------------------------------------------
                if (considerSlackTime && !slackTimesAreFresh)
                {
                    //++++++++++++++++++++++++++
                    reportObject.AddToConsoleLog("Computing slack times before encryption started...");

                    //چون گزارش ساز قبلا حساب کرده، اینجا فقط لود میشه
                    int maxLevel;
                    string loadReport;
                    ASAPALAPSlackTime.LoadOrCalculateASAPALAPSlackTimeOfNets(
                        nets: nets,
                        maxLevel: out maxLevel,
                        netlistName: netlistName,
                        loadReport: out loadReport,
                        forceCalculate: forceCalculate,
                        allowSaveResults: true);

                    slackTimesAreFresh = true;
                    //++++++++++++++++++++++++++
                    reportObject.AddToConsoleLog("Computing slack times before encryption ended");
                }
                //----------------------------------------------------------------------
                //بدست آوردن نت های پیش از این نت نادر
                var previousSingalsHashSet = new HashSet<Net>();
                FillPreviousSignals(rareSignal, previousSingalsHashSet);
                if (previousSingalsHashSet.Count == 0)
                {
                    //MessageBox.Show("این نت، نت قبلی ندارد" + " Name: " + rareSignal.Name);
                    continue;
                }
                //----------------------------------------------------------------------
                //انتخاب نت هایی که اسلک تایم کافی دارند
                var previousSingalsWithEnoughSlackTime = new List<Net>();
                foreach (var previousSingal in previousSingalsHashSet)
                {
                    if (!considerSlackTime || previousSingal.SlackTime >= SLACK_MIN)
                        previousSingalsWithEnoughSlackTime.Add(previousSingal);
                }
                if (previousSingalsWithEnoughSlackTime.Count == 0)
                {
                    //MessageBox.Show("این نت، نت قبلی با اسلک تایم مورد نظر ندارد" + " Name: " + rareSignal.Name);
                    continue;
                }
                //----------------------------------------------------------------------
                //انتخاب نامتوازن ترین از میان سیگنال های پیشین

                bool closeToZero;
                var mostUnbalancedSignal = ChooseMostUnbalancedSignal(previousSingalsWithEnoughSlackTime, out closeToZero);//es in paper //Enhancement Removed , appliedMostUnbalancedSignals
                if (mostUnbalancedSignal == null)
                    continue;//ایجا قبلا اشتباها ریترن بود

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Chosen Most Unbalanced Signal:\t" + mostUnbalancedSignal.Name);

                //----------------------------------------------------------------------

                //ساخت گیت کلید
                Net chosenKeyGate;

                //تعیین نوع گیت کلید
                if (closeToZero)
                {
                    chosenKeyGate = new GateOr();
                    addedKeyValues += "0";
                }
                else
                {
                    chosenKeyGate = new GateAnd();
                    addedKeyValues += "1";
                }

                //اضافه کردن گیت کلید به لیست نت های مدار
                nets.Add(chosenKeyGate);

                //کامل کردن مشخصات گیت کلید
                CommonMethods.CompleteKeyGate(newKeyGate: chosenKeyGate, index: addedKeyValues.Length, location: mostUnbalancedSignal);
                //----------------------------------------------------------------------

                //سیم ورودی کلید برای مدار ساخته می شود
                var newInputNet = CommonMethods.CreateAndInsertInputKeyNetConsideringSlackTimes(newKeyGate: chosenKeyGate, keyIndex: addedKeyValues.Length, location: mostUnbalancedSignal);

                //سیم ورودی کلید به لیست نت های مدار اضافه می شود
                nets.Add(newInputNet);

                //اضافه کردن سیم ورودی کلید به لیست سیم های ورودی کلید مدار
                addedKeyInputNets.Add(newInputNet);
                //----------------------------------------------------------------------

                //درج گیت کلید پس از سیگنال نامتوازن
                CommonMethods.InsertNewGateAfterLocationConsideringSlackTimes(newGate: chosenKeyGate, location: mostUnbalancedSignal);

                slackTimesAreFresh = false;

                //توجه، توجه
                //نگهداری احتمالات در متغیر موقتی تا با بروز رسانی که توسط تحلیل پس از اتمام دور صورت میگیرد، آمیخته نگردند
                foreach (var net in nets)
                    net.SimulatedProbabilityTempForAlgAHTOrighnalAlg13 = net.SimulatedProbability;

                //توجه، توجه
                //این احتمالات رو بروز رسانی می کنه! که نباید در روش اصلی اینکار انجام بشه
                reportObject.Step02FinishRound(nets, addedKeyValues, forceCalculate: forceCalculate);

                //توجه، توجه
                //بازگرداندن احتمالات اولیه، پس از بروزرسانی که توسط عملیات تحلیل صورت گرفته بود
                foreach (var net in nets)
                    net.SimulatedProbability = net.SimulatedProbabilityTempForAlgAHTOrighnalAlg13;
            }
            //======================================================================
        }

        private static List<Net> GetRareSignals(List<Net> nets, double PROBA_MIN, List<Net> rareSignals)
        {
            rareSignals = nets.Where(net => net.SimulatedProbability <= PROBA_MIN || net.SimulatedProbability >= (1 - PROBA_MIN)).ToList();


            //ایده خودم! تا اول نت هایی که خیلی نامتوازن هستند را اصلاح کنیم
            //مشکلی که وجود داشت این بود که وقتی لود می کرد و بعد سورت می کرد
            //با اینکه داده های یکسانی لود می شدند ولی
            //ترتیب با زمانی که محاسبه می کرد متفاوت بود
            //لذا تابع سورتی نوشتم تا اول تا 10 رقم اعشار روند کند و بعد سورت کند
            //rareSignals.Sort((net1, net2) => Math.Sign(Math.Abs(0.5 - net2.SimulatedProbability) - Math.Abs(0.5 - net1.SimulatedProbability)));//New
            //rareSignals = rareSignals.OrderBy(o => Math.Abs(0.5 - o.SimulatedProbability)).ToList();
            rareSignals = LogicSimulation.SortBySimulatedProbabilityFromMaxDistanceToHalfToMin(rareSignals);
            return rareSignals;
        }

        public static Net ChooseMostUnbalancedSignal(List<Net> previousSingalsWithEnoughSlackTime, out bool closeToZero, HashSet<Net> appliedMostUnbalancedSignals = null)
        {
            var possibleSignals = new List<Net>(previousSingalsWithEnoughSlackTime.Except(appliedMostUnbalancedSignals ?? new HashSet<Net>()));
            //sortedNetlist.Sort((net1, net2) => Math.Sign(Math.Abs(0.5 - net2.SimulatedProbability) - Math.Abs(0.5 - net1.SimulatedProbability)));

            var sortedNetlist = LogicSimulation.SortBySimulatedProbabilityFromMaxDistanceToHalfToMin(possibleSignals);

            if (sortedNetlist.Count == 0)
            {
                closeToZero = false;
                return null;
            }

            Net.ToStringMode = Net.NetToStringMode.SimulatedProbability;
            var mostUnbalancedSignal = sortedNetlist[0];

            if (mostUnbalancedSignal.SimulatedProbability < 0.5)
                closeToZero = true;
            else
                closeToZero = false;

            return sortedNetlist[0];
        }

        //public static Net InsertKeyGateAfterLocation(List<Net> nets, Net keyGate, Net location, List<Net> addedKeyInputNets, int keyIndex)
        //{
        //    var inputNet = CommonMethods.CreateAndInsertInputKeyNet(newKeyGate: keyGate, keyIndex: keyIndex, location: location);

        //    addedKeyInputNets.Add(inputNet);
        //    nets.Add(inputNet);
        //    nets.Add(keyGate);

        //    CommonMethods.InsertNewGateAfterLocation(newGate: keyGate, location: location);

        //    return inputNet;
        //}

        //needs to be tested
        /// <summary>
        ///بازگشتی به عقب می رود و همه نت های منتج به این نت را در هش ست اضافه می کند
        /// </summary>
        /// <param name="rareSignal"></param>
        /// <param name="previousSingals"></param>
        public static void FillPreviousSignals(Net rareSignal, HashSet<Net> previousSingals)
        {
            //شرط خروج از بازگشت
            //if (rareSignal.Inputs.Count == 0)
                //return;

            foreach (var input in rareSignal.Inputs)
            {
                if (!previousSingals.Contains(input.Net))
                {
                    previousSingals.Add(input.Net);
                    FillPreviousSignals(input.Net, previousSingals);
                }
            }
        }
    }
}