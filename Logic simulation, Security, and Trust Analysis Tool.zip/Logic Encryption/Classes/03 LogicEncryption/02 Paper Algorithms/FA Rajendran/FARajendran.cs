﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogicEncryption
{
    public class FARajendran
    {
       
        /// <summary>
        ///ورژن اصلی مقاله راجندران که به دلیل اینکه اینورتر ها را بیرون حلقه درج می کند نمی توان سریالی شبیه سازی را انجام داد
        /// </summary>
        /// <param name="nets"></param>
        /// <param name="keyLength"></param>
        /// <param name="addedKeyValues"></param>
        /// <param name="keyGates"></param>
        /// <param name="keyInputs"></param>
        /// <param name="randomSeed"></param>
        /// <param name="uniqueRandomPatterns"></param>
        /// <param name="textBox"></param>
        /// <param name="progressBar"></param>
        /// <param name="reportObject"></param>
        /// <param name="clockTimes"></param>
        /// <param name="threadsCount"></param>
        /// <param name="randomNumbers"></param>
        /// <param name="netlistName"></param>
        /// <param name="stopClockingOnFirstDetection"></param>
        /// <param name="createReport"></param>
        /// <param name="forceCalculate"></param>
        public static void Alg00FARajendranOriginalEncrypt(List<Net> nets, string encryptionKey, out string addedKeyValues, out List<Net> keyGates, out List<Net> keyInputs, int randomSeed, bool uniqueRandomPatterns, TextBox textBox, ProgressBar progressBar, SimulationReporter reportObject, int clockTimes, int threadsCount, int randomNumbers, string netlistName, bool createReport, bool forceCalculate, int rRandomSeed)
        {
            var random = new Random(rRandomSeed);
            var t0 = DateTime.Now;
            var t1 = DateTime.Now;

            keyInputs = new List<Net>();
            keyGates = new List<Net>();
            addedKeyValues = "";

            progressBar.Value = 0;
            Application.DoEvents();

            string report = "";

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Inserting new key gates ...");

            for (int i = 0; i < encryptionKey.Length; i++)
            {
                var percent = ((double)i * 100 / encryptionKey.Length);
                var header = "Total Progress: " + (int)percent + "%\r\n" +
                             FaultImpacts.TimeEstimationString(t0, t1, percent) + "\r\n\r\n" +
                             "Calculating FaultImpacts (" + (i + 1) + "/" + encryptionKey.Length + ")\r\n";

                //Compute FaultImpact;
                string faultImpactsLoadReport;
                var faultImpactNets = FaultImpacts.LoadOrCalculateFaultImpacts(
                    nets: nets,
                    randomSeed: randomSeed,
                    uniqueRandomPatterns: uniqueRandomPatterns,
                    textBox: textBox,
                    clockTimes: clockTimes,
                    threadsCount: threadsCount,
                    randomNumbers: randomNumbers,
                    netlistName: netlistName,
                    header: header,
                    createReport: createReport,
                    report: out report,
                    progressBar: progressBar,
                    loadReport: out faultImpactsLoadReport,
                    forceCalculate: forceCalculate /*|| i > 0*/,
                    allowSaveResults: true /*(i == 0)*/);

                Application.DoEvents();
                if (FaultImpacts.Exiting)
                    break;

                Net.ToStringMode = Net.NetToStringMode.FaultImpact;

                //Select the gate with the highest FaultImpact;
                var chosenNet = faultImpactNets[0];

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Round " + (i + 1) + " Gate (" + chosenNet.Name + ") (" + chosenNet.FaultImpact + ")");

                //اول ایکسور می ذاره
                //Insert XOR gate and update the Netlist;
                CommonMethods.InsertNewXORGateAfterLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs);
                addedKeyValues += encryptionKey[i];
            }

            //Generate R ; //a random number
            var R = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(random, encryptionKey.Length);
            var GateType = Xor(encryptionKey, R);

            for (var i = 0; i < encryptionKey.Length; i++)
            {
                if (R[i] == '1')
                {
                    //Insert an inverter at the o/p of corresponding keygate;
                    CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);
                }
            }

            for (var i = 0; i < encryptionKey.Length; i++)
            {
                if (GateType[i] == '1')
                {
                    //Replace the XOR key-gate with an XNOR key-gate;
                    CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
                }
            }

            reportObject.AddToConsoleLog("End of inserting key gates ...");
        }

        /// <summary>
        /// به هیچ عنوان تکرار را درنظر نمی گیرد
        /// </summary>
        /// <param name="nets"></param>
        /// <param name="keyLength"></param>
        /// <param name="addedKeyValues"></param>
        /// <param name="keyGates"></param>
        /// <param name="keyInputs"></param>
        /// <param name="randomSeed"></param>
        /// <param name="uniqueRandomPatterns"></param>
        /// <param name="textBox"></param>
        /// <param name="progressBar"></param>
        /// <param name="reportObject"></param>
        /// <param name="clockTimes"></param>
        /// <param name="threadsCount"></param>
        /// <param name="randomNumbers"></param>
        /// <param name="netlistName"></param>
        /// <param name="stopClockingOnFirstDetection"></param>
        /// <param name="createReport"></param>
        /// <param name="forceCalculate"></param>
        /// <param name="keyRandomSeed"></param>
        public static void Alg01FARajendranOriginalEncrypt(List<Net> nets, string encryptionKey, out string addedKeyValues, int randomSeed, bool uniqueRandomPatterns, TextBox textBox, ProgressBar progressBar, SimulationReporter reportObject, int clockTimes, int threadsCount, int randomNumbers, string netlistName, bool createReport, bool forceCalculate, int rRandomSeed, bool useFaultImpacts2)
        {
            var random = new Random(rRandomSeed);
            var t0 = DateTime.Now;
            var t1 = DateTime.Now;

            var keyInputs = new List<Net>();
            var keyGates = new List<Net>();
            addedKeyValues = "";

            progressBar.Value = 0;
            Application.DoEvents();

            string report = "";

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Inserting new key gates ...");

            //Generate R ; //a random number
            var R = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(random, encryptionKey.Length);
            var GateType = Xor(encryptionKey, R);

            reportObject.Step02FinishRound(nets,"", forceCalculate: forceCalculate);
            for (int i = 0; i < encryptionKey.Length; i++)
            {
                var percent = ((double)i * 100 / encryptionKey.Length);
                var header = "Total Progress: " + (int)percent + "%\r\n" +
                             FaultImpacts2.TimeEstimationString(t0, t1, percent) + "\r\n\r\n" +
                             "Calculating FaultImpacts (" + (i + 1) + "/" + encryptionKey.Length + ")\r\n";

                //Compute FaultImpact;
                string faultImpactsLoadReport;
                List<Net> faultImpactNets;
                if (!useFaultImpacts2)
                {
                    faultImpactNets = FaultImpacts.LoadOrCalculateFaultImpacts(
                        nets: nets,
                        randomSeed: randomSeed,
                        uniqueRandomPatterns: uniqueRandomPatterns,
                        textBox: textBox,
                        clockTimes: clockTimes,
                        threadsCount: threadsCount,
                        randomNumbers: randomNumbers,
                        netlistName: netlistName,
                        header: header,
                        createReport: createReport,
                        report: out report,
                        progressBar: progressBar,
                        loadReport: out faultImpactsLoadReport,
                        forceCalculate: forceCalculate /*|| i > 0*/,
                        allowSaveResults: true /*(i == 0)*/ /*,
                        key: encryptionKey.Substring(0, i)*/);
                }
                else
                {
                    faultImpactNets = FaultImpacts2.LoadOrCalculateFaultImpacts(
                        nets: nets,
                        randomSeed: randomSeed,
                        uniqueRandomPatterns: uniqueRandomPatterns,
                        textBox: textBox,
                        clockTimes: clockTimes,
                        threadsCount: threadsCount,
                        randomNumbers: randomNumbers,
                        netlistName: netlistName,
                        header: header,
                        createReport: createReport,
                        report: out report,
                        progressBar: progressBar,
                        loadReport: out faultImpactsLoadReport,
                        forceCalculate: forceCalculate /*|| i > 0*/,
                        allowSaveResults: true /*(i == 0)*/ ,
                        key: encryptionKey.Substring(0, i));
                }

                textBox.Text = "";
                string fiText;
                fiText = "Nets of round " + i + ":\r\n";
                foreach (var net in nets)
                {
                    fiText += net.Name + ":\t" + net.NoP0 + ", " + net.NoO0 + " _ " + net.NoP1 + ", " + net.NoO1 + " _ " + net.FaultImpact + "\r\n";
                }
                textBox.Text = fiText;

                fiText = "FaultImpacts of round " + i + ":\r\n";
                foreach (var net in faultImpactNets)
                {
                    fiText += net.Name + ":\t" + net.NoP0 + ", " + net.NoO0 + " _ " + net.NoP1 + ", " + net.NoO1 + " _ " + net.FaultImpact + "\r\n";
                }
                textBox.Text = fiText;
                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog(faultImpactsLoadReport);

                Application.DoEvents();
                if (FaultImpacts.Exiting)
                    break;

                Net.ToStringMode = Net.NetToStringMode.FaultImpact;

                //Select the gate with the highest FaultImpact
                var chosenNet = faultImpactNets[0];

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Round " + (i + 1) + " Gate (" + chosenNet.Name + ") (" + chosenNet.FaultImpact + ")");

                //اول ایکسور می ذاره
                //Insert XOR gate and update the Netlist;
                CommonMethods.InsertNewXORGateAfterLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs);

                //بعد اگه بیت کلید یک بود یک اینورتر سر راه ایکسور قرار میده
                if (R[i] == '1')
                {
                    //Insert an inverter at the o/p of corresponding keygate;
                    CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);
                }
                //بعد اگه بیت کلید یک بود، گیت ایکسور را با گیت ایکسنور تعویض می کند
                if (GateType[i] == '1')
                {
                    //Replace the XOR key-gate with an XNOR key-gate;
                    CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
                }

                addedKeyValues += encryptionKey[i];
                reportObject.Step02FinishRound(nets, encryptionKey.Substring(0, i + 1), forceCalculate: forceCalculate);
            }

            reportObject.AddToConsoleLog("End of inserting key gates ...");
        }

        //حیف، بیخودی خراب شد
        public static void Alg02FARajendranAsIPresumeItIsEncrypt(List<Net> nets, string encryptionKey, out string addedKeyValues, int randomSeed, bool uniqueRandomPatterns, TextBox textBox, ProgressBar progressBar, SimulationReporter reportObject, int clockTimes, int threadsCount, int randomNumbers, string netlistName, bool createReport, bool forceCalculate, int rRandomSeed)
        {
            var random = new Random(rRandomSeed);
            var t0 = DateTime.Now;
            var t1 = DateTime.Now;

            var keyInputs = new List<Net>();
            var keyGates = new List<Net>();
            addedKeyValues = "";

            progressBar.Value = 0;
            Application.DoEvents();

            string report = "";


            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Inserting new key gates ...");

            //لیست اعمال شده های قبلی
            var appliedNets = new HashSet<Net>();

            //Generate R ; //a random number
            var R = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(random, encryptionKey.Length);
            var GateType = Xor(encryptionKey, R);

            reportObject.Step02FinishRound(nets, "", forceCalculate: forceCalculate);
            for (int i = 0; i < encryptionKey.Length; i++)
            {
                var percent = ((double)i * 100 / encryptionKey.Length);
                var header = "Total Progress: " + (int)percent + "%\r\n" +
                             FaultImpacts.TimeEstimationString(t0, t1, percent) + "\r\n\r\n" +
                             "Calculating FaultImpacts (" + (i + 1) + "/" + encryptionKey.Length + ")\r\n";

                string faultImpactsLoadReport;
                var faultImpactNets = FaultImpacts.LoadOrCalculateFaultImpacts(
                    nets: nets,
                    randomSeed: randomSeed,
                    uniqueRandomPatterns: uniqueRandomPatterns,
                    textBox: textBox,
                    clockTimes: clockTimes,
                    threadsCount: threadsCount,
                    randomNumbers: randomNumbers,
                    netlistName: netlistName,
                    header: header,
                    
                    createReport: createReport,
                    report: out report,
                    progressBar: progressBar,
                    loadReport: out faultImpactsLoadReport,
                    forceCalculate: forceCalculate /*|| i > 0*/,
                    allowSaveResults: true /*(i == 0)*/);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog(faultImpactsLoadReport);

                Application.DoEvents();
                if (FaultImpacts.Exiting)
                    break;

                Net.ToStringMode = Net.NetToStringMode.FaultImpact;

                //غیر تکراری انتخاب می کند
                //نه گیت با بیشترین فالت ایمپکت قبلی
                //نه گیت ایکسور (اشتباها ایکسنور را ندید میگرفته) حیف
                Net chosenNet = GetNewNetToEncrypt(sortedNets: faultImpactNets, appliedNets: appliedNets);
                if (chosenNet == null)
                    break;

                //اضافه کردن گیت انتخاب شده به لیست اعمال شدگان قبلی
                appliedNets.Add(chosenNet);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Round " + (i + 1) + " Gate (" + chosenNet.Name + ") (" + chosenNet.FaultImpact + ")");

                //اول ایکسور می ذاره
                //و ایکسور را به لیست اعمال شدگان قبلی اضافه می کند
                CommonMethods.InsertNewXORGateAfterLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs, appliedNets: appliedNets);
                
                //بعد اگه بیت کلید یک بود یک اینورتر سر راه ایکسور قرار میده
                if (R[i] == '1')
                {
                    CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);
                    //××××× اشتباها اینورتر را به لیست اعمال شدگان قبلی اضافه نکرده
                }

                //بعد اگه بیت کلید یک بود، گیت ایکسور را با گیت ایکسنور تعویض می کند
                if (GateType[i] == '1')
                {
                    //ReplaceXORwithXNOR
                    CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
                    //××××× اشتباها ایکسنور را به لیست اعمال شدگان قبلی اضافه نکرده
                }

                addedKeyValues += encryptionKey[i];
                reportObject.Step02FinishRound(nets, encryptionKey.Substring(0, i + 1), forceCalculate: forceCalculate);
            }

            reportObject.AddToConsoleLog("End of inserting key gates ...");
        }

        /// <summary>
        /// در هر مرحله فقط گیت انتخاب شده با بیشترین فالت ایمپکت را به لیست اعمال شده های قبلی اضافه می کند
        /// و گیت کلید درج شده (چه ایکسور یا ایکسنور)، ورودی کلید، و گیت اینورتر را به لیست اعمال شده های قبلی اضافه نمی کند
        /// </summary>
        /// <param name="nets"></param>
        /// <param name="keyLength"></param>
        /// <param name="addedKeyValues"></param>
        /// <param name="keyGates"></param>
        /// <param name="keyInputs"></param>
        /// <param name="randomSeed"></param>
        /// <param name="uniqueRandomPatterns"></param>
        /// <param name="textBox"></param>
        /// <param name="progressBar"></param>
        /// <param name="reportObject"></param>
        /// <param name="clockTimes"></param>
        /// <param name="threadsCount"></param>
        /// <param name="randomNumbers"></param>
        /// <param name="netlistName"></param>
        /// <param name="stopClockingOnFirstDetection"></param>
        /// <param name="createReport"></param>
        /// <param name="forceCalculate"></param>
        /// <param name="keyRandomSeed"></param>
        public static void Alg10FARajendran(List<Net> nets, string encryptionKey, out string addedKeyValues, int randomSeed, bool uniqueRandomPatterns, TextBox textBox, ProgressBar progressBar, SimulationReporter reportObject, int clockTimes, int threadsCount, int randomNumbers, string netlistName, bool createReport, bool forceCalculate, int rRandomSeed)
        {
            var random = new Random(rRandomSeed);
            var t0 = DateTime.Now;
            var t1 = DateTime.Now;

            var keyInputs = new List<Net>();
            var keyGates = new List<Net>();
            addedKeyValues = "";

            progressBar.Value = 0;
            Application.DoEvents();

            string report = "";


            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Inserting new key gates ...");

            //لیست اعمال شده های قبلی
            var appliedNets = new HashSet<Net>();

            //Generate R ; //a random number
            var R = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(random, encryptionKey.Length);
            var GateType = Xor(encryptionKey, R);

            reportObject.Step02FinishRound(nets: nets, addedKeyValues: "", forceCalculate: forceCalculate);
            for (int i = 0; i < encryptionKey.Length; i++)
            {
                var percent = ((double)i * 100 / encryptionKey.Length);
                var header = "Total Progress: " + (int)percent + "%\r\n" +
                             FaultImpacts.TimeEstimationString(t0, t1, percent) + "\r\n\r\n" +
                             "Calculating FaultImpacts (" + (i + 1) + "/" + encryptionKey.Length + ")\r\n";

                //Compute FaultImpact;
                string faultImpactsLoadReport;
                var faultImpactNets = FaultImpacts.LoadOrCalculateFaultImpacts(
                    nets: nets,
                    randomSeed: randomSeed,
                    uniqueRandomPatterns: uniqueRandomPatterns,
                    textBox: textBox,
                    clockTimes: clockTimes,
                    threadsCount: threadsCount,
                    randomNumbers: randomNumbers,
                    netlistName: netlistName,
                    header: header,
                    
                    createReport: createReport,
                    report: out report,
                    progressBar: progressBar,
                    loadReport: out faultImpactsLoadReport,
                    forceCalculate: forceCalculate /*|| i > 0*/,
                    allowSaveResults: true /*(i == 0)*/);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog(faultImpactsLoadReport);

                Application.DoEvents();
                if (FaultImpacts.Exiting)
                    break;

                Net.ToStringMode = Net.NetToStringMode.FaultImpact;

                //غیر تکراری انتخاب می کند
                //نه گیت با بیشترین فالت ایمپکت قبلی
                //Select the gate with the highest FaultImpact;
                Net chosenNet = GetNewNetToEncrypt(sortedNets: faultImpactNets, appliedNets: appliedNets);
                if (chosenNet == null)
                    break;

                //فقط گیت انتخاب شده را به لیست اعمال شدگان قبلی اضافه می کند
                appliedNets.Add(chosenNet);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Round " + (i + 1) + " Gate (" + chosenNet.Name + ") (" + chosenNet.FaultImpact + ")");

                //اول ایکسور می ذاره
                //××××× ولی ایکسور و ورودی کلید را به لیست اعمال شدگان قبلی اضافه نکرده
                //Insert XOR gate and update the Netlist;
                CommonMethods.InsertNewXORGateAfterLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs);

                //بعد اگه بیت کلید یک بود یک اینورتر سر راه ایکسور قرار میده
                if (R[i] == '1')
                {
                    //Insert an inverter at the o/p of corresponding keygate;
                    CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);
                    //××××× ولی اینورتر را به لیست اعمال شدگان قبلی اضافه نکرده
                }
                //بعد اگه بیت کلید یک بود، گیت ایکسور را با گیت ایکسنور تعویض می کند
                if (GateType[i] == '1')
                {
                    //Replace the XOR key-gate with an XNOR key-gate;
                    CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
                    //××××× ولی ایکسنور را به لیست اعمال شدگان قبلی اضافه نکرده
                }

                addedKeyValues += encryptionKey[i];
                reportObject.Step02FinishRound(nets: nets, addedKeyValues: encryptionKey.Substring(0, i + 1), forceCalculate: forceCalculate);
            }

            reportObject.AddToConsoleLog("End of inserting key gates ...");
        }

        /// <summary>
        /// در هر مرحله، 1) گیت انتخاب شده با بیشترین فالت ایمپکت، 2) گیت کلید (ایکسور یا ایکسنور) درج شده، 3) ورودی کلید درج شده، و 4) گیت اینورتر درج شده را
        /// به لیست اعمال شده های قبلی اضافه می کند
        /// </summary>
        /// <param name="nets"></param>
        /// <param name="keyLength"></param>
        /// <param name="addedKeyValues"></param>
        /// <param name="keyGates"></param>
        /// <param name="keyInputs"></param>
        /// <param name="randomSeed"></param>
        /// <param name="uniqueRandomPatterns"></param>
        /// <param name="textBox"></param>
        /// <param name="progressBar"></param>
        /// <param name="reportObject"></param>
        /// <param name="clockTimes"></param>
        /// <param name="threadsCount"></param>
        /// <param name="randomNumbers"></param>
        /// <param name="netlistName"></param>
        /// <param name="stopClockingOnFirstDetection"></param>
        /// <param name="createReport"></param>
        /// <param name="forceCalculate"></param>
        /// <param name="keyRandomSeed"></param>
        public static void Alg11FARajendran(List<Net> nets, string encryptionKey, out string addedKeyValues, int randomSeed, bool uniqueRandomPatterns, TextBox textBox, ProgressBar progressBar, SimulationReporter reportObject, int clockTimes, int threadsCount, int randomNumbers, string netlistName, bool createReport, bool forceCalculate, int rRandomSeed)
        {
            var random = new Random(rRandomSeed);
            var t0 = DateTime.Now;
            var t1 = DateTime.Now;

            var keyInputs = new List<Net>();
            var keyGates = new List<Net>();
            addedKeyValues = "";

            progressBar.Value = 0;
            Application.DoEvents();

            string report = "";

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Inserting new key gates ...");

            //لیست اعمال شده های قبلی
            var appliedNets = new HashSet<Net>();

            //Generate R ; //a random number
            var R = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(random, encryptionKey.Length);
            var GateType = Xor(encryptionKey, R);

            reportObject.Step02FinishRound(nets, "", forceCalculate: forceCalculate);
            for (int i = 0; i < encryptionKey.Length; i++)
            {
                var percent = ((double)i * 100 / encryptionKey.Length);
                var header = "Total Progress: " + (int)percent + "%\r\n" +
                             FaultImpacts.TimeEstimationString(t0, t1, percent) + "\r\n\r\n" +
                             "Calculating FaultImpacts (" + (i + 1) + "/" + encryptionKey.Length + ")\r\n";

                string faultImpactsLoadReport;
                var faultImpactNets = FaultImpacts.LoadOrCalculateFaultImpacts(
                    nets: nets,
                    randomSeed: randomSeed,
                    uniqueRandomPatterns: uniqueRandomPatterns,
                    textBox: textBox,
                    clockTimes: clockTimes,
                    threadsCount: threadsCount,
                    randomNumbers: randomNumbers,
                    netlistName: netlistName,
                    header: header,
                    
                    createReport: createReport,
                    report: out report,
                    progressBar: progressBar,
                    loadReport: out faultImpactsLoadReport,
                    forceCalculate: forceCalculate /*|| i > 0*/,
                    allowSaveResults: true /*(i == 0)*/);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog(faultImpactsLoadReport);

                Application.DoEvents();
                if (FaultImpacts.Exiting)
                    break;

                Net.ToStringMode = Net.NetToStringMode.FaultImpact;

                //غیر تکراری انتخاب می کند
                //نه گیت با بیشترین فالت ایمپکت قبلی
                //نه ورودی کلید
                //نه گیت کلید
                //نه اینورتر گیت کلید
                //Select the gate with the highest FaultImpact;
                Net chosenNet = GetNewNetToEncrypt(sortedNets: faultImpactNets, appliedNets: appliedNets);
                if (chosenNet == null)
                    break;

                //اضافه کردن گیت انتخاب شده به لیست اعمال شدگان قبلی
                appliedNets.Add(chosenNet);

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Round " + (i + 1) + " Gate (" + chosenNet.Name + ") (" + chosenNet.FaultImpact + ")");

                //اول ایکسور می ذاره
                //به لیست اعمال شده های قبلی هم ورودی کلید و خود گیت کلید ایکسور را اضافه می کند
                //Insert XOR gate and update the Netlist;
                CommonMethods.InsertNewXORGateAfterLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs, appliedNets: appliedNets);

                //بعد اگه بیت کلید یک بود یک اینورتر سر راه ایکسور قرار میده
                if (R[i] == '1')
                {
                    //Insert an inverter at the o/p of corresponding keygate;
                    var newInverter = CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);

                    //اینورتر را نیز به لیست اعمال شدگان قبلی اضافه می کند
                    appliedNets.Add(newInverter);
                }

                //بعد اگه بیت کلید یک بود، گیت ایکسور را با گیت ایکسنور تعویض می کند
                if (GateType[i] == '1')
                {
                    //گیت ایکسور را با ایکسنور جایگزین می کند
                    //و گیت ایکسنور را نیز به لیست اعمال شده های قبلی اضافه می کند
                    
                    //Replace the XOR key-gate with an XNOR key-gate;
                    CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates, appliedNets: appliedNets);
                }
                
                addedKeyValues += encryptionKey[i];
                reportObject.Step02FinishRound(nets, encryptionKey.Substring(0, i + 1), forceCalculate: forceCalculate);
            }

            reportObject.AddToConsoleLog("End of inserting key gates ...");
        }

        public static string Xor(string encryptionKey, string R)
        {
            var output = "";
            if(R.Length != encryptionKey.Length || string.IsNullOrEmpty(R))
                throw new Exception("XOR Length Error!");

            for (var i = 0; i < encryptionKey.Length; i++)
            {
                var c1 = encryptionKey[i];
                var c2 = R[i];

                if (c1 == c2)
                    output += '0';
                else
                    output += '1';
            }

            return output;
        }

        public static char Xor(char c1, char c2)
        {
            if (c1 == c2)
                return '0';
            else
                return '1';
        }

        /// <summary>
        ///غیر تکراری انتخاب می کند
        ///نه گیت با بیشترین فالت ایمپکت قبلی
        ///نه گیت کلید
        ///نه اینورتر گیت کلید
        /// </summary>
        /// <param name="sortedNets"></param>
        /// <param name="appliedNets"></param>
        /// <returns></returns>
        public static Net GetNewNetToEncrypt(List<Net> sortedNets, HashSet<Net> appliedNets)
        {
            Net outputNet = null;

            for (int i = 0; i < sortedNets.Count; i++)
            {
                var chosenNet = sortedNets[i];

                if (appliedNets.Contains(chosenNet))
                    continue;

                outputNet = chosenNet;
                break;
            }

            return outputNet;
        }

    }
}
