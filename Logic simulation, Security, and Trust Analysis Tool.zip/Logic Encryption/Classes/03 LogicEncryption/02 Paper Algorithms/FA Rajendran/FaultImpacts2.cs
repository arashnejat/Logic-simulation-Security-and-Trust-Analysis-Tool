﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;


namespace LogicEncryption
{
    public class FaultImpacts2
    {
        public static bool Exiting = false;

        /*توجه:
         * فالت ایمپکتز 2 برای محاسبه از منطق 3 مقداره 0 و 1 و ایکس
         * استفاده می کند
         * عملکرد نیز بدین طریق است که در هر راند، در ابتدا با اعمال ورودی های تصادفی به پایه های غیر کلید و مقادیر صحیح به پایه های کلید
         * خروجی های صحیح را بدست می آورد و نگه می دارد
         * سپس با فعال سازی خطاهای چسبیده به 1 و چسبیده به صفر در نقاط مختلف و اعمال مقادیر تصادفی به پایه های غیر کلید و پایه های کلید
         * به محاسبه فاصله همینگ بین خروجی های تولید شده و خروجی های نگهداری شده در ابتدای راند می پردازد
         * و بر مبنای همین فاصله میزان فالت ایمپکت برای هر نت را محاسبه می کند
         */

        #region CacheManager

        /// <summary>
        /// درصورت لزوم فالت ایمپکت را محاسبه کرده یا از کش لود می کند
        /// و لیستی از نت ها که به طور نزولی بر حسب فالت ایمپکت مرتب شده اند را بر می گرداند
        /// </summary>
        /// <param name="nets"></param>
        /// <param name="randomSeed"></param>
        /// <param name="uniqueRandomPatterns"></param>
        /// <param name="textBox"></param>
        /// <param name="clockTimes"></param>
        /// <param name="threadsCount"></param>
        /// <param name="randomNumbers"></param>
        /// <param name="netlistName"></param>
        /// <param name="header"></param>
        /// <param name="stopClockingOnFirstDetection"></param>
        /// <param name="createReport"></param>
        /// <param name="report"></param>
        /// <param name="progressBar"></param>
        /// <param name="forceCalculate"></param>
        /// <param name="allowSaveResults"></param>
        /// <returns></returns>
        public static List<Net> LoadOrCalculateFaultImpacts(List<Net> nets, string key, int randomSeed, bool uniqueRandomPatterns, TextBox textBox, int clockTimes, int threadsCount, int randomNumbers, string netlistName, string header, bool createReport, out string loadReport,out string report, ProgressBar progressBar, bool forceCalculate, bool allowSaveResults)
        {
            var cacheFileName = netlistName + 
                                CacheManager.GetHashFromNets(nets) +
                                "Count=" + randomNumbers + "," +
                                "Unique=" + uniqueRandomPatterns.ToString() + "," + 
                                "Seed=" + randomSeed + "," +
                                "Ticks=" + clockTimes + "," +
                                "Stop=" + false.ToString() + 
                                ".faultImpacts2";

            var cacheFilePath = CacheManager.CacheDirectory + cacheFileName;

            List<Net> faultImpactNets;
            if (!forceCalculate && !string.IsNullOrEmpty(netlistName))
            {
                if (SamimiIO.Exists(cacheFilePath))
                {
                    if (LoadFaultImpactNetsFromFile(cacheFilePath, nets, out faultImpactNets))
                    {
                        loadReport = "FaultImpacts2 Loaded From File:\t" + cacheFileName;
                        report = "";
                        return faultImpactNets;
                    }
                }
            }

            var s = new Stopwatch();
            s.Start();

            faultImpactNets = CalculateFaultImpacts(nets: nets, key: key, randomSeed: randomSeed, uniqueRandomPatterns: uniqueRandomPatterns, textBox: textBox, clockTimes: clockTimes, threadsCount: threadsCount, randomNumbers: randomNumbers, header: header, createReport: createReport, report: out report, progressBar: progressBar);

            s.Stop();
            loadReport = "FaultImpacts2 Calculation Duration:\t" + s.Elapsed;

            if (allowSaveResults)
            {
                SaveFaultImpactNetsToFile(cacheFilePath, faultImpactNets);
                loadReport += "\r\n" + "Saved To File:\t" + cacheFileName;
            }
            return faultImpactNets;
        }

        private static void SaveFaultImpactNetsToFile(string cacheFilePath, List<Net> nets)
        {
            if (SamimiIO.Exiting)
                return;

            var dataToSave = new List<string>();

            foreach (var net in nets)
            {
                dataToSave.Add(net.Name + "\t" + net.FaultImpact + "\t" + net.NoP0 + "\t" + net.NoO0 + "\t" + net.NoP1 + "\t" + net.NoO1);
            }

            var str = string.Join("\r\n", dataToSave);

            SamimiIO.WriteAllText(cacheFilePath, str);
        }

        private static bool LoadFaultImpactNetsFromFile(string cacheFilePath, List<Net> nets, out List<Net> faultImpactNets)
        {
            try
            {
                var str = SamimiIO.ReadAllText(cacheFilePath);

                string[] seperators = {"\r\n", "\t"};

                var data = str.Split(seperators, StringSplitOptions.RemoveEmptyEntries);

                faultImpactNets = new List<Net>();

                var loadedNetsCount = 0;
                for (int i = 0; i < data.Length; i += 6)
                {
                    var foundNet = nets.Find(net => net.Name == data[i + 0]);
                    loadedNetsCount++;

                    foundNet.FaultImpact = int.Parse(data[i + 1]);//2
                    foundNet.NoP0 = int.Parse(data[i + 2]);
                    foundNet.NoO0 = int.Parse(data[i + 3]);
                    foundNet.NoP1 = int.Parse(data[i + 4]);
                    foundNet.NoO1 = int.Parse(data[i + 5]);

                    faultImpactNets.Add(foundNet);
                }

                var goalCountFaultImpactNets = new List<Net>(nets);
                var clockNet = CommonMethods.GetMainClockNet(nets);
                goalCountFaultImpactNets.Remove(clockNet);
                RemoveNonGateNets(goalCountFaultImpactNets);

                if (loadedNetsCount != goalCountFaultImpactNets.Count)
                    throw new Exception("Count not equal, Load failed.");
         
                //faultImpactNets.Sort((net1, net2) => net2.FaultImpact - net1.FaultImpact);

                return true;
            }
            catch (Exception exception)
            {
                faultImpactNets = new List<Net>(nets);
                return false;
            }
        }

        #endregion

        private static List<Net> CalculateFaultImpacts(List<Net> nets, string key, int randomSeed, bool uniqueRandomPatterns, TextBox textBox, int clockTimes, int threadsCount, int randomNumbers, string header, bool createReport, out string report, ProgressBar progressBar)
        {
            var faultImpactNets = FaultImpacts2.CalculateFaultImpactsMultiThreadUi(
                nets: nets,
                header: header,
                textBox: textBox,
                randomSeed: randomSeed,
                randomNumbers: randomNumbers,
                clockTimes: clockTimes,
                threadNumbers: threadsCount,
                uniqueRandomPatterns: uniqueRandomPatterns,
                createReport: createReport,
                report:out report,
                progressBar:progressBar,
                sortOutput: true,
                key: key);
            return faultImpactNets;
        }

        //خروجی لیستی حاوی تمامی محتویات لیست نتز است
        //با این تفاوت که به ترتیب فالت ایمپکتز از بزرگ به کوچک مرتب شده اند
        //و مقادیر فالت ایمپکتز برای هر نت محاسبه شده است
        public static List<Net> CalculateFaultImpactsMultiThreadUi(List<Net> nets, string key, string header, TextBox textBox, int randomSeed, bool uniqueRandomPatterns, int? randomNumbers = 1000, int? clockTimes = 5, int? threadNumbers = 4)
        {
            string report;
            return CalculateFaultImpactsMultiThreadUi(nets: nets, key: key, textBox: textBox, progressBar: null, threadNumbers: threadNumbers,
                randomSeed: randomSeed, clockTimes: clockTimes, randomNumbers: randomNumbers, report: out report,
                sortOutput: true,  createReport: false, header: header, uniqueRandomPatterns: uniqueRandomPatterns);
        }

        public static List<Net> CalculateFaultImpactsMultiThreadUi(List<Net> nets, string key, bool createReport, out string report, ProgressBar progressBar, string header, TextBox textBox, int randomSeed, bool sortOutput, bool uniqueRandomPatterns, int? randomNumbers = 1000, int? clockTimes = 5, int? threadNumbers = 4)
        {
            //موقتا از منطق 5 مقداره به منطق 3 مقداره می رویم و پس از پایان این تابع به منطق قبلی باز می گردیم
            var oldSignalValueMode = Net.SValueMethods.SignalMode;
            Net.SValueMethods.SignalMode = Net.SignalValueMode.ThreeValues01X;

            var t0 = DateTime.Now;

            //Resetting All Nets
            foreach (var net in nets)
            {
                net.FaultImpact = net.NoO0 = net.NoO1 = net.NoP0 = net.NoP1 = 0;
            }

            //Adjusting Threads Count
            if (threadNumbers > nets.Count)
                threadNumbers = nets.Count;

            List<Net> middleNets;
            List<Net> outputNets;
            List<Net> inputNets;
            Parser.ClassifyInputMiddleOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets);
            var clockNet = CommonMethods.GetMainClockNet(nets);
            inputNets.Remove(clockNet);

            //List<string> randomPatterns;
            //if(uniqueRandomPatterns)
            //    randomPatterns = CommonMethods.RandomPatternGeneration.GenerateUniqueRandomPatterns(lenght: inputNets.Count, count: randomNumbers.Value, seed: randomSeed);
            //else
            //    randomPatterns = CommonMethods.RandomPatternGeneration.GenerateExtraUniqueRandomPatterns(lenght: inputNets.Count, count: randomNumbers.Value, seed: randomSeed);
            List<string> generatedRandomPatterns;
            List<string> correctedPatterns;

            GetGeneratedRandomPatterns(inputNets: inputNets, key: key, randomPatterns: randomNumbers.Value, randomSeed: randomSeed, uniqueRandomPatterns: uniqueRandomPatterns, generatedRandomPatterns: out generatedRandomPatterns, correctedPatterns: out correctedPatterns);

            Net.SValueMethods.ResetSValuesAndSta0AndSta1AndFaultImpactsOfNets(nets);
            var correctOutputResults = GetCorrectOutputResults(generatedRandomPatterns: correctedPatterns, nets: nets, clockNet: clockNet, inputNets: inputNets, outputNets: outputNets, clockTimes: clockTimes.Value);
            Net.SValueMethods.ResetSValuesAndSta0AndSta1AndFaultImpactsOfNets(nets);

            var netsHolder = new List<List<Net>>();
            var parameterHolder = new List<FaultImpactThreadDataHolder>();

            if (textBox != null)
            {
                textBox.Text = header + "Preparing Threads...";
                Application.DoEvents();
            }

            //Creating Duplicates Of Netlist for each Thread (First netlist, is the original one)
            netsHolder.Add(nets);
            if (threadNumbers.Value > 1)
                netsHolder.AddRange(Net.SValueMethods.DuplicateNetlist(nets, threadNumbers.Value - 1));

            //Creating Parameters To Send To Threads
            for (var i = 0; i < threadNumbers; i++)
            {
                parameterHolder.Add(new FaultImpactThreadDataHolder()
                {
                    ClockTimes = clockTimes,
                    Nets = netsHolder[i],
                    RandomNumbers = randomNumbers,
                    SortOutput = sortOutput,
                    ThreadNumbers = threadNumbers.Value,
                    IndexOfThread = i,
                    RandomPatterns = generatedRandomPatterns,
                    FaultImpactNets = null,
                    Percent = 0,
                    CorrectResults = new List<Dictionary<string, Net.Signal>>(correctOutputResults)
                });
            }

            if (textBox != null)
            {
                textBox.Text = header + "Starting Threads...";
                Application.DoEvents();
            }

            //Creating & Starting Threads
            var threadsHolder = new List<Thread>();
            for (var i = 0; i < threadNumbers; i++)
            {
                var thread = new Thread(Start);
                threadsHolder.Add(thread);
                thread.Start(parameterHolder[i]);
            }

            string threadsStatus;
            double percent;

            if (textBox != null)
            {
                textBox.Text = header + "Working...";
                Application.DoEvents();
            }

            var t1 = DateTime.Now;

            var allDone = false;
            while (!allDone && !SamimiIO.Exiting)
            {
                threadsStatus = "";
                percent = 0;
                
                allDone = true;
                for (var i = 0; i < threadsHolder.Count; i++)
                {
                    var thread = threadsHolder[i];

                    if (thread.IsAlive)
                        allDone = false;

                    if (Exiting)
                        thread.Abort();


                    if (textBox != null)
                    {
                        percent += parameterHolder[i].Percent / threadsHolder.Count;
                        threadsStatus += (int) parameterHolder[i].Percent + "% ";
                    }
                }

                if (textBox != null)
                {
                    textBox.Text = header + "Threads Status: " + threadsStatus + "\r\n";
                    textBox.Text += TimeEstimationString(t0, t1, percent);
                    if (progressBar != null)
                        progressBar.Value = (int)percent;
                    Application.DoEvents();
                }

                if(!allDone && nets.Count > 100)
                    Thread.Sleep(1000);
            }

            if (progressBar != null)
            {
                progressBar.Value = 100;
                Application.DoEvents();
            }

            if (textBox != null)
            {
                textBox.Text = header + "Merging Threads Results...";
                Application.DoEvents();
            }

            //Merging Results
            for (var i = 0; i < nets.Count; i++)
            {
                var net = nets[i];
                for (var j = 1; j < netsHolder.Count; j++)
                {
                    net.NoO0 += netsHolder[j][i].NoO0;
                    net.NoO1 += netsHolder[j][i].NoO1;
                    net.NoP0 += netsHolder[j][i].NoP0;
                    net.NoP1 += netsHolder[j][i].NoP1;
                }
                net.FaultImpact = net.NoP0 * net.NoO0 + net.NoP1 * net.NoO1;
            }

            var faultImpactNets = parameterHolder[0].FaultImpactNets;

            if (SamimiIO.Exiting)
            {
                report = null;
                return null;
            }

            if (sortOutput)
            {
                if (textBox != null)
                {
                    textBox.Text = header + "Sorting Outputs";
                    Application.DoEvents();
                }

                var sortedFaultImpacts = faultImpactNets.OrderByDescending(net => net.FaultImpact).ThenBy(net => net.Name).ToList();
                faultImpactNets.Clear();
                faultImpactNets.AddRange(sortedFaultImpacts);
            }

            report = "";
            if (createReport)
            {
                if (clockNet != null)
                {
                    report += "Netlist is sequential\r\n";
                    report += "Clock Net: " + clockNet.Name + "\r\n";
                    report += "\r\n";
                }
                else
                {
                    report += "Netlist is not sequential\r\n";
                    report += "\r\n";
                }

                report += "Total Nets: " + nets.Count + "\r\n";
                report += "Total Fault Impact Nets: " + faultImpactNets.Count + "\r\n";
                report += "Total Primary Inputs: " + inputNets.Count + "\r\n";
                report += "Total Primary Outputs: " + outputNets.Count + "\r\n";

                report += "Generated Random Numbers: " + generatedRandomPatterns.Count + "\r\n";
                report += "Total Duration (Seconds): " + (int)(DateTime.Now - t0).TotalSeconds + "\r\n";
                report += "\r\n";

                //report += "Fault Impacts of Nets (Non PI/PO/Fanout Nets): " + "\r\n";
                report += "Fault Impacts: " + "\r\n";

                foreach (var net in faultImpactNets)
                    report += net.Name + ":\t" + net.FaultImpact + "\r\n";
            }

            Net.SValueMethods.SignalMode = oldSignalValueMode;
            return faultImpactNets;
        }

        public static string TimeEstimationString(DateTime t0, DateTime t1, double percent)
        {
            var elapsedTime = (DateTime.Now - t0).TotalSeconds;
            var timeLeft = ((100 - percent)*(DateTime.Now - t1).TotalSeconds)/percent;
            var totalTime = elapsedTime + timeLeft;

            elapsedTime = Math.Round(elapsedTime, 2);
            timeLeft = Math.Round(timeLeft, 2);
            totalTime = Math.Round(totalTime, 2);

            var timeEstimationString = "";
            timeEstimationString += "Elapsed Time:\t" + (elapsedTime < 60 ? " " + (elapsedTime) + " (Seconds)" : "") +
                                    (elapsedTime > 60 && elapsedTime < 3600 ? " ~ " + (Math.Round(elapsedTime / 60,2)) + " (Minutes)" : "") +
                                    (elapsedTime > 3600 ? " ~ " + (Math.Round(elapsedTime / 3600,2)) + " (Hours)" : "") + "\r\n";

            timeEstimationString += "Remaining Time:\t" + (timeLeft != timeLeft ? "UNKNOWN" : "") + (timeLeft < 60 ? " " + (timeLeft) + " (Seconds)" : "") +
                                    (timeLeft > 60 && timeLeft < 3600 ? " ~ " + (Math.Round(timeLeft / 60,2)) + " (Minutes)" : "") +
                                    (timeLeft > 3600 ? " ~ " + Math.Round(timeLeft / 3600,2) + " (Hours)" : "") + "\r\n";

            timeEstimationString += "Total Time:\t" + (totalTime != totalTime ? "UNKNOWN" : "") + (totalTime < 60 ? " " + (totalTime) + " (Seconds)" : "") +
                                    (totalTime > 60 && totalTime < 3600 ? " ~ " + (Math.Round(totalTime / 60,2)) + " (Minutes)" : "") +
                                    (totalTime > 3600 ? " ~ " + (Math.Round(totalTime / 3600,2)) + " (Hours)" : "") + "\r\n";
            return timeEstimationString;
        }

        private static void Start(object o)
        {
            var p = (FaultImpactThreadDataHolder)o;
            CalculateFaultImpactsMultiThread(nets:p.Nets, clockTimes:p.ClockTimes, threadNumbers: p.ThreadNumbers, indexofThread: p.IndexOfThread, percent: ref p.Percent, faultImpactNets: out p.FaultImpactNets, randomPatterns: p.RandomPatterns, CorrectResults: p.CorrectResults);
        }

        public class FaultImpactThreadDataHolder
        {
            public List<Net> Nets;
            public List<Net> FaultImpactNets;
            public double Percent = 0;
            public List<string> RandomPatterns; 
            public bool SortOutput;
            public int? RandomNumbers = 1000;
            public int? ClockTimes = 5;
            public int ThreadNumbers;
            public int IndexOfThread;
            public List<Dictionary<string, Net.Signal>> CorrectResults;
        }

        public static void GetGeneratedRandomPatterns(string key, int randomPatterns, int randomSeed, bool uniqueRandomPatterns, List<Net> inputNets, out List<string> generatedRandomPatterns, out List<string> correctedPatterns)
        {
            // درابتدا یک لیست از رشته های ورودی تصادفی به طول ورودی های مدار درست می کنیم
            if (uniqueRandomPatterns)
                generatedRandomPatterns = CommonMethods.RandomPatternGeneration.GenerateUniqueRandomPatterns(lenght: inputNets.Count, count: randomPatterns, seed: randomSeed);
            else
                generatedRandomPatterns = CommonMethods.RandomPatternGeneration.GenerateExtraUniqueRandomPatterns(lenght: inputNets.Count, count: randomPatterns, seed: randomSeed);

            correctedPatterns = new List<string>();
            foreach (var randomPattern in generatedRandomPatterns)
            {
                //باید دو رشته ورودی داشته باشیم
                //یکی که در آن کلید ها مقدار نادرست دارند
                //و یکی که در آن مقدار هر کلید در سر جای خود به درستی اصلاح شده است

                var correctedPatternList = new List<char>();
                for (int index = 0; index < inputNets.Count; index++)
                {
                    if (SMSSKeyManager.IsSMSKeyNet(inputNets[index].Name))
                    {
                        var keyIndex = SMSSKeyManager.ExtractKeyIndexFromSMSSKeyName(inputNets[index].Name);
                        correctedPatternList.Add(key[keyIndex - 1]);
                    }
                    else
                    {
                        correctedPatternList.Add(randomPattern[index]);
                    }
                }

                var correctedPattern = (string.Join("", correctedPatternList.ToArray())).Trim();
                correctedPatterns.Add(correctedPattern);
            }
        }

        /// <summary>
        /// ورودی های صحیح را به مدار اعمال می کند و خروجی های صحیح را در دیکشنری نتایج نگه می دارد
        /// </summary>
        /// <param name="generatedRandomPatterns"></param>
        /// <param name="correctedPatterns"></param>
        /// <param name="nets"></param>
        /// <param name="clockNet"></param>
        /// <param name="forceWrongInputs"></param>
        /// <param name="inputNets"></param>
        /// <param name="outputNets"></param>
        /// <param name="clockTimes"></param>
        /// <returns></returns>
        private static List<Dictionary<string, Net.Signal>> GetCorrectOutputResults(List<string> generatedRandomPatterns, List<Net> nets, Net clockNet, List<Net> inputNets, List<Net> outputNets, int clockTimes)
        {
            var results = new List<Dictionary<string, Net.Signal>>();

            //Round1:
            foreach (var net in nets)
            {
                net.SValue = Net.Signal.X;
                if (net is FlipFlop)
                    ((FlipFlop)net).ResetMemory();
            }

            for (int index = 0; index < generatedRandomPatterns.Count; index++)
            {
                if (SamimiIO.Exiting)
                    break;

                //چنانچه مدار ترکیبی است
                //هربار مدار را ریست کنیم
                if (clockNet == null)
                {
                    //!!سرعت را افزایش می دهد ولی تنها برای مدار های ترکیبی!!
                    foreach (var net in nets)
                    {
                        net.SValue = Net.Signal.X;
                        if (net is FlipFlop)
                            ((FlipFlop)net).ResetMemory();
                    }
                }

                var randomPattern = generatedRandomPatterns[index];


                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets, randomPattern);

                StoreResults(outputNets, results);

                if (clockNet != null)
                    for (int i = 0; i < clockTimes; i++)
                    {
                        Net.SValueMethods.Imply(clockNet, Net.Signal.V0);
                        StoreResults(outputNets, results);

                        Net.SValueMethods.Imply(clockNet, Net.Signal.V1);
                        StoreResults(outputNets, results);
                    }
            }

            foreach (var net in nets)
            {
                net.SValue = Net.Signal.X;
                if (net is FlipFlop)
                    ((FlipFlop)net).ResetMemory();
            }

            return results;
        }

        private static void StoreResults(List<Net> outputNets, List<Dictionary<string, Net.Signal>> results)
        {
            //به ازای هر سری از خروجی ها، دیکشنری درست می کند از ترکیب نام خروجی و مقدار آن خروجی
            var dic = new Dictionary<string, Net.Signal>();
            foreach (var outputNet in outputNets)
                dic.Add(outputNet.Name, outputNet.SValue);

            //دیکشنری ایجاد شده را به لیست نتایج اضافه می کند
            results.Add(dic);
        }

        /// <summary>
        /// طول فاصله همینگرا بین خروجی های فعلی و خروجی های محاسبه شده قبلی ، محاسبه می کند
        /// </summary>
        /// <param name="outputNets"></param>
        /// <param name="results"></param>
        /// <param name="compareIndex"></param>
        /// <returns></returns>
        public static int CountHammingDistance(List<Net> outputNets, List<Dictionary<string, Net.Signal>> results, int compareIndex)
        {
            int hammingDistance = 0;

            //خروجی های تولید شده در این سری را با اولین لیست خروجی های موجود در لیست نتایج مقایسه می کند
            for (int i = 0; i < outputNets.Count; i++)
            {
                var outputNet = outputNets[i];
                var name = outputNet.Name;

                if (results[compareIndex][name] != outputNet.SValue)
                    hammingDistance++;
            }

            //اولین لیست خروجی های موجود در لیست نتایج را پاک می کند
            //results.RemoveAt(0);

            return hammingDistance;
        }

        public static void CalculateFaultImpactsMultiThread(List<Net> nets, out List<Net> faultImpactNets,
            int threadNumbers, int indexofThread, List<string> randomPatterns, ref double percent,
            List<Dictionary<string, Net.Signal>> CorrectResults, int? clockTimes = 5)
        {
            List<Net> middleNets;
            List<Net> outputNets;
            List<Net> inputNets;
            List<FlipFlop> flipFlopNets;
            Parser.ClassifyInputMiddleOutputFlipFlopNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets, flipFlopNets: out flipFlopNets);

            var clockNet = CommonMethods.GetMainClockNet(nets);
            inputNets.Remove(clockNet);

            faultImpactNets = new List<Net>(nets);
            RemoveNonGateNets(faultImpactNets);
            faultImpactNets.Remove(clockNet);

            var from = (faultImpactNets.Count * indexofThread / threadNumbers);
            var to = ((faultImpactNets.Count * (indexofThread + 1) / threadNumbers));
            if (indexofThread == threadNumbers - 1)
                to = faultImpactNets.Count;

            for (var i = from; i < to; i++)
            {
                if (SamimiIO.Exiting)
                    return;

                percent = (((i - from) / (double)(to-from)) * 100);
                CalculateFaultImpactOfSingleNet(net: faultImpactNets[i], inputNets: inputNets, outputNets: outputNets, flipFlopNets: flipFlopNets, randomPatterns: randomPatterns, clockNet: clockNet, clockTimes: clockTimes.Value, allNets: nets, CorrectResults: CorrectResults);
            }
            percent = 100;
        }

        private static void CalculateFaultImpactOfSingleNet(Net net, List<Net> inputNets, List<Net> outputNets, List<FlipFlop> flipFlopNets, List<string> randomPatterns, Net clockNet, int clockTimes, List<Net> allNets, List<Dictionary<string, Net.Signal>> CorrectResults)
        {
            net.NoO0 = net.NoO1 = net.NoP0 = net.NoP1 = 0;
            net.Sta0 = false;
            net.Sta1 = false;
            //============================================
            Net.SValueMethods.ResetSValuesOfNets(allNets);
            var compareIndex = 0;
            for (var patternIndex = 0; patternIndex < randomPatterns.Count; patternIndex++)
            {
                if (SamimiIO.Exiting)
                    return;

                ////ریست کردن همه چیز قبل از اعمال پترن جدید
                ////این دستور دکتر فاضلی بوده است
                ////به نظر من در مورد مدار های ترتیبی این کار اشتباه است
                ////ولی در مدار های ترکیبی تاثیری ندارد
                //Net.SValueMethods.ResetSValuesOfNets(allNets);
                //foreach (var flipFlopNet in flipFlopNets)
                //    flipFlopNet.ResetClock();

                net.Sta0 = true;

                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets: inputNets, pattern: randomPatterns[patternIndex]);

                var hd0 = 0;
                hd0 += CountHammingDistance(outputNets: outputNets, results: CorrectResults, compareIndex: compareIndex++);

                if (clockNet != null)
                    for (int i = 0; i < clockTimes; i++)
                    {
                        Net.SValueMethods.Imply(clockNet, Net.Signal.V0);
                        hd0 += CountHammingDistance(outputNets: outputNets, results: CorrectResults, compareIndex: compareIndex++);

                        Net.SValueMethods.Imply(clockNet, Net.Signal.V1);
                        hd0 += CountHammingDistance(outputNets: outputNets, results: CorrectResults, compareIndex: compareIndex++);
                    }

                net.NoO0 += hd0;
                net.NoP0 += hd0 > 0 ? 1 : 0;
            }
            net.Sta0 = false;

            //=============================================
            Net.SValueMethods.ResetSValuesOfNets(allNets); //BigTest
            compareIndex = 0;
            for (var patternIndex = 0; patternIndex < randomPatterns.Count; patternIndex++)
            {
                //ریست کردن همه چیز قبل از اعمال پترن جدید
                ////این دستور دکتر فاضلی بوده است
                ////به نظر من در مورد مدار های ترتیبی این کار اشتباه است
                ////ولی در مدار های ترکیبی تاثیری ندارد
                //Net.SValueMethods.ResetSValuesOfNets(allNets);
                //foreach (var flipFlopNet in flipFlopNets)
                //    flipFlopNet.ResetClock();

                net.Sta1 = true;

                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets: inputNets, pattern: randomPatterns[patternIndex]);

                var hd1 = 0;
                hd1 += CountHammingDistance(outputNets: outputNets, results: CorrectResults, compareIndex: compareIndex++);

                if (clockNet != null)
                    for (int i = 0; i < clockTimes; i++)
                    {
                        Net.SValueMethods.Imply(clockNet, Net.Signal.V0);
                        hd1 += CountHammingDistance(outputNets: outputNets, results: CorrectResults, compareIndex: compareIndex++);

                        Net.SValueMethods.Imply(clockNet, Net.Signal.V1);
                        hd1 += CountHammingDistance(outputNets: outputNets, results: CorrectResults, compareIndex: compareIndex++);
                    }

                net.NoO1 += hd1;
                net.NoP1 += hd1 > 0 ? 1 : 0;
            }
            net.Sta1 = false;
        }

        /// <summary>
        /// حذف سیم هایی که خروجی گیت نیستند
        /// و حذف سیم های خروجی
        /// </summary>
        /// <param name="nets"></param>
        public static void RemoveNonGateNets(List<Net> nets)
        {
            var nonGateNets = new List<Net>();
            foreach (var net in nets)
            {
                if (net is GateEqual /*|| net.IsPrimaryInput || net.IsPrimaryOutput*/)
                    nonGateNets.Add(net);
            }

            foreach (var nonGateNet in nonGateNets)
            {
                nets.Remove(nonGateNet);
            }
        }
    }
}
