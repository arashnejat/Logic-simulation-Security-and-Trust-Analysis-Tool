﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;


namespace LogicEncryption
{
    public class FaultImpacts
    {
        public static bool Exiting = false;

        #region CacheManager

        /// <summary>
        /// درصورت لزوم فالت ایمپکت را محاسبه کرده یا از کش لود می کند
        /// و لیستی از نت ها که به طور نزولی بر حسب فالت ایمپکت مرتب شده اند را بر می گرداند
        /// </summary>
        /// <param name="nets"></param>
        /// <param name="randomSeed"></param>
        /// <param name="uniqueRandomPatterns"></param>
        /// <param name="textBox"></param>
        /// <param name="clockTimes"></param>
        /// <param name="threadsCount"></param>
        /// <param name="randomNumbers"></param>
        /// <param name="netlistName"></param>
        /// <param name="header"></param>
        /// <param name="stopClockingOnFirstDetection"></param>
        /// <param name="createReport"></param>
        /// <param name="report"></param>
        /// <param name="progressBar"></param>
        /// <param name="forceCalculate"></param>
        /// <param name="allowSaveResults"></param>
        /// <returns></returns>
        public static List<Net> LoadOrCalculateFaultImpacts(List<Net> nets, int randomSeed, bool uniqueRandomPatterns, TextBox textBox, int clockTimes, int threadsCount, int randomNumbers, string netlistName, string header, bool createReport, out string loadReport,out string report, ProgressBar progressBar, bool forceCalculate, bool allowSaveResults)
        {
            var cacheFileName = netlistName + 
                                CacheManager.GetHashFromNets(nets) +
                                "Count=" + randomNumbers + "," +
                                "Unique=" + uniqueRandomPatterns.ToString() + "," + 
                                "Seed=" + randomSeed + "," +
                                "Ticks=" + clockTimes + "," +
                                "Stop=" + false.ToString() + 
                                ".faultImpacts";

            var cacheFilePath = CacheManager.CacheDirectory + cacheFileName;

            List<Net> faultImpactNets;
            if (!forceCalculate && !string.IsNullOrEmpty(netlistName))
            {
                if (SamimiIO.Exists(cacheFilePath))
                {
                    if (LoadFaultImpactNetsFromFile(cacheFilePath, nets, out faultImpactNets))
                    {
                        loadReport = "FaultImpacts Loaded From File:\t" + cacheFileName;
                        report = "";
                        return faultImpactNets;
                    }
                }
            }

            var s = new Stopwatch();
            s.Start();

            faultImpactNets = CalculateFaultImpacts(nets: nets, randomSeed: randomSeed, uniqueRandomPatterns: uniqueRandomPatterns, textBox: textBox, clockTimes: clockTimes, threadsCount: threadsCount, randomNumbers: randomNumbers, header: header,  createReport: createReport, report: out report, progressBar: progressBar);

            s.Stop();
            loadReport = "FaultImpacts Calculation Duration:\t" + s.Elapsed;

            if (allowSaveResults)
            {
                SaveFaultImpactNetsToFile(cacheFilePath, faultImpactNets);
                loadReport += "\r\n" + "Saved To File:\t" + cacheFileName;
            }
            return faultImpactNets;
        }

        private static void SaveFaultImpactNetsToFile(string cacheFilePath, List<Net> nets)
        {
            if (SamimiIO.Exiting)
                return;

            var dataToSave = new List<string>();

            foreach (var net in nets)
            {
                dataToSave.Add(net.Name + "\t" + net.FaultImpact + "\t" + net.NoP0 + "\t" + net.NoO0 + "\t" + net.NoP1 + "\t" + net.NoO1);
            }

            var str = string.Join("\r\n", dataToSave);

            SamimiIO.WriteAllText(cacheFilePath, str);
        }

        private static bool LoadFaultImpactNetsFromFile(string cacheFilePath, List<Net> nets, out List<Net> faultImpactNets)
        {
            try
            {
                var str = SamimiIO.ReadAllText(cacheFilePath);

                string[] seperators = {"\r\n", "\t"};

                var data = str.Split(seperators, StringSplitOptions.RemoveEmptyEntries);

                faultImpactNets = new List<Net>();

                var loadedNetsCount = 0;
                for (int i = 0; i < data.Length; i += 6)
                {
                    var foundNet = nets.Find(net => net.Name == data[i + 0]);
                    loadedNetsCount++;

                    foundNet.FaultImpact = int.Parse(data[i + 1]);//2
                    foundNet.NoP0 = int.Parse(data[i + 2]);
                    foundNet.NoO0 = int.Parse(data[i + 3]);
                    foundNet.NoP1 = int.Parse(data[i + 4]);
                    foundNet.NoO1 = int.Parse(data[i + 5]);

                    faultImpactNets.Add(foundNet);
                }

                var goalCountFaultImpactNets = new List<Net>(nets);
                var clockNet = CommonMethods.GetMainClockNet(nets);
                goalCountFaultImpactNets.Remove(clockNet);
                RemoveNonGateNets(goalCountFaultImpactNets);

                if (loadedNetsCount != goalCountFaultImpactNets.Count)
                    throw new Exception("Count not equal, Load failed.");
         
                return true;
            }
            catch (Exception exception)
            {
                faultImpactNets = new List<Net>(nets);
                return false;
            }
        }
        #endregion

        private static List<Net> CalculateFaultImpacts(List<Net> nets, int randomSeed, bool uniqueRandomPatterns, TextBox textBox, int clockTimes, int threadsCount, int randomNumbers, string header, bool createReport, out string report, ProgressBar progressBar)
        {
            var faultImpactNets = FaultImpacts.CalculateFaultImpactsMultiThreadUi(
                nets: nets,
                header: header,
                textBox: textBox,
                randomSeed: randomSeed,
                
                randomNumbers: randomNumbers,
                clockTimes: clockTimes,
                threadNumbers: threadsCount,
                uniqueRandomPatterns: uniqueRandomPatterns,
                createReport: createReport,
                report:out report,
                progressBar:progressBar,
                sortOutput: true);
            return faultImpactNets;
        }

        //خروجی لیستی حاوی تمامی محتویات لیست نتز است
        //با این تفاوت که به ترتیب فالت ایمپکتز از بزرگ به کوچک مرتب شده اند
        //و مقادیر فالت ایمپکتز برای هر نت محاسبه شده است
        public static List<Net> CalculateFaultImpactsMultiThreadUi(List<Net> nets, string header, TextBox textBox, int randomSeed, bool uniqueRandomPatterns, int? randomNumbers = 1000, int? clockTimes = 5, int? threadNumbers = 4)
        {
            string report;
            return CalculateFaultImpactsMultiThreadUi(nets: nets, textBox: textBox, progressBar: null, threadNumbers: threadNumbers,
                randomSeed: randomSeed, clockTimes: clockTimes, randomNumbers: randomNumbers, report: out report,
                sortOutput: true,  createReport: false, header: header,  uniqueRandomPatterns: uniqueRandomPatterns);
        }

        public static List<Net> CalculateFaultImpactsMultiThreadUi(List<Net> nets, bool createReport, out string report, ProgressBar progressBar, string header, TextBox textBox, int randomSeed, bool sortOutput, bool uniqueRandomPatterns, int? randomNumbers = 1000, int? clockTimes = 5, int? threadNumbers = 4)
        {
            var t0 = DateTime.Now;

            //Resetting All Nets
            foreach (var net in nets)
            {
                net.FaultImpact = net.NoO0 = net.NoO1 = net.NoP0 = net.NoP1 = 0;
            }

            //Adjusting Threads Count
            if (threadNumbers > nets.Count)
                threadNumbers = nets.Count;

            Net.SValueMethods.ResetSValuesAndSta0AndSta1AndFaultImpactsOfNets(nets);

            List<Net> middleNets;
            List<Net> outputNets;
            List<Net> inputNets;
            Parser.ClassifyInputMiddleOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets);
            var clockNet = CommonMethods.GetMainClockNet(nets);
            inputNets.Remove(clockNet);

            List<string> randomPatterns;
            if(uniqueRandomPatterns)
                randomPatterns = CommonMethods.RandomPatternGeneration.GenerateUniqueRandomPatterns(lenght: inputNets.Count, count: randomNumbers.Value, seed: randomSeed);
            else
                randomPatterns = CommonMethods.RandomPatternGeneration.GenerateExtraUniqueRandomPatterns(lenght: inputNets.Count, count: randomNumbers.Value, seed: randomSeed);

            var netsHolder = new List<List<Net>>();
            var parameterHolder = new List<FaultImpactThreadDataHolder>();

            if (textBox != null)
            {
                textBox.Text = header + "Preparing Threads...";
                Application.DoEvents();
            }

            //Creating Duplicates Of Netlist for each Thread (First netlist, is the original one)
            netsHolder.Add(nets);
            if (threadNumbers.Value > 1)
                netsHolder.AddRange(Net.SValueMethods.DuplicateNetlist(nets, threadNumbers.Value - 1));

            //Creating Parameters To Send To Threads
            for (var i = 0; i < threadNumbers; i++)
            {
                parameterHolder.Add(new FaultImpactThreadDataHolder()
                {
                    ClockTimes = clockTimes,
                    Nets = netsHolder[i],
                    RandomNumbers = randomNumbers,
                    SortOutput = sortOutput,
                    ThreadNumbers = threadNumbers.Value,
                    IndexOfThread = i,
                    RandomPatterns = randomPatterns,
                    FaultImpactNets = null,
                    Percent = 0
                });
            }

            if (textBox != null)
            {
                textBox.Text = header + "Starting Threads...";
                Application.DoEvents();
            }

            //Creating & Starting Threads
            var threadsHolder = new List<Thread>();
            for (var i = 0; i < threadNumbers; i++)
            {
                var thread = new Thread(Start);
                threadsHolder.Add(thread);
                thread.Start(parameterHolder[i]);
            }

            string threadsStatus;
            double percent;

            if (textBox != null)
            {
                textBox.Text = header + "Working...";
                Application.DoEvents();
            }

            var t1 = DateTime.Now;

            var allDone = false;
            while (!allDone && !SamimiIO.Exiting)
            {
                threadsStatus = "";
                percent = 0;
                
                allDone = true;
                for (var i = 0; i < threadsHolder.Count; i++)
                {
                    var thread = threadsHolder[i];

                    if (thread.IsAlive)
                        allDone = false;

                    if (Exiting)
                        thread.Abort();


                    if (textBox != null)
                    {
                        percent += parameterHolder[i].Percent / threadsHolder.Count;
                        threadsStatus += (int) parameterHolder[i].Percent + "% ";
                    }
                }

                if (textBox != null)
                {
                    textBox.Text = header + "Threads Status: " + threadsStatus + "\r\n";
                    textBox.Text += TimeEstimationString(t0, t1, percent);
                    if (progressBar != null)
                        progressBar.Value = (int)percent;
                    Application.DoEvents();
                }

                if(!allDone && nets.Count > 100)
                    Thread.Sleep(1000);
            }

            if (progressBar != null)
            {
                progressBar.Value = 100;
                Application.DoEvents();
            }

            if (textBox != null)
            {
                textBox.Text = header + "Merging Threads Results...";
                Application.DoEvents();
            }

            //Merging Results
            for (var i = 0; i < nets.Count; i++)
            {
                var net = nets[i];
                for (var j = 1; j < netsHolder.Count; j++)
                {
                    net.NoO0 += netsHolder[j][i].NoO0;
                    net.NoO1 += netsHolder[j][i].NoO1;
                    net.NoP0 += netsHolder[j][i].NoP0;
                    net.NoP1 += netsHolder[j][i].NoP1;
                }
                net.FaultImpact = net.NoP0 * net.NoO0 + net.NoP1 * net.NoO1;
            }

            var faultImpactNets = parameterHolder[0].FaultImpactNets;

            if (SamimiIO.Exiting)
            {
                report = null;
                return null;
            }

            if (sortOutput)
            {
                if (textBox != null)
                {
                    textBox.Text = header + "Sorting Outputs";
                    Application.DoEvents();
                }

                var sortedFaultImpacts = faultImpactNets.OrderByDescending(net => net.FaultImpact).ThenBy(net => net.Name).ToList();
                faultImpactNets.Clear();
                faultImpactNets.AddRange(sortedFaultImpacts);
            }

            report = "";
            if (createReport)
            {
                if (clockNet != null)
                {
                    report += "Netlist is sequential\r\n";
                    report += "Clock Net: " + clockNet.Name + "\r\n";
                    report += "\r\n";
                }
                else
                {
                    report += "Netlist is not sequential\r\n";
                    report += "\r\n";
                }

                report += "Total Nets: " + nets.Count + "\r\n";
                report += "Total Fault Impact Nets: " + faultImpactNets.Count + "\r\n";
                report += "Total Primary Inputs: " + inputNets.Count + "\r\n";
                report += "Total Primary Outputs: " + outputNets.Count + "\r\n";

                report += "Generated Random Numbers: " + randomPatterns.Count + "\r\n";
                report += "Total Duration (Seconds): " + (int)(DateTime.Now - t0).TotalSeconds + "\r\n";
                report += "\r\n";

                report += "Fault Impacts: " + "\r\n";

                foreach (var net in faultImpactNets)
                    report += net.Name + ":\t" + net.FaultImpact + "\r\n";
            }

            return faultImpactNets;
        }

        public static string TimeEstimationString(DateTime t0, DateTime t1, double percent)
        {
            var elapsedTime = (DateTime.Now - t0).TotalSeconds;
            var timeLeft = ((100 - percent)*(DateTime.Now - t1).TotalSeconds)/percent;
            var totalTime = elapsedTime + timeLeft;

            elapsedTime = Math.Round(elapsedTime, 2);
            timeLeft = Math.Round(timeLeft, 2);
            totalTime = Math.Round(totalTime, 2);

            var timeEstimationString = "";
            timeEstimationString += "Elapsed Time:\t" + (elapsedTime < 60 ? " " + (elapsedTime) + " (Seconds)" : "") +
                                    (elapsedTime > 60 && elapsedTime < 3600 ? " ~ " + (Math.Round(elapsedTime / 60,2)) + " (Minutes)" : "") +
                                    (elapsedTime > 3600 ? " ~ " + (Math.Round(elapsedTime / 3600,2)) + " (Hours)" : "") + "\r\n";

            timeEstimationString += "Remaining Time:\t" + (timeLeft != timeLeft ? "UNKNOWN" : "") + (timeLeft < 60 ? " " + (timeLeft) + " (Seconds)" : "") +
                                    (timeLeft > 60 && timeLeft < 3600 ? " ~ " + (Math.Round(timeLeft / 60,2)) + " (Minutes)" : "") +
                                    (timeLeft > 3600 ? " ~ " + Math.Round(timeLeft / 3600,2) + " (Hours)" : "") + "\r\n";

            timeEstimationString += "Total Time:\t" + (totalTime != totalTime ? "UNKNOWN" : "") + (totalTime < 60 ? " " + (totalTime) + " (Seconds)" : "") +
                                    (totalTime > 60 && totalTime < 3600 ? " ~ " + (Math.Round(totalTime / 60,2)) + " (Minutes)" : "") +
                                    (totalTime > 3600 ? " ~ " + (Math.Round(totalTime / 3600,2)) + " (Hours)" : "") + "\r\n";
            return timeEstimationString;
        }

        private static void Start(object o)
        {
            var p = (FaultImpactThreadDataHolder)o;
            CalculateFaultImpactsMultiThread(nets:p.Nets, clockTimes:p.ClockTimes, threadNumbers: p.ThreadNumbers, indexofThread: p.IndexOfThread, percent: ref p.Percent, faultImpactNets: out p.FaultImpactNets, randomPatterns: p.RandomPatterns);
        }

        public class FaultImpactThreadDataHolder
        {
            public List<Net> Nets;
            public List<Net> FaultImpactNets;
            public double Percent = 0;
            public List<string> RandomPatterns; 
            public bool SortOutput;
            public int? RandomNumbers = 1000;
            public int? ClockTimes = 5;
            public int ThreadNumbers;
            public int IndexOfThread;
            public bool StopClockingOnFirstDetection;
        }

        public static void CalculateFaultImpactsMultiThread(List<Net> nets, out List<Net> faultImpactNets,
            int threadNumbers, int indexofThread, List<string> randomPatterns, ref double percent, int? clockTimes = 5)
        {
            Net.ToStringMode = Net.NetToStringMode.SValue;

            List<Net> middleNets;
            List<Net> outputNets;
            List<Net> inputNets;
            List<FlipFlop> flipFlopNets;
            Parser.ClassifyInputMiddleOutputFlipFlopNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets, flipFlopNets: out flipFlopNets);

            var affectedOutputNetsList = new List<bool>();
            for (var i = 0; i < outputNets.Count; i++)
                affectedOutputNetsList.Add(false);

            var clockNet = CommonMethods.GetMainClockNet(nets);
            inputNets.Remove(clockNet);

            faultImpactNets = new List<Net>(nets);
            RemoveNonGateNets(faultImpactNets);
            faultImpactNets.Remove(clockNet);

            var from = (faultImpactNets.Count * indexofThread / threadNumbers);
            var to = ((faultImpactNets.Count * (indexofThread + 1) / threadNumbers));
            if (indexofThread == threadNumbers - 1)
                to = faultImpactNets.Count;

            for (var i = from; i < to; i++)
            {
                if (SamimiIO.Exiting)
                    return;

                percent = (((i - from) / (double)(to-from)) * 100);
                CalculateFaultImpactOfSingleNet(net: faultImpactNets[i], inputNets: inputNets, outputNets: outputNets, flipFlopNets: flipFlopNets, randomPatterns: randomPatterns, clockNet: clockNet, clockTimes: clockTimes.Value, allNets: nets, affectedOutputNetsList: affectedOutputNetsList);
            }
            percent = 100;
        }

        private static void CalculateFaultImpactOfSingleNet(Net net, List<Net> inputNets, List<Net> outputNets, List<FlipFlop> flipFlopNets, List<string> randomPatterns, Net clockNet, int clockTimes, List<Net> allNets, List<bool> affectedOutputNetsList)
        {
            net.NoO0 = net.NoO1 = net.NoP0 = net.NoP1 = 0;
            net.Sta0 = false;
            net.Sta1 = false;
            //============================================
            Net.SValueMethods.ResetSValuesOfNets(allNets);
            for (var patternIndex = 0; patternIndex < randomPatterns.Count; patternIndex++)
            {
                if (SamimiIO.Exiting)
                    return;

                //ریست کردن همه چیز قبل از اعمال پترن جدید
                //این دستور دکتر فاضلی بوده است
                //به نظر من در مورد مدار های ترتیبی این کار اشتباه است
                //ولی در مدار های ترکیبی تاثیری ندارد
                Net.SValueMethods.ResetSValuesOfNets(allNets);
                foreach (var flipFlopNet in flipFlopNets)
                    flipFlopNet.ResetClock();

                net.Sta0 = true;

                var randomPattern = randomPatterns[patternIndex];
                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets: inputNets, pattern: randomPattern);

                var affectedOutputNetsCount = 0;
                affectedOutputNetsCount += DetectFaultAtOutputs(net: net, outputNets: outputNets);
                if (clockNet != null)
                {
                    for (int i = 1; i <= clockTimes; i++)
                    {
                        //کلاک صفر وارد مدار می شود و آمار کل مدار گرفته می شود
                        Net.SValueMethods.Imply(clockNet, Net.Signal.V0);
                        affectedOutputNetsCount += DetectFaultAtOutputs(net: net, outputNets: outputNets);

                        //بعد کلاک یک وارد مدار می شود و آمار کل مدار گرفته می شود
                        Net.SValueMethods.Imply(clockNet, Net.Signal.V1);
                        affectedOutputNetsCount += DetectFaultAtOutputs(net: net, outputNets: outputNets);
                    }
                }
                net.NoO0 += affectedOutputNetsCount;
                net.NoP0 += affectedOutputNetsCount > 0 ? 1 : 0;
            }
            net.Sta0 = false;

            //=============================================
            Net.SValueMethods.ResetSValuesOfNets(allNets); //BigTest

            for (var patternIndex = 0; patternIndex < randomPatterns.Count; patternIndex++)
            {
                //ریست کردن همه چیز قبل از اعمال پترن جدید
                //این دستور دکتر فاضلی بوده است
                //به نظر من در مورد مدار های ترتیبی این کار اشتباه است
                //ولی در مدار های ترکیبی تاثیری ندارد
                Net.SValueMethods.ResetSValuesOfNets(allNets);
                foreach (var flipFlopNet in flipFlopNets)
                    flipFlopNet.ResetClock();

                net.Sta1 = true;

                var randomPattern = randomPatterns[patternIndex];
                Net.SValueMethods.ImplyPatternOnSValueOfInputNets(inputNets: inputNets, pattern: randomPattern);

                var affectedOutputNetsCount = 0;
                affectedOutputNetsCount += DetectFaultAtOutputs(net: net, outputNets: outputNets);
                if (clockNet != null)
                {
                    for (int i = 1; i <= clockTimes; i++)
                    {
                        //کلاک صفر وارد مدار می شود و آمار کل مدار گرفته می شود
                        Net.SValueMethods.Imply(clockNet, Net.Signal.V0);
                        affectedOutputNetsCount += DetectFaultAtOutputs(net: net, outputNets: outputNets);

                        //بعد کلاک یک وارد مدار می شود و آمار کل مدار گرفته می شود
                        Net.SValueMethods.Imply(clockNet, Net.Signal.V1);
                        affectedOutputNetsCount += DetectFaultAtOutputs(net: net, outputNets: outputNets);
                    }
                }
                net.NoO1 += affectedOutputNetsCount;
                net.NoP1 += affectedOutputNetsCount > 0 ? 1 : 0;
            }
            net.Sta1 = false;
        }

        /// <summary>
        /// تحریک اشکال در خروجی ها را بخاطر اعمال ورودی فعلی بررسی می کند
        /// و متناسب با آن، اقدام می کند
        /// </summary>
        /// <param name="net"></param>
        /// <param name="outputNets"></param>
        /// <returns></returns>
        private static int DetectFaultAtOutputs(Net net, List<Net> outputNets)
        {
            //اگر اصلا اشکال در این نت تحریک نشده، پس خارج شو و 0 بر گردان
            if (net.SValue != Net.Signal.D && net.SValue != Net.Signal.D_)
                return 0;

            var affectedOutputs = 0;
            for (var i = 0; i < outputNets.Count; i++)
            {
                var outputNet = outputNets[i];
                if (outputNet.SValue == Net.Signal.D || outputNet.SValue == Net.Signal.D_)
                {
                    affectedOutputs++;
                }
            }
            return affectedOutputs;
        }

        /// <summary>
        /// حذف سیم هایی که خروجی گیت نیستند
        /// و حذف سیم های خروجی
        /// </summary>
        /// <param name="nets"></param>
        public static void RemoveNonGateNets(List<Net> nets)
        {
            var nonGateNets = new List<Net>();
            foreach (var net in nets)
            {
                if (net is GateEqual /*|| net.IsPrimaryInput || net.IsPrimaryOutput*/)
                    nonGateNets.Add(net);
            }

            foreach (var nonGateNet in nonGateNets)
            {
                nets.Remove(nonGateNet);
            }
        }
    }
}
