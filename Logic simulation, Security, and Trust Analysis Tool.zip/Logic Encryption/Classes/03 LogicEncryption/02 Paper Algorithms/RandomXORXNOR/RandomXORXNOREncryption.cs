﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LogicEncryption
{
    public partial class RandomXORXNOREncryption
    {
        public static void RandomXORXNOREncrypt(List<Net> nets, string encryptionKey, int randomSeed, int rRandomSeed, bool forceCalculate, TextBox textBox, ProgressBar progressBar, SimulationReporter reportObject, string netlistName, out string addedKeyValues)
        {
            var rRandom = new Random(rRandomSeed);
            var random = new Random(randomSeed);

            var keyInputs = new List<Net>();
            var keyGates = new List<Net>();
            addedKeyValues = "";

            Application.DoEvents();

            //Generate R ; //a random number
            var R = CommonMethods.RandomPatternGeneration.GenerateSingleRandomPattern(rRandom, encryptionKey.Length);
            var GateType = FARajendran.Xor(encryptionKey, R);

            //++++++++++++++++++++++++++
            reportObject.AddToConsoleLog("Inserting new key gates ...");

            //از انتخاب نت های کلاک به عنوان محل درج کلید جلوگیری می شود
            var clockNets = CommonMethods.GetClockNets(nets);

            reportObject.Step02FinishRound(nets: nets, addedKeyValues: "", forceCalculate: forceCalculate);
            for (int i = 0; i < encryptionKey.Length; i++)
            {
                var locations = nets.Except(clockNets).ToList();

                var randomIndex = random.Next(0, locations.Count);
                var chosenNet = locations[randomIndex];

                //++++++++++++++++++++++++++
                reportObject.AddToConsoleLog("Round " + (i + 1) + " Gate (" + chosenNet.Name + ")");

                //اول ایکسور می ذاره
                //Insert XOR gate and update the Netlist;
                CommonMethods.InsertNewXORGateAfterLocation(nets: nets, location: chosenNet, keyGates: keyGates, keyInputs: keyInputs);

                //بعد اگه بیت یک بود یک اینورتر سر راه ایکسور قرار میده
                if (R[i] == '1')
                {
                    //Insert an inverter at the o/p of corresponding keygate;
                    CommonMethods.CreateAndInsertInverterAfterLocation(nets: nets, location: keyGates[i], index: i + 1);
                }
                //بعد اگه بیت کلید یک بود، گیت ایکسور را با گیت ایکسنور تعویض می کند
                if (GateType[i] == '1')
                {
                    //Replace the XOR key-gate with an XNOR key-gate;
                    CommonMethods.ReplaceXORwithXNOR(location: keyGates[i], nets: nets, keyGates: keyGates);
                }

                addedKeyValues += encryptionKey[i];
                reportObject.Step02FinishRound(nets, encryptionKey.Substring(0, i + 1), forceCalculate: forceCalculate);
            }

            reportObject.AddToConsoleLog("End of inserting key gates ...");
        }
    }
}
