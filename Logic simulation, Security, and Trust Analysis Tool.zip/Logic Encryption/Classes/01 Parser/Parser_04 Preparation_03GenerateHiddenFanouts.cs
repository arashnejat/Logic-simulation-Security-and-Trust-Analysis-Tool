﻿using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class Parser
    {
        private static void GenerateHiddenFanouts(List<Net> nets)
        {
            for (var i = 0; i < nets.Count; i++)
            {
                var currentNet = nets[i];
                if (currentNet.IsGeneratedFanout)
                    continue;

                var usedTimes = 0;
                Input firstInput = null;
                Net firstNet = null;
                var firstInputFixed = false;

                for (var j = 0; j < nets.Count; j++)
                {
                    var net = nets[j];
                    if (net.IsGeneratedFanout)
                        continue;

                    foreach (var input in net.Inputs)
                    {
                        if (input.Name == currentNet.Name)
                        {
                            usedTimes++;

                            if (usedTimes == 1)
                            {
                                firstInput = input;
                                firstNet = net;
                            }
                            if (usedTimes > 1)
                            {
                                if (!firstInputFixed)
                                {
                                    if (!(firstNet is GateEqual))
                                    {
                                        FixFanout(firstInput, currentNet, 1, firstNet, nets);
                                        firstInputFixed = true;
                                    }
                                }
                                if (!(net is GateEqual))
                                    FixFanout(input, currentNet, usedTimes, net, nets);
                            }
                        }
                    }
                }
            }
        }

        private static void FixFanout(Input inputToFix, Net currentNet, int index, Net toNet, List<Net> nets)
        {
            var generatedFanout = new GateEqual()
            {
                Name = currentNet.Name + "_" + index + "[" + toNet.Name + "]",
                IsGeneratedFanout = true,
                Inputs = {new Input() {Name = currentNet.Name, Net = currentNet}}
            };

            inputToFix.Net = generatedFanout;
            inputToFix.Name = generatedFanout.Name;

            nets.Add(generatedFanout);
        }
    }
}
