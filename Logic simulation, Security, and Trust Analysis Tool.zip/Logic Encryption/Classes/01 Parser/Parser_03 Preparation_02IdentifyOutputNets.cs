﻿using System;
using System.Collections.Generic;


namespace LogicEncryption
{
    public partial class Parser
    {
        private static void IdentifyOutputNets(List<Net> nets, List<string> outputNames, out List<Net> outputNets)
        {
            outputNets=new List<Net>();

            foreach (var outputName in outputNames)
                foreach (var net in nets)
                    if (net.Name == outputName)
                    {
                        net.IsPrimaryOutput = true;
                        outputNets.Add(net);
                        break;
                    }
        }

        public static void ClassifyInputMiddleOutputFlipFlopNets(List<Net> nets, out List<Net> inputNets, out List<Net> outputNets, out List<Net> middleNets, out List<FlipFlop> flipFlopNets)
        {
            inputNets = new List<Net>();
            middleNets = new List<Net>();
            outputNets = new List<Net>();
            flipFlopNets = new List<FlipFlop>();

            foreach (var net in nets)
            {
                if (net.IsPrimaryInput)
                    inputNets.Add(net);
                if (net.IsPrimaryOutput)
                    outputNets.Add(net);
                if (!net.IsPrimaryOutput && !net.IsPrimaryInput)
                    middleNets.Add(net);
                if(net is FlipFlop)
                    flipFlopNets.Add((FlipFlop)net);
            }
        }

        public static void ClassifyInputMiddleOutputNets(List<Net> nets, out List<Net> inputNets, out List<Net> outputNets, out List<Net> middleNets)
        {
            inputNets=new List<Net>();
            middleNets=new List<Net>();
            outputNets = new List<Net>();

            foreach (var net in nets)
            {
                if (net.IsPrimaryInput)
                    inputNets.Add(net);
                if(net.IsPrimaryOutput)
                    outputNets.Add(net);
                if(!net.IsPrimaryOutput && !net.IsPrimaryInput)
                    middleNets.Add(net);
            }
        }

        public static void ClassifyInputOutputNets(List<Net> nets, out List<Net> inputNets, out List<Net> outputNets)
        {
            inputNets = new List<Net>();
            outputNets = new List<Net>();

            foreach (var net in nets)
            {
                if (net.IsPrimaryInput)
                    inputNets.Add(net);
                if (net.IsPrimaryOutput)
                    outputNets.Add(net);
            }
        }
    }
}
