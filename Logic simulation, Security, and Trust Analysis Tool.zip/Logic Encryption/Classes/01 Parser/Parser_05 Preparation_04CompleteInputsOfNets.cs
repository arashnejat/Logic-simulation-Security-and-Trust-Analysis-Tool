﻿using System;
using System.Collections.Generic;


namespace LogicEncryption
{
    public partial class Parser
    {
        private static void CompleteInputsOfNets(List<Net> nets, bool generateFanouts)
        {
            Net mainGeneratedClockNet = null;
            var generatedClockFanouts = 0;

            for (var i = 0; i < nets.Count; i++)
            {
                var net = nets[i];

                if (net.IsGeneratedFanout)
                {
                    foreach (var input in net.Inputs)
                        input.Net.NextNets.Add(net);
                    continue;
                }

                foreach (var input in net.Inputs)
                    if (input.Net == null) 
                    { 
                        input.Net = input.IsGeneratedClock ? GetGenerateClockNet(net, ref mainGeneratedClockNet, ref generatedClockFanouts, nets, generateFanouts) : Net.FindNetWithException(input.Name, nets);
                        if (input.Net == null && input.IsGeneratedClock)
                            input.Net = mainGeneratedClockNet;
                    }

                foreach (var input in net.Inputs)
                    input.Net.NextNets.Add(net);
            }
        }

        private static Net GetGenerateClockNet(Net net, ref Net mainGeneratedClockNet, ref int generatedClockFanouts, List<Net> nets, bool generateFanouts)
        {
            if (mainGeneratedClockNet == null) //If main generated clock isn't generated before, then generate it now
            {
                mainGeneratedClockNet = new Net {Name = GeneratedClockName, IsPrimaryInput = true};
                nets.Add(mainGeneratedClockNet);
            }

            if (generateFanouts)
            {
                var newGeneratedClockFanOut = new GateEqual { Name = GeneratedClockName + "_" + (++generatedClockFanouts) + "[" + net.Name + "]" };
                newGeneratedClockFanOut.Inputs.Add(new Input {Name = GeneratedClockName, Net = mainGeneratedClockNet, IsGeneratedClock = true});
                //completing input of the fanout of the generated clock
                nets.Add(newGeneratedClockFanOut);

                return newGeneratedClockFanOut;
            }
            return null;
        }
    }
}
