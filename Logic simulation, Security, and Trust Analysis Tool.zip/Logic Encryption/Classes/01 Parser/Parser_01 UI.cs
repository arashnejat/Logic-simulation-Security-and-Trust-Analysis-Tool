﻿using System;
using System.Collections.Generic;

namespace LogicEncryption
{
    public partial class Parser
    {
        public static List<Net> CreateNets(IEnumerable<string> lines, bool? generateFanouts, out List<Net> outputNets)//, out List<Net> inputNets, out List<Net> middleNets)
        {
            var nets = new List<Net>();

            var outputNames = new List<string>();

            foreach (var line in lines)
                ParseNetlistLine(line: line, nets: nets, outputNames: outputNames);

            IdentifyOutputNets(nets: nets, outputNames: outputNames, outputNets: out outputNets);

            if (generateFanouts != null && generateFanouts.Value)
                GenerateHiddenFanouts(nets: nets);

            CompleteInputsOfNets(nets: nets, generateFanouts: generateFanouts != null && generateFanouts.Value);

            return nets;
        }

        public static List<Net> CreateNets(string input, bool? generateFanouts, out List<Net> outputNets)
        {
            string[] lineSeperators = { "\n", "\r\n" };
            var lines = input.Split(lineSeperators, StringSplitOptions.RemoveEmptyEntries);
            return CreateNets(lines, generateFanouts, out outputNets);
        }
        //======================================================================================================
        public static List<Net> CreateNets(IEnumerable<string> lines, bool? generateFanouts)
        {
            List<Net> outputNets;
            return CreateNets(lines, generateFanouts, out outputNets);
        }

        public static List<Net> CreateNets(IEnumerable<string> lines, bool? generateFanouts, out List<Net> inputNets, out List<Net> outputNets)
        {
            var nets = CreateNets(lines, generateFanouts, out outputNets);
            ClassifyInputOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets);
            return nets;
        }

        public static List<Net> CreateNets(IEnumerable<string> lines, bool? generateFanouts, out List<Net> inputNets, out List<Net> outputNets, out List<Net> middleNets)
        {
            var nets = CreateNets(lines, generateFanouts, out outputNets);
            ClassifyInputMiddleOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets);
            return nets;
        }
        //======================================================================================================

        public static List<Net> CreateNets(string input, bool? generateFanouts)
        {
            List<Net> outputNets;
            return CreateNets(input, generateFanouts, out outputNets);
        }

        public static List<Net> CreateNets(string input, bool? generateFanouts, out List<Net> inputNets, out List<Net> outputNets)
        {
            var nets = CreateNets(input, generateFanouts, out outputNets);
            ClassifyInputOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets);
            return nets;
        }

        public static List<Net> CreateNets(string input, bool? generateFanouts, out List<Net> inputNets, out List<Net> outputNets, out List<Net> middleNets)
        {
            var nets = CreateNets(input, generateFanouts, out outputNets);
            ClassifyInputMiddleOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets);
            return nets;
        }

        public static string GenerateNetlistFromListOfNets(List<Net> nets)
        {
            var netlistutLines = new List<string>();

            List<Net> inputNets;
            List<Net> outputNets;
            List<Net> middleNets;
            Parser.ClassifyInputMiddleOutputNets(nets: nets, inputNets: out inputNets, outputNets: out outputNets, middleNets: out middleNets);

            foreach (var net in inputNets)
            {
                if (net.Name == Parser.GeneratedClockName)
                    continue;

                var line = "Input(" + net.Name + ")";
                if (!netlistutLines.Contains(line))
                    netlistutLines.Add(line);
            }
            netlistutLines.Add(" ");

            foreach (var net in outputNets)
            {
                var line = "Output(" + net.Name + ")";
                if (!netlistutLines.Contains(line))
                    netlistutLines.Add(line);
            }
            netlistutLines.Add(" ");

            foreach (var net in nets)
            {
                if (net.IsPrimaryInput)
                    continue;

                var line = net.Name + " = ";
                if (net is GateEqual)
                {
                    if (net.Inputs[0].IsGeneratedClock)
                        continue;
                    line += " " + net.Inputs[0].Net.Name;
                    netlistutLines.Add(line);
                }
                else
                {
                    if (net is GateAnd)
                        line += "AND";
                    else if (net is GateNand)
                        line += "NAND";
                    else if (net is GateOr)
                        line += "OR";
                    else if (net is GateNor)
                        line += "NOR";
                    else if (net is GateXor)
                        line += "XOR";
                    else if (net is GateXnor)
                        line += "XNOR";
                    else if (net is GateNot)
                        line += "NOT";
                    else if (net is GateBuffer)
                        line += "BUFF";
                    else if (net is DFF)
                        line += "DFF";
                    else if (net is DFFC)
                        line += "DFFC";
                    else if (net is DFFCR)
                        line += "DFFCR";
                    else if (net is DFFR)
                        line += "DFFR";

                    line += "(";

                    for (var i = 0; i < net.Inputs.Count; i++)
                    {
                        var input = net.Inputs[i];
                        //if (input.IsGeneratedClock)
                            //continue; 13951020
                        if (i > 0)
                            line += ",";
                        line += input.Net.Name;
                    }
                    line += ")";

                    netlistutLines.Add(line);
                }
            }

            return (string.Join("\r\n", netlistutLines.ToArray()));
        }

    }
}
