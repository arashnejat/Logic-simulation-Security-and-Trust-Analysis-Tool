﻿using System;
using System.Collections.Generic;


namespace LogicEncryption
{
    public partial class Parser
    {
        public const string GeneratedClockName = "GClk";

        private static void ParseNetlistLine(string line, List<Net> nets, List<string> outputNames)
        {
            if (line.StartsWith("#"))
                return;

            var sharpIndex = line.IndexOf("#");
            if (sharpIndex > 0)
                line = line.Substring(0, sharpIndex); //Removing Comments

            string[] formulaSeperators = {"=", "(", ",", ")", " ", "fanout", "FANOUT", "\t", "\r"};
            var parts = line.Split(formulaSeperators, StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length == 0)
                return;
            //====================================================================================
            var lowerPart0 = parts[0].ToLower();
            //------------------------------------------------------------------------------------
            if (lowerPart0 == "output")
            {
                for (var i = 1; i < parts.Length; i++)
                    outputNames.Add(parts[i]);
                return;
            }
            //------------------------------------------------------------------------------------
            if (lowerPart0 == "input")
            {
                for (var i = 1; i < parts.Length; i++)
                    nets.Add(new Net {IsPrimaryInput = true, Name = parts[i]});
                return;
            }
            //====================================================================================
            if (parts.Length == 2) // EqualGate
            {
                var generatedNet = new GateEqual() { Name = parts[0] };
                generatedNet.Inputs.Add(new Input {Name = parts[1]}); // = parameter
                nets.Add(generatedNet);
                return;
            }
            //====================================================================================
            if (parts.Length > 2) //And Nand Or Nor Xor Xnor Not Buff Dff(s)
            {
                var generatedNet = Net.NetGenerator(type: parts[1], name: parts[0]);

                generatedNet.Inputs.Add(new Input {Name = parts[2]});

                if (generatedNet is DFF || generatedNet is DFFR) // Need to Generate Clock (Clock = absent)
                    generatedNet.Inputs.Add(new Input { Name = GeneratedClockName, IsGeneratedClock = true }); // Clock = absent

                if (generatedNet is DFFR) // Remember to Generate Clock (Clock = absent)
                {
                    if (parts.Length == 4) // a = dffr ( d , r ) =>  a  dffr  d  r  =>  r = parts[3]
                        generatedNet.Inputs.Add(new Input {Name = parts[3]}); // Reset Pin in DFFR | (inputReset) = Part[3] 
                    else
                        throw new Exception("Not enough parameters for net DFFR. Net: " + generatedNet.Name);
                }
                else
                {
                    if (parts.Length > 3)
                        for (var i = 3; i < parts.Length; i++)
                            generatedNet.Inputs.Add(new Input {Name = parts[i]}); //Input2 or Clock in DFFC & DFFCR
                }
                nets.Add(generatedNet);
            }
        }
    }
}
