﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        /// <summary>
        /// Manual Example (Instructor) - Changed Multiple Output V2 Inaccurate Naming o2 o1 o3
        /// </summary>
        public static string SampleInput20 =
@"# Manual Example (Instructor) - Changed Multiple Output V2 Inaccurate Naming o2 o1 o3

input(a)
input(b)
input(ck)

output(o1)
output(o2)
output(o3)

o2=d
o1=z
o3=c

z=dffc(d,ck)
c=and(e,a)
d=or(c,b)
e=z";

        public static string SampleOutput20 =
@"a:
	(1,1) 5
	[0,0] 1
	T(sa0): 6
	T(sa1): 6
b:
	(1,1) 3
	[0,0] 0
	T(sa0): 4
	T(sa1): 4
ck:
	(1,1) 10
	[0,0] 2
	T(sa0): 11
	T(sa1): 11
o2:
	(4,2) 0
	[0,0] 0
	T(sa0): 2
	T(sa1): 4
o1:
	(6,4) 0
	[1,1] 0
	T(sa0): 4
	T(sa1): 6
o3:
	(2,6) 0
	[0,1] 0
	T(sa0): 6
	T(sa1): 2
z:
	(6,4) 0
	[1,1] 0
	T(sa0): 4
	T(sa1): 6
c:
	(2,6) 0
	[0,1] 0
	T(sa0): 6
	T(sa1): 2
d:
	(4,2) 0
	[0,0] 0
	T(sa0): 2
	T(sa1): 4
e:
	(6,4) 2
	[1,1] 0
	T(sa0): 6
	T(sa1): 8

-----------------------------------
Sum of T(sa0)s: 51
Sum of T(sa1)s: 53
Testability index: 2.01703333929878";
    }
}
