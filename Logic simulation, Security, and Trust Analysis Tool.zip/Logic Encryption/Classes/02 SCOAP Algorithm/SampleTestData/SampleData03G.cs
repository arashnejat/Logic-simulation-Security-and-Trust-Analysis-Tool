﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        /// <summary>
        /// Netlist of circuit in slide 30 (DFF)
        /// </summary>
        public static string SampleInput3G =
@"#=========================================#
# Seyyed Mohammad Saleh Samimi - 91721004 #
#                                         #
# Netlist of circuit in slide 30          #
#                                         #
# DFF: DFlipFlop with no specified clock  #
# net and with no Reset net.              #
#                                         #
# Clock & correspondings nets will be     #
# automatically generated.                #
#=========================================#
Input(R)

Output(Z)
#=========================================
2=R
3=R
7=NOT(3)
8=NOT(17)		

9=AND(7,8)
11=9
10=9
12=10
13=10

22=NOR(2,21,13)		
14=AND(20,12)		
Z=14
15=14

18=OR(22,15)

19=DFF(18)
20=19
21=19

17=DFF(11)";

        public static string SampleOutput3G =
@"R:
	(1,1) 26
	[0,0] 3
	T(sa0): 27
	T(sa1): 27
2:
	(1,1) 30
	[0,0] 3
	T(sa0): 31
	T(sa1): 31
3:
	(1,1) 26
	[0,0] 3
	T(sa0): 27
	T(sa1): 27
7:
	(2,2) 25
	[0,0] 3
	T(sa0): 27
	T(sa1): 27
8:
	(12,6) 21
	[2,1] 2
	T(sa0): 27
	T(sa1): 33
9:
	(3,9) 18
	[0,1] 2
	T(sa0): 27
	T(sa1): 21
11:
	(3,9) 24
	[0,1] 3
	T(sa0): 33
	T(sa1): 27
10:
	(3,9) 18
	[0,1] 2
	T(sa0): 27
	T(sa1): 21
12:
	(3,9) 18
	[0,1] 2
	T(sa0): 27
	T(sa1): 21
13:
	(3,9) 28
	[0,1] 3
	T(sa0): 37
	T(sa1): 31
22:
	(2,14) 17
	[0,1] 2
	T(sa0): 31
	T(sa1): 19
14:
	(4,27) 0
	[0,3] 0
	T(sa0): 27
	T(sa1): 4
Z:
	(4,27) 0
	[0,3] 0
	T(sa0): 27
	T(sa1): 4
15:
	(4,27) 15
	[0,3] 2
	T(sa0): 42
	T(sa1): 19
18:
	(7,15) 12
	[0,1] 2
	T(sa0): 27
	T(sa1): 19
19:
	(9,17) 10
	[1,2] 1
	T(sa0): 27
	T(sa1): 19
20:
	(9,17) 10
	[1,2] 1
	T(sa0): 27
	T(sa1): 19
21:
	(9,17) 22
	[1,2] 2
	T(sa0): 39
	T(sa1): 31
17:
	(5,11) 22
	[1,2] 2
	T(sa0): 33
	T(sa1): 27
GClk:
	(1,1) 36
	[0,0] 4
	T(sa0): 37
	T(sa1): 37
GClk_1[19]:
	(1,1) 36
	[0,0] 4
	T(sa0): 37
	T(sa1): 37
GClk_2[17]:
	(1,1) 38
	[0,0] 5
	T(sa0): 39
	T(sa1): 39

-----------------------------------
Sum of T(sa0)s: 683
Sum of T(sa1)s: 540
Testability index: 3.08742645703629";
    }
}
