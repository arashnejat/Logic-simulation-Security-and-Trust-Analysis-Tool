﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        /// <summary>
        /// Problem 6.9
        /// Contains Xor Gate ( xor )
        /// </summary>
        public static string SampleInput9 =
@"# Problem 6.9

input(Vx)
input(Clock)
input(Reset)
output(Dx)

1=dffcr(2,8,7)
3=dffcr(5,9,6)

Bx=xor(1,4)
10=xor(Vx,Bx)

Dx=10
5=10
9=Clock
8=Clock
6=Reset
7=Reset
2=3
4=3";

        public static string SampleOutput9 =
@"Vx:
	(1,1) 8
	[0,0] 2
	T(sa0): 9
	T(sa1): 9
Clock:
	(1,1) 21
	[0,0] 5
	T(sa0): 22
	T(sa1): 22
Reset:
	(1,1) 21
	[0,0] 5
	T(sa0): 22
	T(sa1): 22
1:
	(3,15) 6
	[1,4] 1
	T(sa0): 21
	T(sa1): 9
3:
	(3,12) 6
	[1,3] 1
	T(sa0): 18
	T(sa1): 9
Bx:
	(7,16) 2
	[2,4] 0
	T(sa0): 18
	T(sa1): 9
10:
	(9,9) 0
	[2,2] 0
	T(sa0): 9
	T(sa1): 9
Dx:
	(9,9) 0
	[2,2] 0
	T(sa0): 9
	T(sa1): 9
5:
	(9,9) 9
	[2,2] 2
	T(sa0): 18
	T(sa1): 18
9:
	(1,1) 21
	[0,0] 5
	T(sa0): 22
	T(sa1): 22
8:
	(1,1) 24
	[0,0] 6
	T(sa0): 25
	T(sa1): 25
6:
	(1,1) 21
	[0,0] 5
	T(sa0): 22
	T(sa1): 22
7:
	(1,1) 24
	[0,0] 6
	T(sa0): 25
	T(sa1): 25
2:
	(3,12) 9
	[1,3] 2
	T(sa0): 21
	T(sa1): 12
4:
	(3,12) 6
	[1,3] 1
	T(sa0): 18
	T(sa1): 9

-----------------------------------
Sum of T(sa0)s: 279
Sum of T(sa1)s: 231
Testability index: 2.70757017609794";
    }
}
