﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        /// <summary>
        /// 12 Simple Test - V1 Inaccurate Naming
        /// </summary>
        public static string SampleInput12G =
@"# Simple Test

input(1)
input(2)
input(3)
input(4)
input(5)
input(6)
input(7)
input(8)

output(19)

9=nand(1,2)
10=and(3,4)
11=or(5,6)
12=nor(7,8)

16=nor(9,10)
17=and(10,11,12)
18=and(16,10)
19=and(18,17)";

        public static string SampleOutput12G =
@"1:
	(1,1) 19
	[0,0] 0
	T(sa0): 20
	T(sa1): 20
2:
	(1,1) 19
	[0,0] 0
	T(sa0): 20
	T(sa1): 20
3:
	(1,1) 19
	[0,0] 0
	T(sa0): 20
	T(sa1): 20
4:
	(1,1) 19
	[0,0] 0
	T(sa0): 20
	T(sa1): 20
5:
	(1,1) 20
	[0,0] 0
	T(sa0): 21
	T(sa1): 21
6:
	(1,1) 20
	[0,0] 0
	T(sa0): 21
	T(sa1): 21
7:
	(1,1) 19
	[0,0] 0
	T(sa0): 20
	T(sa1): 20
8:
	(1,1) 19
	[0,0] 0
	T(sa0): 20
	T(sa1): 20
9:
	(3,2) 17
	[0,0] 0
	T(sa0): 19
	T(sa1): 20
10:
	(2,3) 17
	[0,0] 0
	T(sa0): 20
	T(sa1): 19
11:
	(3,2) 18
	[0,0] 0
	T(sa0): 20
	T(sa1): 21
12:
	(2,3) 17
	[0,0] 0
	T(sa0): 20
	T(sa1): 19
16:
	(3,6) 14
	[0,0] 0
	T(sa0): 20
	T(sa1): 17
17:
	(3,9) 11
	[0,0] 0
	T(sa0): 20
	T(sa1): 14
18:
	(3,10) 10
	[0,0] 0
	T(sa0): 20
	T(sa1): 13
19:
	(4,20) 0
	[0,0] 0
	T(sa0): 20
	T(sa1): 4
10_1[16]:
	(2,3) 18
	[0,0] 0
	T(sa0): 21
	T(sa1): 20
10_2[17]:
	(2,3) 17
	[0,0] 0
	T(sa0): 20
	T(sa1): 19
10_3[18]:
	(2,3) 17
	[0,0] 0
	T(sa0): 20
	T(sa1): 19

-----------------------------------
Sum of T(sa0)s: 382
Sum of T(sa1)s: 347
Testability index: 2.86272752831797";
    }
}
