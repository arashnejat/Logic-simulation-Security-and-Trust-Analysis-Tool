﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        /// <summary>
        /// Netlist of circuit in slide 30 (DFFCR)
        /// </summary>
        public static string SampleInput4 =
@"#=========================================#
# Seyyed Mohammad Saleh Samimi - 91721004 #
#                                         #
# Netlist of circuit in slide 30          #
#                                         #
# DFFRCR: DFlipFlop with specified clock  #
# net and with specified Reset net.       #
#=========================================#
Input(R)
Input(CL)
Input(Reset1)
Input(Reset2)
Output(Z)
#=========================================
2=R
3=R
7=NOT(3)
8=NOT(17)		

9=AND(7,8)
11=9
10=9
12=10
13=10

22=NOR(2,21,13)		
14=AND(20,12)		
Z=14
15=14

18=OR(22,15)

5=CL
6=CL
19=DFFCR(18,6,Reset2)
20=19
21=19

17=DFFCR(11,5,Reset1)


";

        public static string SampleOutput4 =
@"R:
	(1,1) 19
	[0,0] 3
	T(sa0): 20
	T(sa1): 20
CL:
	(1,1) 23
	[0,0] 4
	T(sa0): 24
	T(sa1): 24
Reset1:
	(1,1) 30
	[0,0] 5
	T(sa0): 31
	T(sa1): 31
Reset2:
	(1,1) 23
	[0,0] 4
	T(sa0): 24
	T(sa1): 24
2:
	(1,1) 23
	[0,0] 3
	T(sa0): 24
	T(sa1): 24
3:
	(1,1) 19
	[0,0] 3
	T(sa0): 20
	T(sa1): 20
7:
	(2,2) 18
	[0,0] 3
	T(sa0): 20
	T(sa1): 20
8:
	(11,4) 16
	[2,1] 2
	T(sa0): 20
	T(sa1): 27
9:
	(3,7) 13
	[0,1] 2
	T(sa0): 20
	T(sa1): 16
11:
	(3,7) 20
	[0,1] 3
	T(sa0): 27
	T(sa1): 23
10:
	(3,7) 13
	[0,1] 2
	T(sa0): 20
	T(sa1): 16
12:
	(3,7) 13
	[0,1] 2
	T(sa0): 20
	T(sa1): 16
13:
	(3,7) 21
	[0,1] 3
	T(sa0): 28
	T(sa1): 24
22:
	(2,8) 16
	[0,1] 2
	T(sa0): 24
	T(sa1): 18
14:
	(4,20) 0
	[0,3] 0
	T(sa0): 20
	T(sa1): 4
Z:
	(4,20) 0
	[0,3] 0
	T(sa0): 20
	T(sa1): 4
15:
	(4,20) 14
	[0,3] 2
	T(sa0): 34
	T(sa1): 18
18:
	(7,9) 11
	[0,1] 2
	T(sa0): 20
	T(sa1): 18
5:
	(1,1) 30
	[0,0] 5
	T(sa0): 31
	T(sa1): 31
6:
	(1,1) 23
	[0,0] 4
	T(sa0): 24
	T(sa1): 24
19:
	(3,12) 8
	[1,2] 1
	T(sa0): 20
	T(sa1): 11
20:
	(3,12) 8
	[1,2] 1
	T(sa0): 20
	T(sa1): 11
21:
	(3,12) 21
	[1,2] 2
	T(sa0): 33
	T(sa1): 24
17:
	(3,10) 17
	[1,2] 2
	T(sa0): 27
	T(sa1): 20

-----------------------------------
Sum of T(sa0)s: 571
Sum of T(sa1)s: 468
Testability index: 3.01661554755718";
    }
}
