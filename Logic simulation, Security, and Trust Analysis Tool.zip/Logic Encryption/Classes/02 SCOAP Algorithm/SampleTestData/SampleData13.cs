﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        //Sample DFFC (Slide 30) - Changed Multiple Output V0 Accurate Naming V0
        public static string SampleInput13 =
@"# Sample DFFC (Slide 30) - Changed Multiple Output V0 Accurate Naming V0

Input(R)
Input(CL)

Output(Z)
Output(w)
output(x)

Z=19
w=17
x=11

#=========================================
2=R
3=R
7=NOT(3)
8=NOT(25)		

9=AND(7,8)
11=9
10=9
23=11
12=10
13=10

22=NOR(2,21,13)		
14=AND(20,12)		

15=14

18=OR(22,15)

5=CL
6=CL

19=DFFC(18,6)
17=DFFC(23,5)

24=19
20=24
21=24
25=17";

        public static string SampleOutput13 =
@"R:
	(1,1) 8
	[0,0] 1
	T(sa0): 9
	T(sa1): 9
CL:
	(1,1) 16
	[0,0] 3
	T(sa0): 17
	T(sa1): 17
Z:
	(9,17) 0
	[1,2] 0
	T(sa0): 17
	T(sa1): 9
w:
	(5,11) 0
	[1,2] 0
	T(sa0): 11
	T(sa1): 5
x:
	(3,9) 0
	[0,1] 0
	T(sa0): 9
	T(sa1): 3
2:
	(1,1) 20
	[0,0] 2
	T(sa0): 21
	T(sa1): 21
3:
	(1,1) 8
	[0,0] 1
	T(sa0): 9
	T(sa1): 9
7:
	(2,2) 7
	[0,0] 1
	T(sa0): 9
	T(sa1): 9
8:
	(12,6) 3
	[2,1] 0
	T(sa0): 9
	T(sa1): 15
9:
	(3,9) 0
	[0,1] 0
	T(sa0): 9
	T(sa1): 3
11:
	(3,9) 0
	[0,1] 0
	T(sa0): 9
	T(sa1): 3
10:
	(3,9) 18
	[0,1] 2
	T(sa0): 27
	T(sa1): 21
23:
	(3,9) 2
	[0,1] 1
	T(sa0): 11
	T(sa1): 5
12:
	(3,9) 23
	[0,1] 3
	T(sa0): 32
	T(sa1): 26
13:
	(3,9) 18
	[0,1] 2
	T(sa0): 27
	T(sa1): 21
22:
	(2,14) 7
	[0,1] 1
	T(sa0): 21
	T(sa1): 9
14:
	(4,27) 5
	[0,3] 1
	T(sa0): 32
	T(sa1): 9
15:
	(4,27) 5
	[0,3] 1
	T(sa0): 32
	T(sa1): 9
18:
	(7,15) 2
	[0,1] 1
	T(sa0): 17
	T(sa1): 9
5:
	(1,1) 16
	[0,0] 3
	T(sa0): 17
	T(sa1): 17
6:
	(1,1) 26
	[0,0] 3
	T(sa0): 27
	T(sa1): 27
19:
	(9,17) 0
	[1,2] 0
	T(sa0): 17
	T(sa1): 9
17:
	(5,11) 0
	[1,2] 0
	T(sa0): 11
	T(sa1): 5
24:
	(9,17) 12
	[1,2] 1
	T(sa0): 29
	T(sa1): 21
20:
	(9,17) 15
	[1,2] 2
	T(sa0): 32
	T(sa1): 24
21:
	(9,17) 12
	[1,2] 1
	T(sa0): 29
	T(sa1): 21
25:
	(5,11) 4
	[1,2] 0
	T(sa0): 15
	T(sa1): 9

-----------------------------------
Sum of T(sa0)s: 505
Sum of T(sa1)s: 345
Testability index: 2.92941892571429";
    }
}
