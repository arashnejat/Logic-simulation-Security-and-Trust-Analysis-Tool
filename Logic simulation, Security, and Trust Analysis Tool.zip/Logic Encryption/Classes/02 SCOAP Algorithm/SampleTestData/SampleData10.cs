﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        /// <summary>
        /// Lec11 - Slide 54
        /// </summary>
        public static string SampleInput10 =
@"# Lec11 - Slide 54

input(a)
input(b)
input(c)
output(x)
output(y)
output(z)

h=b
d=and(a,b)
d1=d
g=d
k=h
l=h
m=xnor(g,k)
n=m
f=d1
e=d1
r=xnor(f,n)
p=m2
m2=m
q=not(p)
r1=r
r2=r
s=not(r2)
t=s
u=s
v=xnor(l,u)

p2=m2
x=nand(e,r1)
y=or(t,q)
z=nand(v,p2,c)";

        public static string SampleOutput10 =
@"a:
	(1,1) 10
	[0,0] 0
	T(sa0): 11
	T(sa1): 11
b:
	(1,1) 10
	[0,0] 0
	T(sa0): 11
	T(sa1): 11
c:
	(1,1) 15
	[0,0] 0
	T(sa0): 16
	T(sa1): 16
h:
	(1,1) 10
	[0,0] 0
	T(sa0): 11
	T(sa1): 11
d:
	(2,3) 8
	[0,0] 0
	T(sa0): 11
	T(sa1): 10
d1:
	(2,3) 8
	[0,0] 0
	T(sa0): 11
	T(sa1): 10
g:
	(2,3) 9
	[0,0] 0
	T(sa0): 12
	T(sa1): 11
k:
	(1,1) 10
	[0,0] 0
	T(sa0): 11
	T(sa1): 11
l:
	(1,1) 15
	[0,0] 0
	T(sa0): 16
	T(sa1): 16
m:
	(4,4) 7
	[0,0] 0
	T(sa0): 11
	T(sa1): 11
n:
	(4,4) 7
	[0,0] 0
	T(sa0): 11
	T(sa1): 11
f:
	(2,3) 9
	[0,0] 0
	T(sa0): 12
	T(sa1): 11
e:
	(2,3) 8
	[0,0] 0
	T(sa0): 11
	T(sa1): 10
r:
	(7,7) 4
	[0,0] 0
	T(sa0): 11
	T(sa1): 11
p:
	(4,4) 10
	[0,0] 0
	T(sa0): 14
	T(sa1): 14
m2:
	(4,4) 10
	[0,0] 0
	T(sa0): 14
	T(sa1): 14
q:
	(5,5) 9
	[0,0] 0
	T(sa0): 14
	T(sa1): 14
r1:
	(7,7) 4
	[0,0] 0
	T(sa0): 11
	T(sa1): 11
r2:
	(7,7) 7
	[0,0] 0
	T(sa0): 14
	T(sa1): 14
s:
	(8,8) 6
	[0,0] 0
	T(sa0): 14
	T(sa1): 14
t:
	(8,8) 6
	[0,0] 0
	T(sa0): 14
	T(sa1): 14
u:
	(8,8) 8
	[0,0] 0
	T(sa0): 16
	T(sa1): 16
v:
	(10,10) 6
	[0,0] 0
	T(sa0): 16
	T(sa1): 16
p2:
	(4,4) 12
	[0,0] 0
	T(sa0): 16
	T(sa1): 16
x:
	(11,3) 0
	[0,0] 0
	T(sa0): 3
	T(sa1): 11
y:
	(14,6) 0
	[0,0] 0
	T(sa0): 6
	T(sa1): 14
z:
	(16,2) 0
	[0,0] 0
	T(sa0): 2
	T(sa1): 16

-----------------------------------
Sum of T(sa0)s: 320
Sum of T(sa1)s: 345
Testability index: 2.8228216453031";
    }
}
