﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        /// <summary>
        /// Sample DFFC (Slide 30) - Changed Multiple Output V2 Inaccurate Naming xzw
        /// </summary>
        public static string SampleInput24 =
@"# Sample DFFC (Slide 30) - Changed Multiple Output V2 Inaccurate Naming xzw

#=========================================#
# Seyyed Mohammad Saleh Samimi - 91721004 #
#                                         #
# Netlist of circuit in slide 30          #
#                                         #
# DFFC: DFlipFlop with specified clock    #
# net and with no Reset net.              #
#=========================================#
Input(R)
Input(CL)

Output(Z)
Output(w)
output(x)

x=11
Z=19
w=17

#=========================================
2=R
3=R
7=NOT(3)
8=NOT(17)		

9=AND(7,8)
11=9
10=9
12=10
13=10

22=NOR(2,21,13)		
14=AND(20,12)		

15=14

18=OR(22,15)

5=CL
6=CL
19=DFFC(18,6)
20=19
21=19

17=DFFC(11,5)";

        public static string SampleOutput24 =
@"R:
	(1,1) 8
	[0,0] 1
	T(sa0): 9
	T(sa1): 9
CL:
	(1,1) 16
	[0,0] 3
	T(sa0): 17
	T(sa1): 17
x:
	(3,9) 0
	[0,1] 0
	T(sa0): 9
	T(sa1): 3
Z:
	(9,17) 0
	[1,2] 0
	T(sa0): 17
	T(sa1): 9
w:
	(5,11) 0
	[1,2] 0
	T(sa0): 11
	T(sa1): 5
2:
	(1,1) 20
	[0,0] 2
	T(sa0): 21
	T(sa1): 21
3:
	(1,1) 8
	[0,0] 1
	T(sa0): 9
	T(sa1): 9
7:
	(2,2) 7
	[0,0] 1
	T(sa0): 9
	T(sa1): 9
8:
	(12,6) 3
	[2,1] 0
	T(sa0): 9
	T(sa1): 15
9:
	(3,9) 0
	[0,1] 0
	T(sa0): 9
	T(sa1): 3
11:
	(3,9) 0
	[0,1] 0
	T(sa0): 9
	T(sa1): 3
10:
	(3,9) 18
	[0,1] 2
	T(sa0): 27
	T(sa1): 21
12:
	(3,9) 23
	[0,1] 3
	T(sa0): 32
	T(sa1): 26
13:
	(3,9) 18
	[0,1] 2
	T(sa0): 27
	T(sa1): 21
22:
	(2,14) 7
	[0,1] 1
	T(sa0): 21
	T(sa1): 9
14:
	(4,27) 5
	[0,3] 1
	T(sa0): 32
	T(sa1): 9
15:
	(4,27) 5
	[0,3] 1
	T(sa0): 32
	T(sa1): 9
18:
	(7,15) 2
	[0,1] 1
	T(sa0): 17
	T(sa1): 9
5:
	(1,1) 16
	[0,0] 3
	T(sa0): 17
	T(sa1): 17
6:
	(1,1) 26
	[0,0] 3
	T(sa0): 27
	T(sa1): 27
19:
	(9,17) 0
	[1,2] 0
	T(sa0): 17
	T(sa1): 9
20:
	(9,17) 15
	[1,2] 2
	T(sa0): 32
	T(sa1): 24
21:
	(9,17) 12
	[1,2] 1
	T(sa0): 29
	T(sa1): 21
17:
	(5,11) 0
	[1,2] 0
	T(sa0): 11
	T(sa1): 5

-----------------------------------
Sum of T(sa0)s: 450
Sum of T(sa1)s: 310
Testability index: 2.88081359228079";
    }
}
