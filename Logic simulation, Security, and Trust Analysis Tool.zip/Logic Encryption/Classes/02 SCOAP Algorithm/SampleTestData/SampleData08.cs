﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        /// <summary>
        /// Problem 6.13
        /// </summary>
        public static string SampleInput8 =
@"# Problem 6.13

input(Z)
input(CLOCK)
input(RESET)
output(A1)
output(A2)

1=3
2=3
3=8
4=and(Z,1)
5=dffcr(4,9,11)
6=5
7=nand(2,6)
8=dffcr(7,10,12)
A2=8
A1=5
12=RESET
11=RESET
10=CLOCK
9=CLOCK";

        public static string SampleOutput8 =
@"Z:
	(1,1) 11
	[0,0] 3
	T(sa0): 12
	T(sa1): 12
CLOCK:
	(1,1) 10
	[0,0] 3
	T(sa0): 11
	T(sa1): 11
RESET:
	(1,1) 10
	[0,0] 3
	T(sa0): 11
	T(sa1): 11
1:
	(3,7) 5
	[1,2] 1
	T(sa0): 12
	T(sa1): 8
2:
	(3,7) 16
	[1,2] 4
	T(sa0): 23
	T(sa1): 19
3:
	(3,7) 5
	[1,2] 1
	T(sa0): 12
	T(sa1): 8
4:
	(2,9) 3
	[0,2] 1
	T(sa0): 12
	T(sa1): 5
5:
	(3,12) 0
	[1,3] 0
	T(sa0): 12
	T(sa1): 3
6:
	(3,12) 11
	[1,3] 3
	T(sa0): 23
	T(sa1): 14
7:
	(20,4) 3
	[5,1] 1
	T(sa0): 7
	T(sa1): 23
8:
	(3,7) 0
	[1,2] 0
	T(sa0): 7
	T(sa1): 3
A2:
	(3,7) 0
	[1,2] 0
	T(sa0): 7
	T(sa1): 3
A1:
	(3,12) 0
	[1,3] 0
	T(sa0): 12
	T(sa1): 3
12:
	(1,1) 10
	[0,0] 3
	T(sa0): 11
	T(sa1): 11
11:
	(1,1) 15
	[0,0] 4
	T(sa0): 16
	T(sa1): 16
10:
	(1,1) 10
	[0,0] 3
	T(sa0): 11
	T(sa1): 11
9:
	(1,1) 15
	[0,0] 4
	T(sa0): 16
	T(sa1): 16

-----------------------------------
Sum of T(sa0)s: 215
Sum of T(sa1)s: 177
Testability index: 2.59328606702046";
    }
}
