﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        /// <summary>
        /// Manual Example (Instructor)
        /// </summary>
        public static string SampleInput11 =
@"# Manual Example (Instructor)

input(a)
input(b)
input(ck)
output(o)

c=and(e,a)
d=or(c,b)
z=dffc(d,ck)
o=z
e=z";

        public static string SampleOutput11 =
@"a:
	(1,1) 9
	[0,0] 2
	T(sa0): 10
	T(sa1): 10
b:
	(1,1) 5
	[0,0] 1
	T(sa0): 6
	T(sa1): 6
ck:
	(1,1) 10
	[0,0] 2
	T(sa0): 11
	T(sa1): 11
c:
	(2,6) 4
	[0,1] 1
	T(sa0): 10
	T(sa1): 6
d:
	(4,2) 2
	[0,0] 1
	T(sa0): 4
	T(sa1): 6
z:
	(6,4) 0
	[1,1] 0
	T(sa0): 4
	T(sa1): 6
o:
	(6,4) 0
	[1,1] 0
	T(sa0): 4
	T(sa1): 6
e:
	(6,4) 6
	[1,1] 1
	T(sa0): 10
	T(sa1): 12

-----------------------------------
Sum of T(sa0)s: 59
Sum of T(sa1)s: 63
Testability index: 2.08635983067475";
    }
}
