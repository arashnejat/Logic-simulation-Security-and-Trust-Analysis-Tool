﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        /// <summary>
        /// Problem 6.7
        /// DFFCR
        /// </summary>
        public static string SampleInput1 =
@"# Problem 6.7

input(a)
input(b)
input(c)
input(CK)
input(RESET)
output(g)

e=and(c,d)
f=or(b,e)
2=and(a,f)
g=2
1=2
d=dffcr(1,CK,RESET)";

        public static string SampleOutput1 =
@"a:
	(1,1) 3
	[0,0] 0
	T(sa0): 4
	T(sa1): 4
b:
	(1,1) 5
	[0,0] 0
	T(sa0): 6
	T(sa1): 6
c:
	(1,1) 12
	[0,0] 1
	T(sa0): 13
	T(sa1): 13
CK:
	(1,1) 16
	[0,0] 2
	T(sa0): 17
	T(sa1): 17
RESET:
	(1,1) 16
	[0,0] 2
	T(sa0): 17
	T(sa1): 17
e:
	(2,9) 4
	[0,1] 0
	T(sa0): 13
	T(sa1): 6
f:
	(4,2) 2
	[0,0] 0
	T(sa0): 4
	T(sa1): 6
2:
	(2,4) 0
	[0,0] 0
	T(sa0): 4
	T(sa1): 2
g:
	(2,4) 0
	[0,0] 0
	T(sa0): 4
	T(sa1): 2
1:
	(2,4) 9
	[0,0] 1
	T(sa0): 13
	T(sa1): 11
d:
	(3,7) 6
	[1,1] 0
	T(sa0): 13
	T(sa1): 9

-----------------------------------
Sum of T(sa0)s: 108
Sum of T(sa1)s: 93
Testability index: 2.30319605742049";
    }
}
