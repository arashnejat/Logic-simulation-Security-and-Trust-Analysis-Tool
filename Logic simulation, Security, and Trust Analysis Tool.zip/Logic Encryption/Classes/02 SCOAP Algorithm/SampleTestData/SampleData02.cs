﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        /// <summary>
        /// Problem 6.3
        /// </summary>
        public static string SampleInput2 =
@"# Problem 6.3

input(x1)
input(x2)
input(x3)
input(x4)
input(x5)
input(x6)

output(w2)

8=nand(x3,x4)
9=8
10=8
11=10
12=10
7=nand(x2,9)
13=nand(11,x5)
14=nand(12,x6)
15=nand(x1,7)
w1=nand(15,13)
w2=nand(w1,14)
";

        public static string SampleOutput2 = 
@"x1:
	(1,1) 9
	[0,0] 0
	T(sa0): 10
	T(sa1): 10
x2:
	(1,1) 11
	[0,0] 0
	T(sa0): 12
	T(sa1): 12
x3:
	(1,1) 10
	[0,0] 0
	T(sa0): 11
	T(sa1): 11
x4:
	(1,1) 10
	[0,0] 0
	T(sa0): 11
	T(sa1): 11
x5:
	(1,1) 9
	[0,0] 0
	T(sa0): 10
	T(sa1): 10
x6:
	(1,1) 9
	[0,0] 0
	T(sa0): 10
	T(sa1): 10
8:
	(3,2) 8
	[0,0] 0
	T(sa0): 10
	T(sa1): 11
9:
	(3,2) 10
	[0,0] 0
	T(sa0): 12
	T(sa1): 13
10:
	(3,2) 8
	[0,0] 0
	T(sa0): 10
	T(sa1): 11
11:
	(3,2) 8
	[0,0] 0
	T(sa0): 10
	T(sa1): 11
12:
	(3,2) 8
	[0,0] 0
	T(sa0): 10
	T(sa1): 11
7:
	(4,2) 8
	[0,0] 0
	T(sa0): 10
	T(sa1): 12
13:
	(4,2) 6
	[0,0] 0
	T(sa0): 8
	T(sa1): 10
14:
	(4,2) 6
	[0,0] 0
	T(sa0): 8
	T(sa1): 10
15:
	(4,2) 6
	[0,0] 0
	T(sa0): 8
	T(sa1): 10
w1:
	(5,5) 3
	[0,0] 0
	T(sa0): 8
	T(sa1): 8
w2:
	(8,5) 0
	[0,0] 0
	T(sa0): 5
	T(sa1): 8

-----------------------------------
Sum of T(sa0)s: 163
Sum of T(sa1)s: 179
Testability index: 2.53402610605613";
    }
}
