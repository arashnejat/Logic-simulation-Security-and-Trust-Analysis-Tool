﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        /// <summary>
        /// Input to Output net problem
        /// </summary>
        public static string SampleInput26 =
@"# Input to Output net problem

input(a)
output(a)";

        public static string SampleOutput26 =
@"a:
	(1,1) 0
	[0,0] 0
	T(sa0): 1
	T(sa1): 1

-----------------------------------
Sum of T(sa0)s: 1
Sum of T(sa1)s: 1
Testability index: 0.301029995663981";
    }
}
