﻿namespace LogicEncryption
{
    public partial class SampleData
    {
        public static string SampleInputn = 
@"";

        public static string SampleOutputn = 
@"";
    }
}
