﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;


namespace LogicEncryption
{
    public partial class SCOAP
    {
        public static void SCOAPMain(List<Net> nets, SCOAPValue sumOfTsa0s, SCOAPValue sumOfTsa1s, out double testabilityIndex, List<Net> initializedNets, bool? generateFanouts = false)
        {
            testabilityIndex = -1;
            try
            {
                //---------------------------------------------------------

                var outputNets = nets.Where(net => net.IsPrimaryOutput).ToList();
                //---------------------------------------------------------

                //Initializing CC0 CC1 SC0 SC1 CO SO of all nets:
                Step01InitializeNetsForSCOAPAlgorithm(nets: nets, initializedNets: initializedNets);

                //---------------------------------------------------------

                //Levelization of nets
                int maxLevel;
                Step02LevelizeNetsForControllabilities(nets: nets, maxLevel: out maxLevel);

                //---------------------------------------------------------

                //Calculating Controllabilities:
                Step03CalculateControllabilities(nets: nets, maxLevel: maxLevel);

                //---------------------------------------------------------

                //Calculating Observabilities:
                Step04CalculateObservabilities(nets: nets, outputNets: outputNets);

                //---------------------------------------------------------

                //Calculating testability index:
                Step05CalculateTestabilityIndex(nets: nets, sumOfTsa0S: sumOfTsa0s, sumOfTsa1S: sumOfTsa1s, testabilityIndex: out testabilityIndex);

            }
            catch (Exception exception)
            {
                MessageBox.Show("Error message:\r\n" + exception.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static List<Net> SCOAPMain(IEnumerable<string> lines, SCOAPValue sumOfTsa0s, SCOAPValue sumOfTsa1s, out double testabilityIndex, List<Net> initializedNets, bool? generateFanouts = false)
        {
            testabilityIndex = -1;
            try
            {
                //---------------------------------------------------------
                
                //Creating nets from netlist:
                List<Net> outputNets;
                var nets = Parser.CreateNets(lines: lines, generateFanouts: generateFanouts, outputNets: out outputNets);

                //---------------------------------------------------------

                //Initializing CC0 CC1 SC0 SC1 CO SO of all nets:
                Step01InitializeNetsForSCOAPAlgorithm(nets: nets, initializedNets: initializedNets);

                //---------------------------------------------------------

                //Levelization of nets
                int maxLevel;
                Step02LevelizeNetsForControllabilities(nets: nets, maxLevel: out maxLevel);

                //---------------------------------------------------------

                //Calculating Controllabilities:
                Step03CalculateControllabilities(nets: nets, maxLevel: maxLevel);

                //---------------------------------------------------------

                //Calculating Observabilities:
                Step04CalculateObservabilities(nets: nets, outputNets: outputNets);

                //---------------------------------------------------------

                //Calculating testability index:
                Step05CalculateTestabilityIndex(nets:nets,sumOfTsa0S:sumOfTsa0s,sumOfTsa1S:sumOfTsa1s,testabilityIndex: out testabilityIndex);

                return nets;
            }
            catch (Exception exception)
            {
                MessageBox.Show("Error message:\r\n" + exception.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return new List<Net>();
            }
        }
    }
}
