﻿using System;
using System.Collections.Generic;


namespace LogicEncryption
{
    public partial class SCOAP
    {
        public static List<Net> GetNetsOfLevel(List<Net> nets, int levelNumber)
        {
            return nets.FindAll(item => item.LevelNumberInSCOAP == levelNumber);
        }

        private static int MaxLevel(List<Input> inputs)
        {
            var max = int.MinValue;
            foreach (var input in inputs)
            {
                if (input.Net.LevelNumberInSCOAP > max)
                    max = input.Net.LevelNumberInSCOAP;
            }
            return max;
        }

        /// <summary>
        /// در این سطح بندی، خروجی ها و ورودی ها و فلیپ فلاپ ها در سطح صفر قرار می گیرند
        /// </summary>
        /// <param name="nets"></param>
        /// <param name="maxLevel"></param>
        public static void Step02LevelizeNetsForControllabilities(List<Net> nets, out int maxLevel)
        {
            maxLevel = -1;
            foreach (var net in nets)
                net.LevelNumberInSCOAP = -1;

            var notFinished = true;
            while (notFinished)
            {
                foreach (var net in nets)
                {
                    if (net.LevelNumberInSCOAP != -1)
                        continue;

                    if (net.IsPrimaryInput || net is DFlipFlop || net is DFlipFlopNoReset || net.IsPrimaryOutput)
                        net.LevelNumberInSCOAP = 0;
                    else
                    {
                        if (net.Inputs.Count == 1)
                        {
                            if (net.Inputs[0].Net.LevelNumberInSCOAP != -1)
                                net.LevelNumberInSCOAP = net.Inputs[0].Net.LevelNumberInSCOAP + (net is GateEqual ? 0 : 1);
                        }
                        else
                        {
                            var unknowInputExists = false;

                            foreach (var input in net.Inputs)
                                if (input.Net.LevelNumberInSCOAP == -1)
                                    unknowInputExists = true;

                            if (!unknowInputExists)
                                net.LevelNumberInSCOAP = MaxLevel(net.Inputs) + 1;
                        }
                    }
                }

                notFinished = false;
                foreach (var net in nets)
                {
                    if (net.LevelNumberInSCOAP == -1)
                    {
                        notFinished = true;
                        break;
                    }
                    if (net.LevelNumberInSCOAP > maxLevel)
                        maxLevel = net.LevelNumberInSCOAP;
                }
            }
        }
    }
}
