﻿using System;
using System.Collections.Generic;


namespace LogicEncryption
{
    public partial class SCOAP
    {
        private static void Step03CalculateControllabilities(List<Net> nets, int maxLevel)
        {
            var notAllStabilized = true;
            while (notAllStabilized)
            {
                for (var i = 0; i <= maxLevel; i++)
                    ComputeControllabilitiesOfLevel(nets, i);

                ComputeControllabilitiesOfLevel(nets, 0);

                notAllStabilized = false;
                foreach (var net in nets)
                {
                    if (!net.ControllabilitiesStabilized)
                    {
                        notAllStabilized = true;
                        break;
                    }
                }
            }
        }

        private static void ComputeControllabilitiesOfLevel(List<Net> nets, int i)
        {
            var netsOfLevel = SCOAP.GetNetsOfLevel(nets: nets, levelNumber: i);

            foreach (var net in netsOfLevel)
                net.SetControllabilities();
        }
    }
}
