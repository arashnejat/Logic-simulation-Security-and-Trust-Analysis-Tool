﻿using System;
using System.Collections.Generic;


namespace LogicEncryption
{
    public partial class SCOAP
    {
        private static void Step05CalculateTestabilityIndex(List<Net> nets, SCOAPValue sumOfTsa0S, SCOAPValue sumOfTsa1S, out double testabilityIndex)
        {
            var reset= new SCOAPValue {Infinity = false, Amount = 0};

            sumOfTsa0S.Set(reset);
            sumOfTsa1S.Set(reset);

            foreach (var net in nets)
            {
                net.SetTSas();
                sumOfTsa0S.Set(sumOfTsa0S + net.TSa0);
                sumOfTsa1S.Set(sumOfTsa1S + net.TSa1);
            }

            if (!sumOfTsa0S.Infinity && !sumOfTsa1S.Infinity)
                testabilityIndex = Math.Log10((sumOfTsa0S + sumOfTsa1S).Amount);
            else
                testabilityIndex = -1;
        }
    }
}
