﻿using System;
using System.Collections.Generic;


namespace LogicEncryption
{
    public partial class SCOAP
    {
        private static void Step01InitializeNetsForSCOAPAlgorithm(List<Net> nets, List<Net> initializedNets)
        {
            //s35932.bench
            //52.7283 Mixed Mode 6.88238477851622
            //51.8617 Seperated Mode 6.88238477851622
            
            //Seperated just for achieving maximum speed!

            if (initializedNets == null || initializedNets.Count == 0)
                InitializeNetsForSCOAPAlgorithm(nets);
            else
                InitializeNetsForSCOAPAlgorithm(nets, initializedNets);
        }

        private static void InitializeNetsForSCOAPAlgorithm(List<Net> nets)
        {
            var initialInputCCValue = new SCOAPValue { Infinity = false, Amount = 1 };
            var initialInputSCValue = new SCOAPValue { Infinity = false, Amount = 0 };

            var initialOtherCCValue = new SCOAPValue { Infinity = true, Amount = 0 };
            var initialOtherSCValue = new SCOAPValue { Infinity = true, Amount = 0 };

            var initialOutputCOValue = new SCOAPValue { Infinity = false, Amount = 0 };
            var initialOutputSOValue = new SCOAPValue { Infinity = false, Amount = 0 };

            var initialOtherCOValue = new SCOAPValue { Infinity = true, Amount = 0 };
            var initialOtherSOValue = new SCOAPValue { Infinity = true, Amount = 0 };

            foreach (var net in nets)
            {
                if (net.IsPrimaryInput)
                {
                    net.CC0.InitialSet(initialInputCCValue);
                    net.CC1.InitialSet(initialInputCCValue);

                    net.SC0.InitialSet(initialInputSCValue);
                    net.SC1.InitialSet(initialInputSCValue);
                }
                else
                {
                    net.CC0.InitialSet(initialOtherCCValue);
                    net.CC1.InitialSet(initialOtherCCValue);

                    net.SC0.InitialSet(initialOtherSCValue);
                    net.SC1.InitialSet(initialOtherSCValue);
                }

                if (net.IsPrimaryOutput)
                {
                    net.CO.InitialSet(initialOutputCOValue);
                    net.SO.InitialSet(initialOutputSOValue);
                }
                else
                {
                    net.CO.InitialSet(initialOtherCOValue);
                    net.SO.InitialSet(initialOtherSOValue);
                }
            }
        }

        private static void InitializeNetsForSCOAPAlgorithm(List<Net> nets, List<Net> initializedNets)
        {
            var mutableInitializedNets = new List<Net>(initializedNets);

            var initialInputCCValue = new SCOAPValue {Infinity = false, Amount = 1};
            var initialInputSCValue = new SCOAPValue {Infinity = false, Amount = 0};

            var initialOtherCCValue = new SCOAPValue {Infinity = true, Amount = 0};
            var initialOtherSCValue = new SCOAPValue {Infinity = true, Amount = 0};

            var initialOutputCOValue = new SCOAPValue {Infinity = false, Amount = 0};
            var initialOutputSOValue = new SCOAPValue {Infinity = false, Amount = 0};

            var initialOtherCOValue = new SCOAPValue {Infinity = true, Amount = 0};
            var initialOtherSOValue = new SCOAPValue {Infinity = true, Amount = 0};

            foreach (var net in nets)
            {
                var continueForNextNet = false;
                for (var i = 0; i < mutableInitializedNets.Count; i++)
                {
                    var initializedNet = mutableInitializedNets[i];

                    if (net.Name == initializedNet.Name)
                    {
                        net.CC0.InitialSet(initializedNet.CC0);
                        net.CC1.InitialSet(initializedNet.CC1);
                        net.CO.InitialSet(initializedNet.CO);

                        net.SC0.InitialSet(initializedNet.SC0);
                        net.SC1.InitialSet(initializedNet.SC1);
                        net.SO.InitialSet(initializedNet.SO);

                        mutableInitializedNets.RemoveAt(i);
                        continueForNextNet = true;
                        break;
                    }
                }
                if (continueForNextNet)
                    continue;

                if (net.IsPrimaryInput)
                {
                    net.CC0.InitialSet(initialInputCCValue);
                    net.CC1.InitialSet(initialInputCCValue);

                    net.SC0.InitialSet(initialInputSCValue);
                    net.SC1.InitialSet(initialInputSCValue);
                }
                else
                {
                    net.CC0.InitialSet(initialOtherCCValue);
                    net.CC1.InitialSet(initialOtherCCValue);

                    net.SC0.InitialSet(initialOtherSCValue);
                    net.SC1.InitialSet(initialOtherSCValue);
                }

                if (net.IsPrimaryOutput)
                {
                    net.CO.InitialSet(initialOutputCOValue);
                    net.SO.InitialSet(initialOutputSOValue);
                }
                else
                {
                    net.CO.InitialSet(initialOtherCOValue);
                    net.SO.InitialSet(initialOtherSOValue);
                }
            }
        }
    }
}
