﻿using System;
using System.Collections.Generic;


namespace LogicEncryption
{
    public partial class  SCOAP
    {
        private static void Step04CalculateObservabilities(List<Net> nets, List<Net> outputNets)
        {
            foreach (var outputsNet in outputNets)
            {
                var notAllStabilized = true;

                while (notAllStabilized)
                {
                    foreach (var net in nets)
                        net.Observed = false;

                    CalculateObservabilityOfOutputNet(outputsNet);

                    notAllStabilized = false;
                    foreach (var net in nets)
                    {
                        if (!net.ObservabilitiesStabilized)
                        {
                            notAllStabilized = true;
                            break;
                        }
                    }
                }
            }
        }

        private static void CalculateObservabilityOfOutputNet(Net net)
        {
            if (net.Observed)
                return;

            net.SetObservabilities();
            RecurseCalculateObservabilityOfOutputNet(net);
        }

        private static void RecurseCalculateObservabilityOfOutputNet(Net outputNet)
        {
            outputNet.Observed = true;

            foreach (var input in outputNet.Inputs)
                CalculateObservabilityOfOutputNet(input.Net);
        }
    }
}
