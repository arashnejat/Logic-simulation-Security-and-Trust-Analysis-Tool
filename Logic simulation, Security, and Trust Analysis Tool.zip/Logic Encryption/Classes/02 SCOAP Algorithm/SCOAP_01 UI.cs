﻿using System;
using System.Collections.Generic;
using System.IO;

namespace LogicEncryption
{
    public partial class SCOAP
    {
        public static List<Net> SCOAPOnInputFile(string filePath, out string input, SCOAPValue sumOfTsa0S, SCOAPValue sumOfTsa1S, out double testabilityIndex, bool generateFanouts, List<Net> initializedNets)
        {
            if (!File.Exists(filePath))
            {
                input = null;
                testabilityIndex = -1;
                return null;
            }
            var lines = File.ReadAllLines(filePath);
            input = string.Join("\r\n", lines);

            return SCOAPMain(lines: lines, sumOfTsa0s: sumOfTsa0S, sumOfTsa1s: sumOfTsa1S, testabilityIndex: out testabilityIndex, initializedNets: initializedNets, generateFanouts: generateFanouts);
        }

        public static List<Net> SCOAPOnInputString(string inputString, SCOAPValue sumOfTsa0s, SCOAPValue sumOfTsa1s, out double testabilityIndex, bool generateFanouts, List<Net> initializedNets)
        {
            string[] lineSeperators = { "\n" , "\r\n"};
            var lines = inputString.Split(lineSeperators, StringSplitOptions.RemoveEmptyEntries);

            return SCOAPMain(lines: lines, sumOfTsa0s: sumOfTsa0s, sumOfTsa1s: sumOfTsa1s, testabilityIndex: out testabilityIndex, initializedNets: initializedNets, generateFanouts: generateFanouts);
        }
    }
}
