﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change thse attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Logic Encryption Tool")]
[assembly: AssemblyDescription("Developed by: Seyyed Mohammad Saleh Samimi\nmohammadsaleh.samimi@gmail.com\nm_samimi@comp.iust.ac.ir\n\nInstructor: Dr. Mahdi Fazeli\nm_fazeli@iust.ac.ir\nIran University of Science and Technology")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Seyyed Mohammad Saleh Samimi - 91721004\nMSc Thesis Project 1392-1393\nInstructor: Dr. Mahdi Fazeli\nIran University of Science and Technology")]
[assembly: AssemblyProduct("Logic Encryption Tool")]
[assembly: AssemblyCopyright("Copyright ©  2015 Seyyed Mohammad Saleh Samimi")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("20047ac8-b6bc-4ede-aeba-648609a497b9")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
//[assembly: AssemblyVersion("2.0.1.*")]
//[assembly: AssemblyFileVersion("2.0.1")]
[assembly: AssemblyVersion("2.2.*")]

/* 
http://stackoverflow.com/questions/826777/how-to-have-an-auto-incrementing-version-number-visual-studio
If you add an AssemblyInfo class to your project and amend the AssemblyVersion attribute to end with an asterisk, for example:

[assembly: AssemblyVersion("2.10.*")]

Visual studio will increment the final number for you according to these rules (thanks galets, I had that completely wrong!)

To reference this version in code, so you can display it to the user, you use reflection. For example,

string version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();

Two important gotchas that you should know
From @ashes999:

It's also worth noting that if both AssemblyVersion and AssemblyFileVersion are specified, you won't see this on your .exe. 
 * The 3rd number is the number of days since the year 2000, and the 4th number is the number of seconds since midnight (divided by 2) [IT IS NOT RANDOM]. 
 * So if you built the solution late in a day one day, and early in a day the next day, the later build would have an earlier version number. 
 * I recommend always using X.Y.* instead of X.Y.Z.* because your version number will ALWAYS increase this way.*/