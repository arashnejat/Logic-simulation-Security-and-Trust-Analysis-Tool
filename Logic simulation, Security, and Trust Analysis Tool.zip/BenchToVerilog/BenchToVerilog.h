/******************************************************************************

Filename:         bench2ver.h

Author:           Evan Weststrate

Creation date:    24 June 2000

Contents:         Header file for translating ISCAS *.bench format to
structural verilog.


Modifications:

Author:			Seyyed Mohammad Saleh Samimi

Modification date:	18 February 2015


*** DOCUMENTATION ***


******************************************************************************/

#ifndef BENCH2VER_H
#define BENCH2VER_H

#include <string>
#include <iostream>

using namespace std;

class inputElement
{
public:
	inputElement()
	{
		nextInput = 0;
	}
	inputElement(const string & name, inputElement * const next)
	{
		itsName = name;
		nextInput = next;
	}
	~inputElement() {}
	friend class ElementManager;

private:
	inputElement * nextInput;
	string itsName;
};

class outputElement
{
public:
	outputElement()
	{
		nextOutput = 0;
	}
	outputElement(const string & name, outputElement * const next)
	{
		itsName = name;
		nextOutput = next;
	}
	~outputElement() {}
	friend class ElementManager;

private:
	outputElement * nextOutput;
	string itsName;
};

class ffElement
{
public:
	ffElement()
	{
		nextFF = 0;
	}
	ffElement(const string & outputName, const string & type,
		const string & inputs, ffElement * const next)
	{
		itsOutput = outputName;
		itsType = type;
		itsInputs = inputs;
		nextFF = next;
	}
	~ffElement() {}
	friend class ElementManager;

private:
	ffElement * nextFF;
	string itsOutput;
	string itsType;
	string itsInputs;
};

class gateElement
{
public:
	gateElement()
	{
		nextGate = 0;
	}
	gateElement(const string & outputName, const string & type,
		const string & inputs, gateElement * const next)
	{
		itsOutput = outputName;
		itsType = type;
		itsInputs = inputs;
		nextGate = next;
	}
	~gateElement() {}
	friend class ElementManager;

private:
	gateElement * nextGate;
	string itsOutput;
	string itsType;
	string itsInputs;
};

class ElementManager
{
public:
	//constructors
	ElementManager() :
		headInput(0),
		headOutput(0),
		headFF(0),
		headGate(0)
	{}
	~ElementManager() {}

	//accessors
	void AddInput(const string & name)
	{
		inputElement * iPtr = headInput;
		if (iPtr != 0)
		{
			while (iPtr->nextInput != 0)
			{
				iPtr = iPtr->nextInput;
			}
			inputElement * temp = new inputElement(name, NULL);
			iPtr->nextInput = temp;
		}
		else
		{
			inputElement * temp = new inputElement(name, NULL);
			headInput = temp;
		}
	}
	void AddOutput(const string & name)
	{
		outputElement * temp = new outputElement(name, headOutput);
		headOutput = temp;
	}
	void AddFF(const string & outName, const string & type,
		const string & inputs)
	{
		ffElement * temp = new ffElement(outName, type, inputs, headFF);
		headFF = temp;
	}

	void AddGate(const string & outName, const string & type,
		const string & inputs)
	{
		gateElement * temp = new gateElement(outName, type, inputs, headGate);
		headGate = temp;
	}

	void WriteVerilog(ostream & fout, string argval)	 //Samimi
	{
		inputElement * inPtr = headInput;
		outputElement * outPtr = headOutput;
		ffElement * ffPtr = headFF;
		gateElement * gPtr = headGate;
		unsigned int inoutCtr = 0;

		//MODULE LINE
		fout << "\nmodule " << argval << "(GND,VDD";
		if (headFF != 0)  // if a FF exists
			fout << ",CK";

		while (inPtr != 0)
		{
			fout << ",";
			if (inoutCtr++ % 7 == 6)
				fout << "\n\t";
			fout << inPtr->itsName;
			inPtr = inPtr->nextInput;
		}
		while (outPtr != 0)
		{
			fout << ",";
			if (inoutCtr++ % 7 == 6)
				fout << "\n\t";
			fout << outPtr->itsName;
			outPtr = outPtr->nextOutput;
		}
		fout << ");\n\n";

		inPtr = headInput;
		outPtr = headOutput;
		inoutCtr = 0;
		//INPUT LINE
		if (inPtr)
		{
			fout << "  input VCC,GND";
			if (headFF != 0)  // if a FF exists
				fout << ",CK";
			while (inPtr != 0)
			{
				fout << ",";
				if (inoutCtr++ % 7 == 6)
					fout << "\n\t";
				fout << inPtr->itsName;
				inPtr = inPtr->nextInput;
			}
			fout << ";\n";
		}

		inoutCtr = 0;
		//OUTPUT LINE
		if (outPtr)
		{
			fout << "  output " << outPtr->itsName;
			outPtr = outPtr->nextOutput;
			while (outPtr != 0)
			{
				fout << ",";
				if (inoutCtr++ % 7 == 6)
					fout << "\n\t";
				fout << outPtr->itsName;
				outPtr = outPtr->nextOutput;
			}
			fout << ";\n\n";
		}

		/*		//WIRE LINE - writes all gate names regardless if it's a prim. output
		fout << "\n  wire " << gPtr->itsOutput;
		gPtr = gPtr->nextGate;
		while (gPtr != 0)
		{
		fout << "," << gPtr->itsOutput;
		gPtr = gPtr->nextGate;
		}
		while (ffPtr != 0)
		{
		fout << "," << ffPtr->itsOutput;
		ffPtr = ffPtr->nextFF;
		}
		fout << ";\n";
		*/
		ffPtr = headFF;
		gPtr = headGate;
		int count = 0;

		//ELEMENT LINES
		while (ffPtr != 0)
		{
			fout << "  " << ffPtr->itsType
				<< " " << ffPtr->itsType
				<< "_" << count++
				<< "(CK,"
				<< ffPtr->itsOutput
				<< "," <<
				ffPtr->itsInputs << ");\n";
			ffPtr = ffPtr->nextFF;
		}
		fout << '\n';
		while (gPtr != 0)
		{
			fout << "  " << gPtr->itsType << " " << gPtr->itsType
				<< "_" << count++ << "(" << gPtr->itsOutput << "," <<
				gPtr->itsInputs << ");\n";
			gPtr = gPtr->nextGate;
		}
		fout << "\nendmodule";
	}

private:
	inputElement * headInput;
	outputElement * headOutput;
	ffElement * headFF;
	gateElement * headGate;
};

#endif
