/******************************************************************************

Filename:         bench2ver.cpp

Author:           Evan Weststrate

Creation date:    24 June 2000

Contents:         Main program that translates ISCAS *.bench format to
structural verilog.


Modifications:

Author:			Seyyed Mohammad Saleh Samimi

Modification date:	18 February 2015


*** DOCUMENTATION ***



******************************************************************************/
#include "stdafx.h"
#include <fstream>
#include <string>
#include <iostream>
#include <algorithm>

using namespace std;

#include "BenchToVerilog.h"

#define BENCH_EXT ""
#define VERILOG_EXT ".v"

//Function Declarations
//bool PrintFile(char* filename);	//Prints the contents of a file; returns false if error
//void SaveLine(ofstream* pFout,const char* type2,int FInum,const char* type1,
//			  const char* pos,const int topNum);
//writes description line to opened file - fout
//Globals
const int MAX_LLGTH = 200;

int main(int argc, char *argv[])
{
	int i = 0;
	if (argc != 2)
	{
		cerr << "Usage: " << argv[0] << " <filename> " << endl;
		exit(-1);
	}

	//string outFile(argv[1]);								       // set up I/O filenames	 //Samimi
	//string inFile(argv[1]);	 //Samimi
	//outFile = outFile + VERILOG_EXT;	 //Samimi
	//inFile = inFile + BENCH_EXT;	 //Samimi

	char drive[_MAX_DRIVE]; //Samimi
	char dir[_MAX_DIR];	 //Samimi
	char fname[_MAX_FNAME];	 //Samimi
	char ext[_MAX_EXT];	 //Samimi

	_splitpath_s(argv[1], drive, dir, fname, ext);	 //Samimi

	string fnameNoSpaceOrDots = fname;	 //Samimi
	std::replace(fnameNoSpaceOrDots.begin(), fnameNoSpaceOrDots.end(), ' ', '_');	 //Samimi
	std::replace(fnameNoSpaceOrDots.begin(), fnameNoSpaceOrDots.end(), '.', '_');	 //Samimi

	string inFile(argv[1]);	 //Samimi
	string strDrive(drive);	 //Samimi
	string strDir(dir);	 //Samimi
	string strFname(fname);	 //Samimi
	string outFile = drive + strDir + fname + VERILOG_EXT;	 //Samimi

	ifstream fin;
	fin.open(inFile.c_str(), ios::_Nocreate | ios::in);   // open the file specified by the 1st parameter
	if (fin.fail())
	{
		cerr << "Could not open " << inFile << " for conversion.\n";
		exit(-1);
	}

	ofstream fout;
	fout.open(outFile.c_str(),/*ios::noreplace | */ios::out);    //open an output file (truncate it)
	if (fout.fail())
	{
		cerr << "Unable to open " << outFile << "/n";
		cerr << "Rename existing file " << outFile << " if it already exists./n";
		exit(-1);
	}

	char cLine[MAX_LLGTH];
	//	char ch;

	string strLine;
	string strLineUpper;

	string id = "";
	string inputs = "";
	string etype = "";

	ElementManager eMgr;

	do
	{
		fin.getline(cLine, MAX_LLGTH);
		id = "";
		inputs = "";
		etype = "";

		switch (cLine[0])
		{
		case '#':
			fout << "//" << cLine << '\n';  //comment lines
			break;

		default:
			strLine = cLine;	 //Samimi
			strLineUpper = cLine;	 //Samimi
			std::transform(strLineUpper.begin(), strLineUpper.end(), strLineUpper.begin(), ::toupper);	 //Samimi

			if (strLineUpper.find("INPUT") == 0)  //returns -1 if not found	 //Samimi
			{
				for (int j = strLine.find('(') + 1; j < (strLine.find(')')); j++)
					id.append(1, strLine.at(j));
				eMgr.AddInput(id);
			}
			else if (strLineUpper.find("OUTPUT") == 0)	 //Samimi
			{
				for (int j = strLine.find('(') + 1; j < (strLine.find(')')); j++)
					id.append(1, strLine.at(j));
				eMgr.AddOutput(id);
			}
			else if (strLine.find('=') != -1)
			{
				int j;
				for (j = 0; j < (strLine.find(' ')); j++)
					id.append(1, strLine.at(j));
				for (j = strLine.find('(') + 1; j < (strLine.find(')')); j++)
					inputs.append(1, strLine.at(j));
				for (j = strLine.find("= ") + 2; j < (strLine.find('(')); j++)
					etype.append(1, strLine.at(j));

				if (etype.find("DFF") == 0)
					eMgr.AddFF(id, "dff", inputs);
				else if (etype.find("NOT") == 0)
					eMgr.AddGate(id, "not", inputs);
				else if (etype.find("AND") == 0)
					eMgr.AddGate(id, "and", inputs);
				else if (etype.find("OR") == 0)
					eMgr.AddGate(id, "or", inputs);
				else if (etype.find("NAND") == 0)
					eMgr.AddGate(id, "nand", inputs);
				else if (etype.find("NOR") == 0)
					eMgr.AddGate(id, "nor", inputs);
				else if (etype.find("XOR") == 0)
					eMgr.AddGate(id, "xor", inputs);
				else if (etype.find("XNOR") == 0)
					eMgr.AddGate(id, "xnor", inputs);
				else if (etype.find("BUF") == 0)
					eMgr.AddGate(id, "buf", inputs);
				else
					eMgr.AddGate(id, "unknown", inputs);
			}
			else
			{
				//	cout << "unknown or blank line\n";
			}
			break;
		}
	} while (!fin.eof());


	//eMgr.WriteVerilog(fout, argv[1]);
	eMgr.WriteVerilog(fout, fnameNoSpaceOrDots);

	fin.close();
	fout.close(); //close file after output-ing
	return 0;
}
